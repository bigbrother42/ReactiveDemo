package com.em.clinicapi.common.db.aspect;

import com.em.clinicapi.common.cache.DbMapperContextHolder;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;

@Aspect
@Configuration
public class MapperAspect {

    /**
     * ロギング機能の対象メソッド実行の定義
     */
    @Pointcut("execution(* com.em.clinicapi.mapper.*.*(..)) || "
            + "execution(* com.em.clinicapi.mapper.*.*.*(..)) || "
            + "execution(* com.em.clinicapi.*.mapper.*.*(..)) || "
            + "execution(* com.em.clinicapi.*.mapper.*.*.*(..))")
    public void defineEntryPoint() {
    }

    @Before("defineEntryPoint()")
    public void before(JoinPoint joinPoint) {
        DbMapperContextHolder.set(joinPoint.getSignature().getDeclaringTypeName());
    }
}
