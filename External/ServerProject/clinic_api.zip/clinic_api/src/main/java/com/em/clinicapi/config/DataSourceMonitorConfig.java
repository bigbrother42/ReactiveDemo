package com.em.clinicapi.config;

import com.em.clinicapi.common.db.DbExecutionMonitor;
import com.em.clinicapi.common.db.StatementsDeregisteringAdvice;
import com.em.clinicapi.common.db.StatementsRegisteringAdvice;
import org.springframework.aop.aspectj.AspectJExpressionPointcutAdvisor;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
//@ComponentScan(basePackages = { "com.em.clinicapi.common.db" })
public class DataSourceMonitorConfig {

    @Bean("statementsMonitor")
    public DbExecutionMonitor getStatementsMonitor() {
        return new DbExecutionMonitor();
    }

    @Bean("statementsRegisteringAdvice")
    public StatementsRegisteringAdvice getStatementsRegisteringAdvice() {
        StatementsRegisteringAdvice advice = new StatementsRegisteringAdvice();
        advice.setStatementsMonitor(getStatementsMonitor());
        return advice;
    }

    @Bean("statementsDeregisteringAdvice")
    public StatementsDeregisteringAdvice getStatementsDeregisteringAdvice() {
        StatementsDeregisteringAdvice advice = new StatementsDeregisteringAdvice();
        advice.setStatementsMonitor(getStatementsMonitor());
        return advice;
    }

    @Bean
    @Qualifier("connectionQualifier")
    public AspectJExpressionPointcutAdvisor statementsRegisteringAdvisor() {
        AspectJExpressionPointcutAdvisor advisor = new AspectJExpressionPointcutAdvisor();
        advisor.setExpression("execution (java.sql.* java.sql.Connection.*(..))");
        advisor.setAdvice(getStatementsRegisteringAdvice());
        advisor.setOrder(100);
        return advisor;
    }

    @Bean
    @Qualifier("connectionQualifier")
    public AspectJExpressionPointcutAdvisor statementsDeregisteringeAdvisor() {
        AspectJExpressionPointcutAdvisor advisor = new AspectJExpressionPointcutAdvisor();
        advisor.setExpression("execution (* java.sql.Connection.close(..))");
        advisor.setAdvice(getStatementsDeregisteringAdvice());
        advisor.setOrder(10);
        return advisor;
    }
}
