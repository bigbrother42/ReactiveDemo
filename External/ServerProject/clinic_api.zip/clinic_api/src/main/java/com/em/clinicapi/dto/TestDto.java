package com.em.clinicapi.dto;

import com.alibaba.fastjson.annotation.JSONField;
import org.springframework.stereotype.Component;

@Component
public class TestDto {

    private boolean testBool;

    private String testStr;

    @JSONField(format = "yyyy-MM-dd'T'HH:mm:ss")
    private java.util.Date testDate;

    public boolean getTestBool() {
        return testBool;
    }

    public void setTestBool(boolean testBool) {
        this.testBool = testBool;
    }

    public String getTestStr() {
        return testStr;
    }

    public void setTestStr(String testStr) {
        this.testStr = testStr;
    }

    public java.util.Date getTestDate() {
        return testDate;
    }

    public void setTestDate(java.util.Date testDate) {
        this.testDate = testDate;
    }

}
