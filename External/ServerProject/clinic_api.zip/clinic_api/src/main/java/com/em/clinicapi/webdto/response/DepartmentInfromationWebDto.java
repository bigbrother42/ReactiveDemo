package com.em.clinicapi.webdto.response;


import com.fasterxml.jackson.annotation.JsonProperty;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : DepartmentInfromationWebDto クラス <br/>
 * 項目：  <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class DepartmentInfromationWebDto {

	/**
	 * 項目： 区分 <br/>
	 * 説明： <br/>
	 *       診療科(医科)Mの施設番号を設定 <br/>
	 */
	@JsonProperty("Code")
	private String code;

	/**
	 * 項目： 診療科名 <br/>
	 * 説明： <br/>
	 *       診療科(医科)Mの診療科名を設定 <br/>
	 */
	@JsonProperty("WholeName")
	private String wholeName;

	/**
	 * 項目： 診療科カナ名 <br/>
	 * 説明： <br/>
	 *       診療科(医科)Mの診療科カナ名を設定 <br/>
	 */
	@JsonProperty("WholeName_inKana")
	private String wholeNameInKana;

	/**
	 * 項目： Name1 <br/>
	 */
	@JsonProperty("Name1")
	private String name1;

	/**
	 * 項目： Name2 <br/>
	 */
	@JsonProperty("Name2")
	private String name2;

	/**
	 * 項目： Name3 <br/>
	 */
	@JsonProperty("Name3")
	private String name3;

	/**
	 * 項目： 基金診療科コード <br/>
	 * 説明： <br/>
	 *       診療科(医科)Mの基金診療科コードを設定 <br/>
	 */
	@JsonProperty("Receipt_Code")
	private String receiptCode;

	/**
	 * 区分を返事します。
	 * @return 区分の値
	 */
	@JsonProperty("Code")
	public String getCode() {
		return code;
	}

	/**
	 * 区分を設定します。
	 * @param code 区分
	 */
	@JsonProperty("Code")
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 診療科名を返事します。
	 * @return 診療科名の値
	 */
	@JsonProperty("WholeName")
	public String getWholeName() {
		return wholeName;
	}

	/**
	 * 診療科名を設定します。
	 * @param wholeName 診療科名
	 */
	@JsonProperty("WholeName")
	public void setWholeName(String wholeName) {
		this.wholeName = wholeName;
	}

	/**
	 * 診療科カナ名を返事します。
	 * @return 診療科カナ名の値
	 */
	@JsonProperty("WholeName_inKana")
	public String getWholeNameInKana() {
		return wholeNameInKana;
	}

	/**
	 * 診療科カナ名を設定します。
	 * @param wholeNameInKana 診療科カナ名
	 */
	@JsonProperty("WholeName_inKana")
	public void setWholeNameInKana(String wholeNameInKana) {
		this.wholeNameInKana = wholeNameInKana;
	}

	/**
	 * Name1を返事します。
	 * @return Name1の値
	 */
	@JsonProperty("Name1")
	public String getName1() {
		return name1;
	}

	/**
	 * Name1を設定します。
	 * @param name1 Name1
	 */
	@JsonProperty("Name1")
	public void setName1(String name1) {
		this.name1 = name1;
	}

	/**
	 * Name2を返事します。
	 * @return Name2の値
	 */
	@JsonProperty("Name2")
	public String getName2() {
		return name2;
	}

	/**
	 * Name2を設定します。
	 * @param name2 Name2
	 */
	@JsonProperty("Name2")
	public void setName2(String name2) {
		this.name2 = name2;
	}

	/**
	 * Name3を返事します。
	 * @return Name3の値
	 */
	@JsonProperty("Name3")
	public String getName3() {
		return name3;
	}

	/**
	 * Name3を設定します。
	 * @param name3 Name3
	 */
	@JsonProperty("Name3")
	public void setName3(String name3) {
		this.name3 = name3;
	}

	/**
	 * 基金診療科コードを返事します。
	 * @return 基金診療科コードの値
	 */
	@JsonProperty("Receipt_Code")
	public String getReceiptCode() {
		return receiptCode;
	}

	/**
	 * 基金診療科コードを設定します。
	 * @param receiptCode 基金診療科コード
	 */
	@JsonProperty("Receipt_Code")
	public void setReceiptCode(String receiptCode) {
		this.receiptCode = receiptCode;
	}

}