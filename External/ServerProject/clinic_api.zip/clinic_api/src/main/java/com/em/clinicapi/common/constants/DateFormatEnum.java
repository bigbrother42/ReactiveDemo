package com.em.clinicapi.common.constants;

public enum DateFormatEnum {

    FormatYYYYMMDD("yyyyMMdd"),
    FormatYYYYMMDDM("yyyy-MM-dd"),
    FormatYYYYMMDDMinus("yyyy-MM-dd"),
    FormatYYYYMMDDSlash("yyyy/MM/dd"),
    FormatYYYYMMDDHHmmss("yyyy/MM/dd HH:mm:ss");

    String value;

    DateFormatEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
