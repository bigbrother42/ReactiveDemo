package com.em.clinicapi.common.constants;

public class RequestConstants {

    public static final String REQUEST_NUMBER = "Request_Number";
}
