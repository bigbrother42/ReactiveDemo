package com.em.clinicapi.common.constants;

public enum ReskeyEnum {

    PatientInfo("PatientInfo");


    private final String key;

    ReskeyEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
