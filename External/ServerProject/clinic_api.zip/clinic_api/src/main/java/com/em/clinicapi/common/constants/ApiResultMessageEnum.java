package com.em.clinicapi.common.constants;

public enum ApiResultMessageEnum {
    Success("処理終了");

    private final String message;

    ApiResultMessageEnum(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
