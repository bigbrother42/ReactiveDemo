package com.em.clinicapi.common.util;

import java.util.Objects;

public class StringUtil {
    public static String EMPTY = "";

    /**
     * 文字列にスペース以外のデータがあるかどうか判断
     *
     * @param string
     * @return
     */
    public static boolean isNullOrEmpty(String string) {
        return string == null || "".equals(string) || "".equals(string.trim());
    }

    public static boolean nonEmpty(String string) {
        return !isNullOrEmpty(string);
    }

    public static Integer checkInt(Integer num) {
        if (num == null) {
            return -1;
        } else {
            return num;
        }
    }

    public static String checkString(String str) {
        if (str == null) {
            return "";
        } else {
            return str;
        }
    }

    public static Integer checkStringToInt(String str) {
        if (str == null) {
            return -1;
        } else {
            return Integer.parseInt(str);
        }
    }

    public static String checkIntToString(Integer num) {
        if (num == null) {
            return "";
        } else {
            return num + "";
        }
    }

    public static Integer checkBooleanToInt(Boolean flag) {
        if (flag == null) {
            return 0;
        } else if (flag) {
            return 1;
        } else {
            return 0;
        }
    }

    public static Boolean checkIntToBoolean(Integer num) {
        if (num == 1) {
            return true;
        } else {
            return false;
        }
    }

    public static Boolean equals(String s1, String s2) {
        return Objects.equals(s1, s2);
    }
}
