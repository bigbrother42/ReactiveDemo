package com.em.clinicapi.common.cache;

import java.util.HashMap;
import java.util.Map;

public class RequestCacheHolder {
    public static final String REQUEST_BODY_XML = "REQUEST_BODY_XML";

    /**
     * キャッシュを保持する。
     * なお、リクエスト内で別スレッドが起動されてもキャッシュの内容は引き継ぐ。
     */
    private static InheritableThreadLocal<Map<String, Object>> CONTEXT = new InheritableThreadLocal<>();

    /**
     * キャッシュを初期化します。
     * 初期化した場合は、利用終了時に適切に clear() を実行するようにしてください。
     */
    public static void initialize() {
        if (CONTEXT.get() == null) {
            CONTEXT.set(new HashMap<>());
        }
    }
    /**
     * キャッシュが初期化されているかどうかをチェックする。
     * 初期化されていない場合、 NullPointerException をスローします。
     */
    private static void checkInitialized() {
        if (CONTEXT.get() == null)
            throw new NullPointerException("Cache was not initialized.");
    }

    /**
     * キャッシュしたいデータを格納します。
     * キャッシュが初期化されていない場合、NullPointerExceptionがスローされます。
     *
     * @see HashMap#put(Object, Object)
     * @param key
     * @param value
     */
    public static void put(String key, Object value) {
        checkInitialized();
        CONTEXT.get().put(key, value);
    }
    /**
     * キャッシュされているデータを取得します。
     * キャッシュが初期化されていない場合、NullPointerExceptionがスローされます。
     *
     * 型が特定可能な場合は、
     *  SomeDto dto = EmRequestCacheHolder.get("some");
     * のように、キャストなしで値を取得することが可能です。
     * （実際に格納されているものが違う型だった場合、 ClassCastException がスローされます）
     *
     * 型が不明な場合は、Object で取得して、型の判断を行ってください。
     *
     * @see HashMap#get(Object);
     * @param key
     * @return 指定されたキーに対するキャッシュが存在しない場合 null を戻します。
     */
    @SuppressWarnings("unchecked")
    public static <E> E get(String key) {
        checkInitialized();
        return (E) (CONTEXT.get().get(key));
    }
    /**
     * 指定されたキーのキャッシュ情報を削除します。
     * キャッシュオブジェクトが初期化されていない場合、NullPointerExceptionがスローされます。
     *
     * 戻り値に関しては {@link #get(String)} を参照してください。
     *
     * @see HashMap#remove(Object);
     * @param key
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <E> E remove(String key) {
        checkInitialized();
        return (E) (CONTEXT.get().remove(key));
    }

    /**
     * キャッシュデータの後始末を行います。
     */
    public static void clear() {
        if (CONTEXT.get() != null) {
            // HashMapの内容をクリアする
            CONTEXT.get().clear();
        }
        CONTEXT.remove();
    }
}
