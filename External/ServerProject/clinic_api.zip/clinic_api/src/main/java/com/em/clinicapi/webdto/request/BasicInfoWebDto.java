package com.em.clinicapi.webdto.request;


import com.em.clinicapi.webdto.base.RequestBase;
import com.fasterxml.jackson.annotation.JsonProperty;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : BasicInfoWebDto クラス <br/>
 * 項目：  <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class BasicInfoWebDto extends RequestBase {

    /**
     * 項目： レクエスト区分 <br/>
     * 説明： <br/>
     *       ”02"(ドクター)、”03"(職員) <br/>
     */
    @JsonProperty("Request_Number")
    private String requestNumber;

    /**
     * 項目： 日付 <br/>
     * 説明： <br/>
     *       書式：yyyy-MM-dd <br/>
     */
    @JsonProperty("Base_Date")
    private String baseDate;

    /**
     * レクエスト区分を返事します。
     * @return レクエスト区分の値
     */
    @JsonProperty("Request_Number")
    public String getRequestNumber() {
        return requestNumber;
    }

    /**
     * レクエスト区分を設定します。
     * @param requestNumber レクエスト区分
     */
    @JsonProperty("Request_Number")
    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    /**
     * 日付を返事します。
     * @return 日付の値
     */
    @JsonProperty("Base_Date")
    public String getBaseDate() {
        return baseDate;
    }

    /**
     * 日付を設定します。
     * @param baseDate 日付
     */
    @JsonProperty("Base_Date")
    public void setBaseDate(String baseDate) {
        this.baseDate = baseDate;
    }

}