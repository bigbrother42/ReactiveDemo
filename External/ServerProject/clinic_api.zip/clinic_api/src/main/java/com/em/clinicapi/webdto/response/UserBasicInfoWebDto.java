package com.em.clinicapi.webdto.response;

import com.em.clinicapi.webdto.base.ResponseBase;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : DoctorBasicInfoWebDto クラス <br/>
 * 項目：  <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class UserBasicInfoWebDto extends ResponseBase {

	/**
	 * 項目： Reskey <br/>
	 */
	@JsonProperty("Reskey")
	private String reskey;

	/**
	 * 項目： Base_Date <br/>
	 * 説明： <br/>
	 *       リクエスト側のBase_Dateを返却 <br/>
	 */
	@JsonProperty("Base_Date")
	private String baseDate;

	/**
	 * 項目： Physician_Information <br/>
	 */
	@JsonProperty("Physician_Information")
	@JacksonXmlElementWrapper(localName = "Physician_Information_List")
	private List<PhysicianInformationWebDto> physicianInformation;

	/**
	 * Reskeyを返事します。
	 * @return Reskeyの値
	 */
	@JsonProperty("Reskey")
	public String getReskey() {
		return reskey;
	}

	/**
	 * Reskeyを設定します。
	 * @param reskey Reskey
	 */
	@JsonProperty("Reskey")
	public void setReskey(String reskey) {
		this.reskey = reskey;
	}

	/**
	 * Base_Dateを返事します。
	 * @return Base_Dateの値
	 */
	@JsonProperty("Base_Date")
	public String getBaseDate() {
		return baseDate;
	}

	/**
	 * Base_Dateを設定します。
	 * @param baseDate Base_Date
	 */
	@JsonProperty("Base_Date")
	public void setBaseDate(String baseDate) {
		this.baseDate = baseDate;
	}

	/**
	 * Physician_Informationを返事します。
	 * @return Physician_Informationの値
	 */
	@JsonProperty("Physician_Information")
	public List<PhysicianInformationWebDto> getPhysicianInformation() {
		return physicianInformation;
	}

	/**
	 * Physician_Informationを設定します。
	 * @param physicianInformation Physician_Information
	 */
	@JsonProperty("Physician_Information")
	public void setPhysicianInformation(List<PhysicianInformationWebDto> physicianInformation) {
		this.physicianInformation = physicianInformation;
	}

}