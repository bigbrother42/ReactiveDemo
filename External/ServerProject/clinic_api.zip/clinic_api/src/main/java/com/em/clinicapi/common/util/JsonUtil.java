package com.em.clinicapi.common.util;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.em.clinicapi.common.exception.JsonParseException;
import com.em.clinicapi.common.constants.*;

public class JsonUtil {

    public static <T> T parseObject(String text, TypeReference<T> type) throws JsonParseException {
        try{
            if (!text.isEmpty()) {
                text = text.replaceAll(RegexConstants.WRAP_AND_ENTER, StringConstants.EMPTY_STRING);

                return (T) JSON.parseObject(text, type);
            }
            else {
                // TODO exception message
                throw new JsonParseException("");
            }
        } catch(Exception e) {
            // TODO exception message
            throw new JsonParseException("");
        }
    }

    public static String toJSONString(Object obj) throws JsonParseException {
        if (obj != null) {
            return (String) JSON.toJSONString(obj);
        }
        else {
            // TODO exception message
            throw new JsonParseException("");
        }
    }
}
