package com.em.clinicapi.webdto.base;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseBase {

    /**
     * レスポンスを返す時点の日付
     */
    @JsonProperty("Information_Date")
    private String informationDate;

    /**
     * レスポンスを返す時点の時刻
     */
    @JsonProperty("Information_Time")
    private String informationTime;

    @JsonProperty("Api_Result")
    private String apiResult;

    @JsonProperty("Api_Result_Message")
    private String apiResultMessage;

    @JsonProperty("Information_Date")
    public String getInformationDate() {
        return informationDate;
    }

    @JsonProperty("Information_Date")
    public void setInformationDate(String informationDate) {
        this.informationDate = informationDate;
    }

    @JsonProperty("Information_Time")
    public String getInformationTime() {
        return informationTime;
    }

    @JsonProperty("Information_Time")
    public void setInformationTime(String informationTime) {
        this.informationTime = informationTime;
    }

    @JsonProperty("Api_Result")
    public String getApiResult() {
        return apiResult;
    }

    @JsonProperty("Api_Result")
    public void setApiResult(String apiResult) {
        this.apiResult = apiResult;
    }

    @JsonProperty("Api_Result_Message")
    public String getApiResultMessage() {
        return apiResultMessage;
    }

    @JsonProperty("Api_Result_Message")
    public void setApiResultMessage(String apiResultMessage) {
        this.apiResultMessage = apiResultMessage;
    }
}
