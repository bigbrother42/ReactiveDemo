package com.em.clinicapi.filter;

import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.Semaphore;

public class ApiRequestLimitFilter extends OncePerRequestFilter {
    private int limitNum;
    private Semaphore semaphore;
    private final Queue<Runnable> taskQueue = new ConcurrentLinkedQueue<>();

    public ApiRequestLimitFilter(int limitNum) {
        this.limitNum = limitNum;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try{
            semaphore = new Semaphore(limitNum);

            if (semaphore.tryAcquire()) {
                filterChain.doFilter(request, response);
            } else {
                taskQueue.add(() -> {
                    try {
                        filterChain.doFilter(request, response);
                    } catch (IOException | ServletException e) {
                        e.printStackTrace();
                    }
                });
            }
        } finally {
            semaphore.release();

            Runnable task;
            while ((task = taskQueue.poll()) != null) {
                try {
                    semaphore.acquire();
                    task.run();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    semaphore.release();
                }
            }
        }
    }
}
