package com.em.clinicapi.controller.base;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.exception.XmlParseException;
import com.em.clinicapi.common.util.XmlUtil;

public class BaseController {
    /*protected String getRequestBodyXML() {
        return RequestCacheHolder.get(RequestCacheHolder.REQUEST_BODY_XML);
    }*/

    /*protected <T> T getRequestBody(Class<T> targetClass) throws XmlParseException {
        String xml = getRequestBodyXML();
        T obj = XmlUtil.parseObject(xml, targetClass);
        return obj;
    }*/
}
