package com.em.clinicapi.common.cache;

import org.springframework.util.Assert;

public class DbMapperContextHolder {

    /**
     * 実際スレッドのセッション情報
     */
    private static ThreadLocal<String> CONTEXT = new ThreadLocal<>();

    /**
     * 実際スレッドのセッション情報を設定する
     *
     * @param mapperName RESTAPIリクエストセッション情報
     */
    public static void set(String mapperName) {
        Assert.hasText(mapperName, "'mapperName' nust not be empty.");
        CONTEXT.set(mapperName);
    }

    /**
     * 実際スレッドのセッション情報を取得する
     *
     * @return 現在のセッション情報オブジェクト
     */
    public static String get() {
        return CONTEXT.get();
    }

    /**
     * 実際スレッドのセッション情報を破棄する
     */
    public static void clear() {
        CONTEXT.remove();
    }

}
