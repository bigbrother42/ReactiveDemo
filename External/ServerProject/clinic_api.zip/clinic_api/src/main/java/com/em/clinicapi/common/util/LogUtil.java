package com.em.clinicapi.common.util;

import com.nimbusds.oauth2.sdk.util.StringUtils;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.PrintWriter;
import java.io.StringWriter;

import static org.apache.logging.log4j.Level.*;

public class LogUtil {
    public static final Logger LOG = LogManager.getLogger(LogUtil.class);

    public static Logger getLogger() {
        return LOG;
    }

    public static Logger getLogger(Object o) {
        return LogManager.getLogger(o.getClass());
    }

    public static Logger getLogger(Class<?> clazz) {
        return LogManager.getLogger(clazz.getName());
    }

    public static Logger getLogger(String s) {
        return LogManager.getLogger(s);
    }

    public static String getStackTrace(Throwable t) {
        String stackTrace = null;
        try (StringWriter stringWriter = new StringWriter()) {
            try (PrintWriter printWriter = new PrintWriter(stringWriter)) {
                t.printStackTrace(printWriter);
                printWriter.flush();
                stringWriter.flush();
                stackTrace = stringWriter.toString();
            } catch (Exception ex) {
                //LOG.error(ex.getMessage(), ex);
            }
        } catch (Exception ex) {
            //LOG.error(ex.getMessage(), ex);
        }
        return stackTrace;
    }

    public static void log(Logger logger, Level level, String format, Object... args) {
        if (logger != null && level != null) {
            if (level.equals(TRACE)) {
                logger.trace(format, args);
            } else if (level.equals(DEBUG)) {
                logger.debug(format, args);
            } else if (level.equals(INFO)) {
                logger.info(format, args);
            } else if (level.equals(WARN)) {
                logger.warn(format, args);
            } else if (level.equals(ERROR)) {
                logger.error(format, args);
            }
        }
    }

    public static Level getLogLevel(Throwable t) {
        Level level = INFO;
        /*if (t.getCause() != null) {
            level = getLogLevel(t.getCause());
        } else if (t instanceof EmMapsAppStatusException) {
            MapsAppStatus status = ((EmMapsAppStatusException) t).getStatus();
            if (status != null) {
                level = status.getLogLevel();
            }
        }*/
        return level;
    }

    public static String getLogMessage(Throwable t) {
        String message = t.getMessage();
        if (StringUtils.isBlank(message)) {
            if (t.getCause() != null) {
                message = getLogMessage(t.getCause());
            }
            if (StringUtils.isBlank(message)) {
                message = t.toString();
            }
        }
        return message;
    }
}
