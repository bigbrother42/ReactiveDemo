package com.em.clinicapi.common.db.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.aop.Advisor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.util.List;

@Aspect
@Component
public class DataSourceMonitorAspect {

    @Autowired
    @Qualifier("connectionQualifier")
    private List<Advisor> advisors;

    @Around(value = "anyDataSource()")
    public Object onNewConnection(final ProceedingJoinPoint pjp) throws Throwable {
        Connection retVal = (Connection) pjp.proceed(pjp.getArgs());
        ProxyFactory proxyFactory = new ProxyFactory(retVal);
        for (Advisor adv : this.advisors) {
            proxyFactory.addAdvisor(adv);
        }
        retVal = (Connection) proxyFactory.getProxy();
        return retVal;
    }

    @Pointcut("execution (* javax.sql.DataSource.getConnection())")
    private void anyDataSource() {

    }
}
