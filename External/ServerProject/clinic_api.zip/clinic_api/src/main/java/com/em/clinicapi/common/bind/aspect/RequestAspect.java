package com.em.clinicapi.common.bind.aspect;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.util.XmlUtil;
import com.em.clinicapi.webdto.base.RequestBase;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.context.annotation.Configuration;

//@Aspect
//@Configuration
public class RequestAspect {

    //@Pointcut("execution(public * com.em.clinicapi.controller.*.*(.., @com.em.clinicapi.common.bind.annotation.XMLWebDto (*), ..))")
    public void pointCut() { }

    //@Around("pointCut()")
    public Object beforeMethodWithCustomParam(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs(); // Get method arguments

        // If controller has only 1 parameter and it is a RequestBase
        // This is the most case scenario
        if (args.length == 1 && args[0] instanceof RequestBase) {
            String xml = RequestCacheHolder.get(RequestCacheHolder.REQUEST_BODY_XML);
            args[0] = XmlUtil.parseObject(xml, args[0].getClass());
        }
        // otherwise find the parameter annotated with @XMLWebDto
        else if (args.length > 1) {
            // todo: find the parameter annotated with @XMLWebDto
            for (int i = 0; i < args.length; i++) {
                Object param = args[i];
                if (param instanceof RequestBase) {
                    String xml = RequestCacheHolder.get(RequestCacheHolder.REQUEST_BODY_XML);
                    args[i] = XmlUtil.parseObject(xml, param.getClass());
                }
            }
        }
        return joinPoint.proceed(args);
    }

}
