package com.em.clinicapi.webdto;

import com.em.clinicapi.webdto.base.RequestBase;

public class ReplicationMCustomWebDto extends RequestBase {

    /** プロパティ customerReplicationId */
    private String customerReplicationId = null;

    /** プロパティ customerReplicationName */
    private String customerReplicationName = null;

    /** プロパティ customerConnectionUrl */
    private String customerConnectionUrl = null;

    /** プロパティ customerDbConnectionUrl */
    private String customerDbConnectionUrl = null;

    /** プロパティ customerDbServerInstanceId */
    private String customerDbServerInstanceId = null;

    /** プロパティ customerDbSchemaName */
    private String customerDbSchemaName = null;

    /** プロパティ customerIsDeleted */
    private boolean customerIsDeleted;

    /** プロパティ groupReplicationId */
    private String groupReplicationId = null;

    /** プロパティ groupReplicationName */
    private String groupReplicationName = null;

    /** プロパティ groupConnectionUrl */
    private String groupConnectionUrl = null;

    /** プロパティ groupDbConnectionUrl */
    private String groupDbConnectionUrl = null;

    /** プロパティ groupDbServerInstanceId */
    private String groupDbServerInstanceId = null;

    /** プロパティ groupDbSchemaName */
    private String groupDbSchemaName = null;

    /** プロパティ groupIsDeleted */
    private boolean groupIsDeleted;
    /**
     * デフォルトのコンストラクタ
     */
    public ReplicationMCustomWebDto() {
        super();
    }

    /**
     * プロパティー：customerReplicationId を返します。
     *
     * @return customerReplicationId
     */
    public String getCustomerReplicationId() {
        return customerReplicationId;
    }

    /**
     * プロパティー：customerReplicationId を設定します。
     *
     * @param customerReplicationId customerReplicationIdを設定。
     */
    public void setCustomerReplicationId(String customerReplicationId) {
        this.customerReplicationId = customerReplicationId;
    }

    /**
     * プロパティー：customerReplicationName を返します。
     *
     * @return customerReplicationName
     */
    public String getCustomerReplicationName() {
        return customerReplicationName;
    }

    /**
     * プロパティー：customerReplicationName を設定します。
     *
     * @param customerReplicationName customerReplicationNameを設定。
     */
    public void setCustomerReplicationName(String customerReplicationName) {
        this.customerReplicationName = customerReplicationName;
    }

    /**
     * プロパティー：connectionUrl を返します。
     *
     * @return customerConnectionUrl
     */
    public String getCustomerConnectionUrl() {
        return customerConnectionUrl;
    }

    /**
     * プロパティー：connectionUrl を設定します。
     *
     * @param customerConnectionUrl connectionUrlを設定。
     */
    public void setCustomerConnectionUrl(String customerConnectionUrl) {
        this.customerConnectionUrl = customerConnectionUrl;
    }

    /**
     * プロパティー：customerDbConnectionUrl を返します。
     *
     * @return customerDbConnectionUrl
     */
    public String getCustomerDbConnectionUrl() {
        return customerDbConnectionUrl;
    }

    /**
     * プロパティー：customerDbConnectionUrl を設定します。
     *
     * @param customerDbConnectionUrl customerDbConnectionUrlを設定。
     */
    public void setCustomerDbConnectionUrl(String customerDbConnectionUrl) {
        this.customerDbConnectionUrl = customerDbConnectionUrl;
    }

    /**
     * プロパティー：customerDbServerInstanceId を返します。
     *
     * @return customerDbServerInstanceId
     */
    public String getCustomerDbServerInstanceId() {
        return customerDbServerInstanceId;
    }

    /**
     * プロパティー：customerDbServerInstanceId を設定します。
     *
     * @param customerDbServerInstanceId customerDbServerInstanceIdを設定。
     */
    public void setCustomerDbServerInstanceId(String customerDbServerInstanceId) {
        this.customerDbServerInstanceId = customerDbServerInstanceId;
    }

    /**
     * プロパティー：customerDbSchemaName を返します。
     *
     * @return customerDbSchemaName
     */
    public String getCustomerDbSchemaName() {
        return customerDbSchemaName;
    }

    /**
     * プロパティー：customerDbSchemaName を設定します。
     *
     * @param customerDbSchemaName customerDbSchemaNameを設定。
     */
    public void setCustomerDbSchemaName(String customerDbSchemaName) {
        this.customerDbSchemaName = customerDbSchemaName;
    }

    /**
     * プロパティー：customerIsDeleted を返します。
     *
     * @return customerIsDeleted
     */
    public boolean getCustomerIsDeleted() {
        return customerIsDeleted;
    }

    /**
     * プロパティー：customerIsDeleted を設定します。
     *
     * @param customerIsDeleted customerIsDeletedを設定。
     */
    public void setCustomerIsDeleted(boolean customerIsDeleted) {
        this.customerIsDeleted = customerIsDeleted;
    }

    /**
     * プロパティー：groupReplicationId を返します。
     *
     * @return groupReplicationId
     */
    public String getGroupReplicationId() {
        return groupReplicationId;
    }

    /**
     * プロパティー：groupReplicationId を設定します。
     *
     * @param groupReplicationId groupReplicationIdを設定。
     */
    public void setGroupReplicationId(String groupReplicationId) {
        this.groupReplicationId = groupReplicationId;
    }

    /**
     * プロパティー：groupReplicationName を返します。
     *
     * @return groupReplicationName
     */
    public String getGroupReplicationName() {
        return groupReplicationName;
    }

    /**
     * プロパティー：groupReplicationName を設定します。
     *
     * @param groupReplicationName groupReplicationNameを設定。
     */
    public void setGroupReplicationName(String groupReplicationName) {
        this.groupReplicationName = groupReplicationName;
    }

    /**
     * プロパティー：connectionUrl を返します。
     *
     * @return groupConnectionUrl
     */
    public String getGroupConnectionUrl() {
        return groupConnectionUrl;
    }

    /**
     * プロパティー：connectionUrl を設定します。
     *
     * @param groupConnectionUrl connectionUrlを設定。
     */
    public void setGroupConnectionUrl(String groupConnectionUrl) {
        this.groupConnectionUrl = groupConnectionUrl;
    }

    /**
     * プロパティー：groupDbConnectionUrl を返します。
     *
     * @return groupDbConnectionUrl
     */
    public String getGroupDbConnectionUrl() {
        return groupDbConnectionUrl;
    }

    /**
     * プロパティー：groupDbConnectionUrl を設定します。
     *
     * @param groupDbConnectionUrl groupDbConnectionUrlを設定。
     */
    public void setGroupDbConnectionUrl(String groupDbConnectionUrl) {
        this.groupDbConnectionUrl = groupDbConnectionUrl;
    }

    /**
     * プロパティー：groupDbServerInstanceId を返します。
     *
     * @return groupDbServerInstanceId
     */
    public String getGroupDbServerInstanceId() {
        return groupDbServerInstanceId;
    }

    /**
     * プロパティー：groupDbServerInstanceId を設定します。
     *
     * @param groupDbServerInstanceId groupDbServerInstanceIdを設定。
     */
    public void setGroupDbServerInstanceId(String groupDbServerInstanceId) {
        this.groupDbServerInstanceId = groupDbServerInstanceId;
    }

    /**
     * プロパティー：groupDbSchemaName を返します。
     *
     * @return groupDbSchemaName
     */
    public String getGroupDbSchemaName() {
        return groupDbSchemaName;
    }

    /**
     * プロパティー：groupDbSchemaName を設定します。
     *
     * @param groupDbSchemaName groupDbSchemaNameを設定。
     */
    public void setGroupDbSchemaName(String groupDbSchemaName) {
        this.groupDbSchemaName = groupDbSchemaName;
    }

    /**
     * プロパティー：groupIsDeleted を返します。
     *
     * @return groupIsDeleted
     */
    public boolean getGroupIsDeleted() {
        return groupIsDeleted;
    }

    /**
     * プロパティー：groupIsDeleted を設定します。
     *
     * @param groupIsDeleted groupIsDeletedを設定。
     */
    public void setGroupIsDeleted(boolean groupIsDeleted) {
        this.groupIsDeleted = groupIsDeleted;
    }
}
