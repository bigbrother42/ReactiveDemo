package com.em.clinicapi.common.exception;

public class XmlParseException extends Exception {

    public XmlParseException(String message) {
        super(message);
    }

    public XmlParseException(String message, Throwable cause) {
        super(message, cause);
    }
}
