package com.em.clinicapi.logic;

import com.em.clinicapi.webdto.AuditTrailWebDto;
import com.em.clinicapi.mapper.AuditTrailMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

@Component
public class AuditTrailLogic {

    @Autowired
    private AuditTrailMapper mapper;

    @Retryable(value = { Exception.class }, maxAttempts = 10, backoff = @Backoff(multiplier = 2.3, maxDelay = 10000))
    public int createAuditTrail(AuditTrailWebDto request) {
        request.setSousaSeq(0);
        return mapper.insertAuditTrailDto(request);
    }
}
