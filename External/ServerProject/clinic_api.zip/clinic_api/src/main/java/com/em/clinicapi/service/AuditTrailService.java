package com.em.clinicapi.service;

import com.em.clinicapi.common.util.DateUtil;
import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.webdto.AuditTrailWebDto;
import com.em.clinicapi.logic.AuditTrailLogic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AuditTrailService {

    @Autowired
    private AuditTrailLogic logic;

    @Transactional
    public int createAuditTrail(int customerSeq, String terminalId, String screenName, String sousaContent) {
        AuditTrailWebDto request = new AuditTrailWebDto();

        //TODO
        int userSeq = 99;

        if (customerSeq != 0 && !StringUtil.isNullOrEmpty(terminalId) && userSeq != 0) {
            request.setCustomerSeq(customerSeq);
            request.setTerminalId(terminalId);
            request.setUserSeq(userSeq);
            request.setScreenName(screenName);
            request.setSousaContent(sousaContent);
            request.setSousaAt(DateUtil.currentTimestamp());
            request.setCreatedBy(userSeq);
            request.setUpdatedBy(userSeq);

            return createAuditTrail(request);
        }

        return 0;
    }

    @Transactional
    public int createAuditTrail(AuditTrailWebDto request) {
        try {
            return logic.createAuditTrail(request);
        } catch (Exception ex) {
            LogUtil.getLogger(this).error(ex.getMessage(), ex);
            return 0;
        }
    }
}
