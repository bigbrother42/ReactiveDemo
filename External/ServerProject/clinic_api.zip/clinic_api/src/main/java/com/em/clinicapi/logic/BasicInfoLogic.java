package com.em.clinicapi.logic;

import com.em.clinicapi.common.constants.ApiResultEnum;
import com.em.clinicapi.common.constants.ApiResultMessageEnum;
import com.em.clinicapi.common.constants.ReskeyEnum;
import com.em.clinicapi.common.util.WebDtoUtil;
import com.em.clinicapi.mapper.BasicInfoMapper;
import com.em.clinicapi.webdto.request.BasicInfoWebDto;
import com.em.clinicapi.webdto.response.DepartmentBasicInfoWebDto;
import com.em.clinicapi.webdto.response.DepartmentInfromationWebDto;
import com.em.clinicapi.webdto.response.UserBasicInfoWebDto;
import com.em.clinicapi.webdto.response.PhysicianInformationWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
public class BasicInfoLogic {

    @Autowired
    BasicInfoMapper basicInfoMapper;

    /**
     * アカウント情報取得(医師)
     * @param dto
     * @return
     */
    public UserBasicInfoWebDto getDoctorBasicInfo(BasicInfoWebDto dto) {
        List<PhysicianInformationWebDto> physicianInformationWebDtos = basicInfoMapper.selectDoctorBasicInfo();
        UserBasicInfoWebDto doctorBasicInfoWebDto = new UserBasicInfoWebDto();

        WebDtoUtil.setResponseBase(doctorBasicInfoWebDto, ApiResultEnum.Success, ApiResultMessageEnum.Success);

        doctorBasicInfoWebDto.setReskey(ReskeyEnum.PatientInfo.getKey());
        doctorBasicInfoWebDto.setBaseDate(dto.getBaseDate());
        doctorBasicInfoWebDto.setPhysicianInformation(physicianInformationWebDtos);

        return doctorBasicInfoWebDto;
    }

    /**
     * アカウント情報取得(職員)
     * @param dto
     * @return
     */
    public UserBasicInfoWebDto getStaffBasicInfo(BasicInfoWebDto dto) {
        List<PhysicianInformationWebDto> physicianInformationWebDtos = basicInfoMapper.selectStaffBasicInfo();
        UserBasicInfoWebDto doctorBasicInfoWebDto = new UserBasicInfoWebDto();

        WebDtoUtil.setResponseBase(doctorBasicInfoWebDto, ApiResultEnum.Success, ApiResultMessageEnum.Success);

        doctorBasicInfoWebDto.setReskey(ReskeyEnum.PatientInfo.getKey());
        doctorBasicInfoWebDto.setBaseDate(dto.getBaseDate());
        doctorBasicInfoWebDto.setPhysicianInformation(physicianInformationWebDtos);

        return doctorBasicInfoWebDto;
    }

    /**
     * 診療科情報取得
     * @param dto
     * @return
     */
    public DepartmentBasicInfoWebDto getDepartmentBasicInfo(BasicInfoWebDto dto) {
        List<DepartmentInfromationWebDto> departmentInfromationWebDtos = basicInfoMapper.selectDepartmentBasicInfo(dto);
        DepartmentBasicInfoWebDto departmentBasicInfoWebDto = new DepartmentBasicInfoWebDto();

        WebDtoUtil.setResponseBase(departmentBasicInfoWebDto, ApiResultEnum.Success, ApiResultMessageEnum.Success);

        departmentBasicInfoWebDto.setReskey(ReskeyEnum.PatientInfo.getKey());
        departmentBasicInfoWebDto.setBaseDate(dto.getBaseDate());
        departmentBasicInfoWebDto.setDepartmentInfromation(departmentInfromationWebDtos);

        return departmentBasicInfoWebDto;
    }

}
