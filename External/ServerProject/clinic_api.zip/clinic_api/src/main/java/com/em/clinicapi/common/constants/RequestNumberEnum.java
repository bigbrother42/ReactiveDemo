package com.em.clinicapi.common.constants;

public enum RequestNumberEnum {
    Shinryouka("01", "診療科"),
    Doctor("02", "ドクター"),
    Staff("03", "職員"),
    InstitutionInfo("04", "医療機関基本情報");

    private final String code;
    private final String description;

    RequestNumberEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
