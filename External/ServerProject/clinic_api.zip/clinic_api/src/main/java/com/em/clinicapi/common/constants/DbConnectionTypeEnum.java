package com.em.clinicapi.common.constants;

public enum DbConnectionTypeEnum {
    KIBAN,
    GROUP,
    CUSTOMER,
    COMMON
}
