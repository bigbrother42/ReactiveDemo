package com.em.clinicapi.common.util;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public class ListUtil {

    public static boolean isEmpty(final List<?> target) {
        return target == null || target.isEmpty();
    }

    public static boolean isEmpty(final Collection<?> target) {
        return target == null || target.isEmpty();
    }

    public static boolean isEmpty(final Iterable<?> target) {
        return target == null || target.iterator().hasNext();
    }

    public static boolean isEmpty(final Map<?, ?> target) {
        return target == null || target.isEmpty();
    }

    public static boolean nonEmpty(final List<?> target) {
        return !isEmpty(target);
    }

    public static boolean nonEmpty(final Collection<?> target) {
        return !isEmpty(target);
    }

    public static boolean nonEmpty(final Iterable<?> target) {
        return !isEmpty(target);
    }

    public static boolean nonEmpty(final Map<?, ?> target) {
        return !isEmpty(target);
    }
}
