package com.em.clinicapi.common.db.interceptors;

import com.em.clinicapi.common.cache.ServerReplicationManager;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import org.springframework.beans.BeanUtils;

import java.beans.IntrospectionException;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

public class EmMyBatisInterceptorBase {

    public static final int PARAMETER_INDEX_PARAMETER = 1;
    public static final String SQL_PARAMETER_HOLDER_GROUP_SCHEMA = "grp";
    public static final String SQL_PARAMETER_HOLDER_CUSTOMER_SCHEMA = "cst";
    public static final String SQL_PARAMETER_HOLDER_COMMON_SCHEMA = "cmn";

    public static final String SQL_PARAMETER_HOLDER_GROUP_SEQ = "SESSION_GROUP_SEQ";
    public static final String SQL_PARAMETER_HOLDER_CUSTOMER_SEQ = "SESSION_CUSTOMER_SEQ";
    public static final String SQL_PARAMETER_HOLDER_USER_SEQ = "SESSION_USER_SEQ";
    public static final String SQL_PARAMETER_COMMON_SCHEMA = "common";
    public static final int SQL_PARAMETER_DEFAULT_SEQ = 0;

    /**
     * DBとの関連付けで無視するフィールド。
     */
    public static final String IGNORE_FIELD_serialVersionUID = "serialVersionUID";

    /**
     * SQL用のセッション情報Mapを作成
     *
     * @return セッション情報Mapオブジェクト
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Map createSessionParameterMap() {

        Map parameterMap = new HashMap<String, Object>();

        String groupSchema = SQL_PARAMETER_COMMON_SCHEMA;
        String customerSchema = SQL_PARAMETER_COMMON_SCHEMA;
        String commonSchema = SQL_PARAMETER_COMMON_SCHEMA;

        int groupSeq = 0;
        int customerSeq = 0;
        //int userSeq = SQL_PARAMETER_DEFAULT_SEQ;

        // グループのレプリケーション情報からグループスキーマ名を設定
        ReplicationMWebDto groupReplication = ServerReplicationManager.getCurrentGroupReplication();
        if (groupReplication != null) {
            groupSchema = groupReplication.getDbSchemaName();
            groupSeq = groupReplication.getGroupId();
        }

        // グループのレプリケーション情報からグループスキーマ名を設定
        ReplicationMWebDto customerReplication = ServerReplicationManager.getCurrentCustomerReplication();
        if (customerReplication != null) {
            customerSchema = customerReplication.getDbSchemaName();
            customerSeq = groupReplication.getCustomerId();
        }

//        EmUserSessionUtil util = EmUserSessionUtil.getInstance();
//        if (util != null) {
//            SessionInfo session = EmUserSessionUtil.getInstance().getSessionInfo();
//            if (session != null) {
//                // セッション情報からグループSEQを取得
//                if (session.getGroup() != null) {
//                    groupSeq = session.getGroup().getGroupSeq();
//                }
//                // セッション情報から顧客SEQを取得
//                if (session.getCustomer() != null) {
//                    customerSeq = session.getCustomer().getCustomerSeq();
//                }
//                // セッション情報からユーザSEQを取得
//                if (session.getUser() != null) {
//                    userSeq = session.getUser().getUserSeq();
//                }
//            }
//        }

        parameterMap.putIfAbsent(SQL_PARAMETER_HOLDER_GROUP_SCHEMA, addQuotes(groupSchema));
        parameterMap.putIfAbsent(SQL_PARAMETER_HOLDER_CUSTOMER_SCHEMA, addQuotes(customerSchema));
        parameterMap.putIfAbsent(SQL_PARAMETER_HOLDER_COMMON_SCHEMA, addQuotes(commonSchema));

        parameterMap.putIfAbsent(SQL_PARAMETER_HOLDER_GROUP_SEQ, groupSeq);
        parameterMap.putIfAbsent(SQL_PARAMETER_HOLDER_CUSTOMER_SEQ, customerSeq);
        //parameterMap.putIfAbsent(SQL_PARAMETER_HOLDER_USER_SEQ, userSeq);

        return parameterMap;
    }

    /**
     * セッション情報含むSQL用パラメータMapを作成<br>
     * SQL用パラメータにMapオブジェクトが存在する場合、Mapを更新する。<br>
     * SQL用パラメータにDbDtoBaseのオブジェクトが存在する場合、Mapを作成する。<br>
     * SQL用パラメータにその他のオブジェクトが存在する場合、Mapを作成する。<br>
     *
     * @param args MyBatisのInvocationの引数データ配列
     * @return セッション情報を含むSQL用パラメータMapオブジェクト
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public Map createSqlParameterMap(Object[] args) {
        // パラメータコレクションを作成
        Map parameterMap = new HashMap<String, Object>();
        if (args[PARAMETER_INDEX_PARAMETER] != null) {
            if (args[PARAMETER_INDEX_PARAMETER] instanceof Map) {
                parameterMap = (Map) args[PARAMETER_INDEX_PARAMETER];
            } else if (BeanUtils.isSimpleValueType(args[PARAMETER_INDEX_PARAMETER].getClass())) {
                parameterMap.putIfAbsent("arg0", args[PARAMETER_INDEX_PARAMETER]);
            } else {
                List<Field> fields = new ArrayList<>();
                fields = getAllFields(fields, args[PARAMETER_INDEX_PARAMETER].getClass());
                for (Field field : fields) {
                    Object fieldValue = null;
                    String fieldName = field.getName();

                    // Serializable固有のプロパティはDBデータとの紐づけは存在しないので、スキップする。
                    if (IGNORE_FIELD_serialVersionUID.equals(fieldName)) {
                        continue;
                    }

                    try {
                        fieldValue = new PropertyDescriptor(fieldName, args[PARAMETER_INDEX_PARAMETER].getClass())
                                .getReadMethod().invoke(args[PARAMETER_INDEX_PARAMETER]);
                    } catch (IllegalArgumentException ex) {
                        //EmLogUtil.getLogger(this).error(ex.getMessage(), ex);
                    } catch (IllegalAccessException ex) {
                        //EmLogUtil.getLogger(this).error(ex.getMessage(), ex);
                    } catch (InvocationTargetException ex) {
                        //EmLogUtil.getLogger(this).error(ex.getMessage(), ex);
                    } catch (IntrospectionException ex) {
                        //EmLogUtil.getLogger(this).debug(ex.getMessage(), ex);
                    } catch (Exception ex) {
                        //EmLogUtil.getLogger(this).debug(ex.getMessage(), ex);
                    }
                    parameterMap.putIfAbsent(field.getName(), fieldValue);
                }
            }
        }
        // パラメータコレクションに追加情報
        Map sessionParameterMap = createSessionParameterMap();
        parameterMap.putAll(sessionParameterMap);
        return parameterMap;
    }

    private List<Field> getAllFields(List<Field> fields, Class<?> type) {
        fields.addAll(Arrays.asList(type.getDeclaredFields()));
        if (type.getSuperclass() != null) {
            getAllFields(fields, type.getSuperclass());
        }
        return fields;
    }

    private String addQuotes(String s) {
        StringBuilder sb = new StringBuilder();
        sb.append('"');
        sb.append(s);
        sb.append('"');
        return sb.toString();
    }
}
