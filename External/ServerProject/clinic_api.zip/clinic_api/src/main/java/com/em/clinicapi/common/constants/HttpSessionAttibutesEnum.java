package com.em.clinicapi.common.constants;

public enum HttpSessionAttibutesEnum {

    WebToken("WEB_TOKEN"),
    GroupReplication("GROUP_REPLICATION"),
    CustomerReplication("CUSTOMER_REPLICATION"),
    SourceApplication("SOURCE_APPLICATION"),
    UserAuthInfo("USER_AUTH_INFO"),
    SessionInfo("SESSION_INFO"),
    CustomerHonbuOption("CUSTOMER_HONBU_OPTION"),
    CustomerAcl("CUSTOMER_ACL"),
    SessionGuid("SESSION_GUID"),
    OemInfo("OEM_INFO"),
    OemAcl("OEM_ACL"),
    ;

    String value;

    HttpSessionAttibutesEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
