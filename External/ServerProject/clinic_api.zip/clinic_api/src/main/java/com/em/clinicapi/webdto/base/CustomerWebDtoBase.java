package com.em.clinicapi.webdto.base;

import com.em.clinicapi.webdto.base.WebDtoBase;

public class CustomerWebDtoBase extends WebDtoBase {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** プロパティ customerSeq */
    private int customerSeq = 0;

    /**
     * プロパティー：customerSeq を返します。
     *
     * @return customerSeq
     */
    public int getCustomerSeq() {
        return this.customerSeq;
    }

    /**
     * プロパティー：customerSeq を設定します。
     *
     * @param customerSeq
     */
    public void setCustomerSeq(int customerSeq) {
        this.customerSeq = customerSeq;
    }

}
