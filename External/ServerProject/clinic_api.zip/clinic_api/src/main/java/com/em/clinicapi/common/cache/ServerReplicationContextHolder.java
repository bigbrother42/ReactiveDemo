package com.em.clinicapi.common.cache;

import com.em.clinicapi.webdto.ReplicationMWebDto;
import org.springframework.util.Assert;

public class ServerReplicationContextHolder {

    /**
     * 実際スレッドのセッション情報
     */
    private static ThreadLocal<ReplicationMWebDto> GROUP_CONTEXT = new ThreadLocal<>();
    private static ThreadLocal<ReplicationMWebDto> CUSTOMER_CONTEXT = new ThreadLocal<>();

    /**
     * 実際スレッドのセッション情報を設定する
     *
     * @param replication RESTAPIリクエストセッション情報
     */
    public static void setGroup(ReplicationMWebDto replication) {
        Assert.notNull(replication, "Group replication cannot be null.");
        GROUP_CONTEXT.set(replication);
    }

    /**
     * 実際スレッドのセッション情報を取得する
     *
     * @return 現在のセッション情報オブジェクト
     */
    public static ReplicationMWebDto getGroup() {
        return GROUP_CONTEXT.get();
    }

    /**
     * 実際スレッドのセッション情報を設定する
     *
     * @param replication RESTAPIリクエストセッション情報
     */
    public static void setCustomer(ReplicationMWebDto replication) {
        Assert.notNull(replication, "Customer replication cannot be null.");
        CUSTOMER_CONTEXT.set(replication);
    }

    /**
     * 実際スレッドのセッション情報を取得する
     *
     * @return 現在のセッション情報オブジェクト
     */
    public static ReplicationMWebDto getCustomer() {
        return CUSTOMER_CONTEXT.get();
    }

    /**
     * 実際スレッドのセッション情報を破棄する
     */
    public static void clearGroup() {
        GROUP_CONTEXT.remove();
    }

    /**
     * 実際スレッドのセッション情報を破棄する
     */
    public static void clearCustomer() {
        CUSTOMER_CONTEXT.remove();
    }

    /**
     * 実際スレッドのセッション情報を破棄する
     */
    public static void clearAll() {
        GROUP_CONTEXT.remove();
        CUSTOMER_CONTEXT.remove();
    }
}
