package com.em.clinicapi.config;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;

public class CustomClientRegistrationRepository implements ClientRegistrationRepository {

    private final PasswordEncoder passwordEncoder;

    public CustomClientRegistrationRepository(PasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public ClientRegistration findByRegistrationId(String registrationId) {
        return ClientRegistration
                .withRegistrationId("custom")
                .clientId("custom-client-id")
                .clientSecret(passwordEncoder.encode("custom-client-secret"))
                .clientAuthenticationMethod(ClientAuthenticationMethod.BASIC)
                .authorizationGrantType(AuthorizationGrantType.AUTHORIZATION_CODE)
                .redirectUriTemplate("{baseUrl}/login/oauth2/code/{registrationId}")
                .scope("read:user")
                .build();
    }
}
