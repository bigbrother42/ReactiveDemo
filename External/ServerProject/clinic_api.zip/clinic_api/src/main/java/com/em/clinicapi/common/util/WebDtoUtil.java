package com.em.clinicapi.common.util;

import com.em.clinicapi.common.constants.ApiResultEnum;
import com.em.clinicapi.common.constants.ApiResultMessageEnum;
import com.em.clinicapi.webdto.base.ResponseBase;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class WebDtoUtil {

    public static void setResponseBase(ResponseBase responseBase, ApiResultEnum apiResult, ApiResultMessageEnum apiResultMessage) {
       responseBase.setInformationDate( LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) );
       responseBase.setInformationTime( LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) );
       responseBase.setApiResult(apiResult.getCode());
       responseBase.setApiResultMessage(apiResultMessage.getMessage());
    }
}
