package com.em.clinicapi.filter;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.cache.ServerReplicationManager;
import com.em.clinicapi.common.constants.HttpSessionAttibutesEnum;
import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.exception.XmlParseException;
import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.common.util.XmlUtil;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import com.em.clinicapi.webdto.base.RequestBase;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.Logger;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class ServerReplicationRoutingFilter extends GenericFilterBean {

    private static final Logger LOG = LogUtil.getLogger(ServerReplicationRoutingFilter.class);

    public static final String HEADER_GROUP_REPLICATION_ID = "X-Em-Group-Replication-Id";
    public static final String HEADER_GROUP_CONNECTION_URL = "X-Em-Group-Connection-Url";
    public static final String HEADER_GROUP_DB_CONNECTION_URL = "X-Em-Group-Db-Connection-Url";
    public static final String HEADER_GROUP_DB_SERVER_INSTANCE_ID = "X-Em-Group-Db-Server-Instance-Id";
    public static final String HEADER_GROUP_DB_SCHEMA_NAME = "X-Em-Group-Db-Schema-Name";

    public static final String HEADER_CUSTOMER_REPLICATION_ID = "X-Em-Customer-Replication-Id";
    public static final String HEADER_CUSTOMER_CONNECTION_URL = "X-Em-Customer-Connection-Url";
    public static final String HEADER_CUSTOMER_DB_CONNECTION_URL = "X-Em-Customer-Db-Connection-Url";
    public static final String HEADER_CUSTOMER_DB_SERVER_INSTANCE_ID = "X-Em-Customer-Db-Server-Instance-Id";
    public static final String HEADER_CUSTOMER_DB_SCHEMA_NAME = "X-Em-Customer-Db-Schema-Name";

    public static final String GROUP_ID = "EM_GROUP_ID";

    public static final String CUSTOMER_ID = "EM_CUSTOMER_ID";

    /*
     * (non-Javadoc)
     *
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     * javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        try {
            LOG.debug("Replication Information Processing Filter START");
            if (request instanceof HttpServletRequest) {
                loadReplication((HttpServletRequest) request);
            }
            chain.doFilter(request, response);
        } finally {
            LOG.debug("Replication Information Processing Filter END");
        }
    }

    private void loadReplication(HttpServletRequest request) throws IOException {
        Map<String, Integer> headerMap = new HashMap<>();
        //String type = request.getHeader("Content-Type");
        headerMap = getHeaders(request);

        Integer groupId = null;
        Integer customerId = null;
        if(headerMap.containsKey(GROUP_ID)) {
            groupId = headerMap.get(GROUP_ID);
        }
        if(headerMap.containsKey(CUSTOMER_ID)) {
            customerId = headerMap.get(CUSTOMER_ID);
        }

        ServerReplicationManager.switchReplicationByGroupIdCustomerId(groupId, customerId);

//        ServerReplicationManager.clearCurrentAllReplication();
//        boolean isGroupReplicationDataLoaded = false;
//        boolean isCustomerReplicationDataLoaded = false;
//
//        ReplicationMWebDto groupReplication = getGroupReplication(headerMap);
//        ReplicationMWebDto customerReplication = getCustomerReplication(headerMap);
//
//        if (groupReplication != null && StringUtil.nonEmpty(groupReplication.getReplicationId())) {
//            isGroupReplicationDataLoaded = true;
//        } else {
//            HttpSession session = request.getSession(false);
//            if (session != null) {
//                groupReplication = (ReplicationMWebDto) session.getAttribute(HttpSessionAttibutesEnum.GroupReplication.getValue());
//                if (groupReplication != null) {
//                    isGroupReplicationDataLoaded = true;
//                }
//            }
//        }
//
//        ServerReplicationManager.switchReplication(groupReplication, null);
//
//        if (customerReplication != null && StringUtil.nonEmpty(customerReplication.getReplicationId())) {
//            isCustomerReplicationDataLoaded = true;
//        } else {
//            HttpSession session = request.getSession(false);
//            if (session != null) {
//                customerReplication = (ReplicationMWebDto) session.getAttribute(HttpSessionAttibutesEnum.CustomerReplication.getValue());
//                if (customerReplication != null) {
//                    isCustomerReplicationDataLoaded = true;
//                }
//            }
//        }
//
//        ServerReplicationManager.switchReplication(groupReplication, customerReplication);
//
//        if (!isGroupReplicationDataLoaded) {
//            LOG.debug("No group replication information was detected.");
//        }
//
//        if (!isCustomerReplicationDataLoaded) {
//            LOG.debug("No customer replication information was detected.");
//        }
    }

    private Map<String, Integer> getHeaders(HttpServletRequest request) throws IOException {
        Map<String, Integer> headerMap = new HashMap<String, Integer>();
        StringBuilder requestBody = new StringBuilder();
        BufferedReader bufferedReader = null;

        try {
            ServletInputStream servletInputStream = request.getInputStream();
            if (servletInputStream != null) {
                bufferedReader = new BufferedReader(new InputStreamReader(servletInputStream));
                String line = StringConstants.EMPTY_STRING;
                while ((line = bufferedReader.readLine()) != null) {
                    requestBody.append(line);
                }

                String requestBodyStr = requestBody.toString();
                RequestBase requestBodyObj = XmlUtil.parseObject(requestBodyStr, RequestBase.class);
                if (requestBodyObj != null) {
                    RequestCacheHolder.put(RequestCacheHolder.REQUEST_BODY_XML, requestBodyStr);
                    headerMap.put(GROUP_ID, requestBodyObj.getGroupId());
                    headerMap.put(CUSTOMER_ID, requestBodyObj.getCustomerId());
                }
            }
        } catch(XmlParseException ex) {
            LOG.error(ex.getStackTrace(), ex);
        }

        return headerMap;
    }

    private ReplicationMWebDto getGroupReplication(Map<String, String> headerMap) {
        ReplicationMWebDto replicationInfo = new ReplicationMWebDto();

//        headerMap.keySet().forEach(key -> {
//            if (key.equalsIgnoreCase(HEADER_GROUP_REPLICATION_ID)) {
//                replicationInfo.setReplicationId(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_GROUP_CONNECTION_URL)) {
//                replicationInfo.setConnectionUrl(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_GROUP_DB_CONNECTION_URL)) {
//                replicationInfo.setDbConnectionUrl(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_GROUP_DB_SERVER_INSTANCE_ID)) {
//                replicationInfo.setDbServerInstanceId(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_GROUP_DB_SCHEMA_NAME)) {
//                replicationInfo.setDbSchemaName(headerMap.get(key));
//            }
//        });

        return !StringUtils.isAllEmpty(replicationInfo.getReplicationId()) ? replicationInfo : null;
    }

    private ReplicationMWebDto getCustomerReplication(Map<String, String> headerMap) {
        ReplicationMWebDto replicationInfo = new ReplicationMWebDto();

//        headerMap.keySet().forEach(key -> {
//            if (key.equalsIgnoreCase(HEADER_CUSTOMER_REPLICATION_ID)) {
//                replicationInfo.setReplicationId(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_CUSTOMER_CONNECTION_URL)) {
//                replicationInfo.setConnectionUrl(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_CUSTOMER_DB_CONNECTION_URL)) {
//                replicationInfo.setDbConnectionUrl(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_CUSTOMER_DB_SERVER_INSTANCE_ID)) {
//                replicationInfo.setDbServerInstanceId(headerMap.get(key));
//            }
//            if (key.equalsIgnoreCase(HEADER_CUSTOMER_DB_SCHEMA_NAME)) {
//                replicationInfo.setDbSchemaName(headerMap.get(key));
//            }
//        });

        return !StringUtils.isAllEmpty(replicationInfo.getReplicationId()) ? replicationInfo : null;
    }
}
