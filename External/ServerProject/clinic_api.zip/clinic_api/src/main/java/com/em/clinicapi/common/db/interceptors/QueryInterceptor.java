package com.em.clinicapi.common.db.interceptors;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.util.Properties;

@Intercepts({ @Signature(type = Executor.class, method = "query", args = { MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class }) })
public class QueryInterceptor extends EmMyBatisInterceptorBase implements Interceptor {

    /*
     * (non-Javadoc)
     *
     * @see org.apache.ibatis.plugin.Interceptor#intercept(org.apache.ibatis.plugin.
     * Invocation)
     */
    public Object intercept(Invocation invocation) throws Throwable {
        // 引数の配列を取得
        Object[] args = invocation.getArgs();
        // パラメータを上書き
        args[PARAMETER_INDEX_PARAMETER] = createSqlParameterMap(args);
        // 新Invocationオブジェクトを作成（パラメータ上書き済み）
        Invocation overrideInvocation = new Invocation(invocation.getTarget(), invocation.getMethod(), args);
        // 新Invocationオブジェクトを実行
        return overrideInvocation.proceed();
    }

    /*
     * (non-Javadoc)
     *
     * @see org.apache.ibatis.plugin.Interceptor#plugin(java.lang.Object)
     */
    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    /*
     * (non-Javadoc)
     *
     * @see org.apache.ibatis.plugin.Interceptor#setProperties(java.util.Properties)
     */
    public void setProperties(Properties properties) {
    }
}
