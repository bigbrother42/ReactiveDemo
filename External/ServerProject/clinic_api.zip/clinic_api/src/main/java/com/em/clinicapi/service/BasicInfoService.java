package com.em.clinicapi.service;

import com.em.clinicapi.logic.BasicInfoLogic;
import com.em.clinicapi.webdto.request.BasicInfoWebDto;
import com.em.clinicapi.webdto.response.DepartmentBasicInfoWebDto;
import com.em.clinicapi.webdto.response.UserBasicInfoWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BasicInfoService {

    @Autowired
    private BasicInfoLogic basicInfoLogic;

    /**
     * アカウント情報取得(医師)
     * @param dto
     * @return
     */
    public UserBasicInfoWebDto getDoctorBasicInfo(BasicInfoWebDto dto) {
        return basicInfoLogic.getDoctorBasicInfo(dto);
    }

    /**
     * アカウント情報取得(職員)
     * @param dto
     * @return
     */
    public UserBasicInfoWebDto getStaffBasicInfo(BasicInfoWebDto dto) {
        return basicInfoLogic.getStaffBasicInfo(dto);
    }

    /**
     * 診療科情報取得
     * @param dto
     * @return
     */
    public DepartmentBasicInfoWebDto getDepartmentBasicInfo(BasicInfoWebDto dto) {
        return basicInfoLogic.getDepartmentBasicInfo(dto);
    }
}
