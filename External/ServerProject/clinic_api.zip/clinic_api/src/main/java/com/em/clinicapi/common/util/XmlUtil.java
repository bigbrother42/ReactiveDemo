package com.em.clinicapi.common.util;

import com.em.clinicapi.common.constants.RegexConstants;
import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.exception.XmlParseException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class XmlUtil {

    public static <T> T parseObject(String text, Class<T> targetClass) throws XmlParseException {
        try{
            if (!text.isEmpty()) {
                text = text.replaceAll(RegexConstants.WRAP_AND_ENTER, StringConstants.EMPTY_STRING);

                XmlMapper xmlMapper = new XmlMapper();

                return xmlMapper.readValue(text, targetClass);
            }
            else {
                // TODO exception message
                throw new XmlParseException("xml is empty!");
            }
        } catch(Exception e) {
            // TODO exception message
            throw new XmlParseException("", e);
        }
    }
}
