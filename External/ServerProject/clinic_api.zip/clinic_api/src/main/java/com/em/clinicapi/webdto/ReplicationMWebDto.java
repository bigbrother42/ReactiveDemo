package com.em.clinicapi.webdto;

import com.em.clinicapi.webdto.base.RequestBase;
import com.em.clinicapi.webdto.base.WebDtoBase;

public class ReplicationMWebDto extends RequestBase {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** プロパティ replicationId */
    private String replicationId = null;

    /** プロパティ replicationName */
    private String replicationName = null;

    /** プロパティ connectionUrl */
    private String connectionUrl = null;

    /** プロパティ dbConnectionUrl */
    private String dbConnectionUrl = null;

    /** プロパティ dbServerInstanceId */
    private String dbServerInstanceId = null;

    /** プロパティ dbSchemaName */
    private String dbSchemaName = null;

    /** プロパティ isDeleted */
    private boolean isDeleted;

    /**
     * デフォルトのコンストラクタ
     */
    public ReplicationMWebDto() {
        super();
    }

    /**
     * プロパティー：replicationId を返します。
     *
     * @return replicationId
     */
    public String getReplicationId() {
        return replicationId;
    }

    /**
     * プロパティー：replicationId を設定します。
     *
     * @param replicationId replicationIdを設定。
     */
    public void setReplicationId(String replicationId) {
        this.replicationId = replicationId;
    }

    /**
     * プロパティー：replicationName を返します。
     *
     * @return replicationName
     */
    public String getReplicationName() {
        return replicationName;
    }

    /**
     * プロパティー：replicationName を設定します。
     *
     * @param replicationName replicationNameを設定。
     */
    public void setReplicationName(String replicationName) {
        this.replicationName = replicationName;
    }

    /**
     * プロパティー：connectionUrl を返します。
     *
     * @return connectionUrl
     */
    public String getConnectionUrl() {
        return connectionUrl;
    }

    /**
     * プロパティー：connectionUrl を設定します。
     *
     * @param connectionUrl connectionUrlを設定。
     */
    public void setConnectionUrl(String connectionUrl) {
        this.connectionUrl = connectionUrl;
    }

    /**
     * プロパティー：dbConnectionUrl を返します。
     *
     * @return dbConnectionUrl
     */
    public String getDbConnectionUrl() {
        return dbConnectionUrl;
    }

    /**
     * プロパティー：dbConnectionUrl を設定します。
     *
     * @param dbConnectionUrl dbConnectionUrlを設定。
     */
    public void setDbConnectionUrl(String dbConnectionUrl) {
        this.dbConnectionUrl = dbConnectionUrl;
    }

    /**
     * プロパティー：dbServerInstanceId を返します。
     *
     * @return dbServerInstanceId
     */
    public String getDbServerInstanceId() {
        return dbServerInstanceId;
    }

    /**
     * プロパティー：dbServerInstanceId を設定します。
     *
     * @param dbServerInstanceId dbServerInstanceIdを設定。
     */
    public void setDbServerInstanceId(String dbServerInstanceId) {
        this.dbServerInstanceId = dbServerInstanceId;
    }

    /**
     * プロパティー：dbSchemaName を返します。
     *
     * @return dbSchemaName
     */
    public String getDbSchemaName() {
        return dbSchemaName;
    }

    /**
     * プロパティー：dbSchemaName を設定します。
     *
     * @param dbSchemaName dbSchemaNameを設定。
     */
    public void setDbSchemaName(String dbSchemaName) {
        this.dbSchemaName = dbSchemaName;
    }

    /**
     * プロパティー：isDeleted を返します。
     *
     * @return isDeleted
     */
    public boolean getIsDeleted() {
        return isDeleted;
    }

    /**
     * プロパティー：isDeleted を設定します。
     *
     * @param isDeleted isDeletedを設定。
     */
    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
}
