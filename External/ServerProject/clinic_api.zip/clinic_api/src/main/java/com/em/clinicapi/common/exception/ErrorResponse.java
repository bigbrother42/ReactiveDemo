package com.em.clinicapi.common.exception;

public class ErrorResponse {
    private String message;
    private String errorTypeCode;
    private String errorTypeName;

    public ErrorResponse(String errorTypeCode, String errorTypeName, String message) {
        this.message = message;
        this.errorTypeName = errorTypeName;
        this.errorTypeCode = errorTypeCode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorTypeName() {
        return errorTypeName;
    }

    public void setErrorTypeName(String errorTypeName) {
        this.errorTypeName = errorTypeName;
    }

    public String getErrorTypeCode() {
        return errorTypeCode;
    }

    public void setErrorTypeCode(String errorTypeCode) {
        this.errorTypeCode = errorTypeCode;
    }
}
