package com.em.clinicapi.common.constants;

import org.springframework.http.HttpStatus;
import org.springframework.lang.Nullable;

public enum ErrorEnum {
    InvalidRequest("E400000", "不正なリクエスト"),
    InvalidJSONFormat("E400001", "JSON形式不正"),
    InvalidType("E400002", "型が不正"),
    RequiredFieldsNotFilled("E400003", "必須項目で未入力"),
    InvalidFormat("E400004", "フォーマットが不正"),
    NotAValidValue("E400005", "有効な値でない"),
    NonExistentValue("E400006", "存在しない値"),
    ImportError("E400007", "インポートエラー"),
    ErrorInCorrelation("E400008", "相関関係でエラー"),
    ExceedsSpecifiedNumberOfDigits("E400009", "指定桁数を超えている"),
    InternalServerError("E400010", "Internal Server Error"),
    JsonParseError("E400011", "Json Parse Error"),
    XmlParseError("E400012", "XML Parse Error"),
    TokenAuthenticationError("E401000", "トークン認証エラー"),
    IDPassAuthenticationError("E401001", "ID/Pass認証エラー"),
    ConcurrentAccessLimitExceededError("E401002", "同時アクセス制限オーバーエラー"),
    AuthenticationErrorDueToInvalidHeader("E401003", "Header不正による認証エラー"),
    NoAccess("E403000", "アクセス権なし"),
    ProhibitedOperations("E403001", "禁止されているオペレーション"),
    ItemsCannotBeSet("E403002", "設定不可の項目"),
    NoData("E404001", "該当データなし"),
    NoService("E404002", "該当サービスなし"),
    NoField("E404003", "該当フィールドなし"),
    NoApplications("E404004", "該当アプリケーションなし"),
    NoUsers("E404005", "該当ユーザなし"),
    InvalidRequestURIMethod("E405001", "リクエストURI/メソッドが不正"),
    DuplicationError("E409001", "重複エラー"),
    SizeLimitErrorPerFile("E413001", "1ファイルあたりのサイズ上限エラー"),
    SystemError("E500001", "システムエラー"),
    DBError("E500002", "DBエラー"),
    EmailSendingError("E501001", "メール送信エラー"),
    ServiceUnavailable("E502001", "サービス利用不可");

    private final String value;
    private final String description;

    ErrorEnum(String value, String description) {
        this.value = value;
        this.description = description;
    }

    public String value() {
        return this.value;
    }

    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        return this.value + " " + name();
    }
}
