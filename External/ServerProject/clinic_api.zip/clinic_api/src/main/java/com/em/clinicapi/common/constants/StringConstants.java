package com.em.clinicapi.common.constants;

public class StringConstants {

    public static final String EMPTY_STRING = "";
}
