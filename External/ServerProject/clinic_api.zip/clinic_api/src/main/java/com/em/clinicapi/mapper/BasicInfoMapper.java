package com.em.clinicapi.mapper;

import com.em.clinicapi.dto.TestDto;
import com.em.clinicapi.webdto.request.BasicInfoWebDto;
import com.em.clinicapi.webdto.response.DepartmentInfromationWebDto;
import com.em.clinicapi.webdto.response.PhysicianInformationWebDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface BasicInfoMapper {

    List<PhysicianInformationWebDto> selectDoctorBasicInfo();

    List<PhysicianInformationWebDto> selectStaffBasicInfo();

    List<DepartmentInfromationWebDto> selectDepartmentBasicInfo(BasicInfoWebDto dto);

}
