package com.em.clinicapi.service;

import com.em.clinicapi.dto.TestDto;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.List;

import static org.junit.Assert.assertEquals;

@RunWith(MockitoJUnitRunner.class)
public class MyServiceTest {
    /*@InjectMocks
    private MyService myService;

    @Test
    public void testGetMessage() {
        String message = myService.accessTest();
        assertEquals("Hello World", message);
    }*/
}
