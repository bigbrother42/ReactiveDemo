package com.em.clinicapi;

import com.em.clinicapi.common.exception.XmlParseException;
import com.em.clinicapi.common.util.XmlUtil;
import com.em.clinicapi.dto.UserDTO;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@SpringBootTest
class ClinicApiApplicationTests {

    @Test
    void contextLoads() {
    }

    @Test
    public void testParseXml() {
        try {
            String xmlString = "<user>" +
                                    "<id>1</id>" +
                                    "<name>John</name>" +
                                    "<email>john@example.com</email>" +
                                    "<birthday>1993-10-12</birthday>" +
                                    "<items>" +
                                        "<item>Item 1</item>" +
                                        "<item>Item 2</item>" +
                                        "<item>Item 3</item>" +
                                    "</items>" +
                                "</user>";
            UserDTO userDTO = XmlUtil.parseObject(xmlString, UserDTO.class);

            assertTrue(!"".equals(userDTO.getName()));
        } catch(XmlParseException xmlParseException) {
            System.out.println(xmlParseException.getStackTrace());
        }
    }
}
