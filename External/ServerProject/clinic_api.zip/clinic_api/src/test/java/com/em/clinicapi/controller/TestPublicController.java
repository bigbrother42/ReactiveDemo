package com.em.clinicapi.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
//@WebMvcTest(PublicController.class)
public class TestPublicController {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void testAccess() throws Exception {
        String requestBody = "{\"test\": \"1\"}";

        /*MyService myService = org.mockito.Mockito.mock(MyService.class);
        org.mockito.Mockito.when(myService.accessTest()).thenReturn("Hello World2");*/

        mockMvc.perform(
                post("/clinic/api/access")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(requestBody)
                )
                .andExpect(status().isOk())
                .andExpect(content().string("success"));
    }
}
