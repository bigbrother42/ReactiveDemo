package com.em.clinicapi.logic;

import com.em.clinicapi.common.constants.*;
import com.em.clinicapi.common.constants.enumerations.*;
import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.common.exception.SystemException;
import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.mapper.BasicInfoMapper;
import com.em.clinicapi.webdto.db.JihiHasuuMWebDto;
import com.em.clinicapi.webdto.db.ShouhizeiritsuMWebDto;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequest;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequestWebDto;
import com.em.clinicapi.webdto.response.basicinfo.PhysicianInformation;
import com.em.clinicapi.webdto.response.basicinfo.PhysicianInformationArr;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponse;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponseWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;


@Component
public class BasicInfoLogic {

    public static final String Reskey = "PatientInfo";

    // yyyy-MM-dd
    private SimpleDateFormat sdfDate = new SimpleDateFormat(DateFormatEnum.FormatYYYYMMDDM.getValue());
    // HH:mm:ss
    private SimpleDateFormat sdfTime = new SimpleDateFormat(DateFormatEnum.FormatHHmmss.getValue());
    private String customerSeq;

    @Autowired
    BasicInfoMapper basicInfoMapper;

    /**
     * アカウント情報取得(医師)
     * @param doctorInfoRequestWebDto
     * @return
     */
    public UserBasicInfoResponseWebDto getDoctorBasicInfo(BasicInfoRequestWebDto doctorInfoRequestWebDto)
    {
        Date responseDate = new Date();

        UserBasicInfoResponseWebDto doctorBasicInfoResponseWebDto = new UserBasicInfoResponseWebDto();
        UserBasicInfoResponse doctorBasicInfoResponse = new UserBasicInfoResponse();
        // レスポンスを返す時点の日付
        doctorBasicInfoResponse.setInformationDate(sdfDate.format(responseDate));
        // レスポンスを返す時点の時刻
        doctorBasicInfoResponse.setInformationTime(sdfTime.format(responseDate));
        // 成功時は"00"を返す
        doctorBasicInfoResponse.setApiResult(ApiResultEnum.Success.getCode());
        doctorBasicInfoResponse.setApiResultMessage(ApiResultMessageEnum.Success.getMessage());
        doctorBasicInfoResponse.setReskey(ReskeyEnum.PatientInfo.getKey());
        doctorBasicInfoResponse.setBaseDate(doctorInfoRequestWebDto.getBasicInfoRequest().getBaseDate());

        if (!RequestNumberEnum.Doctor.getCode().equals(doctorInfoRequestWebDto.getBasicInfoRequest().getRequestNumber())){
            doctorBasicInfoResponse.setApiResult(ApiResultSystemInfoEnum.OperationTypeNotSet.getCode());
            doctorBasicInfoResponse.setApiResultMessage(ApiResultSystemInfoEnum.OperationTypeNotSet.getDescription());
        }else {
            try {
                customerSeq = doctorInfoRequestWebDto.getBasicInfoRequest().getCustomerId();
                List<PhysicianInformation> physicianInformations = basicInfoMapper.selectDoctorBasicInfo(Integer.valueOf(customerSeq));
                if(physicianInformations == null){
                    // アカウント情報(医師)が取得できません
                    throw new SystemException(StringConstants.EMPTY_STRING, ApiResultSystemInfoEnum.UnableGetStaff.getCode());
                }
                PhysicianInformationArr physicianInformationArr = new PhysicianInformationArr();
                physicianInformationArr.setType(ClassTypeEnum.array);
                physicianInformationArr.setPhysicianInformation(physicianInformations);
                doctorBasicInfoResponse.setPhysicianInformationArr(physicianInformationArr);
            } catch(SystemException systemException) {
                doctorBasicInfoResponse.setApiResult(ApiResultSystemInfoEnum.UnableGetStaff.getCode());
                doctorBasicInfoResponse.setApiResultMessage(ApiResultSystemInfoEnum.UnableGetStaff.getDescription());
            }
        }
        doctorBasicInfoResponseWebDto.setUserBasicInfoResponse(doctorBasicInfoResponse);

        return doctorBasicInfoResponseWebDto;
    }

    /**
     * アカウント情報取得(職員)
     * @param staffInfoRequestWebDto
     * @return
     */
    public UserBasicInfoResponseWebDto getStaffBasicInfo(BasicInfoRequestWebDto staffInfoRequestWebDto) {
        Date responseDate = new Date();

        UserBasicInfoResponseWebDto staffBasicInfoResponseWebDto = new UserBasicInfoResponseWebDto();
        UserBasicInfoResponse staffBasicInfoResponse = new UserBasicInfoResponse();
        // レスポンスを返す時点の日付
        staffBasicInfoResponse.setInformationDate(sdfDate.format(responseDate));
        // レスポンスを返す時点の時刻
        staffBasicInfoResponse.setInformationTime(sdfTime.format(responseDate));
        // 成功時は"00"を返す
        staffBasicInfoResponse.setApiResult(ApiResultEnum.Success.getCode());
        staffBasicInfoResponse.setApiResultMessage(ApiResultMessageEnum.Success.getMessage());
        staffBasicInfoResponse.setReskey(ReskeyEnum.PatientInfo.getKey());
        staffBasicInfoResponse.setBaseDate(staffInfoRequestWebDto.getBasicInfoRequest().getBaseDate());

        if (!RequestNumberEnum.Staff.getCode().equals(staffInfoRequestWebDto.getBasicInfoRequest().getRequestNumber())){
            staffBasicInfoResponse.setApiResult(ApiResultSystemInfoEnum.OperationTypeNotSet.getCode());
            staffBasicInfoResponse.setApiResultMessage(ApiResultSystemInfoEnum.OperationTypeNotSet.getDescription());
        }else {
            try {
                customerSeq = staffInfoRequestWebDto.getBasicInfoRequest().getCustomerId();
                List<PhysicianInformation> physicianInformations = basicInfoMapper.selectStaffBasicInfo(Integer.valueOf(customerSeq));
                if(physicianInformations == null){
                    // アカウント情報(職員)が取得できません
                    throw new SystemException(StringConstants.EMPTY_STRING, ApiResultSystemInfoEnum.UnableGetStaff.getCode());
                }
                PhysicianInformationArr physicianInformationArr = new PhysicianInformationArr();
                physicianInformationArr.setType(ClassTypeEnum.array);
                physicianInformationArr.setPhysicianInformation(physicianInformations);
                staffBasicInfoResponse.setPhysicianInformationArr(physicianInformationArr);
            } catch(SystemException systemException) {
                staffBasicInfoResponse.setApiResult(ApiResultSystemInfoEnum.UnableGetStaff.getCode());
                staffBasicInfoResponse.setApiResultMessage(ApiResultSystemInfoEnum.UnableGetStaff.getDescription());
            }
        }

        staffBasicInfoResponseWebDto.setUserBasicInfoResponse(staffBasicInfoResponse);

        return staffBasicInfoResponseWebDto;
    }
}
