package com.em.clinicapi.common.db;

import org.springframework.aop.AfterReturningAdvice;

import java.lang.reflect.Method;
import java.sql.Statement;

public class StatementsRegisteringAdvice implements AfterReturningAdvice {

    private DbExecutionMonitor statementsMonitor;

    /**
     * @return the statementsMonitor
     */
    public DbExecutionMonitor getStatementsMonitor() {
        return statementsMonitor;
    }

    /**
     * @param statementsMonitor the statementsMonitor to set
     */
    public void setStatementsMonitor(DbExecutionMonitor statementsMonitor) {
        this.statementsMonitor = statementsMonitor;
    }

    @Override
    public void afterReturning(final Object returnValue, final Method method, final Object[] args, final Object target)
            throws Throwable {
        if (returnValue instanceof Statement) {
            Statement stmt = Statement.class.cast(returnValue);
            this.statementsMonitor.add(stmt, args != null && args.length > 0 ? args[0].toString() : null);
        }
    }
}
