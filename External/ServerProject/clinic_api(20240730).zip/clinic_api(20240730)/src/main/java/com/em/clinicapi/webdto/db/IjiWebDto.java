package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class IjiWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ prescriptionSeq */
	private int  prescriptionSeq = 0;

	/**  プロパティ shinryouKbn */
	private String  shinryouKbn = null;

	/**  プロパティ prescriptionNissuuKaisuu */
	private int  prescriptionNissuuKaisuu = 0;

	/**  プロパティ ingaiTouyakuKbn */
	private String  ingaiTouyakuKbn = null;

	/**  プロパティ touyoHouhouTouyakuKbn */
	private String  touyoHouhouTouyakuKbn = null;

	/**  プロパティ isRinjiTouyoTouyaku */
	private boolean  isRinjiTouyoTouyaku;

	/**  プロパティ isKongouTouyaku */
	private boolean  isKongouTouyaku;

	/**  プロパティ isIppoukaTaishougai */
	private boolean  isIppoukaTaishougai;

	/**  プロパティ isHoukatsuTaishougai */
	private boolean  isHoukatsuTaishougai;

	/**  プロパティ isMarumeTaishougai */
	private boolean  isMarumeTaishougai;

	/**  プロパティ bunkatsuCommentTouyaku */
	private String  bunkatsuCommentTouyaku = null;

	/**  プロパティ shinryoukaCode */
	private String  shinryoukaCode = null;

	/**  プロパティ doctorCode */
	private String  doctorCode = null;

	/**  プロパティ karteSeq */
	private int  karteSeq = 0;

	/**  プロパティ shochiPrescription */
	private String  shochiPrescription = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：prescriptionSeq を返します。
	* @return prescriptionSeq
	*/
	public int getPrescriptionSeq(){
		return prescriptionSeq;
	}

	/**
	* プロパティー：prescriptionSeq を設定します。
	* @param param  int prescriptionSeq
	*/
	public void setPrescriptionSeq(int prescriptionSeq){
		this.prescriptionSeq = prescriptionSeq;
	}

	/**
	* プロパティー：shinryouKbn を返します。
	* @return shinryouKbn
	*/
	public String getShinryouKbn(){
		return shinryouKbn;
	}

	/**
	* プロパティー：shinryouKbn を設定します。
	* @param param  String shinryouKbn
	*/
	public void setShinryouKbn(String shinryouKbn){
		this.shinryouKbn = shinryouKbn;
	}

	/**
	* プロパティー：prescriptionNissuuKaisuu を返します。
	* @return prescriptionNissuuKaisuu
	*/
	public int getPrescriptionNissuuKaisuu(){
		return prescriptionNissuuKaisuu;
	}

	/**
	* プロパティー：prescriptionNissuuKaisuu を設定します。
	* @param param  int prescriptionNissuuKaisuu
	*/
	public void setPrescriptionNissuuKaisuu(int prescriptionNissuuKaisuu){
		this.prescriptionNissuuKaisuu = prescriptionNissuuKaisuu;
	}

	/**
	* プロパティー：ingaiTouyakuKbn を返します。
	* @return ingaiTouyakuKbn
	*/
	public String getIngaiTouyakuKbn(){
		return ingaiTouyakuKbn;
	}

	/**
	* プロパティー：ingaiTouyakuKbn を設定します。
	* @param param  String ingaiTouyakuKbn
	*/
	public void setIngaiTouyakuKbn(String ingaiTouyakuKbn){
		this.ingaiTouyakuKbn = ingaiTouyakuKbn;
	}

	/**
	* プロパティー：touyoHouhouTouyakuKbn を返します。
	* @return touyoHouhouTouyakuKbn
	*/
	public String getTouyoHouhouTouyakuKbn(){
		return touyoHouhouTouyakuKbn;
	}

	/**
	* プロパティー：touyoHouhouTouyakuKbn を設定します。
	* @param param  String touyoHouhouTouyakuKbn
	*/
	public void setTouyoHouhouTouyakuKbn(String touyoHouhouTouyakuKbn){
		this.touyoHouhouTouyakuKbn = touyoHouhouTouyakuKbn;
	}

	/**
	* プロパティー：isRinjiTouyoTouyaku を返します。
	* @return isRinjiTouyoTouyaku
	*/
	public boolean getIsRinjiTouyoTouyaku(){
		return isRinjiTouyoTouyaku;
	}

	/**
	* プロパティー：isRinjiTouyoTouyaku を設定します。
	* @param param  boolean isRinjiTouyoTouyaku
	*/
	public void setIsRinjiTouyoTouyaku(boolean isRinjiTouyoTouyaku){
		this.isRinjiTouyoTouyaku = isRinjiTouyoTouyaku;
	}

	/**
	* プロパティー：isKongouTouyaku を返します。
	* @return isKongouTouyaku
	*/
	public boolean getIsKongouTouyaku(){
		return isKongouTouyaku;
	}

	/**
	* プロパティー：isKongouTouyaku を設定します。
	* @param param  boolean isKongouTouyaku
	*/
	public void setIsKongouTouyaku(boolean isKongouTouyaku){
		this.isKongouTouyaku = isKongouTouyaku;
	}

	/**
	* プロパティー：isIppoukaTaishougai を返します。
	* @return isIppoukaTaishougai
	*/
	public boolean getIsIppoukaTaishougai(){
		return isIppoukaTaishougai;
	}

	/**
	* プロパティー：isIppoukaTaishougai を設定します。
	* @param param  boolean isIppoukaTaishougai
	*/
	public void setIsIppoukaTaishougai(boolean isIppoukaTaishougai){
		this.isIppoukaTaishougai = isIppoukaTaishougai;
	}

	/**
	* プロパティー：isHoukatsuTaishougai を返します。
	* @return isHoukatsuTaishougai
	*/
	public boolean getIsHoukatsuTaishougai(){
		return isHoukatsuTaishougai;
	}

	/**
	* プロパティー：isHoukatsuTaishougai を設定します。
	* @param param  boolean isHoukatsuTaishougai
	*/
	public void setIsHoukatsuTaishougai(boolean isHoukatsuTaishougai){
		this.isHoukatsuTaishougai = isHoukatsuTaishougai;
	}

	/**
	* プロパティー：isMarumeTaishougai を返します。
	* @return isMarumeTaishougai
	*/
	public boolean getIsMarumeTaishougai(){
		return isMarumeTaishougai;
	}

	/**
	* プロパティー：isMarumeTaishougai を設定します。
	* @param param  boolean isMarumeTaishougai
	*/
	public void setIsMarumeTaishougai(boolean isMarumeTaishougai){
		this.isMarumeTaishougai = isMarumeTaishougai;
	}

	/**
	* プロパティー：bunkatsuCommentTouyaku を返します。
	* @return bunkatsuCommentTouyaku
	*/
	public String getBunkatsuCommentTouyaku(){
		return bunkatsuCommentTouyaku;
	}

	/**
	* プロパティー：bunkatsuCommentTouyaku を設定します。
	* @param param  String bunkatsuCommentTouyaku
	*/
	public void setBunkatsuCommentTouyaku(String bunkatsuCommentTouyaku){
		this.bunkatsuCommentTouyaku = bunkatsuCommentTouyaku;
	}

	/**
	* プロパティー：shinryoukaCode を返します。
	* @return shinryoukaCode
	*/
	public String getShinryoukaCode(){
		return shinryoukaCode;
	}

	/**
	* プロパティー：shinryoukaCode を設定します。
	* @param param  String shinryoukaCode
	*/
	public void setShinryoukaCode(String shinryoukaCode){
		this.shinryoukaCode = shinryoukaCode;
	}

	/**
	* プロパティー：doctorCode を返します。
	* @return doctorCode
	*/
	public String getDoctorCode(){
		return doctorCode;
	}

	/**
	* プロパティー：doctorCode を設定します。
	* @param param  String doctorCode
	*/
	public void setDoctorCode(String doctorCode){
		this.doctorCode = doctorCode;
	}

	/**
	* プロパティー：karteSeq を返します。
	* @return karteSeq
	*/
	public int getKarteSeq(){
		return karteSeq;
	}

	/**
	* プロパティー：karteSeq を設定します。
	* @param param  int karteSeq
	*/
	public void setKarteSeq(int karteSeq){
		this.karteSeq = karteSeq;
	}

	/**
	* プロパティー：shochiPrescription を返します。
	* @return shochiPrescription
	*/
	public String getShochiPrescription(){
		return shochiPrescription;
	}

	/**
	* プロパティー：shochiPrescription を設定します。
	* @param param  String shochiPrescription
	*/
	public void setShochiPrescription(String shochiPrescription){
		this.shochiPrescription = shochiPrescription;
	}
}
