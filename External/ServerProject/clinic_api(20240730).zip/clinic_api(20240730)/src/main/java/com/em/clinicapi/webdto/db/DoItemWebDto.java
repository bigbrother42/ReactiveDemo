package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

public class DoItemWebDto  extends CustomerWebDtoBase {
    /** プロパティ patientSeq */
    private Integer patientSeq = null;

    /** プロパティ hokenSeq */
    private Integer hokenSeq = null;

    /** プロパティ shinryouDate */
    private java.sql.Date shinryouDate = null;

    /** プロパティ raiinKaisuu */
    private Integer raiinKaisuu = null;

    /** プロパティ karteSeq */
    private Integer karteSeq = null;

    /** プロパティ prescriptionSeq */
    private Integer prescriptionSeq = null;

    /** プロパティ doBaseHokenSeq */
    private Integer doBaseHokenSeq = null;

    /** プロパティ doBaseShuhokenHokenshaNo */
    private String doBaseShuhokenHokenshaNo = null;

    /** プロパティ doBaseKou1FukushiNo */
    private String doBaseKou1FukushiNo = null;

    /** プロパティ doBaseKou1FutanshaNo */
    private String doBaseKou1FutanshaNo = null;

    /** プロパティ doBaseKou2FukushiNo */
    private String doBaseKou2FukushiNo = null;

    /** プロパティ doBaseKou2FutanshaNo */
    private String doBaseKou2FutanshaNo = null;

    /** プロパティ doBaseKou3FukushiNo */
    private String doBaseKou3FukushiNo = null;

    /** プロパティ doBaseKou3FutanshaNo */
    private String doBaseKou3FutanshaNo = null;

    /** プロパティ doBaseFukushiNo */
    private String doBaseFukushiNo = null;

    /** プロパティ doBaseFukushiFutanshaNo */
    private String doBaseFukushiFutanshaNo = null;

    /**
     * デフォルトのコンストラクタ
     */
    public DoItemWebDto() {
        super();
    }

    /**
     * プロパティー：patientSeq を返します。
     *
     * @return patientSeq
     */
    public Integer getPatientSeq() {
        return patientSeq;
    }

    /**
     * プロパティー：patientSeq を設定します。
     *
     * @param patientSeq patientSeqを設定。
     */
    public void setPatientSeq(Integer patientSeq) {
        this.patientSeq = patientSeq;
    }

    /**
     * プロパティー：hokenSeq を返します。
     *
     * @return hokenSeq
     */
    public Integer getHokenSeq() {
        return hokenSeq;
    }

    /**
     * プロパティー：hokenSeq を設定します。
     *
     * @param hokenSeq hokenSeqを設定。
     */
    public void setHokenSeq(Integer hokenSeq) {
        this.hokenSeq = hokenSeq;
    }

    /**
     * プロパティー：shinryouDate を返します。
     *
     * @return shinryouDate
     */
    public java.sql.Date getShinryouDate() {
        return shinryouDate;
    }

    /**
     * プロパティー：shinryouDate を設定します。
     *
     * @param shinryouDate shinryouDateを設定。
     */
    public void setShinryouDate(java.sql.Date shinryouDate) {
        this.shinryouDate = shinryouDate;
    }

    /**
     * プロパティー：raiinKaisuu を返します。
     *
     * @return raiinKaisuu
     */
    public Integer getRaiinKaisuu() {
        return raiinKaisuu;
    }

    /**
     * プロパティー：raiinKaisuu を設定します。
     *
     * @param raiinKaisuu raiinKaisuuを設定。
     */
    public void setRaiinKaisuu(Integer raiinKaisuu) {
        this.raiinKaisuu = raiinKaisuu;
    }

    /**
     * プロパティー：karteSeq を返します。
     *
     * @return karteSeq
     */
    public Integer getKarteSeq() {
        return karteSeq;
    }

    /**
     * プロパティー：karteSeq を設定します。
     *
     * @param karteSeq karteSeqを設定。
     */
    public void setKarteSeq(Integer karteSeq) {
        this.karteSeq = karteSeq;
    }

    /**
     * プロパティー：prescriptionSeq を返します。
     *
     * @return prescriptionSeq
     */
    public Integer getPrescriptionSeq() {
        return prescriptionSeq;
    }

    /**
     * プロパティー：prescriptionSeq を設定します。
     *
     * @param prescriptionSeq prescriptionSeqを設定。
     */
    public void setPrescriptionSeq(Integer prescriptionSeq) {
        this.prescriptionSeq = prescriptionSeq;
    }

    /**
     * プロパティー：doBaseHokenSeq を返します。
     *
     * @return doBaseHokenSeq
     */
    public Integer getDoBaseHokenSeq() {
        return doBaseHokenSeq;
    }

    /**
     * プロパティー：doBaseHokenSeq を設定します。
     *
     * @param doBaseHokenSeq doBaseHokenSeqを設定。
     */
    public void setDoBaseHokenSeq(Integer doBaseHokenSeq) {
        this.doBaseHokenSeq = doBaseHokenSeq;
    }

    /**
     * プロパティー：doBaseShuhokenHokenshaNo を返します。
     *
     * @return doBaseShuhokenHokenshaNo
     */
    public String getDoBaseShuhokenHokenshaNo() {
        return doBaseShuhokenHokenshaNo;
    }

    /**
     * プロパティー：doBaseShuhokenHokenshaNo を設定します。
     *
     * @param doBaseShuhokenHokenshaNo doBaseShuhokenHokenshaNoを設定。
     */
    public void setDoBaseShuhokenHokenshaNo(String doBaseShuhokenHokenshaNo) {
        this.doBaseShuhokenHokenshaNo = doBaseShuhokenHokenshaNo;
    }

    /**
     * プロパティー：doBaseKou1FukushiNo を返します。
     *
     * @return doBaseKou1FukushiNo
     */
    public String getDoBaseKou1FukushiNo() {
        return doBaseKou1FukushiNo;
    }

    /**
     * プロパティー：doBaseKou1FukushiNo を設定します。
     *
     * @param doBaseKou1FukushiNo doBaseKou1FukushiNoを設定。
     */
    public void setDoBaseKou1FukushiNo(String doBaseKou1FukushiNo) {
        this.doBaseKou1FukushiNo = doBaseKou1FukushiNo;
    }

    /**
     * プロパティー：doBaseKou1FutanshaNo を返します。
     *
     * @return doBaseKou1FutanshaNo
     */
    public String getDoBaseKou1FutanshaNo() {
        return doBaseKou1FutanshaNo;
    }

    /**
     * プロパティー：doBaseKou1FutanshaNo を設定します。
     *
     * @param doBaseKou1FutanshaNo doBaseKou1FutanshaNoを設定。
     */
    public void setDoBaseKou1FutanshaNo(String doBaseKou1FutanshaNo) {
        this.doBaseKou1FutanshaNo = doBaseKou1FutanshaNo;
    }

    /**
     * プロパティー：doBaseKou2FukushiNo を返します。
     *
     * @return doBaseKou2FukushiNo
     */
    public String getDoBaseKou2FukushiNo() {
        return doBaseKou2FukushiNo;
    }

    /**
     * プロパティー：doBaseKou2FukushiNo を設定します。
     *
     * @param doBaseKou2FukushiNo doBaseKou2FukushiNoを設定。
     */
    public void setDoBaseKou2FukushiNo(String doBaseKou2FukushiNo) {
        this.doBaseKou2FukushiNo = doBaseKou2FukushiNo;
    }

    /**
     * プロパティー：doBaseKou2FutanshaNo を返します。
     *
     * @return doBaseKou2FutanshaNo
     */
    public String getDoBaseKou2FutanshaNo() {
        return doBaseKou2FutanshaNo;
    }

    /**
     * プロパティー：doBaseKou2FutanshaNo を設定します。
     *
     * @param doBaseKou2FutanshaNo doBaseKou2FutanshaNoを設定。
     */
    public void setDoBaseKou2FutanshaNo(String doBaseKou2FutanshaNo) {
        this.doBaseKou2FutanshaNo = doBaseKou2FutanshaNo;
    }

    /**
     * プロパティー：doBaseKou3FukushiNo を返します。
     *
     * @return doBaseKou3FukushiNo
     */
    public String getDoBaseKou3FukushiNo() {
        return doBaseKou3FukushiNo;
    }

    /**
     * プロパティー：doBaseKou3FukushiNo を設定します。
     *
     * @param doBaseKou3FukushiNo doBaseKou3FukushiNoを設定。
     */
    public void setDoBaseKou3FukushiNo(String doBaseKou3FukushiNo) {
        this.doBaseKou3FukushiNo = doBaseKou3FukushiNo;
    }

    /**
     * プロパティー：doBaseKou3FutanshaNo を返します。
     *
     * @return doBaseKou3FutanshaNo
     */
    public String getDoBaseKou3FutanshaNo() {
        return doBaseKou3FutanshaNo;
    }

    /**
     * プロパティー：doBaseKou3FutanshaNo を設定します。
     *
     * @param doBaseKou3FutanshaNo doBaseKou3FutanshaNoを設定。
     */
    public void setDoBaseKou3FutanshaNo(String doBaseKou3FutanshaNo) {
        this.doBaseKou3FutanshaNo = doBaseKou3FutanshaNo;
    }

    /**
     * プロパティー：doBaseFukushiNo を返します。
     *
     * @return doBaseFukushiNo
     */
    public String getDoBaseFukushiNo() {
        return doBaseFukushiNo;
    }

    /**
     * プロパティー：doBaseFukushiNo を設定します。
     *
     * @param doBaseFukushiNo doBaseFukushiNoを設定。
     */
    public void setDoBaseFukushiNo(String doBaseFukushiNo) {
        this.doBaseFukushiNo = doBaseFukushiNo;
    }

    /**
     * プロパティー：doBaseFukushiFutanshaNo を返します。
     *
     * @return doBaseFukushiFutanshaNo
     */
    public String getDoBaseFukushiFutanshaNo() {
        return doBaseFukushiFutanshaNo;
    }

    /**
     * プロパティー：doBaseFukushiFutanshaNo を設定します。
     *
     * @param doBaseFukushiFutanshaNo doBaseFukushiFutanshaNoを設定。
     */
    public void setDoBaseFukushiFutanshaNo(String doBaseFukushiFutanshaNo) {
        this.doBaseFukushiFutanshaNo = doBaseFukushiFutanshaNo;
    }
}
