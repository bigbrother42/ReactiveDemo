package com.em.clinicapi.filter;

import com.em.clinicapi.common.cache.DbMapperContextHolder;
import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.cache.ServerReplicationContextHolder;
import com.em.clinicapi.common.logging.AuditTrailManager;
import com.em.clinicapi.common.util.LogUtil;
import org.apache.logging.log4j.Logger;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import java.io.IOException;

import static com.em.clinicapi.common.util.LogUtil.LOG;

public class ClearCacheFilter extends GenericFilterBean {

    private static final Logger LOG = LogUtil.getLogger(ClearCacheFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            LOG.debug("Clear Cache Processing Filter START");

            chain.doFilter(request, response);
        } finally {
            writeAuditTrailLog(request, response);
            clearCache();

            LOG.debug("Clear Cache Processing Filter END");
        }
    }

    private void writeAuditTrailLog(ServletRequest request, ServletResponse response) {
        try{
            AuditTrailManager.writeAuditTrailLog(request, response);
        }
        catch (Exception ex)
        {
            LOG.error(ex.getStackTrace(), ex);
        }
    }

    private void clearCache(){
        RequestCacheHolder.clear();
        ServerReplicationContextHolder.clearAll();
        DbMapperContextHolder.clear();
    }
}
