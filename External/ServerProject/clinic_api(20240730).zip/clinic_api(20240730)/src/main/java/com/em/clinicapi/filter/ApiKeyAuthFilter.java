package com.em.clinicapi.filter;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.constants.enumerations.ErrorEnum;
import com.em.clinicapi.common.exception.CustomAuthenticationException;
import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.config.auth.CustomAuthenticationEntryPoint;
import com.em.clinicapi.config.auth.UserModel;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Base64;

public class ApiKeyAuthFilter extends AbstractPreAuthenticatedProcessingFilter {

    private static final Logger LOG = LogUtil.getLogger(ApiKeyAuthFilter.class);

    private String principalRequestHeader;
    private final CustomAuthenticationEntryPoint authenticationEntryPoint;

    public ApiKeyAuthFilter(String principalRequestHeader, CustomAuthenticationEntryPoint authenticationEntryPoint) {
        this.principalRequestHeader = principalRequestHeader;
        this.authenticationEntryPoint = authenticationEntryPoint;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        RequestCacheHolder.initialize();

        try {
            String contentType = request.getContentType();
            if (StringUtil.isNullOrEmpty(contentType) || !contentType.contains(StringConstants.ContentTypeXml)) {
                AuthenticationException exception = new CustomAuthenticationException(
                        ErrorEnum.AuthenticationErrorDueToInvalidHeader.value(), ErrorEnum.AuthenticationErrorDueToInvalidHeader.getDescription());
                RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, exception);
                throw exception;
            }

            super.doFilter(request, response, chain);
        } catch (AuthenticationException ex) {
            LOG.error(ex.getMessage(), ex);

            // Handle the authentication exception using the CustomAuthenticationEntryPoint
            this.authenticationEntryPoint.commence((HttpServletRequest) request, (HttpServletResponse) response, ex);
            return; // Stop further processing of the filter chain
        }
    }

    @Override
    protected Object getPreAuthenticatedPrincipal(HttpServletRequest request) {
        Object principal = request.getHeader(principalRequestHeader);
        if (principal == null) {
            AuthenticationException exception = new CustomAuthenticationException(
                    ErrorEnum.TokenAuthenticationError.value(), ErrorEnum.TokenAuthenticationError.getDescription());
            RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, exception);
            throw exception;
        }

        return principal;
    }

    @Override
    protected Object getPreAuthenticatedCredentials(HttpServletRequest request) {

        String authenticationHeader = request.getHeader("Authorization");
        if (authenticationHeader != null && authenticationHeader.startsWith("Basic ")) {
            String base64Credentials = authenticationHeader.substring("Basic ".length()).trim();
            String credentials = new String(Base64.getDecoder().decode(base64Credentials));

            final String[] values = credentials.split(":", 2);
            if (values.length == 2) {
                String username = values[0];
                String password = values[1];

                UserModel userModel = new UserModel();
                userModel.setUsername(username);
                userModel.setPassword(password);

                return userModel;
            }
        }

        return null;
    }
}
