package com.em.clinicapi.common.exception;

public class ErrorResponse {
    private String Error;
    private String ErrorCode;
    private String Message;

    public ErrorResponse(String errorTypeCode, String errorTypeName, String message) {
        this.Error = errorTypeName;
        this.ErrorCode = errorTypeCode;
        this.Message = message;
    }

    public String getError() {
        return Error;
    }

    public void setError(String error) {
        Error = error;
    }

    public String getErrorCode() {
        return ErrorCode;
    }

    public void setErrorCode(String errorCode) {
        ErrorCode = errorCode;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String message) {
        Message = message;
    }
}
