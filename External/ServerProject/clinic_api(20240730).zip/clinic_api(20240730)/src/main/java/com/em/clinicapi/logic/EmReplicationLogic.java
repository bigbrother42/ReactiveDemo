package com.em.clinicapi.logic;

import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.mapper.EmReplicationMapper;
import com.em.clinicapi.webdto.ReplicationMCustomWebDto;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmReplicationLogic {

    @Autowired
    private EmReplicationMapper replicationMapper;

    /**
     * 顧客Replication情報取得
     * @param groupSeq グループID
     * @param customerSeq 顧客ID
     * @return 顧客Replication
     */
    public ReplicationMCustomWebDto selectGroupCustomerReplication(Integer groupSeq, Integer customerSeq) {
        return replicationMapper.selectGroupCustomerReplication(groupSeq, customerSeq);
    }

}
