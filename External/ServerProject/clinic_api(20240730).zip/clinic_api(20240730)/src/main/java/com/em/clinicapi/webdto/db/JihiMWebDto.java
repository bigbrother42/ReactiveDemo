package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class JihiMWebDto extends CustomerWebDtoBase {
    /**  プロパティ jihiCode */
    private String  jihiCode = null;

    /**  プロパティ startDate */
    private java.sql.Date  startDate = null;

    /**  プロパティ changeKbn */
    private String  changeKbn = null;

    /**  プロパティ masterType */
    private String  masterType = null;

    /**  プロパティ jihiKanjiValidCharCount */
    private int  jihiKanjiValidCharCount = 0;

    /**  プロパティ jihiKanjiName */
    private String  jihiKanjiName = null;

    /**  プロパティ jihiKanaValidCharCount */
    private int  jihiKanaValidCharCount = 0;

    /**  プロパティ jihiKanaName */
    private String  jihiKanaName = null;

    /**  プロパティ unitCode */
    private String  unitCode = null;

    /**  プロパティ unitNameValidCharCount */
    private int  unitNameValidCharCount = 0;

    /**  プロパティ unitName */
    private String  unitName = null;

    /**  プロパティ kingakuType */
    private String  kingakuType = null;

    /**  プロパティ kingaku */
    private java.math.BigDecimal  kingaku = null;

    /**  プロパティ shouhizeiSanteiKbn */
    private String  shouhizeiSanteiKbn = null;

    /**  プロパティ jitsuNissuuSanteiKbn */
    private String  jitsuNissuuSanteiKbn = null;

    /**  プロパティ kanjiNameChangeKbn */
    private String  kanjiNameChangeKbn = null;

    /**  プロパティ kanaNameChangeKbn */
    private String  kanaNameChangeKbn = null;

    /**  プロパティ changeDate */
    private java.sql.Date  changeDate = null;

    /**  プロパティ endDate */
    private java.sql.Date  endDate = null;

    /**  プロパティ shinryouKbn */
    private String  shinryouKbn = null;

    /**  プロパティ kikinSoutouMasterCode */
    private String  kikinSoutouMasterCode = null;

    /**  プロパティ jihiBunruiNo */
    private String  jihiBunruiNo = null;

    /**  プロパティ prescriptionShinryouKbn */
    private String  prescriptionShinryouKbn = null;

    /**  プロパティ isYakuzaiInfoPrint */
    private boolean  isYakuzaiInfoPrint;

    /**  プロパティ prescriptionInnaiPrintKbn */
    private String  prescriptionInnaiPrintKbn = null;

    /**  プロパティ prescriptionIngaiPrintKbn */
    private String  prescriptionIngaiPrintKbn = null;

    /**  プロパティ kingakuInputKbn */
    private String  kingakuInputKbn = null;


    /**
     *  デフォルトのコンストラクタ
     */
    public JihiMWebDto()	{
        super();
    }


    /**
     * プロパティー：jihiCode を返します。
     * @return jihiCode
     */
    public String getJihiCode(){
        return jihiCode;
    }

    /**
     * プロパティー：jihiCode を設定します。
     * @param param  String jihiCode
     */
    public void setJihiCode(String jihiCode){
        this.jihiCode = jihiCode;
    }

    /**
     * プロパティー：startDate を返します。
     * @return startDate
     */
    public java.sql.Date getStartDate(){
        return startDate;
    }

    /**
     * プロパティー：startDate を設定します。
     * @param param  java.sql.Date startDate
     */
    public void setStartDate(java.sql.Date startDate){
        this.startDate = startDate;
    }

    /**
     * プロパティー：changeKbn を返します。
     * @return changeKbn
     */
    public String getChangeKbn(){
        return changeKbn;
    }

    /**
     * プロパティー：changeKbn を設定します。
     * @param param  String changeKbn
     */
    public void setChangeKbn(String changeKbn){
        this.changeKbn = changeKbn;
    }

    /**
     * プロパティー：masterType を返します。
     * @return masterType
     */
    public String getMasterType(){
        return masterType;
    }

    /**
     * プロパティー：masterType を設定します。
     * @param param  String masterType
     */
    public void setMasterType(String masterType){
        this.masterType = masterType;
    }

    /**
     * プロパティー：jihiKanjiValidCharCount を返します。
     * @return jihiKanjiValidCharCount
     */
    public int getJihiKanjiValidCharCount(){
        return jihiKanjiValidCharCount;
    }

    /**
     * プロパティー：jihiKanjiValidCharCount を設定します。
     * @param param  int jihiKanjiValidCharCount
     */
    public void setJihiKanjiValidCharCount(int jihiKanjiValidCharCount){
        this.jihiKanjiValidCharCount = jihiKanjiValidCharCount;
    }

    /**
     * プロパティー：jihiKanjiName を返します。
     * @return jihiKanjiName
     */
    public String getJihiKanjiName(){
        return jihiKanjiName;
    }

    /**
     * プロパティー：jihiKanjiName を設定します。
     * @param param  String jihiKanjiName
     */
    public void setJihiKanjiName(String jihiKanjiName){
        this.jihiKanjiName = jihiKanjiName;
    }

    /**
     * プロパティー：jihiKanaValidCharCount を返します。
     * @return jihiKanaValidCharCount
     */
    public int getJihiKanaValidCharCount(){
        return jihiKanaValidCharCount;
    }

    /**
     * プロパティー：jihiKanaValidCharCount を設定します。
     * @param param  int jihiKanaValidCharCount
     */
    public void setJihiKanaValidCharCount(int jihiKanaValidCharCount){
        this.jihiKanaValidCharCount = jihiKanaValidCharCount;
    }

    /**
     * プロパティー：jihiKanaName を返します。
     * @return jihiKanaName
     */
    public String getJihiKanaName(){
        return jihiKanaName;
    }

    /**
     * プロパティー：jihiKanaName を設定します。
     * @param param  String jihiKanaName
     */
    public void setJihiKanaName(String jihiKanaName){
        this.jihiKanaName = jihiKanaName;
    }

    /**
     * プロパティー：unitCode を返します。
     * @return unitCode
     */
    public String getUnitCode(){
        return unitCode;
    }

    /**
     * プロパティー：unitCode を設定します。
     * @param param  String unitCode
     */
    public void setUnitCode(String unitCode){
        this.unitCode = unitCode;
    }

    /**
     * プロパティー：unitNameValidCharCount を返します。
     * @return unitNameValidCharCount
     */
    public int getUnitNameValidCharCount(){
        return unitNameValidCharCount;
    }

    /**
     * プロパティー：unitNameValidCharCount を設定します。
     * @param param  int unitNameValidCharCount
     */
    public void setUnitNameValidCharCount(int unitNameValidCharCount){
        this.unitNameValidCharCount = unitNameValidCharCount;
    }

    /**
     * プロパティー：unitName を返します。
     * @return unitName
     */
    public String getUnitName(){
        return unitName;
    }

    /**
     * プロパティー：unitName を設定します。
     * @param param  String unitName
     */
    public void setUnitName(String unitName){
        this.unitName = unitName;
    }

    /**
     * プロパティー：kingakuType を返します。
     * @return kingakuType
     */
    public String getKingakuType(){
        return kingakuType;
    }

    /**
     * プロパティー：kingakuType を設定します。
     * @param param  String kingakuType
     */
    public void setKingakuType(String kingakuType){
        this.kingakuType = kingakuType;
    }

    /**
     * プロパティー：kingaku を返します。
     * @return kingaku
     */
    public java.math.BigDecimal getKingaku(){
        return kingaku;
    }

    /**
     * プロパティー：kingaku を設定します。
     * @param param  java.math.BigDecimal kingaku
     */
    public void setKingaku(java.math.BigDecimal kingaku){
        this.kingaku = kingaku;
    }

    /**
     * プロパティー：shouhizeiSanteiKbn を返します。
     * @return shouhizeiSanteiKbn
     */
    public String getShouhizeiSanteiKbn(){
        return shouhizeiSanteiKbn;
    }

    /**
     * プロパティー：shouhizeiSanteiKbn を設定します。
     * @param param  String shouhizeiSanteiKbn
     */
    public void setShouhizeiSanteiKbn(String shouhizeiSanteiKbn){
        this.shouhizeiSanteiKbn = shouhizeiSanteiKbn;
    }

    /**
     * プロパティー：jitsuNissuuSanteiKbn を返します。
     * @return jitsuNissuuSanteiKbn
     */
    public String getJitsuNissuuSanteiKbn(){
        return jitsuNissuuSanteiKbn;
    }

    /**
     * プロパティー：jitsuNissuuSanteiKbn を設定します。
     * @param param  String jitsuNissuuSanteiKbn
     */
    public void setJitsuNissuuSanteiKbn(String jitsuNissuuSanteiKbn){
        this.jitsuNissuuSanteiKbn = jitsuNissuuSanteiKbn;
    }

    /**
     * プロパティー：kanjiNameChangeKbn を返します。
     * @return kanjiNameChangeKbn
     */
    public String getKanjiNameChangeKbn(){
        return kanjiNameChangeKbn;
    }

    /**
     * プロパティー：kanjiNameChangeKbn を設定します。
     * @param param  String kanjiNameChangeKbn
     */
    public void setKanjiNameChangeKbn(String kanjiNameChangeKbn){
        this.kanjiNameChangeKbn = kanjiNameChangeKbn;
    }

    /**
     * プロパティー：kanaNameChangeKbn を返します。
     * @return kanaNameChangeKbn
     */
    public String getKanaNameChangeKbn(){
        return kanaNameChangeKbn;
    }

    /**
     * プロパティー：kanaNameChangeKbn を設定します。
     * @param param  String kanaNameChangeKbn
     */
    public void setKanaNameChangeKbn(String kanaNameChangeKbn){
        this.kanaNameChangeKbn = kanaNameChangeKbn;
    }

    /**
     * プロパティー：changeDate を返します。
     * @return changeDate
     */
    public java.sql.Date getChangeDate(){
        return changeDate;
    }

    /**
     * プロパティー：changeDate を設定します。
     * @param param  java.sql.Date changeDate
     */
    public void setChangeDate(java.sql.Date changeDate){
        this.changeDate = changeDate;
    }

    /**
     * プロパティー：endDate を返します。
     * @return endDate
     */
    public java.sql.Date getEndDate(){
        return endDate;
    }

    /**
     * プロパティー：endDate を設定します。
     * @param param  java.sql.Date endDate
     */
    public void setEndDate(java.sql.Date endDate){
        this.endDate = endDate;
    }

    /**
     * プロパティー：shinryouKbn を返します。
     * @return shinryouKbn
     */
    public String getShinryouKbn(){
        return shinryouKbn;
    }

    /**
     * プロパティー：shinryouKbn を設定します。
     * @param param  String shinryouKbn
     */
    public void setShinryouKbn(String shinryouKbn){
        this.shinryouKbn = shinryouKbn;
    }

    /**
     * プロパティー：kikinSoutouMasterCode を返します。
     * @return kikinSoutouMasterCode
     */
    public String getKikinSoutouMasterCode(){
        return kikinSoutouMasterCode;
    }

    /**
     * プロパティー：kikinSoutouMasterCode を設定します。
     * @param param  String kikinSoutouMasterCode
     */
    public void setKikinSoutouMasterCode(String kikinSoutouMasterCode){
        this.kikinSoutouMasterCode = kikinSoutouMasterCode;
    }

    /**
     * プロパティー：jihiBunruiNo を返します。
     * @return jihiBunruiNo
     */
    public String getJihiBunruiNo(){
        return jihiBunruiNo;
    }

    /**
     * プロパティー：jihiBunruiNo を設定します。
     * @param param  String jihiBunruiNo
     */
    public void setJihiBunruiNo(String jihiBunruiNo){
        this.jihiBunruiNo = jihiBunruiNo;
    }

    /**
     * プロパティー：prescriptionShinryouKbn を返します。
     * @return prescriptionShinryouKbn
     */
    public String getPrescriptionShinryouKbn(){
        return prescriptionShinryouKbn;
    }

    /**
     * プロパティー：prescriptionShinryouKbn を設定します。
     * @param param  String prescriptionShinryouKbn
     */
    public void setPrescriptionShinryouKbn(String prescriptionShinryouKbn){
        this.prescriptionShinryouKbn = prescriptionShinryouKbn;
    }

    /**
     * プロパティー：isYakuzaiInfoPrint を返します。
     * @return isYakuzaiInfoPrint
     */
    public boolean getIsYakuzaiInfoPrint(){
        return isYakuzaiInfoPrint;
    }

    /**
     * プロパティー：isYakuzaiInfoPrint を設定します。
     * @param param  boolean isYakuzaiInfoPrint
     */
    public void setIsYakuzaiInfoPrint(boolean isYakuzaiInfoPrint){
        this.isYakuzaiInfoPrint = isYakuzaiInfoPrint;
    }

    /**
     * プロパティー：prescriptionInnaiPrintKbn を返します。
     * @return prescriptionInnaiPrintKbn
     */
    public String getPrescriptionInnaiPrintKbn(){
        return prescriptionInnaiPrintKbn;
    }

    /**
     * プロパティー：prescriptionInnaiPrintKbn を設定します。
     * @param param  String prescriptionInnaiPrintKbn
     */
    public void setPrescriptionInnaiPrintKbn(String prescriptionInnaiPrintKbn){
        this.prescriptionInnaiPrintKbn = prescriptionInnaiPrintKbn;
    }

    /**
     * プロパティー：prescriptionIngaiPrintKbn を返します。
     * @return prescriptionIngaiPrintKbn
     */
    public String getPrescriptionIngaiPrintKbn(){
        return prescriptionIngaiPrintKbn;
    }

    /**
     * プロパティー：prescriptionIngaiPrintKbn を設定します。
     * @param param  String prescriptionIngaiPrintKbn
     */
    public void setPrescriptionIngaiPrintKbn(String prescriptionIngaiPrintKbn){
        this.prescriptionIngaiPrintKbn = prescriptionIngaiPrintKbn;
    }

    /**
     * プロパティー：kingakuInputKbn を返します。
     * @return kingakuInputKbn
     */
    public String getKingakuInputKbn(){
        return kingakuInputKbn;
    }

    /**
     * プロパティー：kingakuInputKbn を設定します。
     * @param param  String kingakuInputKbn
     */
    public void setKingakuInputKbn(String kingakuInputKbn){
        this.kingakuInputKbn = kingakuInputKbn;
    }
}
