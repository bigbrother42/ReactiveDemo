package com.em.clinicapi.config.auth;

import com.em.clinicapi.common.constants.enumerations.ErrorEnum;
import com.em.clinicapi.common.exception.CustomAuthenticationException;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        // TODO get user from db by username
        if (!"master".equals(username)) throw new CustomAuthenticationException(
                ErrorEnum.IDAuthenticationError.value(), ErrorEnum.IDAuthenticationError.getDescription());

        // TODO password: 123456
        User user = new User(username, "$2a$08$FyZPa3/68bfKDxNr5r48we7e5QT7rTQVRw9j0dNUCG7DU3NkbV3eG", Collections.EMPTY_LIST);
        if (user != null) {
            return new CustomUserDetails(user);
        } else {
            throw new CustomAuthenticationException(
                    ErrorEnum.IDAuthenticationError.value(), ErrorEnum.IDAuthenticationError.getDescription());
        }
    }
}
