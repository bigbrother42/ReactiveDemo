package com.em.clinicapi.filter.gzip;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import java.io.IOException;
import java.io.InputStream;

public class DecompressServletInputStream extends ServletInputStream {
    private InputStream inputStream;

    public DecompressServletInputStream(InputStream input) {
        inputStream = input;
    }

    @Override
    public int read() throws IOException {
        return inputStream.read();
    }

    @Override
    public boolean isFinished() {
        return false;
    }

    @Override
    public boolean isReady() {
        return false;
    }

    @Override
    public void setReadListener(ReadListener listener) {
    }

}
