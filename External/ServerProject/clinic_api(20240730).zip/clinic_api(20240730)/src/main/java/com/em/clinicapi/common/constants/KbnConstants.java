package com.em.clinicapi.common.constants;

public class KbnConstants {
    public enum MasterType {
        /// 診療行為
        Shinryou("S"),
        /// 一般名
        Ipanmei ("I"),
        /// 医薬品
        Iyakuhin ("Y"),
        /// 特定機材
        Tokuteikizai ("T"),
        /// コメント
        Comment ("C"),
        /// 用法
        Yohou ("U"),
        /// 修飾語
        Shuushokugo ("Z"),
        /// 自費
        Jihi ("J"),
        /// 傷病名
        Shoubyoumei ("B"),
        /// 検査
        Kensa ("K"),
        /// mks画像合成マスター
        MksMaster ("M"),

        /// 未使用
        None ("None"),

        /// 結合傷病名
        Ketsugou ("KG"),

        /// 介護
        Kaigo ("KGM");
        String value;

        MasterType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    public enum JidoSanteiKbn {
        /// 自動算定項目ではない
        Nai("1"),
        /// 自動算定項目である(そのまま)
        Aru ("2"),
        /// 自動算定項目を手入力した
        Tenyuuryoku ("3"),
        /// 自動算定項目を手動削除した
        ShudouSakujo ("4"),
        /// 基本の項目を手動削除した
        KihonShudouSakujo ("5"),
        /// レセ自動算定項目
        Rezpt ("6");

        String value;

        JidoSanteiKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    public enum OrcaMasterCode {
        /// 労災特定器材商品名、ORCA、基金なし
        TokuteikizaiCodeStart09593("09593"),
        TokuteikizaiCodeStart09693 ("09693"),
        TokuteikizaiCodeStartEMT058 ("EMT058"),
        /// その他材料商品名、特定器材、ORCA、基金なし
        TokuteikizaiCodeStart059 ("059"),

        /// 診断書料
        ShinryouCodeStart09591 ("09591"),
        ShinryouCodeStart09691 ("09691"),

        /// 明細書料
        ShinryouCodeStart09592 ("09592"),
        ShinryouCodeStart09692 ("09692"),

        ///自費マスタ（消費税を計算しない）
        JihiMaster_1 ("095"),
        /// 自費マスタ（消費税を計算する）
        JihiMaster_2 ("096"),
        /// リフィル 回
        ReFillComment ("099208102");

        String value;

        OrcaMasterCode(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    public enum IngaiTouyakuKbn {
        /// 院内
        Innai("0"),

        /// 院外
        Ingai ("1");

        String value;

        IngaiTouyakuKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    /// 告示識別区分
    public enum KokujiKbn {
        /// 告示
        Kokuji("1"),
        /// 合成
        Gousei ("3"),
        /// 通知
        Tsuuchi("5"),
        /// 注加算
        Tyukasan("7"),

        /// 通則加算
        Tsusokukasan("9");

        String value;

        KokujiKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    /**
     * @Author: EMSH
     * @Description: 消費税課税区分（共通エンジン）
     */
    public enum ShouhizeiKazeiKbnCom {
        // 1：課税（外税）
        Kazei("1"),

        // 2：非課税
        Hikazei("2"),

        // 3:外税（軽減税率対象)
        KazeiKeiGenTaishou("3"),

        // 4 内税（軽減税率対象）
        NazeiKeiGenTaishou("4");
        String value;

        ShouhizeiKazeiKbnCom(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    /**
     * @Description: 消費税種別
     */
    public enum ShouhizeiType {
        // 0：通常
        Tuujyou("0"),

        // 1：食料品軽減税率
        Keigen("1");

        String value;

        ShouhizeiType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
}
