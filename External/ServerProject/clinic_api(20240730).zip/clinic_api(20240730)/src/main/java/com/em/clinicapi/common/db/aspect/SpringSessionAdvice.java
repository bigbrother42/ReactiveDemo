package com.em.clinicapi.common.db.aspect;

import com.em.clinicapi.common.cache.DbMapperContextHolder;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class SpringSessionAdvice {

    public static final String DATASOURCE_LOOKUP_KEY = "SPRING_SSSION_ADVICE";

    /**
     * Spring session の機能を用いたテーブルアクセスを行う前に実行する処理です。
     * @param joinPoint
     */
    @Before("(execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.save(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.findById(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.deleteById(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.findByIndexNameAndIndexValue(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.cleanUpExpiredSessions(..)))"
    )
    public void set(JoinPoint joinPoint) {
        DbMapperContextHolder.set(DATASOURCE_LOOKUP_KEY);
    }

    /**
     * Spring session の機能を用いたテーブルアクセスを行った後に実行する処理です。`
     */
    @After("(execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.save(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.findById(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.deleteById(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.findByIndexNameAndIndexValue(..)) || "
            + "execution(* org.springframework.session.jdbc.JdbcOperationsSessionRepository.cleanUpExpiredSessions(..)))"
    )
    public void clear() {
        DbMapperContextHolder.clear();
    }
}
