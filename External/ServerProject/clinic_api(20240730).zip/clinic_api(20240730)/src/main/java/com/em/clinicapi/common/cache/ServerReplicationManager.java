package com.em.clinicapi.common.cache;

import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.common.exception.SystemException;
import com.em.clinicapi.service.EmReplicationService;
import com.em.clinicapi.webdto.ReplicationMCustomWebDto;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import java.util.Objects;

@Component
public class ServerReplicationManager implements InitializingBean {

    private static ServerReplicationManager instance;

    @Override
    public void afterPropertiesSet() throws Exception {
        setInstance(this);
    }

    public static synchronized void setInstance(ServerReplicationManager objectInstance) {
        instance = objectInstance;
    }

    @Autowired
    private EmReplicationService replicationService;

    public static void switchReplicationByGroupIdCustomerId(Integer groupSeq, Integer customerSeq) {
        Assert.notNull(groupSeq, "GroupSeq is not defined.");
        Assert.notNull(customerSeq, "CustomerSeq is not defined.");

        clearCurrentAllReplication();

        if(Objects.nonNull(groupSeq) && Objects.nonNull(customerSeq)) {
            ReplicationMCustomWebDto replication = instance.replicationService.loadGroupCustomerReplication(groupSeq, customerSeq);
            if(replication == null){
                Assert.notNull(groupSeq, "No replication information was detected.");
                throw new InvalidRequestException("No replication information was detected.");
            }

            ReplicationMWebDto groupReplication = new ReplicationMWebDto();
            groupReplication.setCustomerId(replication.getCustomerId());
            groupReplication.setGroupId(replication.getGroupId());
            groupReplication.setReplicationId(replication.getGroupReplicationId());
            groupReplication.setReplicationName(replication.getGroupReplicationName());
            groupReplication.setConnectionUrl(replication.getGroupConnectionUrl());
            groupReplication.setDbConnectionUrl(replication.getGroupDbConnectionUrl());
            groupReplication.setDbServerInstanceId(replication.getGroupDbServerInstanceId());
            groupReplication.setDbSchemaName(replication.getGroupDbSchemaName());
            groupReplication.setIsDeleted(replication.getGroupIsDeleted());

            ReplicationMWebDto customerReplication = new ReplicationMWebDto();
            customerReplication.setCustomerId(replication.getCustomerId());
            customerReplication.setGroupId(replication.getGroupId());
            customerReplication.setReplicationId(replication.getCustomerReplicationId());
            customerReplication.setReplicationName(replication.getCustomerReplicationName());
            customerReplication.setConnectionUrl(replication.getCustomerConnectionUrl());
            customerReplication.setDbConnectionUrl(replication.getCustomerDbConnectionUrl());
            customerReplication.setDbServerInstanceId(replication.getCustomerDbServerInstanceId());
            customerReplication.setDbSchemaName(replication.getCustomerDbSchemaName());
            customerReplication.setIsDeleted(replication.getCustomerIsDeleted());

            if(!Objects.nonNull(groupReplication.getDbSchemaName()) || !Objects.nonNull(customerReplication.getDbSchemaName())){
                Assert.notNull(groupSeq, "No replication information was detected.");
            }

            switchReplication(groupReplication, customerReplication);
        }
    }
    /**
     *
     * @param groupReplication
     * @param customerReplication
     */
    public static void switchReplication(ReplicationMWebDto groupReplication, ReplicationMWebDto customerReplication) {
        if (groupReplication != null) {
            ServerReplicationContextHolder.setGroup(groupReplication);
        }
        if (customerReplication != null) {
            ServerReplicationContextHolder.setCustomer(customerReplication);
        }
    }

    /**
     *
     * @return
     */
    public static ReplicationMWebDto getCurrentGroupReplication() {
        return ServerReplicationContextHolder.getGroup();
    }

    /**
     *
     * @return
     */
    public static ReplicationMWebDto getCurrentCustomerReplication() {
        return ServerReplicationContextHolder.getCustomer();
    }

    /**
     *
     */
    public static void clearCurrentGroupReplication() {
        ServerReplicationContextHolder.clearGroup();
    }

    /**
     *
     */
    public static void clearCurrentCustomerReplication() {
        ServerReplicationContextHolder.clearCustomer();
    }

    /**
     *
     */
    public static void clearCurrentAllReplication() {
        ServerReplicationContextHolder.clearAll();
    }

}
