package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

public class NyuukinRekiWebDto  extends CustomerWebDtoBase {
    /**  プロパティ patientSeq */
    private Integer  patientSeq = null;

    /**  プロパティ hokenSeq */
    private Integer  hokenSeq = null;

    /**  プロパティ shinryouDate */
    private java.sql.Date  shinryouDate = null;

    /**  プロパティ raiinKaisuu */
    private Integer  raiinKaisuu = null;

    /**  プロパティ nyuukinDate */
    private java.sql.Date  nyuukinDate = null;

    /**  プロパティ kaikeiKaisuu */
    private Integer  kaikeiKaisuu = null;

    /**  プロパティ futanKingaku */
    private java.math.BigDecimal  futanKingaku = null;

    /**  プロパティ jihiKingaku */
    private java.math.BigDecimal  jihiKingaku = null;

    /**  プロパティ nyuukin1Type */
    private String  nyuukin1Type = null;

    /**  プロパティ nyuukin2Type */
    private String  nyuukin2Type = null;

    /**  プロパティ nyuukin3Type */
    private String  nyuukin3Type = null;

    /**  プロパティ nyuukingaku */
    private java.math.BigDecimal  nyuukingaku = null;

    /**  プロパティ nyuukin1Kingaku */
    private java.math.BigDecimal  nyuukin1Kingaku = null;

    /**  プロパティ nyuukin2Kingaku */
    private java.math.BigDecimal  nyuukin2Kingaku = null;

    /**  プロパティ nyuukin3Kingaku */
    private java.math.BigDecimal  nyuukin3Kingaku = null;

    /**  プロパティ nyuukingakuComment1 */
    private String  nyuukingakuComment1 = null;

    /**  プロパティ nyuukingakuComment2 */
    private String  nyuukingakuComment2 = null;

    /**  プロパティ nyuukingakuComment3 */
    private String  nyuukingakuComment3 = null;

    /**  プロパティ chouseiReason1 */
    private String  chouseiReason1 = null;

    /**  プロパティ chouseiReason2 */
    private String  chouseiReason2 = null;

    /**  プロパティ chouseiKingaku */
    private java.math.BigDecimal  chouseiKingaku = null;

    /**  プロパティ chousei1Kingaku */
    private java.math.BigDecimal  chousei1Kingaku = null;

    /**  プロパティ chousei2Kingaku */
    private java.math.BigDecimal  chousei2Kingaku = null;

    /**  プロパティ chouseiKingakuComment1 */
    private String  chouseiKingakuComment1 = null;

    /**  プロパティ chouseiKingakuComment2 */
    private String  chouseiKingakuComment2 = null;

    /**  プロパティ jibaisekiPatientSeikyuuKbn */
    private String  jibaisekiPatientSeikyuuKbn = null;

    /**  プロパティ teiseiNyuukinKbn */
    private String  teiseiNyuukinKbn = null;

    /**  プロパティ nyuukinTeiseiComment */
    private String  nyuukinTeiseiComment = null;

    /** プロパティ kaikeiKbn */
    private String kaikeiKbn = null;

    /**
     *  デフォルトのコンストラクタ
     */
    public NyuukinRekiWebDto()	{
        super();
    }


    /**
     * プロパティー：patientSeq を返します。
     * @return patientSeq
     */
    public Integer getPatientSeq(){
        return patientSeq;
    }
    /**
     * プロパティー：patientSeq を設定します。
     * @param  patientSeq
     */
    public void setPatientSeq(Integer patientSeq){
        this.patientSeq = patientSeq;
    }

    /**
     * プロパティー：hokenSeq を返します。
     * @return hokenSeq
     */
    public Integer getHokenSeq(){
        return hokenSeq;
    }
    /**
     * プロパティー：hokenSeq を設定します。
     * @param  hokenSeq
     */
    public void setHokenSeq(Integer hokenSeq){
        this.hokenSeq = hokenSeq;
    }

    /**
     * プロパティー：shinryouDate を返します。
     * @return shinryouDate
     */
    public java.sql.Date getShinryouDate(){
        return shinryouDate;
    }
    /**
     * プロパティー：shinryouDate を設定します。
     * @param  shinryouDate
     */
    public void setShinryouDate(java.sql.Date shinryouDate){
        this.shinryouDate = shinryouDate;
    }

    /**
     * プロパティー：raiinKaisuu を返します。
     * @return raiinKaisuu
     */
    public Integer getRaiinKaisuu(){
        return raiinKaisuu;
    }
    /**
     * プロパティー：raiinKaisuu を設定します。
     * @param  raiinKaisuu
     */
    public void setRaiinKaisuu(Integer raiinKaisuu){
        this.raiinKaisuu = raiinKaisuu;
    }

    /**
     * プロパティー：nyuukinDate を返します。
     * @return nyuukinDate
     */
    public java.sql.Date getNyuukinDate(){
        return nyuukinDate;
    }
    /**
     * プロパティー：nyuukinDate を設定します。
     * @param nyuukinDate
     */
    public void setNyuukinDate(java.sql.Date nyuukinDate){
        this.nyuukinDate = nyuukinDate;
    }

    /**
     * プロパティー：kaikeiKaisuu を返します。
     * @return kaikeiKaisuu
     */
    public Integer getKaikeiKaisuu(){
        return kaikeiKaisuu;
    }
    /**
     * プロパティー：kaikeiKaisuu を設定します。
     * @param  kaikeiKaisuu
     */
    public void setKaikeiKaisuu(Integer kaikeiKaisuu){
        this.kaikeiKaisuu = kaikeiKaisuu;
    }

    /**
     * プロパティー：futanKingaku を返します。
     * @return futanKingaku
     */
    public java.math.BigDecimal getFutanKingaku(){
        return futanKingaku;
    }
    /**
     * プロパティー：futanKingaku を設定します。
     * @param  futanKingaku
     */
    public void setFutanKingaku(java.math.BigDecimal futanKingaku){
        this.futanKingaku = futanKingaku;
    }

    /**
     * プロパティー：jihiKingaku を返します。
     * @return jihiKingaku
     */
    public java.math.BigDecimal getJihiKingaku(){
        return jihiKingaku;
    }
    /**
     * プロパティー：jihiKingaku を設定します。
     * @param jihiKingaku
     */
    public void setJihiKingaku(java.math.BigDecimal jihiKingaku){
        this.jihiKingaku = jihiKingaku;
    }

    /**
     * プロパティー：nyuukin1Type を返します。
     * @return nyuukin1Type
     */
    public String getNyuukin1Type(){
        return nyuukin1Type;
    }
    /**
     * プロパティー：nyuukin1Type を設定します。
     * @param nyuukin1Type
     */
    public void setNyuukin1Type(String nyuukin1Type){
        this.nyuukin1Type = nyuukin1Type;
    }

    /**
     * プロパティー：nyuukin2Type を返します。
     * @return nyuukin2Type
     */
    public String getNyuukin2Type(){
        return nyuukin2Type;
    }
    /**
     * プロパティー：nyuukin2Type を設定します。
     * @param nyuukin2Type
     */
    public void setNyuukin2Type(String nyuukin2Type){
        this.nyuukin2Type = nyuukin2Type;
    }

    /**
     * プロパティー：nyuukin3Type を返します。
     * @return nyuukin3Type
     */
    public String getNyuukin3Type(){
        return nyuukin3Type;
    }
    /**
     * プロパティー：nyuukin3Type を設定します。
     * @param nyuukin3Type
     */
    public void setNyuukin3Type(String nyuukin3Type){
        this.nyuukin3Type = nyuukin3Type;
    }

    /**
     * プロパティー：nyuukingaku を返します。
     * @return nyuukingaku
     */
    public java.math.BigDecimal getNyuukingaku(){
        return nyuukingaku;
    }
    /**
     * プロパティー：nyuukingaku を設定します。
     * @param nyuukingaku
     */
    public void setNyuukingaku(java.math.BigDecimal nyuukingaku){
        this.nyuukingaku = nyuukingaku;
    }

    /**
     * プロパティー：nyuukin1Kingaku を返します。
     * @return nyuukin1Kingaku
     */
    public java.math.BigDecimal getNyuukin1Kingaku(){
        return nyuukin1Kingaku;
    }
    /**
     * プロパティー：nyuukin1Kingaku を設定します。
     * @param nyuukin1Kingaku
     */
    public void setNyuukin1Kingaku(java.math.BigDecimal nyuukin1Kingaku){
        this.nyuukin1Kingaku = nyuukin1Kingaku;
    }

    /**
     * プロパティー：nyuukin2Kingaku を返します。
     * @return nyuukin2Kingaku
     */
    public java.math.BigDecimal getNyuukin2Kingaku(){
        return nyuukin2Kingaku;
    }
    /**
     * プロパティー：nyuukin2Kingaku を設定します。
     * @param  nyuukin2Kingaku
     */
    public void setNyuukin2Kingaku(java.math.BigDecimal nyuukin2Kingaku){
        this.nyuukin2Kingaku = nyuukin2Kingaku;
    }

    /**
     * プロパティー：nyuukin3Kingaku を返します。
     * @return nyuukin3Kingaku
     */
    public java.math.BigDecimal getNyuukin3Kingaku(){
        return nyuukin3Kingaku;
    }
    /**
     * プロパティー：nyuukin3Kingaku を設定します。
     * @param nyuukin3Kingaku
     */
    public void setNyuukin3Kingaku(java.math.BigDecimal nyuukin3Kingaku){
        this.nyuukin3Kingaku = nyuukin3Kingaku;
    }

    /**
     * プロパティー：nyuukingakuComment1 を返します。
     * @return nyuukingakuComment1
     */
    public String getNyuukingakuComment1(){
        return nyuukingakuComment1;
    }
    /**
     * プロパティー：nyuukingakuComment1 を設定します。
     * @param nyuukingakuComment1
     */
    public void setNyuukingakuComment1(String nyuukingakuComment1){
        this.nyuukingakuComment1 = nyuukingakuComment1;
    }

    /**
     * プロパティー：nyuukingakuComment2 を返します。
     * @return nyuukingakuComment2
     */
    public String getNyuukingakuComment2(){
        return nyuukingakuComment2;
    }
    /**
     * プロパティー：nyuukingakuComment2 を設定します。
     * @param nyuukingakuComment2
     */
    public void setNyuukingakuComment2(String nyuukingakuComment2){
        this.nyuukingakuComment2 = nyuukingakuComment2;
    }

    /**
     * プロパティー：nyuukingakuComment3 を返します。
     * @return nyuukingakuComment3
     */
    public String getNyuukingakuComment3(){
        return nyuukingakuComment3;
    }
    /**
     * プロパティー：nyuukingakuComment3 を設定します。
     * @param nyuukingakuComment3
     */
    public void setNyuukingakuComment3(String nyuukingakuComment3){
        this.nyuukingakuComment3 = nyuukingakuComment3;
    }

    /**
     * プロパティー：chouseiReason1 を返します。
     * @return chouseiReason1
     */
    public String getChouseiReason1(){
        return chouseiReason1;
    }
    /**
     * プロパティー：chouseiReason1 を設定します。
     * @param chouseiReason1
     */
    public void setChouseiReason1(String chouseiReason1){
        this.chouseiReason1 = chouseiReason1;
    }

    /**
     * プロパティー：chouseiReason2 を返します。
     * @return chouseiReason2
     */
    public String getChouseiReason2(){
        return chouseiReason2;
    }
    /**
     * プロパティー：chouseiReason2 を設定します。
     * @param chouseiReason2
     */
    public void setChouseiReason2(String chouseiReason2){
        this.chouseiReason2 = chouseiReason2;
    }

    /**
     * プロパティー：chouseiKingaku を返します。
     * @return chouseiKingaku
     */
    public java.math.BigDecimal getChouseiKingaku(){
        return chouseiKingaku;
    }
    /**
     * プロパティー：chouseiKingaku を設定します。
     * @param chouseiKingaku
     */
    public void setChouseiKingaku(java.math.BigDecimal chouseiKingaku){
        this.chouseiKingaku = chouseiKingaku;
    }

    /**
     * プロパティー：chousei1Kingaku を返します。
     * @return chousei1Kingaku
     */
    public java.math.BigDecimal getChousei1Kingaku(){
        return chousei1Kingaku;
    }
    /**
     * プロパティー：chousei1Kingaku を設定します。
     * @param chousei1Kingaku
     */
    public void setChousei1Kingaku(java.math.BigDecimal chousei1Kingaku){
        this.chousei1Kingaku = chousei1Kingaku;
    }

    /**
     * プロパティー：chousei2Kingaku を返します。
     * @return chousei2Kingaku
     */
    public java.math.BigDecimal getChousei2Kingaku(){
        return chousei2Kingaku;
    }
    /**
     * プロパティー：chousei2Kingaku を設定します。
     * @param  chousei2Kingaku
     */
    public void setChousei2Kingaku(java.math.BigDecimal chousei2Kingaku){
        this.chousei2Kingaku = chousei2Kingaku;
    }

    /**
     * プロパティー：chouseiKingakuComment1 を返します。
     * @return chouseiKingakuComment1
     */
    public String getChouseiKingakuComment1(){
        return chouseiKingakuComment1;
    }
    /**
     * プロパティー：chouseiKingakuComment1 を設定します。
     * @param chouseiKingakuComment1
     */
    public void setChouseiKingakuComment1(String chouseiKingakuComment1){
        this.chouseiKingakuComment1 = chouseiKingakuComment1;
    }

    /**
     * プロパティー：chouseiKingakuComment2 を返します。
     * @return chouseiKingakuComment2
     */
    public String getChouseiKingakuComment2(){
        return chouseiKingakuComment2;
    }
    /**
     * プロパティー：chouseiKingakuComment2 を設定します。
     * @param chouseiKingakuComment2
     */
    public void setChouseiKingakuComment2(String chouseiKingakuComment2){
        this.chouseiKingakuComment2 = chouseiKingakuComment2;
    }

    /**
     * プロパティー：jibaisekiPatientSeikyuuKbn を返します。
     * @return jibaisekiPatientSeikyuuKbn
     */
    public String getJibaisekiPatientSeikyuuKbn(){
        return jibaisekiPatientSeikyuuKbn;
    }
    /**
     * プロパティー：jibaisekiPatientSeikyuuKbn を設定します。
     * @param jibaisekiPatientSeikyuuKbn
     */
    public void setJibaisekiPatientSeikyuuKbn(String jibaisekiPatientSeikyuuKbn){
        this.jibaisekiPatientSeikyuuKbn = jibaisekiPatientSeikyuuKbn;
    }

    /**
     * プロパティー：teiseiNyuukinKbn を返します。
     * @return teiseiNyuukinKbn
     */
    public String getTeiseiNyuukinKbn(){
        return teiseiNyuukinKbn;
    }
    /**
     * プロパティー：teiseiNyuukinKbn を設定します。
     * @param teiseiNyuukinKbn
     */
    public void setTeiseiNyuukinKbn(String teiseiNyuukinKbn){
        this.teiseiNyuukinKbn = teiseiNyuukinKbn;
    }

    /**
     * プロパティー：nyuukinTeiseiComment を返します。
     * @return nyuukinTeiseiComment
     */
    public String getNyuukinTeiseiComment(){
        return nyuukinTeiseiComment;
    }
    /**
     * プロパティー：nyuukinTeiseiComment を設定します。
     * @param nyuukinTeiseiComment
     */
    public void setNyuukinTeiseiComment(String nyuukinTeiseiComment){
        this.nyuukinTeiseiComment = nyuukinTeiseiComment;
    }

    /**
     * プロパティー：kaikeiKbn を返します。
     *
     * @return kaikeiKbn
     */
    public String getKaikeiKbn() {
        return kaikeiKbn;
    }

    /**
     * プロパティー：kaikeiKbn を設定します。
     *
     * @param kaikeiKbn kaikeiKbnを設定。
     */
    public void setKaikeiKbn(String kaikeiKbn) {
        this.kaikeiKbn = kaikeiKbn;
    }
}
