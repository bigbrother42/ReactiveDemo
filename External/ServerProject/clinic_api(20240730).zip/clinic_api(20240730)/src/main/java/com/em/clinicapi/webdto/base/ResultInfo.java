package com.em.clinicapi.webdto.base;

public interface ResultInfo {

    void setInformationDate(String informationDate);
    void setInformationTime(String informationTime);
    void setApiResult(String result);
    void setApiResultMessage(String resultMessage);
}
