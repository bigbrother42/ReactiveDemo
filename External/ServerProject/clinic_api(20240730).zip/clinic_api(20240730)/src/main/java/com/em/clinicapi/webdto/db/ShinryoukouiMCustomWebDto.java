package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class ShinryoukouiMCustomWebDto extends CustomerWebDtoBase {
	private String shinryoukouiCode;
	private java.sql.Date startDate;
	private String masterType;
	private String shinryoukouiShortKanjiName;
	private String shinryoukouiShortKanaName;
	private String dataKikakuCode;
	private String dataKikakuKanjiName;
	private String tensuuShikibetsuKbn;
	private BigDecimal tensuu = BigDecimal.ZERO;
	private String nyuugaiTekiyouKbn;
	private String koukiKoureishaIryouTekiyouKbn;
	private String tensuuShuukeisakiShikibetsuNyuuingaiKbn;
	private String houkatsuTaishouKensaKbn;
	private String hospitalClinicKbn;
	private String shoubyouNameKanrenKbn;
	private String igakuKanriryou;
	private String jitsuNissuuSanteiKbn;
	private String nissuuKaisuuKbn;
	private String iyakuhinKanrenKbn;
	private String kizamiKeisanShikibetsuKbn;
	private int kizamiKagenValue;
	private int kizamiJougenValue;
	private int kizamiValue;
	private BigDecimal kizamiTensuu = BigDecimal.ZERO;
	private String kizamiJoukagenErrorProcessKbn;
	private int jougenKaisuu;
	private String jougenKaisuuErrorProcessKbn;
	private String chuukasanCode;
	private String chuukasanTsuubanKbn;
	private String tsuusokuAgeKbn;
	private String kagenAge;
	private String jougenAge;
	private String timeKasanKbn;
	private String tekigouKbn;
	private String taishouShisetsuKijunCode;
	private String shochiNyuuyoujiKasanKbn;
	private String lowShusseiTaijuujiKasanKbn;
	private String kensaJisshiHandanKbn;
	private String kensaJisshiHandanGroupKbn;
	private String teigenTaishouKbn;
	private String sekizuiYuuhatsuDeniSokuteiKasanKbn;
	private String keibuKakuseijutsuHeishiKasanKbn;
	private String autoHougoukiKasanKbn;
	private String gairaiKanriKasanKbn;
	private String kentaiKensaCommentKbn;
	private String tsuusokuKasanShoteiTensuuTaishouKbn;
	private String houkatsuTeigenKbn;
	private String chouonpaNaishikyouKasanKbn;
	private String tensuuShuukeisakiShikibetsuNyuuinKbn;
	private String autoFungoukiKasanKbn;
	private String kokujiShikibetsu1Kbn;
	private String kokujiShikibetsu2Kbn;
	private String regionKasanKbn;
	private String shisetsuKijun01Code;
	private String shisetsuKijun02Code;
	private String shisetsuKijun03Code;
	private String shisetsuKijun04Code;
	private String shisetsuKijun05Code;
	private String shisetsuKijun06Code;
	private String shisetsuKijun07Code;
	private String shisetsuKijun08Code;
	private String shisetsuKijun09Code;
	private String shisetsuKijun10Code;
	private String chouonpaGyoukoSekkaiSouchiKasanKbn;
	private String codehyouNoAlphabetPart;
	private String kokujiTsuuchiKanrenNoAlphabetPart;
	private java.sql.Date endDate;
	private String codehyouNoShou;
	private String codehyouNoPart;
	private String codehyouNoKbnNo;
	private String codehyouNoEdabanNo;
	private String codehyouNoKoubanNo;
	private String ageKasan01KagenAge;
	private String ageKasan01JougenAge;
	private String ageKasan01ChuukasanCode;
	private String ageKasan02KagenAge;
	private String ageKasan02JougenAge;
	private String ageKasan02ChuukasanCode;
	private String ageKasan03KagenAge;
	private String ageKasan03JougenAge;
	private String ageKasan03ChuukasanCode;
	private String ageKasan04KagenAge;
	private String ageKasan04JougenAge;
	private String ageKasan04ChuukasanCode;
	private String shinryouKbn;
	private String imageShindanId;
	private String tekiyouHokenKbn;
	private BigDecimal shishiKasanBairitsu = BigDecimal.ZERO;
	private BigDecimal shushiKasanBairitsu = BigDecimal.ZERO;
	private String shouenChintsuuKbn;
	private String fukubikouShujutsuNaishikyouKasan;
	private String fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan;
	private String choujikanMasuiKanriKasan;
	private String tensuuhyouKbnNo;
	private String fukushamotoShinryoukouiCode;
	private String shindanshoryouKbn;
	private String yobi124;
	private String yobi125;
	private String yobi129;
	
	/**
	*  デフォルトのコンストラクタ
	*/
	public ShinryoukouiMCustomWebDto(){
		super();
	}

    /**
     * @return ShinryoukouiCode 診療行為コード
     */
    public String getShinryoukouiCode() {
        return shinryoukouiCode;
    }
    /**
     * @param ShinryoukouiCode セットする ShinryoukouiCode 診療行為コード
     */
    public void setShinryoukouiCode(String shinryoukouiCode) {
        this.shinryoukouiCode = shinryoukouiCode;
    }
	/**
     * @return StartDate 開始年月日
     */
    public java.sql.Date getStartDate() {
        return startDate;
    }
    /**
     * @param StartDate セットする StartDate 開始年月日
     */
    public void setStartDate(java.sql.Date startDate) {
        this.startDate = startDate;
    }
	/**
     * @return MasterType マスター種別
     */
    public String getMasterType() {
        return masterType;
    }
    /**
     * @param MasterType セットする MasterType マスター種別
     */
    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }
	/**
     * @return ShinryoukouiShortKanjiName 診療行為省略漢字名
     */
    public String getShinryoukouiShortKanjiName() {
        return shinryoukouiShortKanjiName;
    }
    /**
     * @param ShinryoukouiShortKanjiName セットする ShinryoukouiShortKanjiName 診療行為省略漢字名
     */
    public void setShinryoukouiShortKanjiName(String shinryoukouiShortKanjiName) {
        this.shinryoukouiShortKanjiName = shinryoukouiShortKanjiName;
    }
	/**
     * @return ShinryoukouiShortKanaName 診療行為省略カナ名
     */
    public String getShinryoukouiShortKanaName() {
        return shinryoukouiShortKanaName;
    }
    /**
     * @param ShinryoukouiShortKanaName セットする ShinryoukouiShortKanaName 診療行為省略カナ名
     */
    public void setShinryoukouiShortKanaName(String shinryoukouiShortKanaName) {
        this.shinryoukouiShortKanaName = shinryoukouiShortKanaName;
    }
	/**
     * @return DataKikakuCode データ規格コード
     */
    public String getDataKikakuCode() {
        return dataKikakuCode;
    }
    /**
     * @param DataKikakuCode セットする DataKikakuCode データ規格コード
     */
    public void setDataKikakuCode(String dataKikakuCode) {
        this.dataKikakuCode = dataKikakuCode;
    }
	/**
     * @return DataKikakuKanjiName データ規格漢字名称
     */
    public String getDataKikakuKanjiName() {
        return dataKikakuKanjiName;
    }
    /**
     * @param DataKikakuKanjiName セットする DataKikakuKanjiName データ規格漢字名称
     */
    public void setDataKikakuKanjiName(String dataKikakuKanjiName) {
        this.dataKikakuKanjiName = dataKikakuKanjiName;
    }
	/**
     * @return TensuuShikibetsuKbn 点数識別区分
     */
    public String getTensuuShikibetsuKbn() {
        return tensuuShikibetsuKbn;
    }
    /**
     * @param TensuuShikibetsuKbn セットする TensuuShikibetsuKbn 点数識別区分
     */
    public void setTensuuShikibetsuKbn(String tensuuShikibetsuKbn) {
        this.tensuuShikibetsuKbn = tensuuShikibetsuKbn;
    }
	/**
     * @return Tensuu 点数
     */
    public BigDecimal getTensuu() {
        return tensuu;
    }
    /**
     * @param Tensuu セットする Tensuu 点数
     */
    public void setTensuu(BigDecimal tensuu) {
        this.tensuu = tensuu;
    }
	/**
     * @return NyuugaiTekiyouKbn 入外適用区分
     */
    public String getNyuugaiTekiyouKbn() {
        return nyuugaiTekiyouKbn;
    }
    /**
     * @param NyuugaiTekiyouKbn セットする NyuugaiTekiyouKbn 入外適用区分
     */
    public void setNyuugaiTekiyouKbn(String nyuugaiTekiyouKbn) {
        this.nyuugaiTekiyouKbn = nyuugaiTekiyouKbn;
    }
	/**
     * @return KoukiKoureishaIryouTekiyouKbn 後期高齢者医療適用区分
     */
    public String getKoukiKoureishaIryouTekiyouKbn() {
        return koukiKoureishaIryouTekiyouKbn;
    }
    /**
     * @param KoukiKoureishaIryouTekiyouKbn セットする KoukiKoureishaIryouTekiyouKbn 後期高齢者医療適用区分
     */
    public void setKoukiKoureishaIryouTekiyouKbn(String koukiKoureishaIryouTekiyouKbn) {
        this.koukiKoureishaIryouTekiyouKbn = koukiKoureishaIryouTekiyouKbn;
    }
	/**
     * @return TensuuShuukeisakiShikibetsuNyuuingaiKbn 点数欄集計先識別入院外区分
     */
    public String getTensuuShuukeisakiShikibetsuNyuuingaiKbn() {
        return tensuuShuukeisakiShikibetsuNyuuingaiKbn;
    }
    /**
     * @param TensuuShuukeisakiShikibetsuNyuuingaiKbn セットする TensuuShuukeisakiShikibetsuNyuuingaiKbn 点数欄集計先識別入院外区分
     */
    public void setTensuuShuukeisakiShikibetsuNyuuingaiKbn(String tensuuShuukeisakiShikibetsuNyuuingaiKbn) {
        this.tensuuShuukeisakiShikibetsuNyuuingaiKbn = tensuuShuukeisakiShikibetsuNyuuingaiKbn;
    }
	/**
     * @return HoukatsuTaishouKensaKbn 包括対象検査区分
     */
    public String getHoukatsuTaishouKensaKbn() {
        return houkatsuTaishouKensaKbn;
    }
    /**
     * @param HoukatsuTaishouKensaKbn セットする HoukatsuTaishouKensaKbn 包括対象検査区分
     */
    public void setHoukatsuTaishouKensaKbn(String houkatsuTaishouKensaKbn) {
        this.houkatsuTaishouKensaKbn = houkatsuTaishouKensaKbn;
    }
	/**
     * @return HospitalClinicKbn 病院診療所区分
     */
    public String getHospitalClinicKbn() {
        return hospitalClinicKbn;
    }
    /**
     * @param HospitalClinicKbn セットする HospitalClinicKbn 病院診療所区分
     */
    public void setHospitalClinicKbn(String hospitalClinicKbn) {
        this.hospitalClinicKbn = hospitalClinicKbn;
    }
	/**
     * @return ShoubyouNameKanrenKbn 傷病名関連区分
     */
    public String getShoubyouNameKanrenKbn() {
        return shoubyouNameKanrenKbn;
    }
    /**
     * @param ShoubyouNameKanrenKbn セットする ShoubyouNameKanrenKbn 傷病名関連区分
     */
    public void setShoubyouNameKanrenKbn(String shoubyouNameKanrenKbn) {
        this.shoubyouNameKanrenKbn = shoubyouNameKanrenKbn;
    }
	/**
     * @return IgakuKanriryou 医学管理料
     */
    public String getIgakuKanriryou() {
        return igakuKanriryou;
    }
    /**
     * @param IgakuKanriryou セットする IgakuKanriryou 医学管理料
     */
    public void setIgakuKanriryou(String igakuKanriryou) {
        this.igakuKanriryou = igakuKanriryou;
    }
	/**
     * @return JitsuNissuuSanteiKbn 実日数算定区分
     */
    public String getJitsuNissuuSanteiKbn() {
        return jitsuNissuuSanteiKbn;
    }
    /**
     * @param JitsuNissuuSanteiKbn セットする JitsuNissuuSanteiKbn 実日数算定区分
     */
    public void setJitsuNissuuSanteiKbn(String jitsuNissuuSanteiKbn) {
        this.jitsuNissuuSanteiKbn = jitsuNissuuSanteiKbn;
    }
	/**
     * @return NissuuKaisuuKbn 日数回数区分
     */
    public String getNissuuKaisuuKbn() {
        return nissuuKaisuuKbn;
    }
    /**
     * @param NissuuKaisuuKbn セットする NissuuKaisuuKbn 日数回数区分
     */
    public void setNissuuKaisuuKbn(String nissuuKaisuuKbn) {
        this.nissuuKaisuuKbn = nissuuKaisuuKbn;
    }
	/**
     * @return IyakuhinKanrenKbn 医薬品関連区分
     */
    public String getIyakuhinKanrenKbn() {
        return iyakuhinKanrenKbn;
    }
    /**
     * @param IyakuhinKanrenKbn セットする IyakuhinKanrenKbn 医薬品関連区分
     */
    public void setIyakuhinKanrenKbn(String iyakuhinKanrenKbn) {
        this.iyakuhinKanrenKbn = iyakuhinKanrenKbn;
    }
	/**
     * @return KizamiKeisanShikibetsuKbn きざみ計算識別区分
     */
    public String getKizamiKeisanShikibetsuKbn() {
        return kizamiKeisanShikibetsuKbn;
    }
    /**
     * @param KizamiKeisanShikibetsuKbn セットする KizamiKeisanShikibetsuKbn きざみ計算識別区分
     */
    public void setKizamiKeisanShikibetsuKbn(String kizamiKeisanShikibetsuKbn) {
        this.kizamiKeisanShikibetsuKbn = kizamiKeisanShikibetsuKbn;
    }
	/**
     * @return KizamiKagenValue きざみ下限値
     */
    public int getKizamiKagenValue() {
        return kizamiKagenValue;
    }
    /**
     * @param KizamiKagenValue セットする KizamiKagenValue きざみ下限値
     */
    public void setKizamiKagenValue(int kizamiKagenValue) {
        this.kizamiKagenValue = kizamiKagenValue;
    }
	/**
     * @return KizamiJougenValue きざみ上限値
     */
    public int getKizamiJougenValue() {
        return kizamiJougenValue;
    }
    /**
     * @param KizamiJougenValue セットする KizamiJougenValue きざみ上限値
     */
    public void setKizamiJougenValue(int kizamiJougenValue) {
        this.kizamiJougenValue = kizamiJougenValue;
    }
	/**
     * @return KizamiValue きざみ値
     */
    public int getKizamiValue() {
        return kizamiValue;
    }
    /**
     * @param KizamiValue セットする KizamiValue きざみ値
     */
    public void setKizamiValue(int kizamiValue) {
        this.kizamiValue = kizamiValue;
    }
	/**
     * @return KizamiTensuu きざみ点数
     */
    public BigDecimal getKizamiTensuu() {
        return kizamiTensuu;
    }
    /**
     * @param KizamiTensuu セットする KizamiTensuu きざみ点数
     */
    public void setKizamiTensuu(BigDecimal kizamiTensuu) {
        this.kizamiTensuu = kizamiTensuu;
    }
	/**
     * @return KizamiJoukagenErrorProcessKbn きざみ上下限エラー処理区分
     */
    public String getKizamiJoukagenErrorProcessKbn() {
        return kizamiJoukagenErrorProcessKbn;
    }
    /**
     * @param KizamiJoukagenErrorProcessKbn セットする KizamiJoukagenErrorProcessKbn きざみ上下限エラー処理区分
     */
    public void setKizamiJoukagenErrorProcessKbn(String kizamiJoukagenErrorProcessKbn) {
        this.kizamiJoukagenErrorProcessKbn = kizamiJoukagenErrorProcessKbn;
    }
	/**
     * @return JougenKaisuu 上限回数
     */
    public int getJougenKaisuu() {
        return jougenKaisuu;
    }
    /**
     * @param JougenKaisuu セットする JougenKaisuu 上限回数
     */
    public void setJougenKaisuu(int jougenKaisuu) {
        this.jougenKaisuu = jougenKaisuu;
    }
	/**
     * @return JougenKaisuuErrorProcessKbn 上限回数エラー処理区分
     */
    public String getJougenKaisuuErrorProcessKbn() {
        return jougenKaisuuErrorProcessKbn;
    }
    /**
     * @param JougenKaisuuErrorProcessKbn セットする JougenKaisuuErrorProcessKbn 上限回数エラー処理区分
     */
    public void setJougenKaisuuErrorProcessKbn(String jougenKaisuuErrorProcessKbn) {
        this.jougenKaisuuErrorProcessKbn = jougenKaisuuErrorProcessKbn;
    }
	/**
     * @return ChuukasanCode 注加算コード
     */
    public String getChuukasanCode() {
        return chuukasanCode;
    }
    /**
     * @param ChuukasanCode セットする ChuukasanCode 注加算コード
     */
    public void setChuukasanCode(String chuukasanCode) {
        this.chuukasanCode = chuukasanCode;
    }
	/**
     * @return ChuukasanTsuubanKbn 注加算通番区分
     */
    public String getChuukasanTsuubanKbn() {
        return chuukasanTsuubanKbn;
    }
    /**
     * @param ChuukasanTsuubanKbn セットする ChuukasanTsuubanKbn 注加算通番区分
     */
    public void setChuukasanTsuubanKbn(String chuukasanTsuubanKbn) {
        this.chuukasanTsuubanKbn = chuukasanTsuubanKbn;
    }
	/**
     * @return TsuusokuAgeKbn 通則年齢区分
     */
    public String getTsuusokuAgeKbn() {
        return tsuusokuAgeKbn;
    }
    /**
     * @param TsuusokuAgeKbn セットする TsuusokuAgeKbn 通則年齢区分
     */
    public void setTsuusokuAgeKbn(String tsuusokuAgeKbn) {
        this.tsuusokuAgeKbn = tsuusokuAgeKbn;
    }
	/**
     * @return KagenAge 下限年齢
     */
    public String getKagenAge() {
        return kagenAge;
    }
    /**
     * @param KagenAge セットする KagenAge 下限年齢
     */
    public void setKagenAge(String kagenAge) {
        this.kagenAge = kagenAge;
    }
	/**
     * @return JougenAge 上限年齢
     */
    public String getJougenAge() {
        return jougenAge;
    }
    /**
     * @param JougenAge セットする JougenAge 上限年齢
     */
    public void setJougenAge(String jougenAge) {
        this.jougenAge = jougenAge;
    }
	/**
     * @return TimeKasanKbn 時間加算区分
     */
    public String getTimeKasanKbn() {
        return timeKasanKbn;
    }
    /**
     * @param TimeKasanKbn セットする TimeKasanKbn 時間加算区分
     */
    public void setTimeKasanKbn(String timeKasanKbn) {
        this.timeKasanKbn = timeKasanKbn;
    }
	/**
     * @return TekigouKbn 適合区分
     */
    public String getTekigouKbn() {
        return tekigouKbn;
    }
    /**
     * @param TekigouKbn セットする TekigouKbn 適合区分
     */
    public void setTekigouKbn(String tekigouKbn) {
        this.tekigouKbn = tekigouKbn;
    }
	/**
     * @return TaishouShisetsuKijunCode 対象施設基準コード
     */
    public String getTaishouShisetsuKijunCode() {
        return taishouShisetsuKijunCode;
    }
    /**
     * @param TaishouShisetsuKijunCode セットする TaishouShisetsuKijunCode 対象施設基準コード
     */
    public void setTaishouShisetsuKijunCode(String taishouShisetsuKijunCode) {
        this.taishouShisetsuKijunCode = taishouShisetsuKijunCode;
    }
	/**
     * @return ShochiNyuuyoujiKasanKbn 処置乳幼児加算区分
     */
    public String getShochiNyuuyoujiKasanKbn() {
        return shochiNyuuyoujiKasanKbn;
    }
    /**
     * @param ShochiNyuuyoujiKasanKbn セットする ShochiNyuuyoujiKasanKbn 処置乳幼児加算区分
     */
    public void setShochiNyuuyoujiKasanKbn(String shochiNyuuyoujiKasanKbn) {
        this.shochiNyuuyoujiKasanKbn = shochiNyuuyoujiKasanKbn;
    }
	/**
     * @return LowShusseiTaijuujiKasanKbn 極低出生体重児加算区分
     */
    public String getLowShusseiTaijuujiKasanKbn() {
        return lowShusseiTaijuujiKasanKbn;
    }
    /**
     * @param LowShusseiTaijuujiKasanKbn セットする LowShusseiTaijuujiKasanKbn 極低出生体重児加算区分
     */
    public void setLowShusseiTaijuujiKasanKbn(String lowShusseiTaijuujiKasanKbn) {
        this.lowShusseiTaijuujiKasanKbn = lowShusseiTaijuujiKasanKbn;
    }
	/**
     * @return KensaJisshiHandanKbn 検査実施判断区分
     */
    public String getKensaJisshiHandanKbn() {
        return kensaJisshiHandanKbn;
    }
    /**
     * @param KensaJisshiHandanKbn セットする KensaJisshiHandanKbn 検査実施判断区分
     */
    public void setKensaJisshiHandanKbn(String kensaJisshiHandanKbn) {
        this.kensaJisshiHandanKbn = kensaJisshiHandanKbn;
    }
	/**
     * @return KensaJisshiHandanGroupKbn 検査実施判断グループ区分
     */
    public String getKensaJisshiHandanGroupKbn() {
        return kensaJisshiHandanGroupKbn;
    }
    /**
     * @param KensaJisshiHandanGroupKbn セットする KensaJisshiHandanGroupKbn 検査実施判断グループ区分
     */
    public void setKensaJisshiHandanGroupKbn(String kensaJisshiHandanGroupKbn) {
        this.kensaJisshiHandanGroupKbn = kensaJisshiHandanGroupKbn;
    }
	/**
     * @return TeigenTaishouKbn 逓減対象区分
     */
    public String getTeigenTaishouKbn() {
        return teigenTaishouKbn;
    }
    /**
     * @param TeigenTaishouKbn セットする TeigenTaishouKbn 逓減対象区分
     */
    public void setTeigenTaishouKbn(String teigenTaishouKbn) {
        this.teigenTaishouKbn = teigenTaishouKbn;
    }
	/**
     * @return SekizuiYuuhatsuDeniSokuteiKasanKbn 脊髄誘発電位測定加算区分
     */
    public String getSekizuiYuuhatsuDeniSokuteiKasanKbn() {
        return sekizuiYuuhatsuDeniSokuteiKasanKbn;
    }
    /**
     * @param SekizuiYuuhatsuDeniSokuteiKasanKbn セットする SekizuiYuuhatsuDeniSokuteiKasanKbn 脊髄誘発電位測定加算区分
     */
    public void setSekizuiYuuhatsuDeniSokuteiKasanKbn(String sekizuiYuuhatsuDeniSokuteiKasanKbn) {
        this.sekizuiYuuhatsuDeniSokuteiKasanKbn = sekizuiYuuhatsuDeniSokuteiKasanKbn;
    }
	/**
     * @return KeibuKakuseijutsuHeishiKasanKbn 頸部郭清術併施加算区分
     */
    public String getKeibuKakuseijutsuHeishiKasanKbn() {
        return keibuKakuseijutsuHeishiKasanKbn;
    }
    /**
     * @param KeibuKakuseijutsuHeishiKasanKbn セットする KeibuKakuseijutsuHeishiKasanKbn 頸部郭清術併施加算区分
     */
    public void setKeibuKakuseijutsuHeishiKasanKbn(String keibuKakuseijutsuHeishiKasanKbn) {
        this.keibuKakuseijutsuHeishiKasanKbn = keibuKakuseijutsuHeishiKasanKbn;
    }
	/**
     * @return AutoHougoukiKasanKbn 自動縫合器加算区分
     */
    public String getAutoHougoukiKasanKbn() {
        return autoHougoukiKasanKbn;
    }
    /**
     * @param AutoHougoukiKasanKbn セットする AutoHougoukiKasanKbn 自動縫合器加算区分
     */
    public void setAutoHougoukiKasanKbn(String autoHougoukiKasanKbn) {
        this.autoHougoukiKasanKbn = autoHougoukiKasanKbn;
    }
	/**
     * @return GairaiKanriKasanKbn 外来管理加算区分
     */
    public String getGairaiKanriKasanKbn() {
        return gairaiKanriKasanKbn;
    }
    /**
     * @param GairaiKanriKasanKbn セットする GairaiKanriKasanKbn 外来管理加算区分
     */
    public void setGairaiKanriKasanKbn(String gairaiKanriKasanKbn) {
        this.gairaiKanriKasanKbn = gairaiKanriKasanKbn;
    }
	/**
     * @return KentaiKensaCommentKbn 検体検査コメント区分
     */
    public String getKentaiKensaCommentKbn() {
        return kentaiKensaCommentKbn;
    }
    /**
     * @param KentaiKensaCommentKbn セットする KentaiKensaCommentKbn 検体検査コメント区分
     */
    public void setKentaiKensaCommentKbn(String kentaiKensaCommentKbn) {
        this.kentaiKensaCommentKbn = kentaiKensaCommentKbn;
    }
	/**
     * @return TsuusokuKasanShoteiTensuuTaishouKbn 通則加算所定点数対象区分
     */
    public String getTsuusokuKasanShoteiTensuuTaishouKbn() {
        return tsuusokuKasanShoteiTensuuTaishouKbn;
    }
    /**
     * @param TsuusokuKasanShoteiTensuuTaishouKbn セットする TsuusokuKasanShoteiTensuuTaishouKbn 通則加算所定点数対象区分
     */
    public void setTsuusokuKasanShoteiTensuuTaishouKbn(String tsuusokuKasanShoteiTensuuTaishouKbn) {
        this.tsuusokuKasanShoteiTensuuTaishouKbn = tsuusokuKasanShoteiTensuuTaishouKbn;
    }
	/**
     * @return HoukatsuTeigenKbn 包括逓減区分
     */
    public String getHoukatsuTeigenKbn() {
        return houkatsuTeigenKbn;
    }
    /**
     * @param HoukatsuTeigenKbn セットする HoukatsuTeigenKbn 包括逓減区分
     */
    public void setHoukatsuTeigenKbn(String houkatsuTeigenKbn) {
        this.houkatsuTeigenKbn = houkatsuTeigenKbn;
    }
	/**
     * @return ChouonpaNaishikyouKasanKbn 超音波内視鏡加算区分
     */
    public String getChouonpaNaishikyouKasanKbn() {
        return chouonpaNaishikyouKasanKbn;
    }
    /**
     * @param ChouonpaNaishikyouKasanKbn セットする ChouonpaNaishikyouKasanKbn 超音波内視鏡加算区分
     */
    public void setChouonpaNaishikyouKasanKbn(String chouonpaNaishikyouKasanKbn) {
        this.chouonpaNaishikyouKasanKbn = chouonpaNaishikyouKasanKbn;
    }
	/**
     * @return TensuuShuukeisakiShikibetsuNyuuinKbn 点数欄集計先識別入院区分
     */
    public String getTensuuShuukeisakiShikibetsuNyuuinKbn() {
        return tensuuShuukeisakiShikibetsuNyuuinKbn;
    }
    /**
     * @param TensuuShuukeisakiShikibetsuNyuuinKbn セットする TensuuShuukeisakiShikibetsuNyuuinKbn 点数欄集計先識別入院区分
     */
    public void setTensuuShuukeisakiShikibetsuNyuuinKbn(String tensuuShuukeisakiShikibetsuNyuuinKbn) {
        this.tensuuShuukeisakiShikibetsuNyuuinKbn = tensuuShuukeisakiShikibetsuNyuuinKbn;
    }
	/**
     * @return AutoFungoukiKasanKbn 自動吻合器加算区分
     */
    public String getAutoFungoukiKasanKbn() {
        return autoFungoukiKasanKbn;
    }
    /**
     * @param AutoFungoukiKasanKbn セットする AutoFungoukiKasanKbn 自動吻合器加算区分
     */
    public void setAutoFungoukiKasanKbn(String autoFungoukiKasanKbn) {
        this.autoFungoukiKasanKbn = autoFungoukiKasanKbn;
    }
	/**
     * @return KokujiShikibetsu1Kbn 告示識別1区分
     */
    public String getKokujiShikibetsu1Kbn() {
        return kokujiShikibetsu1Kbn;
    }
    /**
     * @param KokujiShikibetsu1Kbn セットする KokujiShikibetsu1Kbn 告示識別1区分
     */
    public void setKokujiShikibetsu1Kbn(String kokujiShikibetsu1Kbn) {
        this.kokujiShikibetsu1Kbn = kokujiShikibetsu1Kbn;
    }
	/**
     * @return KokujiShikibetsu2Kbn 告示識別2区分
     */
    public String getKokujiShikibetsu2Kbn() {
        return kokujiShikibetsu2Kbn;
    }
    /**
     * @param KokujiShikibetsu2Kbn セットする KokujiShikibetsu2Kbn 告示識別2区分
     */
    public void setKokujiShikibetsu2Kbn(String kokujiShikibetsu2Kbn) {
        this.kokujiShikibetsu2Kbn = kokujiShikibetsu2Kbn;
    }
	/**
     * @return RegionKasanKbn 地域加算区分
     */
    public String getRegionKasanKbn() {
        return regionKasanKbn;
    }
    /**
     * @param RegionKasanKbn セットする RegionKasanKbn 地域加算区分
     */
    public void setRegionKasanKbn(String regionKasanKbn) {
        this.regionKasanKbn = regionKasanKbn;
    }
	/**
     * @return ShisetsuKijun01Code 施設基準01コード
     */
    public String getShisetsuKijun01Code() {
        return shisetsuKijun01Code;
    }
    /**
     * @param ShisetsuKijun01Code セットする ShisetsuKijun01Code 施設基準01コード
     */
    public void setShisetsuKijun01Code(String shisetsuKijun01Code) {
        this.shisetsuKijun01Code = shisetsuKijun01Code;
    }
	/**
     * @return ShisetsuKijun02Code 施設基準02コード
     */
    public String getShisetsuKijun02Code() {
        return shisetsuKijun02Code;
    }
    /**
     * @param ShisetsuKijun02Code セットする ShisetsuKijun02Code 施設基準02コード
     */
    public void setShisetsuKijun02Code(String shisetsuKijun02Code) {
        this.shisetsuKijun02Code = shisetsuKijun02Code;
    }
	/**
     * @return ShisetsuKijun03Code 施設基準03コード
     */
    public String getShisetsuKijun03Code() {
        return shisetsuKijun03Code;
    }
    /**
     * @param ShisetsuKijun03Code セットする ShisetsuKijun03Code 施設基準03コード
     */
    public void setShisetsuKijun03Code(String shisetsuKijun03Code) {
        this.shisetsuKijun03Code = shisetsuKijun03Code;
    }
	/**
     * @return ShisetsuKijun04Code 施設基準04コード
     */
    public String getShisetsuKijun04Code() {
        return shisetsuKijun04Code;
    }
    /**
     * @param ShisetsuKijun04Code セットする ShisetsuKijun04Code 施設基準04コード
     */
    public void setShisetsuKijun04Code(String shisetsuKijun04Code) {
        this.shisetsuKijun04Code = shisetsuKijun04Code;
    }
	/**
     * @return ShisetsuKijun05Code 施設基準05コード
     */
    public String getShisetsuKijun05Code() {
        return shisetsuKijun05Code;
    }
    /**
     * @param ShisetsuKijun05Code セットする ShisetsuKijun05Code 施設基準05コード
     */
    public void setShisetsuKijun05Code(String shisetsuKijun05Code) {
        this.shisetsuKijun05Code = shisetsuKijun05Code;
    }
	/**
     * @return ShisetsuKijun06Code 施設基準06コード
     */
    public String getShisetsuKijun06Code() {
        return shisetsuKijun06Code;
    }
    /**
     * @param ShisetsuKijun06Code セットする ShisetsuKijun06Code 施設基準06コード
     */
    public void setShisetsuKijun06Code(String shisetsuKijun06Code) {
        this.shisetsuKijun06Code = shisetsuKijun06Code;
    }
	/**
     * @return ShisetsuKijun07Code 施設基準07コード
     */
    public String getShisetsuKijun07Code() {
        return shisetsuKijun07Code;
    }
    /**
     * @param ShisetsuKijun07Code セットする ShisetsuKijun07Code 施設基準07コード
     */
    public void setShisetsuKijun07Code(String shisetsuKijun07Code) {
        this.shisetsuKijun07Code = shisetsuKijun07Code;
    }
	/**
     * @return ShisetsuKijun08Code 施設基準08コード
     */
    public String getShisetsuKijun08Code() {
        return shisetsuKijun08Code;
    }
    /**
     * @param ShisetsuKijun08Code セットする ShisetsuKijun08Code 施設基準08コード
     */
    public void setShisetsuKijun08Code(String shisetsuKijun08Code) {
        this.shisetsuKijun08Code = shisetsuKijun08Code;
    }
	/**
     * @return ShisetsuKijun09Code 施設基準09コード
     */
    public String getShisetsuKijun09Code() {
        return shisetsuKijun09Code;
    }
    /**
     * @param ShisetsuKijun09Code セットする ShisetsuKijun09Code 施設基準09コード
     */
    public void setShisetsuKijun09Code(String shisetsuKijun09Code) {
        this.shisetsuKijun09Code = shisetsuKijun09Code;
    }
	/**
     * @return ShisetsuKijun10Code 施設基準10コード
     */
    public String getShisetsuKijun10Code() {
        return shisetsuKijun10Code;
    }
    /**
     * @param ShisetsuKijun10Code セットする ShisetsuKijun10Code 施設基準10コード
     */
    public void setShisetsuKijun10Code(String shisetsuKijun10Code) {
        this.shisetsuKijun10Code = shisetsuKijun10Code;
    }
	/**
     * @return ChouonpaGyoukoSekkaiSouchiKasanKbn 超音波凝固切開装置加算区分
     */
    public String getChouonpaGyoukoSekkaiSouchiKasanKbn() {
        return chouonpaGyoukoSekkaiSouchiKasanKbn;
    }
    /**
     * @param ChouonpaGyoukoSekkaiSouchiKasanKbn セットする ChouonpaGyoukoSekkaiSouchiKasanKbn 超音波凝固切開装置加算区分
     */
    public void setChouonpaGyoukoSekkaiSouchiKasanKbn(String chouonpaGyoukoSekkaiSouchiKasanKbn) {
        this.chouonpaGyoukoSekkaiSouchiKasanKbn = chouonpaGyoukoSekkaiSouchiKasanKbn;
    }
	/**
     * @return CodehyouNoAlphabetPart コード表用番号アルファベット部
     */
    public String getCodehyouNoAlphabetPart() {
        return codehyouNoAlphabetPart;
    }
    /**
     * @param CodehyouNoAlphabetPart セットする CodehyouNoAlphabetPart コード表用番号アルファベット部
     */
    public void setCodehyouNoAlphabetPart(String codehyouNoAlphabetPart) {
        this.codehyouNoAlphabetPart = codehyouNoAlphabetPart;
    }
	/**
     * @return KokujiTsuuchiKanrenNoAlphabetPart 告示通知関連番号アルファベット部
     */
    public String getKokujiTsuuchiKanrenNoAlphabetPart() {
        return kokujiTsuuchiKanrenNoAlphabetPart;
    }
    /**
     * @param KokujiTsuuchiKanrenNoAlphabetPart セットする KokujiTsuuchiKanrenNoAlphabetPart 告示通知関連番号アルファベット部
     */
    public void setKokujiTsuuchiKanrenNoAlphabetPart(String kokujiTsuuchiKanrenNoAlphabetPart) {
        this.kokujiTsuuchiKanrenNoAlphabetPart = kokujiTsuuchiKanrenNoAlphabetPart;
    }
	/**
     * @return EndDate 終了年月日
     */
    public java.sql.Date getEndDate() {
        return endDate;
    }
    /**
     * @param EndDate セットする EndDate 終了年月日
     */
    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }
	/**
     * @return CodehyouNoShou コード表用番号章
     */
    public String getCodehyouNoShou() {
        return codehyouNoShou;
    }
    /**
     * @param CodehyouNoShou セットする CodehyouNoShou コード表用番号章
     */
    public void setCodehyouNoShou(String codehyouNoShou) {
        this.codehyouNoShou = codehyouNoShou;
    }
	/**
     * @return CodehyouNoPart コード表用番号部
     */
    public String getCodehyouNoPart() {
        return codehyouNoPart;
    }
    /**
     * @param CodehyouNoPart セットする CodehyouNoPart コード表用番号部
     */
    public void setCodehyouNoPart(String codehyouNoPart) {
        this.codehyouNoPart = codehyouNoPart;
    }
	/**
     * @return CodehyouNoKbnNo コード表用番号区分番号
     */
    public String getCodehyouNoKbnNo() {
        return codehyouNoKbnNo;
    }
    /**
     * @param CodehyouNoKbnNo セットする CodehyouNoKbnNo コード表用番号区分番号
     */
    public void setCodehyouNoKbnNo(String codehyouNoKbnNo) {
        this.codehyouNoKbnNo = codehyouNoKbnNo;
    }
	/**
     * @return CodehyouNoEdabanNo コード表用番号枝番
     */
    public String getCodehyouNoEdabanNo() {
        return codehyouNoEdabanNo;
    }
    /**
     * @param CodehyouNoEdabanNo セットする CodehyouNoEdabanNo コード表用番号枝番
     */
    public void setCodehyouNoEdabanNo(String codehyouNoEdabanNo) {
        this.codehyouNoEdabanNo = codehyouNoEdabanNo;
    }
	/**
     * @return CodehyouNoKoubanNo コード表用番号項番
     */
    public String getCodehyouNoKoubanNo() {
        return codehyouNoKoubanNo;
    }
    /**
     * @param CodehyouNoKoubanNo セットする CodehyouNoKoubanNo コード表用番号項番
     */
    public void setCodehyouNoKoubanNo(String codehyouNoKoubanNo) {
        this.codehyouNoKoubanNo = codehyouNoKoubanNo;
    }
	/**
     * @return AgeKasan01KagenAge 年齢加算01下限年齢
     */
    public String getAgeKasan01KagenAge() {
        return ageKasan01KagenAge;
    }
    /**
     * @param AgeKasan01KagenAge セットする AgeKasan01KagenAge 年齢加算01下限年齢
     */
    public void setAgeKasan01KagenAge(String ageKasan01KagenAge) {
        this.ageKasan01KagenAge = ageKasan01KagenAge;
    }
	/**
     * @return AgeKasan01JougenAge 年齢加算01上限年齢
     */
    public String getAgeKasan01JougenAge() {
        return ageKasan01JougenAge;
    }
    /**
     * @param AgeKasan01JougenAge セットする AgeKasan01JougenAge 年齢加算01上限年齢
     */
    public void setAgeKasan01JougenAge(String ageKasan01JougenAge) {
        this.ageKasan01JougenAge = ageKasan01JougenAge;
    }
	/**
     * @return AgeKasan01ChuukasanCode 年齢加算01注加算コード
     */
    public String getAgeKasan01ChuukasanCode() {
        return ageKasan01ChuukasanCode;
    }
    /**
     * @param AgeKasan01ChuukasanCode セットする AgeKasan01ChuukasanCode 年齢加算01注加算コード
     */
    public void setAgeKasan01ChuukasanCode(String ageKasan01ChuukasanCode) {
        this.ageKasan01ChuukasanCode = ageKasan01ChuukasanCode;
    }
	/**
     * @return AgeKasan02KagenAge 年齢加算02下限年齢
     */
    public String getAgeKasan02KagenAge() {
        return ageKasan02KagenAge;
    }
    /**
     * @param AgeKasan02KagenAge セットする AgeKasan02KagenAge 年齢加算02下限年齢
     */
    public void setAgeKasan02KagenAge(String ageKasan02KagenAge) {
        this.ageKasan02KagenAge = ageKasan02KagenAge;
    }
	/**
     * @return AgeKasan02JougenAge 年齢加算02上限年齢
     */
    public String getAgeKasan02JougenAge() {
        return ageKasan02JougenAge;
    }
    /**
     * @param AgeKasan02JougenAge セットする AgeKasan02JougenAge 年齢加算02上限年齢
     */
    public void setAgeKasan02JougenAge(String ageKasan02JougenAge) {
        this.ageKasan02JougenAge = ageKasan02JougenAge;
    }
	/**
     * @return AgeKasan02ChuukasanCode 年齢加算02注加算コード
     */
    public String getAgeKasan02ChuukasanCode() {
        return ageKasan02ChuukasanCode;
    }
    /**
     * @param AgeKasan02ChuukasanCode セットする AgeKasan02ChuukasanCode 年齢加算02注加算コード
     */
    public void setAgeKasan02ChuukasanCode(String ageKasan02ChuukasanCode) {
        this.ageKasan02ChuukasanCode = ageKasan02ChuukasanCode;
    }
	/**
     * @return AgeKasan03KagenAge 年齢加算03下限年齢
     */
    public String getAgeKasan03KagenAge() {
        return ageKasan03KagenAge;
    }
    /**
     * @param AgeKasan03KagenAge セットする AgeKasan03KagenAge 年齢加算03下限年齢
     */
    public void setAgeKasan03KagenAge(String ageKasan03KagenAge) {
        this.ageKasan03KagenAge = ageKasan03KagenAge;
    }
	/**
     * @return AgeKasan03JougenAge 年齢加算03上限年齢
     */
    public String getAgeKasan03JougenAge() {
        return ageKasan03JougenAge;
    }
    /**
     * @param AgeKasan03JougenAge セットする AgeKasan03JougenAge 年齢加算03上限年齢
     */
    public void setAgeKasan03JougenAge(String ageKasan03JougenAge) {
        this.ageKasan03JougenAge = ageKasan03JougenAge;
    }
	/**
     * @return AgeKasan03ChuukasanCode 年齢加算03注加算コード
     */
    public String getAgeKasan03ChuukasanCode() {
        return ageKasan03ChuukasanCode;
    }
    /**
     * @param AgeKasan03ChuukasanCode セットする AgeKasan03ChuukasanCode 年齢加算03注加算コード
     */
    public void setAgeKasan03ChuukasanCode(String ageKasan03ChuukasanCode) {
        this.ageKasan03ChuukasanCode = ageKasan03ChuukasanCode;
    }
	/**
     * @return AgeKasan04KagenAge 年齢加算04下限年齢
     */
    public String getAgeKasan04KagenAge() {
        return ageKasan04KagenAge;
    }
    /**
     * @param AgeKasan04KagenAge セットする AgeKasan04KagenAge 年齢加算04下限年齢
     */
    public void setAgeKasan04KagenAge(String ageKasan04KagenAge) {
        this.ageKasan04KagenAge = ageKasan04KagenAge;
    }
	/**
     * @return AgeKasan04JougenAge 年齢加算04上限年齢
     */
    public String getAgeKasan04JougenAge() {
        return ageKasan04JougenAge;
    }
    /**
     * @param AgeKasan04JougenAge セットする AgeKasan04JougenAge 年齢加算04上限年齢
     */
    public void setAgeKasan04JougenAge(String ageKasan04JougenAge) {
        this.ageKasan04JougenAge = ageKasan04JougenAge;
    }
	/**
     * @return AgeKasan04ChuukasanCode 年齢加算04注加算コード
     */
    public String getAgeKasan04ChuukasanCode() {
        return ageKasan04ChuukasanCode;
    }
    /**
     * @param AgeKasan04ChuukasanCode セットする AgeKasan04ChuukasanCode 年齢加算04注加算コード
     */
    public void setAgeKasan04ChuukasanCode(String ageKasan04ChuukasanCode) {
        this.ageKasan04ChuukasanCode = ageKasan04ChuukasanCode;
    }
	/**
     * @return ShinryouKbn 診療区分
     */
    public String getShinryouKbn() {
        return shinryouKbn;
    }
    /**
     * @param ShinryouKbn セットする ShinryouKbn 診療区分
     */
    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }
	/**
     * @return ImageShindanId イメージ診断ID
     */
    public String getImageShindanId() {
        return imageShindanId;
    }
    /**
     * @param ImageShindanId セットする ImageShindanId イメージ診断ID
     */
    public void setImageShindanId(String imageShindanId) {
        this.imageShindanId = imageShindanId;
    }
	/**
     * @return TekiyouHokenKbn 適用保険区分
     */
    public String getTekiyouHokenKbn() {
        return tekiyouHokenKbn;
    }
    /**
     * @param TekiyouHokenKbn セットする TekiyouHokenKbn 適用保険区分
     */
    public void setTekiyouHokenKbn(String tekiyouHokenKbn) {
        this.tekiyouHokenKbn = tekiyouHokenKbn;
    }
	/**
     * @return ShishiKasanBairitsu 四肢加算倍率
     */
    public BigDecimal getShishiKasanBairitsu() {
        return shishiKasanBairitsu;
    }
    /**
     * @param ShishiKasanBairitsu セットする ShishiKasanBairitsu 四肢加算倍率
     */
    public void setShishiKasanBairitsu(BigDecimal shishiKasanBairitsu) {
        this.shishiKasanBairitsu = shishiKasanBairitsu;
    }
	/**
     * @return ShushiKasanBairitsu 手指加算倍率
     */
    public BigDecimal getShushiKasanBairitsu() {
        return shushiKasanBairitsu;
    }
    /**
     * @param ShushiKasanBairitsu セットする ShushiKasanBairitsu 手指加算倍率
     */
    public void setShushiKasanBairitsu(BigDecimal shushiKasanBairitsu) {
        this.shushiKasanBairitsu = shushiKasanBairitsu;
    }
	/**
     * @return ShouenChintsuuKbn 消炎鎮痛区分
     */
    public String getShouenChintsuuKbn() {
        return shouenChintsuuKbn;
    }
    /**
     * @param ShouenChintsuuKbn セットする ShouenChintsuuKbn 消炎鎮痛区分
     */
    public void setShouenChintsuuKbn(String shouenChintsuuKbn) {
        this.shouenChintsuuKbn = shouenChintsuuKbn;
    }
	/**
     * @return FukubikouShujutsuNaishikyouKasan 副鼻腔手術用内視鏡加算
     */
    public String getFukubikouShujutsuNaishikyouKasan() {
        return fukubikouShujutsuNaishikyouKasan;
    }
    /**
     * @param FukubikouShujutsuNaishikyouKasan セットする FukubikouShujutsuNaishikyouKasan 副鼻腔手術用内視鏡加算
     */
    public void setFukubikouShujutsuNaishikyouKasan(String fukubikouShujutsuNaishikyouKasan) {
        this.fukubikouShujutsuNaishikyouKasan = fukubikouShujutsuNaishikyouKasan;
    }
	/**
     * @return FukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan 副鼻腔手術用骨軟部組織切除機器加算
     */
    public String getFukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan() {
        return fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan;
    }
    /**
     * @param FukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan セットする FukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan 副鼻腔手術用骨軟部組織切除機器加算
     */
    public void setFukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan(String fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan) {
        this.fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan = fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan;
    }
	/**
     * @return ChoujikanMasuiKanriKasan 長時間麻酔管理加算
     */
    public String getChoujikanMasuiKanriKasan() {
        return choujikanMasuiKanriKasan;
    }
    /**
     * @param ChoujikanMasuiKanriKasan セットする ChoujikanMasuiKanriKasan 長時間麻酔管理加算
     */
    public void setChoujikanMasuiKanriKasan(String choujikanMasuiKanriKasan) {
        this.choujikanMasuiKanriKasan = choujikanMasuiKanriKasan;
    }
	/**
     * @return TensuuhyouKbnNo 点数表区分番号
     */
    public String getTensuuhyouKbnNo() {
        return tensuuhyouKbnNo;
    }
    /**
     * @param TensuuhyouKbnNo セットする TensuuhyouKbnNo 点数表区分番号
     */
    public void setTensuuhyouKbnNo(String tensuuhyouKbnNo) {
        this.tensuuhyouKbnNo = tensuuhyouKbnNo;
    }
	/**
     * @return FukushamotoShinryoukouiCode 複写元診療行為コード
     */
    public String getFukushamotoShinryoukouiCode() {
        return fukushamotoShinryoukouiCode;
    }
    /**
     * @param FukushamotoShinryoukouiCode セットする FukushamotoShinryoukouiCode 複写元診療行為コード
     */
    public void setFukushamotoShinryoukouiCode(String fukushamotoShinryoukouiCode) {
        this.fukushamotoShinryoukouiCode = fukushamotoShinryoukouiCode;
    }
	/**
     * @return ShindanshoryouKbn 診断書料区分
     */
    public String getShindanshoryouKbn() {
        return shindanshoryouKbn;
    }
    /**
     * @param ShindanshoryouKbn セットする ShindanshoryouKbn 診断書料区分
     */
    public void setShindanshoryouKbn(String shindanshoryouKbn) {
        this.shindanshoryouKbn = shindanshoryouKbn;
    }
	/**
     * @return Yobi124 予備124(外来感染対策向上加算等)
     */
    public String getYobi124() {
        return yobi124;
    }
    /**
     * @param Yobi124 セットする Yobi124 予備124(外来感染対策向上加算等)
     */
    public void setYobi124(String yobi124) {
        this.yobi124 = yobi124;
    }
	/**
     * @return Yobi125 予備125(耳鼻咽喉科乳幼児処置加算)
     */
    public String getYobi125() {
        return yobi125;
    }
    /**
     * @param Yobi125 セットする Yobi125 予備125(耳鼻咽喉科乳幼児処置加算)
     */
    public void setYobi125(String yobi125) {
        this.yobi125 = yobi125;
    }
	/**
     * @return Yobi129 予備129(外来・在宅ベースアップ評価料(1))
     */
    public String getYobi129() {
        return yobi129;
    }
    /**
     * @param Yobi129 セットする Yobi129 予備129(外来・在宅ベースアップ評価料(1))
     */
    public void setYobi129(String yobi129) {
        this.yobi129 = yobi129;
    }
	
}
