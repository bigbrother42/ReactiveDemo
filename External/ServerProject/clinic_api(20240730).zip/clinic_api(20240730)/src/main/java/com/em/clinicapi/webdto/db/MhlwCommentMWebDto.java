package com.em.clinicapi.webdto.db;

import java.sql.Date;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class MhlwCommentMWebDto extends CustomerWebDtoBase {
    private String commentCode = null;
    private Date startDate = null;
    private String changeKbn = null;
    private String masterType = null;
    private int commentKanjiValidCharCount = 0;
    private String commentKanjiName = null;
    private int commentKanaValidCharCount = 0;
    private String commentKanaName = null;
    private int column1Pos = 0;
    private int charCount1 = 0;
    private int column2Pos = 0;
    private int charCount2 = 0;
    private int column3Pos = 0;
    private int charCount3 = 0;
    private int column4Pos = 0;
    private int charCount4 = 0;
    private String yobi1 = null;
    private String yobi2 = null;
    private Date changeDate = null;
    private Date endDate = null;
    private String shinryouKbn = null;
    private String commentKbn = null;
    private String kikinSoutouMasterCode = null;
    private String kouhyouOrderNo = null;

    public MhlwCommentMWebDto() {
    }

    public String getCommentCode() {
        return this.commentCode;
    }

    public void setCommentCode(String commentCode) {
        this.commentCode = commentCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getChangeKbn() {
        return this.changeKbn;
    }

    public void setChangeKbn(String changeKbn) {
        this.changeKbn = changeKbn;
    }

    public String getMasterType() {
        return this.masterType;
    }

    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }

    public int getCommentKanjiValidCharCount() {
        return this.commentKanjiValidCharCount;
    }

    public void setCommentKanjiValidCharCount(int commentKanjiValidCharCount) {
        this.commentKanjiValidCharCount = commentKanjiValidCharCount;
    }

    public String getCommentKanjiName() {
        return this.commentKanjiName;
    }

    public void setCommentKanjiName(String commentKanjiName) {
        this.commentKanjiName = commentKanjiName;
    }

    public int getCommentKanaValidCharCount() {
        return this.commentKanaValidCharCount;
    }

    public void setCommentKanaValidCharCount(int commentKanaValidCharCount) {
        this.commentKanaValidCharCount = commentKanaValidCharCount;
    }

    public String getCommentKanaName() {
        return this.commentKanaName;
    }

    public void setCommentKanaName(String commentKanaName) {
        this.commentKanaName = commentKanaName;
    }

    public int getColumn1Pos() {
        return this.column1Pos;
    }

    public void setColumn1Pos(int column1Pos) {
        this.column1Pos = column1Pos;
    }

    public int getCharCount1() {
        return this.charCount1;
    }

    public void setCharCount1(int charCount1) {
        this.charCount1 = charCount1;
    }

    public int getColumn2Pos() {
        return this.column2Pos;
    }

    public void setColumn2Pos(int column2Pos) {
        this.column2Pos = column2Pos;
    }

    public int getCharCount2() {
        return this.charCount2;
    }

    public void setCharCount2(int charCount2) {
        this.charCount2 = charCount2;
    }

    public int getColumn3Pos() {
        return this.column3Pos;
    }

    public void setColumn3Pos(int column3Pos) {
        this.column3Pos = column3Pos;
    }

    public int getCharCount3() {
        return this.charCount3;
    }

    public void setCharCount3(int charCount3) {
        this.charCount3 = charCount3;
    }

    public int getColumn4Pos() {
        return this.column4Pos;
    }

    public void setColumn4Pos(int column4Pos) {
        this.column4Pos = column4Pos;
    }

    public int getCharCount4() {
        return this.charCount4;
    }

    public void setCharCount4(int charCount4) {
        this.charCount4 = charCount4;
    }

    public String getYobi1() {
        return this.yobi1;
    }

    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    public String getYobi2() {
        return this.yobi2;
    }

    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getShinryouKbn() {
        return this.shinryouKbn;
    }

    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }

    public String getCommentKbn() {
        return this.commentKbn;
    }

    public void setCommentKbn(String commentKbn) {
        this.commentKbn = commentKbn;
    }

    public String getKikinSoutouMasterCode() {
        return this.kikinSoutouMasterCode;
    }

    public void setKikinSoutouMasterCode(String kikinSoutouMasterCode) {
        this.kikinSoutouMasterCode = kikinSoutouMasterCode;
    }

    public String getKouhyouOrderNo() {
        return this.kouhyouOrderNo;
    }

    public void setKouhyouOrderNo(String kouhyouOrderNo) {
        this.kouhyouOrderNo = kouhyouOrderNo;
    }
}
