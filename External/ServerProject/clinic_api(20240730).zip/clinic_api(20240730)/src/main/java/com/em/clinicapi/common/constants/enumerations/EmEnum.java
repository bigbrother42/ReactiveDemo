package com.em.clinicapi.common.constants.enumerations;

import java.util.Arrays;

public class EmEnum {
    // マスタータイプ
    public enum MasterType {
        // 診療行為
        Shinryou("S"),
        // 一般名
        Ippanmei("I"),
        // 医薬品
        Iyakuhin("Y"),
        // 特定機材
        Tokuteikizai("T"),
        // コメント
        Comment("C"),
        // 用法
        Youhou("U"),
        // 修飾語
        Shuushokugo("Z"),
        //mks画像合成マスター
        MksMaster("M"),
        // 自費
        Jihi("J"),
        // 傷病名
        Shoubyoumei("B"),
        // 検査
        Kensa("K"),
        // 介護マスター　
        // 20220929 63959 qishiyun add
        KaigoMaster("KGM"),
        // 未使用
        None("None");

        String value;

        MasterType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum TenkiKbn {
        // なし
        None("0"),
        // 治ゆ
        Cure("2"),
        // 転医
        Transfer("5"),
        // 中止
        Stop("4"),
        // 死亡
        Dead("3");

        String value;

        TenkiKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum TenkiKbnForRegister {
        // なし
        None("0",""),
        // 治ゆ
        Cure("2","治ゆ"),
        // 転医
        Transfer("5","転医"),
        // 中止
        Stop("4","中止"),
        // 死亡
        Dead("3","死亡");

        private final String code;
        private final String description;

        TenkiKbnForRegister(String code, String description) {
            this.code = code;
            this.description = description;
        }

        public String getCode() {
            return code;
        }

        public String getDescription() {
            return description;
        }

        public static TenkiSpecialKbnForRegister getByCode(String code) {
            for (TenkiSpecialKbnForRegister enumValue : TenkiSpecialKbnForRegister.values()) {
                if (enumValue.getCode() == code) {
                    return enumValue;
                }
            }
            return null;
        }
    }

    public enum TenkiSpecialKbnForRegister {
        // なし
        None("3",""),

        // 治ゆ
        Cure("1","治ゆ"),
        // 転医
        Transfer("5","転医"),
        // 中止
        Stop("7","中止"),
        // 死亡
        Dead("9","死亡");

        private final String code;
        private final String description;

        TenkiSpecialKbnForRegister(String code, String description) {
            this.code = code;
            this.description = description;
        }

        public String getCode() {
            return code;
        }

        public String getDescription() {
            return description;
        }

        public static TenkiSpecialKbnForRegister getByDescription(String description) {
            for (TenkiSpecialKbnForRegister enumValue : TenkiSpecialKbnForRegister.values()) {
                if (enumValue.getDescription() == description) {
                    return enumValue;
                }
            }
            return null;
        }
    }

    public enum OrcaTenkiKbn {
        // なし
        None(""),
        // 死亡
        Dead("D"),
        // 転医
        Transfer("S"),
        // 中止
        Stop("C"),
        // 治ゆ
        Cure("F");


        String value;

        OrcaTenkiKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum FukuHokenKbn {
        Kouhi("1"),
        Fukushi("2");

        String value;

        FukuHokenKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum FutanKbn {

        // なし
        None("0"),

        // 主
        Shu("1"),

        //主のみ
        ShuNomi("1"),


        //主+公1
        ShuKou1("2"),

        //主+公2
        ShuKou2("3"),

        //主公1公2
        ShuKou12("4"),

        //公1
        Kou1("5"),

        //公2
        Kou2("6"),

        //公12
        Kou12("7"),

        //主公1公2公3公4
        ShuKou1234("9"),

        //公3
        Kou3("B"),

        //公4
        Kou4("C"),

        //主+公3
        Shukou3("E"),

        //主+公4
        Shukou4("G"),

        //公1公3
        Kou13("H"),

        //公1公4
        Kou14("I"),

        //公2公3
        Kou23("J"),

        //公2公4
        Kou24("K"),

        //公3公4
        Kou34("L"),

        //主公1公3
        ShuKou13("M"),

        //主公1公4
        ShuKou14("N"),

        //主公2公3
        ShuKou23("O"),

        //主公2公4
        ShuKou24("P"),

        //主公3公4
        ShuKou34("Q"),

        //公1公2公3
        Kou123("R"),

        //公1公2公4
        Kou124("S"),

        //公1公3公4
        Kou134("T"),

        //公2公3公4
        Kou234("U"),

        //主公1公2公3
        ShuKou123("V"),

        //主公1公2公4
        ShuKou124("W"),

        //主公1公3公4
        ShuKou134("X"),

        //主公2公3公4
        ShuKou234("Y"),

        //公1公2公3公4
        Kou1234("Z");

        String value;

        FutanKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

    }

    /**
     * 保険種類
     */
    public enum HokenKbn {

        /**
         * 社保
         */
        SHAHO("1"),

        /**
         * 　国保
         */
        KOKUHO("2"),

        /**
         * 公費
         */
        KOUHI("3"),


        /**
         * 介護
         */
        KAIGO("4"),

        /**
         * 労災
         */
        ROUSAI("5"),

        /**
         * 自賠責
         */
        JIBAISEKI("6"),

        /**
         * 公害
         */
        KOUGAI("7"),

        /**
         * 自費
         */
        JIHI("100"),
        // 20210225 #42719 add start
        /**
         * 治験
         */
        CHIKEN("101"),
        // 20210225 #42719 add end
        /**
         * 保険証忘れ
         */
        NONE("102");

        String value;

        HokenKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static HokenKbn GeteEnumByValue(String value) {
            return Arrays.stream(HokenKbn.values()).filter(data -> data.getValue().equals(value)).findFirst().orElse(null);
        }
    }

    //20240708 #94377 病名登録 liyan add start
    /**
     * 指導管理料区分
     */
    public enum ShidouKanriryouKbn {
        // なし
        None("00"),
        // 特定疾患
        TokuteiKikann("05"),
        // 皮膚科特定疾患Ⅰ
        HifuTokuteiKikann1("03"),
        // 皮膚科特定疾患Ⅱ
        HifuTokuteiKikann2("04"),
        // てんかん指導料
        TenkanShidouSanntei("07"),
        // 特定疾患又はてんかん指導料（特定疾患又はてんかん指導料）
        TokuteiKikannTenkanShidou("08"),
        // 特定疾患又はてんかん指導料（難病外来指導管理料）
        NanbyouGairaiShidouKanriryou("09");

        String value;

        ShidouKanriryouKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum TenkiKbnOrca {
        // 死亡
        Dead("D"),
        // 完治　
        FullyRecovered("F"),
        // 不変　
        Unchanged("N"),
        // 軽快
        Recovering("R"),
        // 後遺症残
        Sequelae("S"),
        // 不明
        Nnknown("U"),
        // 悪化
        Worsening("W");

        String value;

        TenkiKbnOrca(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }
    //20240708 #94377 病名登録 liyan add end

}
