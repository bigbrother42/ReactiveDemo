package com.em.clinicapi.webdto.db;
import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
/****************************************************************************/
/*                      (C) EM Systems Ltd. 2020
/****************************************************************************/
/**
* WebDto : RehabilitationJisshiInfoWebDto クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2020/02/19 <BR>
*
* @author DAOGenerator4Smart
*/
//***************************************************************************

import org.springframework.stereotype.Component;

@Component
public class RehabilitationJisshiInfoWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ karteSeq */
	private int  karteSeq = 0;

	/**  プロパティ prescriptionSeq */
	private int  prescriptionSeq = 0;

	/**  プロパティ itemSeq */
	private int  itemSeq = 0;

	/**  プロパティ tantouPtCode */
	private String  tantouPtCode = null;

	/**  プロパティ jisshiStartDateTime */
	private java.sql.Timestamp  jisshiStartDateTime = null;

	/**  プロパティ jisshiEndDateTime */
	private java.sql.Timestamp  jisshiEndDateTime = null;

	/**  プロパティ jisshiInfoComment */
	private String  jisshiInfoComment = null;

	/**  プロパティ kiguCodeList */
	private String  kiguCodeList = null;

	/**  プロパティ shoubyouName */
	private String  shoubyouName = null;

	/**  プロパティ kisanDate */
	private java.sql.Date  kisanDate = null;

	/**  プロパティ kisanReason */
	private String  kisanReason = null;

	/**  プロパティ isRehabilitionDisplay */
	private boolean  isRehabilitionDisplay;


	/**
	*  デフォルトのコンストラクタ
	*/
	public RehabilitationJisshiInfoWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：karteSeq を返します。
	* @return karteSeq
	*/
	public int getKarteSeq(){
		return karteSeq;
	}

	/**
	* プロパティー：karteSeq を設定します。
	* @param param  int karteSeq
	*/
	public void setKarteSeq(int karteSeq){
		this.karteSeq = karteSeq;
	}

	/**
	* プロパティー：prescriptionSeq を返します。
	* @return prescriptionSeq
	*/
	public int getPrescriptionSeq(){
		return prescriptionSeq;
	}

	/**
	* プロパティー：prescriptionSeq を設定します。
	* @param param  int prescriptionSeq
	*/
	public void setPrescriptionSeq(int prescriptionSeq){
		this.prescriptionSeq = prescriptionSeq;
	}

	/**
	* プロパティー：itemSeq を返します。
	* @return itemSeq
	*/
	public int getItemSeq(){
		return itemSeq;
	}

	/**
	* プロパティー：itemSeq を設定します。
	* @param param  int itemSeq
	*/
	public void setItemSeq(int itemSeq){
		this.itemSeq = itemSeq;
	}

	/**
	* プロパティー：tantouPtCode を返します。
	* @return tantouPtCode
	*/
	public String getTantouPtCode(){
		return tantouPtCode;
	}

	/**
	* プロパティー：tantouPtCode を設定します。
	* @param param  String tantouPtCode
	*/
	public void setTantouPtCode(String tantouPtCode){
		this.tantouPtCode = tantouPtCode;
	}

	/**
	* プロパティー：jisshiStartDateTime を返します。
	* @return jisshiStartDateTime
	*/
	public java.sql.Timestamp getJisshiStartDateTime(){
		return jisshiStartDateTime;
	}

	/**
	* プロパティー：jisshiStartDateTime を設定します。
	* @param param  java.sql.Timestamp jisshiStartDateTime
	*/
	public void setJisshiStartDateTime(java.sql.Timestamp jisshiStartDateTime){
		this.jisshiStartDateTime = jisshiStartDateTime;
	}

	/**
	* プロパティー：jisshiEndDateTime を返します。
	* @return jisshiEndDateTime
	*/
	public java.sql.Timestamp getJisshiEndDateTime(){
		return jisshiEndDateTime;
	}

	/**
	* プロパティー：jisshiEndDateTime を設定します。
	* @param param  java.sql.Timestamp jisshiEndDateTime
	*/
	public void setJisshiEndDateTime(java.sql.Timestamp jisshiEndDateTime){
		this.jisshiEndDateTime = jisshiEndDateTime;
	}

	/**
	* プロパティー：jisshiInfoComment を返します。
	* @return jisshiInfoComment
	*/
	public String getJisshiInfoComment(){
		return jisshiInfoComment;
	}

	/**
	* プロパティー：jisshiInfoComment を設定します。
	* @param param  String jisshiInfoComment
	*/
	public void setJisshiInfoComment(String jisshiInfoComment){
		this.jisshiInfoComment = jisshiInfoComment;
	}

	/**
	* プロパティー：kiguCodeList を返します。
	* @return kiguCodeList
	*/
	public String getKiguCodeList(){
		return kiguCodeList;
	}

	/**
	* プロパティー：kiguCodeList を設定します。
	* @param param  String kiguCodeList
	*/
	public void setKiguCodeList(String kiguCodeList){
		this.kiguCodeList = kiguCodeList;
	}

	/**
	* プロパティー：shoubyouName を返します。
	* @return shoubyouName
	*/
	public String getShoubyouName(){
		return shoubyouName;
	}

	/**
	* プロパティー：shoubyouName を設定します。
	* @param param  String shoubyouName
	*/
	public void setShoubyouName(String shoubyouName){
		this.shoubyouName = shoubyouName;
	}

	/**
	* プロパティー：kisanDate を返します。
	* @return kisanDate
	*/
	public java.sql.Date getKisanDate(){
		return kisanDate;
	}

	/**
	* プロパティー：kisanDate を設定します。
	* @param param  java.sql.Date kisanDate
	*/
	public void setKisanDate(java.sql.Date kisanDate){
		this.kisanDate = kisanDate;
	}

	/**
	* プロパティー：kisanReason を返します。
	* @return kisanReason
	*/
	public String getKisanReason(){
		return kisanReason;
	}

	/**
	* プロパティー：kisanReason を設定します。
	* @param param  String kisanReason
	*/
	public void setKisanReason(String kisanReason){
		this.kisanReason = kisanReason;
	}

	/**
	* プロパティー：isRehabilitionDisplay を返します。
	* @return isRehabilitionDisplay
	*/
	public boolean getIsRehabilitionDisplay(){
		return isRehabilitionDisplay;
	}

	/**
	* プロパティー：isRehabilitionDisplay を設定します。
	* @param param  boolean isRehabilitionDisplay
	*/
	public void setIsRehabilitionDisplay(boolean isRehabilitionDisplay){
		this.isRehabilitionDisplay = isRehabilitionDisplay;
	}
}
