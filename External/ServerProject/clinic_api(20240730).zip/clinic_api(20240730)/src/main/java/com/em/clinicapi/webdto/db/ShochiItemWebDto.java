package com.em.clinicapi.webdto.db;

import org.springframework.stereotype.Component;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2022
/****************************************************************************/
/**
 * WebDto : ShochiItemWebDto クラス<br>
 *
 * 自動生成クラス<br>
 *
 * 作成日 ： 2022/09/16<br>
 *
 * @author DAOGenerator4Smart
 */
//***************************************************************************
@Component
public class ShochiItemWebDto extends CustomerWebDtoBase{

	/** プロパティ patientSeq */
	private int patientSeq = 0;

	/** プロパティ hokenSeq */
	private int hokenSeq = 0;

	/** プロパティ shinryouDate */
	private java.sql.Date shinryouDate = null;

	/** プロパティ raiinKaisuu */
	private int raiinKaisuu = 0;

	/** プロパティ karteSeq */
	private int karteSeq = 0;

	/** プロパティ prescriptionSeq */
	private int prescriptionSeq = 0;

	/** プロパティ itemSeq */
	private int itemSeq = 0;

	/** プロパティ masterKbn */
	private String masterKbn = null;

	/** プロパティ masterType */
	private String masterType = null;

	/** プロパティ masterCode */
	private String masterCode = null;

	/** プロパティ productNameCode */
	private String productNameCode = null;

	/** プロパティ ippanNameCode */
	private String ippanNameCode = null;

	/** プロパティ kensaKbn */
	private String kensaKbn = null;

	/** プロパティ kensaType */
	private String kensaType = null;

	/** プロパティ kensaMGaichuusakiCode */
	private String kensaMGaichuusakiCode = null;

	/** プロパティ kensaMParentItemCode */
	private String kensaMParentItemCode = null;

	/** プロパティ kensaMChildItemCode */
	private String kensaMChildItemCode = null;

	/** プロパティ codehyouNoAlphabetPart */
	private String codehyouNoAlphabetPart = null;

	/** プロパティ codehyouNoKbnNo */
	private String codehyouNoKbnNo = null;

	/** プロパティ codehyouNoEdabanNo */
	private String codehyouNoEdabanNo = null;

	/** プロパティ codehyouNoKoubanNo */
	private String codehyouNoKoubanNo = null;

	/** プロパティ itemName */
	private String itemName = null;

	/** プロパティ suuryouInputKbn */
	private String suuryouInputKbn = null;

	/** プロパティ suuryouUsedQty */
	private java.math.BigDecimal suuryouUsedQty = null;

	/** プロパティ unitCode */
	private String unitCode = null;

	/** プロパティ kansanSeq */
	private int kansanSeq = 0;

	/** プロパティ kansanInfo */
	private String kansanInfo = null;

	/** プロパティ comment */
	private String comment = null;

	/** プロパティ commentKbn */
	private String commentKbn = null;

	/** プロパティ tooltip */
	private String tooltip = null;

	/** プロパティ jidouSanteiKbn */
	private String jidouSanteiKbn = null;

	/** プロパティ yakuzaiBunruiNo */
	private String yakuzaiBunruiNo = null;

	/** プロパティ kensaMasterIjiCode */
	private String kensaMasterIjiCode = null;

	/** プロパティ isHoukatsuTaishougai */
	private boolean isHoukatsuTaishougai;

	/** プロパティ isMarumeTaishougai */
	private boolean isMarumeTaishougai;

	/** プロパティ yakuzaiStatusTouyakuKbn */
	private String yakuzaiStatusTouyakuKbn = null;

	/** プロパティ zengenKakujitsuConfigTouyakuKbn */
	private String zengenKakujitsuConfigTouyakuKbn = null;

	/** プロパティ futanKbn */
	private String futanKbn = null;

	/** プロパティ fukushiFutanKbn */
	private String fukushiFutanKbn = null;

	/** プロパティ isDo */
	private boolean isDo;

	/** プロパティ doShinryouDate */
	private java.sql.Date doShinryouDate = null;

	/** プロパティ jihiBunruiNo */
	private String jihiBunruiNo = null;

	/** プロパティ jihiKingaku */
	private java.math.BigDecimal jihiKingaku = null;

	/** プロパティ commentTenkiKbn */
	private String commentTenkiKbn = null;

	/** プロパティ isKanrenComment */
	private boolean isKanrenComment;

	/** プロパティ makerCode */
	private String makerCode = null;

	/** プロパティ purotokoruCode */
	private String purotokoruCode = null;

	/** プロパティ shijiKbn */
	private String shijiKbn = "0";

	/**
	 * デフォルトのコンストラクタ
	 */
	public ShochiItemWebDto() {
		super();
	}

	/**
	 * プロパティー：patientSeq を返します。
	 *
	 * @return patientSeq
	 */
	public int getPatientSeq() {
		return patientSeq;
	}

	/**
	 * プロパティー：patientSeq を設定します。
	 *
	 * @param patientSeq patientSeqを設定。
	 */
	public void setPatientSeq(int patientSeq) {
		this.patientSeq = patientSeq;
	}

	/**
	 * プロパティー：hokenSeq を返します。
	 *
	 * @return hokenSeq
	 */
	public int getHokenSeq() {
		return hokenSeq;
	}

	/**
	 * プロパティー：hokenSeq を設定します。
	 *
	 * @param hokenSeq hokenSeqを設定。
	 */
	public void setHokenSeq(int hokenSeq) {
		this.hokenSeq = hokenSeq;
	}

	/**
	 * プロパティー：shinryouDate を返します。
	 *
	 * @return shinryouDate
	 */
	public java.sql.Date getShinryouDate() {
		return shinryouDate;
	}

	/**
	 * プロパティー：shinryouDate を設定します。
	 *
	 * @param shinryouDate shinryouDateを設定。
	 */
	public void setShinryouDate(java.sql.Date shinryouDate) {
		this.shinryouDate = shinryouDate;
	}

	/**
	 * プロパティー：raiinKaisuu を返します。
	 *
	 * @return raiinKaisuu
	 */
	public int getRaiinKaisuu() {
		return raiinKaisuu;
	}

	/**
	 * プロパティー：raiinKaisuu を設定します。
	 *
	 * @param raiinKaisuu raiinKaisuuを設定。
	 */
	public void setRaiinKaisuu(int raiinKaisuu) {
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	 * プロパティー：karteSeq を返します。
	 *
	 * @return karteSeq
	 */
	public int getKarteSeq() {
		return karteSeq;
	}

	/**
	 * プロパティー：karteSeq を設定します。
	 *
	 * @param karteSeq karteSeqを設定。
	 */
	public void setKarteSeq(int karteSeq) {
		this.karteSeq = karteSeq;
	}

	/**
	 * プロパティー：prescriptionSeq を返します。
	 *
	 * @return prescriptionSeq
	 */
	public int getPrescriptionSeq() {
		return prescriptionSeq;
	}

	/**
	 * プロパティー：prescriptionSeq を設定します。
	 *
	 * @param prescriptionSeq prescriptionSeqを設定。
	 */
	public void setPrescriptionSeq(int prescriptionSeq) {
		this.prescriptionSeq = prescriptionSeq;
	}

	/**
	 * プロパティー：itemSeq を返します。
	 *
	 * @return itemSeq
	 */
	public int getItemSeq() {
		return itemSeq;
	}

	/**
	 * プロパティー：itemSeq を設定します。
	 *
	 * @param itemSeq itemSeqを設定。
	 */
	public void setItemSeq(int itemSeq) {
		this.itemSeq = itemSeq;
	}

	/**
	 * プロパティー：masterKbn を返します。
	 *
	 * @return masterKbn
	 */
	public String getMasterKbn() {
		return masterKbn;
	}

	/**
	 * プロパティー：masterKbn を設定します。
	 *
	 * @param masterKbn masterKbnを設定。
	 */
	public void setMasterKbn(String masterKbn) {
		this.masterKbn = masterKbn;
	}

	/**
	 * プロパティー：masterType を返します。
	 *
	 * @return masterType
	 */
	public String getMasterType() {
		return masterType;
	}

	/**
	 * プロパティー：masterType を設定します。
	 *
	 * @param masterType masterTypeを設定。
	 */
	public void setMasterType(String masterType) {
		this.masterType = masterType;
	}

	/**
	 * プロパティー：masterCode を返します。
	 *
	 * @return masterCode
	 */
	public String getMasterCode() {
		return masterCode;
	}

	/**
	 * プロパティー：masterCode を設定します。
	 *
	 * @param masterCode masterCodeを設定。
	 */
	public void setMasterCode(String masterCode) {
		this.masterCode = masterCode;
	}

	/**
	 * プロパティー：productNameCode を返します。
	 *
	 * @return productNameCode
	 */
	public String getProductNameCode() {
		return productNameCode;
	}

	/**
	 * プロパティー：productNameCode を設定します。
	 *
	 * @param productNameCode productNameCodeを設定。
	 */
	public void setProductNameCode(String productNameCode) {
		this.productNameCode = productNameCode;
	}

	/**
	 * プロパティー：ippanNameCode を返します。
	 *
	 * @return ippanNameCode
	 */
	public String getIppanNameCode() {
		return ippanNameCode;
	}

	/**
	 * プロパティー：ippanNameCode を設定します。
	 *
	 * @param ippanNameCode ippanNameCodeを設定。
	 */
	public void setIppanNameCode(String ippanNameCode) {
		this.ippanNameCode = ippanNameCode;
	}

	/**
	 * プロパティー：kensaKbn を返します。
	 *
	 * @return kensaKbn
	 */
	public String getKensaKbn() {
		return kensaKbn;
	}

	/**
	 * プロパティー：kensaKbn を設定します。
	 *
	 * @param kensaKbn kensaKbnを設定。
	 */
	public void setKensaKbn(String kensaKbn) {
		this.kensaKbn = kensaKbn;
	}

	/**
	 * プロパティー：kensaType を返します。
	 *
	 * @return kensaType
	 */
	public String getKensaType() {
		return kensaType;
	}

	/**
	 * プロパティー：kensaType を設定します。
	 *
	 * @param kensaType kensaTypeを設定。
	 */
	public void setKensaType(String kensaType) {
		this.kensaType = kensaType;
	}

	/**
	 * プロパティー：kensaMGaichuusakiCode を返します。
	 *
	 * @return kensaMGaichuusakiCode
	 */
	public String getKensaMGaichuusakiCode() {
		return kensaMGaichuusakiCode;
	}

	/**
	 * プロパティー：kensaMGaichuusakiCode を設定します。
	 *
	 * @param kensaMGaichuusakiCode kensaMGaichuusakiCodeを設定。
	 */
	public void setKensaMGaichuusakiCode(String kensaMGaichuusakiCode) {
		this.kensaMGaichuusakiCode = kensaMGaichuusakiCode;
	}

	/**
	 * プロパティー：kensaMParentItemCode を返します。
	 *
	 * @return kensaMParentItemCode
	 */
	public String getKensaMParentItemCode() {
		return kensaMParentItemCode;
	}

	/**
	 * プロパティー：kensaMParentItemCode を設定します。
	 *
	 * @param kensaMParentItemCode kensaMParentItemCodeを設定。
	 */
	public void setKensaMParentItemCode(String kensaMParentItemCode) {
		this.kensaMParentItemCode = kensaMParentItemCode;
	}

	/**
	 * プロパティー：kensaMChildItemCode を返します。
	 *
	 * @return kensaMChildItemCode
	 */
	public String getKensaMChildItemCode() {
		return kensaMChildItemCode;
	}

	/**
	 * プロパティー：kensaMChildItemCode を設定します。
	 *
	 * @param kensaMChildItemCode kensaMChildItemCodeを設定。
	 */
	public void setKensaMChildItemCode(String kensaMChildItemCode) {
		this.kensaMChildItemCode = kensaMChildItemCode;
	}

	/**
	 * プロパティー：codehyouNoAlphabetPart を返します。
	 *
	 * @return codehyouNoAlphabetPart
	 */
	public String getCodehyouNoAlphabetPart() {
		return codehyouNoAlphabetPart;
	}

	/**
	 * プロパティー：codehyouNoAlphabetPart を設定します。
	 *
	 * @param codehyouNoAlphabetPart codehyouNoAlphabetPartを設定。
	 */
	public void setCodehyouNoAlphabetPart(String codehyouNoAlphabetPart) {
		this.codehyouNoAlphabetPart = codehyouNoAlphabetPart;
	}

	/**
	 * プロパティー：codehyouNoKbnNo を返します。
	 *
	 * @return codehyouNoKbnNo
	 */
	public String getCodehyouNoKbnNo() {
		return codehyouNoKbnNo;
	}

	/**
	 * プロパティー：codehyouNoKbnNo を設定します。
	 *
	 * @param codehyouNoKbnNo codehyouNoKbnNoを設定。
	 */
	public void setCodehyouNoKbnNo(String codehyouNoKbnNo) {
		this.codehyouNoKbnNo = codehyouNoKbnNo;
	}

	/**
	 * プロパティー：codehyouNoEdabanNo を返します。
	 *
	 * @return codehyouNoEdabanNo
	 */
	public String getCodehyouNoEdabanNo() {
		return codehyouNoEdabanNo;
	}

	/**
	 * プロパティー：codehyouNoEdabanNo を設定します。
	 *
	 * @param codehyouNoEdabanNo codehyouNoEdabanNoを設定。
	 */
	public void setCodehyouNoEdabanNo(String codehyouNoEdabanNo) {
		this.codehyouNoEdabanNo = codehyouNoEdabanNo;
	}

	/**
	 * プロパティー：codehyouNoKoubanNo を返します。
	 *
	 * @return codehyouNoKoubanNo
	 */
	public String getCodehyouNoKoubanNo() {
		return codehyouNoKoubanNo;
	}

	/**
	 * プロパティー：codehyouNoKoubanNo を設定します。
	 *
	 * @param codehyouNoKoubanNo codehyouNoKoubanNoを設定。
	 */
	public void setCodehyouNoKoubanNo(String codehyouNoKoubanNo) {
		this.codehyouNoKoubanNo = codehyouNoKoubanNo;
	}

	/**
	 * プロパティー：itemName を返します。
	 *
	 * @return itemName
	 */
	public String getItemName() {
		return itemName;
	}

	/**
	 * プロパティー：itemName を設定します。
	 *
	 * @param itemName itemNameを設定。
	 */
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	/**
	 * プロパティー：suuryouInputKbn を返します。
	 *
	 * @return suuryouInputKbn
	 */
	public String getSuuryouInputKbn() {
		return suuryouInputKbn;
	}

	/**
	 * プロパティー：suuryouInputKbn を設定します。
	 *
	 * @param suuryouInputKbn suuryouInputKbnを設定。
	 */
	public void setSuuryouInputKbn(String suuryouInputKbn) {
		this.suuryouInputKbn = suuryouInputKbn;
	}

	/**
	 * プロパティー：suuryouUsedQty を返します。
	 *
	 * @return suuryouUsedQty
	 */
	public java.math.BigDecimal getSuuryouUsedQty() {
		return suuryouUsedQty;
	}

	/**
	 * プロパティー：suuryouUsedQty を設定します。
	 *
	 * @param suuryouUsedQty suuryouUsedQtyを設定。
	 */
	public void setSuuryouUsedQty(java.math.BigDecimal suuryouUsedQty) {
		this.suuryouUsedQty = suuryouUsedQty;
	}

	/**
	 * プロパティー：unitCode を返します。
	 *
	 * @return unitCode
	 */
	public String getUnitCode() {
		return unitCode;
	}

	/**
	 * プロパティー：unitCode を設定します。
	 *
	 * @param unitCode unitCodeを設定。
	 */
	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	/**
	 * プロパティー：kansanSeq を返します。
	 *
	 * @return kansanSeq
	 */
	public int getKansanSeq() {
		return kansanSeq;
	}

	/**
	 * プロパティー：kansanSeq を設定します。
	 *
	 * @param kansanSeq kansanSeqを設定。
	 */
	public void setKansanSeq(int kansanSeq) {
		this.kansanSeq = kansanSeq;
	}

	/**
	 * プロパティー：kansanInfo を返します。
	 *
	 * @return kansanInfo
	 */
	public String getKansanInfo() {
		return kansanInfo;
	}

	/**
	 * プロパティー：kansanInfo を設定します。
	 *
	 * @param kansanInfo kansanInfoを設定。
	 */
	public void setKansanInfo(String kansanInfo) {
		this.kansanInfo = kansanInfo;
	}

	/**
	 * プロパティー：comment を返します。
	 *
	 * @return comment
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * プロパティー：comment を設定します。
	 *
	 * @param comment commentを設定。
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * プロパティー：commentKbn を返します。
	 *
	 * @return commentKbn
	 */
	public String getCommentKbn() {
		return commentKbn;
	}

	/**
	 * プロパティー：commentKbn を設定します。
	 *
	 * @param commentKbn commentKbnを設定。
	 */
	public void setCommentKbn(String commentKbn) {
		this.commentKbn = commentKbn;
	}

	/**
	 * プロパティー：tooltip を返します。
	 *
	 * @return tooltip
	 */
	public String getTooltip() {
		return tooltip;
	}

	/**
	 * プロパティー：tooltip を設定します。
	 *
	 * @param tooltip tooltipを設定。
	 */
	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}

	/**
	 * プロパティー：jidouSanteiKbn を返します。
	 *
	 * @return jidouSanteiKbn
	 */
	public String getJidouSanteiKbn() {
		return jidouSanteiKbn;
	}

	/**
	 * プロパティー：jidouSanteiKbn を設定します。
	 *
	 * @param jidouSanteiKbn jidouSanteiKbnを設定。
	 */
	public void setJidouSanteiKbn(String jidouSanteiKbn) {
		this.jidouSanteiKbn = jidouSanteiKbn;
	}

	/**
	 * プロパティー：yakuzaiBunruiNo を返します。
	 *
	 * @return yakuzaiBunruiNo
	 */
	public String getYakuzaiBunruiNo() {
		return yakuzaiBunruiNo;
	}

	/**
	 * プロパティー：yakuzaiBunruiNo を設定します。
	 *
	 * @param yakuzaiBunruiNo yakuzaiBunruiNoを設定。
	 */
	public void setYakuzaiBunruiNo(String yakuzaiBunruiNo) {
		this.yakuzaiBunruiNo = yakuzaiBunruiNo;
	}

	/**
	 * プロパティー：kensaMasterIjiCode を返します。
	 *
	 * @return kensaMasterIjiCode
	 */
	public String getKensaMasterIjiCode() {
		return kensaMasterIjiCode;
	}

	/**
	 * プロパティー：kensaMasterIjiCode を設定します。
	 *
	 * @param kensaMasterIjiCode kensaMasterIjiCodeを設定。
	 */
	public void setKensaMasterIjiCode(String kensaMasterIjiCode) {
		this.kensaMasterIjiCode = kensaMasterIjiCode;
	}

	/**
	 * プロパティー：isHoukatsuTaishougai を返します。
	 *
	 * @return isHoukatsuTaishougai
	 */
	public boolean getIsHoukatsuTaishougai() {
		return isHoukatsuTaishougai;
	}

	/**
	 * プロパティー：isHoukatsuTaishougai を設定します。
	 *
	 * @param isHoukatsuTaishougai isHoukatsuTaishougaiを設定。
	 */
	public void setIsHoukatsuTaishougai(boolean isHoukatsuTaishougai) {
		this.isHoukatsuTaishougai = isHoukatsuTaishougai;
	}

	/**
	 * プロパティー：isMarumeTaishougai を返します。
	 *
	 * @return isMarumeTaishougai
	 */
	public boolean getIsMarumeTaishougai() {
		return isMarumeTaishougai;
	}

	/**
	 * プロパティー：isMarumeTaishougai を設定します。
	 *
	 * @param isMarumeTaishougai isMarumeTaishougaiを設定。
	 */
	public void setIsMarumeTaishougai(boolean isMarumeTaishougai) {
		this.isMarumeTaishougai = isMarumeTaishougai;
	}

	/**
	 * プロパティー：yakuzaiStatusTouyakuKbn を返します。
	 *
	 * @return yakuzaiStatusTouyakuKbn
	 */
	public String getYakuzaiStatusTouyakuKbn() {
		return yakuzaiStatusTouyakuKbn;
	}

	/**
	 * プロパティー：yakuzaiStatusTouyakuKbn を設定します。
	 *
	 * @param yakuzaiStatusTouyakuKbn yakuzaiStatusTouyakuKbnを設定。
	 */
	public void setYakuzaiStatusTouyakuKbn(String yakuzaiStatusTouyakuKbn) {
		this.yakuzaiStatusTouyakuKbn = yakuzaiStatusTouyakuKbn;
	}

	/**
	 * プロパティー：zengenKakujitsuConfigTouyakuKbn を返します。
	 *
	 * @return zengenKakujitsuConfigTouyakuKbn
	 */
	public String getZengenKakujitsuConfigTouyakuKbn() {
		return zengenKakujitsuConfigTouyakuKbn;
	}

	/**
	 * プロパティー：zengenKakujitsuConfigTouyakuKbn を設定します。
	 *
	 * @param zengenKakujitsuConfigTouyakuKbn zengenKakujitsuConfigTouyakuKbnを設定。
	 */
	public void setZengenKakujitsuConfigTouyakuKbn(String zengenKakujitsuConfigTouyakuKbn) {
		this.zengenKakujitsuConfigTouyakuKbn = zengenKakujitsuConfigTouyakuKbn;
	}

	/**
	 * プロパティー：futanKbn を返します。
	 *
	 * @return futanKbn
	 */
	public String getFutanKbn() {
		return futanKbn;
	}

	/**
	 * プロパティー：futanKbn を設定します。
	 *
	 * @param futanKbn futanKbnを設定。
	 */
	public void setFutanKbn(String futanKbn) {
		this.futanKbn = futanKbn;
	}

	/**
	 * プロパティー：fukushiFutanKbn を返します。
	 *
	 * @return fukushiFutanKbn
	 */
	public String getFukushiFutanKbn() {
		return fukushiFutanKbn;
	}

	/**
	 * プロパティー：fukushiFutanKbn を設定します。
	 *
	 * @param fukushiFutanKbn fukushiFutanKbnを設定。
	 */
	public void setFukushiFutanKbn(String fukushiFutanKbn) {
		this.fukushiFutanKbn = fukushiFutanKbn;
	}

	/**
	 * プロパティー：isDo を返します。
	 *
	 * @return isDo
	 */
	public boolean getIsDo() {
		return isDo;
	}

	/**
	 * プロパティー：isDo を設定します。
	 *
	 * @param isDo isDoを設定。
	 */
	public void setIsDo(boolean isDo) {
		this.isDo = isDo;
	}

	/**
	 * プロパティー：doShinryouDate を返します。
	 *
	 * @return doShinryouDate
	 */
	public java.sql.Date getDoShinryouDate() {
		return doShinryouDate;
	}

	/**
	 * プロパティー：doShinryouDate を設定します。
	 *
	 * @param doShinryouDate doShinryouDateを設定。
	 */
	public void setDoShinryouDate(java.sql.Date doShinryouDate) {
		this.doShinryouDate = doShinryouDate;
	}

	/**
	 * プロパティー：jihiBunruiNo を返します。
	 *
	 * @return jihiBunruiNo
	 */
	public String getJihiBunruiNo() {
		return jihiBunruiNo;
	}

	/**
	 * プロパティー：jihiBunruiNo を設定します。
	 *
	 * @param jihiBunruiNo jihiBunruiNoを設定。
	 */
	public void setJihiBunruiNo(String jihiBunruiNo) {
		this.jihiBunruiNo = jihiBunruiNo;
	}

	/**
	 * プロパティー：jihiKingaku を返します。
	 *
	 * @return jihiKingaku
	 */
	public java.math.BigDecimal getJihiKingaku() {
		return jihiKingaku;
	}

	/**
	 * プロパティー：jihiKingaku を設定します。
	 *
	 * @param jihiKingaku jihiKingakuを設定。
	 */
	public void setJihiKingaku(java.math.BigDecimal jihiKingaku) {
		this.jihiKingaku = jihiKingaku;
	}

	/**
	 * プロパティー：commentTenkiKbn を返します。
	 *
	 * @return commentTenkiKbn
	 */
	public String getCommentTenkiKbn() {
		return commentTenkiKbn;
	}

	/**
	 * プロパティー：commentTenkiKbn を設定します。
	 *
	 * @param commentTenkiKbn commentTenkiKbnを設定。
	 */
	public void setCommentTenkiKbn(String commentTenkiKbn) {
		this.commentTenkiKbn = commentTenkiKbn;
	}

	/**
	 * プロパティー：isKanrenComment を返します。
	 *
	 * @return isKanrenComment
	 */
	public boolean getIsKanrenComment() {
		return isKanrenComment;
	}

	/**
	 * プロパティー：isKanrenComment を設定します。
	 *
	 * @param isKanrenComment isKanrenCommentを設定。
	 */
	public void setIsKanrenComment(boolean isKanrenComment) {
		this.isKanrenComment = isKanrenComment;
	}

	/**
	 * プロパティー：makerCode を返します。
	 *
	 * @return makerCode
	 */
	public String getMakerCode() {
		return makerCode;
	}

	/**
	 * プロパティー：makerCode を設定します。
	 *
	 * @param makerCode makerCodeを設定。
	 */
	public void setMakerCode(String makerCode) {
		this.makerCode = makerCode;
	}

	/**
	 * プロパティー：purotokoruCode を返します。
	 *
	 * @return purotokoruCode
	 */
	public String getPurotokoruCode() {
		return purotokoruCode;
	}

	/**
	 * プロパティー：purotokoruCode を設定します。
	 *
	 * @param purotokoruCode purotokoruCodeを設定。
	 */
	public void setPurotokoruCode(String purotokoruCode) {
		this.purotokoruCode = purotokoruCode;
	}

	/**
	 * プロパティー：shijiKbn を返します。
	 *
	 * @return shijiKbn
	 */
	public String getShijiKbn() {
		return shijiKbn;
	}

	/**
	 * プロパティー：shijiKbn を設定します。
	 *
	 * @param shijiKbn shijiKbnを設定。
	 */
	public void setShijiKbn(String shijiKbn) {
		this.shijiKbn = shijiKbn;
	}
}
