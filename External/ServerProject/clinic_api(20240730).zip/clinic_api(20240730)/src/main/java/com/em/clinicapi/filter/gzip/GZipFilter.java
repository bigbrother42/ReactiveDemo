package com.em.clinicapi.filter.gzip;

import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.filter.ResponseWrapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.GZIPInputStream;

public class GZipFilter  extends OncePerRequestFilter {

    private boolean compressionEnabled;

    public GZipFilter(boolean compressEnable) {
        this.compressionEnabled = compressEnable;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        HttpServletRequest internalRequest = getInternalRequest(request);
        HttpServletResponse internalResponse = getInternalResponse(request, response);
        //HttpServletRequest internalRequest = request;
        //HttpServletResponse internalResponse = response;

        filterChain.doFilter(internalRequest, internalResponse);

        if (internalResponse instanceof ResponseWrapper) {
            ((ResponseWrapper) internalResponse).finish();

            LogUtil.getLogger(this).debug("HTTP Response is successfully compressed with GZIP compression.");
        }
    }

    private HttpServletRequest getInternalRequest(HttpServletRequest request) {
        final String contentEncoding = request.getHeader(HttpHeaders.CONTENT_ENCODING);
        if (contentEncoding != null && contentEncoding.toLowerCase().indexOf("gzip") > -1) {
            LogUtil.getLogger(this).debug("HTTP Request is compressed.");

            try {
                final InputStream decompressStream = new GZIPInputStream(request.getInputStream());
                HttpServletRequest internalRequest = new HttpServletRequestWrapper(request) {
                    @Override
                    public String getHeader(String name) {
                        if (name.equalsIgnoreCase("Content-Type")) {
                            return MediaType.APPLICATION_JSON_VALUE;
                        }
                        return super.getHeader(name);
                    }

                    @Override
                    public Enumeration<String> getHeaders(String name) {
                        List<String> headerVals = Collections.list(super.getHeaders(name));
                        for (int index = 0; index < headerVals.size(); index++) {
                            if ("Content-Type".equalsIgnoreCase(name)) {
                                headerVals.set(index, MediaType.APPLICATION_JSON_VALUE);
                            }
                        }
                        return Collections.enumeration(headerVals);
                    }

                    @Override
                    public ServletInputStream getInputStream() throws IOException {
                        return new DecompressServletInputStream(decompressStream);
                    }

                    @Override
                    public BufferedReader getReader() throws IOException {
                        return new BufferedReader(new InputStreamReader(decompressStream, StandardCharsets.UTF_8));
                    }
                };

                LogUtil.getLogger(this).debug("HTTP Request is successfully decompressed from GZIP compression.");
                return internalRequest;
            } catch (IOException ex) {
                LogUtil.getLogger(this).error(ex.getMessage(), ex);
            }
        }
        return request;
    }

    private HttpServletResponse getInternalResponse(HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        if (Boolean.valueOf(this.compressionEnabled)) {
            LogUtil.getLogger(this).debug("HTTP Response Compression is enabled.");
            final String acceptEncoding = request.getHeader(HttpHeaders.ACCEPT_ENCODING);
            if (acceptEncoding != null && acceptEncoding.indexOf("gzip") >= 0) {
                return new ResponseWrapper(response);
            }
        }
        return response;
    }
}
