package com.em.clinicapi.config;

import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.filter.gzip.GZipFilter;
import org.springframework.context.annotation.*;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.RetryContext;
import org.springframework.retry.RetryListener;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.listener.RetryListenerSupport;

import java.util.Collections;
import java.util.List;

@Configuration
//@Import({ GZipFilter.class })
@EnableRetry
public class ApplicationConfig {

    @Bean
    public List<RetryListener> retryListeners() {
        return Collections.singletonList(new RetryListenerSupport() {
            @Override
            public <T, E extends Throwable> void onError(RetryContext context, RetryCallback<T, E> callback,
                                                         Throwable throwable) {
                LogUtil.LOG.warn("Retryable method {} threw {}th exception {}",
                        context.getAttribute("context.name"), context.getRetryCount(), throwable.toString());
            }
        });
    }
}
