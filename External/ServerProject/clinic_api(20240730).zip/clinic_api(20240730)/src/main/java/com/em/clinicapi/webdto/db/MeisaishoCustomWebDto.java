package com.em.clinicapi.webdto.db;

import java.math.BigDecimal;
import java.sql.Date;

public class MeisaishoCustomWebDto extends IjiItemWebDto  {

    /**  プロパティ shinryouKbn */
    private String shinryouKbn = null;

    /**  プロパティ ingaiTouyakuKbn */
    private String ingaiTouyakuKbn = null;

    /**  プロパティ prescriptionNissuuKaisuu */
    private Integer prescriptionNissuuKaisuu = null;

    /**  プロパティ shinryouShikibetsuTensuu */
    private java.math.BigDecimal shinryouShikibetsuTensuu = null;

    /**  プロパティ shinryouShikibetsuKingaku */
    private java.math.BigDecimal shinryouShikibetsuKingaku = null;

    /**  プロパティ saiyouKanjiName */
    private String saiyouKanjiName = null;

    /**  プロパティ unitName */
    private String unitName = null;

    /**  プロパティ suuryouInputKbn */
    private String suuryouInputKbn = null;

    private String codehyouNoAlphabetPart = null;

    /**  プロパティ shouhizeiSanteiKbn */
    private String shouhizeiSanteiKbn = null;

    /**  プロパティ isHoukatsu */
    private Boolean isHoukatsu = false;
    private boolean  isRinjiTouyoTouyaku= false;
    private String  shinryouShikibetsuKbn = null;
    private ShinryoukouiMCustomWebDto shinryoukouiMCustomWebDto;
    /**
     * プロパティー：shinryouKbn を返します。
     * @return shinryouKbn
     */
    public String getShinryouKbn(){
        return shinryouKbn;
    }
    /**
     * プロパティー：shinryouKbn を設定します。
     * @param shinryouKbn
     */
    public void setShinryouKbn(String shinryouKbn){
        this.shinryouKbn = shinryouKbn;
    }

    /**
     * プロパティー：ingaiTouyakuKbn を返します。
     * @return ingaiTouyakuKbn
     */
    public String getIngaiTouyakuKbn(){
        return ingaiTouyakuKbn;
    }
    /**
     * プロパティー：ingaiTouyakuKbn を設定します。
     * @param ingaiTouyakuKbn
     */
    public void setIngaiTouyakuKbn(String ingaiTouyakuKbn){
        this.ingaiTouyakuKbn = ingaiTouyakuKbn;
    }

    /**
     * プロパティー：prescriptionNissuuKaisuu を返します。
     * @return prescriptionNissuuKaisuu
     */
    public Integer getPrescriptionNissuuKaisuu(){
        return prescriptionNissuuKaisuu;
    }
    /**
     * プロパティー：prescriptionNissuuKaisuu を設定します。
     * @param prescriptionNissuuKaisuu
     */
    public void setPrescriptionNissuuKaisuu(Integer prescriptionNissuuKaisuu){
        this.prescriptionNissuuKaisuu = prescriptionNissuuKaisuu;
    }

    /**
     * プロパティー：shinryouShikibetsuTensuu を返します。
     * @return shinryouShikibetsuTensuu
     */
    public java.math.BigDecimal getShinryouShikibetsuTensuu(){
        return shinryouShikibetsuTensuu;
    }
    /**
     * プロパティー：shinryouShikibetsuTensuu を設定します。
     * @param shinryouShikibetsuTensuu
     */
    public void setShinryouShikibetsuTensuu(java.math.BigDecimal shinryouShikibetsuTensuu){
        this.shinryouShikibetsuTensuu = shinryouShikibetsuTensuu;
    }

    /**
     * プロパティー：shinryouShikibetsuKingaku を返します。
     * @return shinryouShikibetsuKingaku
     */
    public java.math.BigDecimal getShinryouShikibetsuKingaku(){
        return shinryouShikibetsuKingaku;
    }
    /**
     * プロパティー：shinryouShikibetsuKingaku を設定します。
     * @param shinryouShikibetsuKingaku
     */
    public void setShinryouShikibetsuKingaku(java.math.BigDecimal shinryouShikibetsuKingaku){
        this.shinryouShikibetsuKingaku = shinryouShikibetsuKingaku;
    }

    /**
     * プロパティー：saiyouKanjiName を返します。
     * @return saiyouKanjiName
     */
    public String getSaiyouKanjiName(){
        return saiyouKanjiName;
    }
    /**
     * プロパティー：saiyouKanjiName を設定します。
     * @param saiyouKanjiName
     */
    public void setSaiyouKanjiName(String saiyouKanjiName){
        this.saiyouKanjiName = saiyouKanjiName;
    }

    /**
     * プロパティー：unitName を返します。
     * @return unitName
     */
    public String getUnitName(){
        return unitName;
    }
    /**
     * プロパティー：unitName を設定します。
     * @param unitName
     */
    public void setUnitName(String unitName){
        this.unitName = unitName;
    }

    /**
     * プロパティー：suuryouInputKbn を返します。
     * @return suuryouInputKbn
     */
    public String getSuuryouInputKbn(){
        return suuryouInputKbn;
    }
    /**
     * プロパティー：suuryouInputKbn を設定します。
     * @param suuryouInputKbn
     */
    public void setSuuryouInputKbn(String suuryouInputKbn){
        this.suuryouInputKbn = suuryouInputKbn;
    }

    public String getCodehyouNoAlphabetPart() {
        return this.codehyouNoAlphabetPart;
    }

    public void setCodehyouNoAlphabetPart(String codehyouNoAlphabetPart) {
        this.codehyouNoAlphabetPart = codehyouNoAlphabetPart;
    }

    /**
     * プロパティー：shouhizeiSanteiKbn を返します。
     * @return shouhizeiSanteiKbn
     */
    public String getShouhizeiSanteiKbn(){
        return shouhizeiSanteiKbn;
    }
    /**
     * プロパティー：shouhizeiSanteiKbn を設定します。
     * @param shouhizeiSanteiKbn
     */
    public void setShouhizeiSanteiKbn(String shouhizeiSanteiKbn){
        this.shouhizeiSanteiKbn = shouhizeiSanteiKbn;
    }

    /**
     * プロパティー：isHoukatsu を返します。
     * @return isHoukatsu
     */
    public Boolean getIsHoukatsu(){
        return isHoukatsu;
    }
    /**
     * プロパティー：isHoukatsu を設定します。
     */
    public void setIsHoukatsu(Boolean isHoukatsu){
        this.isHoukatsu = isHoukatsu;
    }

    public ShinryoukouiMCustomWebDto getShinryoukouiMCustomWebDto() {
        return shinryoukouiMCustomWebDto;
    }

    public void setShinryoukouiMCustomWebDto(ShinryoukouiMCustomWebDto shinryoukouiMCustomWebDto) {
        this.shinryoukouiMCustomWebDto = shinryoukouiMCustomWebDto;
    }
    /**
     * プロパティー：isRinjiTouyoTouyaku を返します。
     * @return isRinjiTouyoTouyaku
     */
    public boolean getIsRinjiTouyoTouyaku(){
        return isRinjiTouyoTouyaku;
    }

    /**
     * プロパティー：isRinjiTouyoTouyaku を設定します。
     * @param   isRinjiTouyoTouyaku
     */
    public void setIsRinjiTouyoTouyaku(boolean isRinjiTouyoTouyaku){
        this.isRinjiTouyoTouyaku = isRinjiTouyoTouyaku;
    }
    /**
     * プロパティー：shinryouShikibetsuKbn を返します。
     * @return shinryouShikibetsuKbn
     */
    public String getShinryouShikibetsuKbn(){
        return shinryouShikibetsuKbn;
    }
    /**
     * プロパティー：shinryouShikibetsuKbn を設定します。
     * @param  shinryouShikibetsuKbn
     */
    public void setShinryouShikibetsuKbn(String shinryouShikibetsuKbn){
        this.shinryouShikibetsuKbn = shinryouShikibetsuKbn;
    }
}
