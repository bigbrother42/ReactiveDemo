package com.em.clinicapi.webdto;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class AuditTrailWebDto extends CustomerWebDtoBase {

    /** プロパティ sousaSeq */
    private long sousaSeq = 0;

    /** プロパティ terminalId */
    private String terminalId = null;

    /** プロパティ userSeq */
    private int userSeq = 0;

    /** プロパティ screenName */
    private String screenName = null;

    /** プロパティ sousaContent */
    private String sousaContent = null;

    /** プロパティ sousaAt */
    private java.sql.Timestamp sousaAt = null;

    /**
     * デフォルトのコンストラクタ
     */
    public AuditTrailWebDto() {
        super();
    }

    /**
     * プロパティー：sousaSeq を返します。
     *
     * @return sousaSeq
     */
    public long getSousaSeq() {
        return sousaSeq;
    }

    /**
     * プロパティー：sousaSeq を設定します。
     *
     * @param sousaSeq sousaSeqを設定。
     */
    public void setSousaSeq(long sousaSeq) {
        this.sousaSeq = sousaSeq;
    }

    /**
     * プロパティー：terminalId を返します。
     *
     * @return terminalId
     */
    public String getTerminalId() {
        return terminalId;
    }

    /**
     * プロパティー：terminalId を設定します。
     *
     * @param terminalId terminalIdを設定。
     */
    public void setTerminalId(String terminalId) {
        this.terminalId = terminalId;
    }

    /**
     * プロパティー：userSeq を返します。
     *
     * @return userSeq
     */
    public int getUserSeq() {
        return userSeq;
    }

    /**
     * プロパティー：userSeq を設定します。
     *
     * @param userSeq userSeqを設定。
     */
    public void setUserSeq(int userSeq) {
        this.userSeq = userSeq;
    }

    /**
     * プロパティー：screenName を返します。
     *
     * @return screenName
     */
    public String getScreenName() {
        return screenName;
    }

    /**
     * プロパティー：screenName を設定します。
     *
     * @param screenName screenNameを設定。
     */
    public void setScreenName(String screenName) {
        this.screenName = screenName;
    }

    /**
     * プロパティー：sousaContent を返します。
     *
     * @return sousaContent
     */
    public String getSousaContent() {
        return sousaContent;
    }

    /**
     * プロパティー：sousaContent を設定します。
     *
     * @param sousaContent sousaContentを設定。
     */
    public void setSousaContent(String sousaContent) {
        this.sousaContent = sousaContent;
    }

    /**
     * プロパティー：sousaAt を返します。
     *
     * @return sousaAt
     */
    public java.sql.Timestamp getSousaAt() {
        return sousaAt;
    }

    /**
     * プロパティー：sousaAt を設定します。
     *
     * @param sousaAt sousaAtを設定。
     */
    public void setSousaAt(java.sql.Timestamp sousaAt) {
        this.sousaAt = sousaAt;
    }
}
