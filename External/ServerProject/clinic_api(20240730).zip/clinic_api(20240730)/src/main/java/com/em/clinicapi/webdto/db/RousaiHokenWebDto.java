package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class RousaiHokenWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ rousaiKbn */
	private String  rousaiKbn = null;

	/**  プロパティ roudouHokenNo */
	private String  roudouHokenNo = null;

	/**  プロパティ nenkinShoushoNo */
	private String  nenkinShoushoNo = null;

	/**  プロパティ rousaiSeikyuuKbn */
	private String  rousaiSeikyuuKbn = null;

	/**  プロパティ jigyoushoSeq */
	private int  jigyoushoSeq = 0;

	/**  プロパティ ryouyouStartDate */
	private java.sql.Date  ryouyouStartDate = null;

	/**  プロパティ ryouyouEndDate */
	private java.sql.Date  ryouyouEndDate = null;

	/**  プロパティ healthKanriHandbookNo */
	private String  healthKanriHandbookNo = null;

	/**  プロパティ shoubyouCode */
	private String  shoubyouCode = null;

	/**  プロパティ densanSeikyuuKanaName */
	private String  densanSeikyuuKanaName = null;

	/**  プロパティ jibaisekiTypeKbn */
	private String  jibaisekiTypeKbn = null;

	/**  プロパティ santeiKijunKbn */
	private String  santeiKijunKbn = null;

	/**  プロパティ kaikeiKbn */
	private String  kaikeiKbn = null;

	/**  プロパティ ihoSeq */
	private int  ihoSeq = 0;

	/**  プロパティ isTensuuKobetsuConfig */
	private boolean  isTensuuKobetsuConfig;

	/**  プロパティ tensuuKobetsuConfigKingaku */
	private java.math.BigDecimal  tensuuKobetsuConfigKingaku = null;

	/**  プロパティ jushouDate */
	private java.sql.Date  jushouDate = null;

	/**  プロパティ shoshinDate */
	private java.sql.Date  shoshinDate = null;

	/**  プロパティ shoubyouCause */
	private int  shoubyouCause = 0;

	/**  プロパティ seikyuusaki1Kbn */
	private String  seikyuusaki1Kbn = null;

	/**  プロパティ seikyuusaki1Seq */
	private int  seikyuusaki1Seq = 0;

	/**  プロパティ seikyuusaki1Memo */
	private String  seikyuusaki1Memo = null;

	/**  プロパティ seikyuusaki2Kbn */
	private String  seikyuusaki2Kbn = null;

	/**  プロパティ seikyuusaki2Seq */
	private int  seikyuusaki2Seq = 0;

	/**  プロパティ seikyuusaki2Memo */
	private String  seikyuusaki2Memo = null;

	/**  プロパティ seikyuusaki3Kbn */
	private String  seikyuusaki3Kbn = null;

	/**  プロパティ seikyuusaki3Seq */
	private int  seikyuusaki3Seq = 0;

	/**  プロパティ seikyuusaki3Memo */
	private String  seikyuusaki3Memo = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public RousaiHokenWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：rousaiKbn を返します。
	* @return rousaiKbn
	*/
	public String getRousaiKbn(){
		return rousaiKbn;
	}

	/**
	* プロパティー：rousaiKbn を設定します。
	* @param param  String rousaiKbn
	*/
	public void setRousaiKbn(String rousaiKbn){
		this.rousaiKbn = rousaiKbn;
	}

	/**
	* プロパティー：roudouHokenNo を返します。
	* @return roudouHokenNo
	*/
	public String getRoudouHokenNo(){
		return roudouHokenNo;
	}

	/**
	* プロパティー：roudouHokenNo を設定します。
	* @param param  String roudouHokenNo
	*/
	public void setRoudouHokenNo(String roudouHokenNo){
		this.roudouHokenNo = roudouHokenNo;
	}

	/**
	* プロパティー：nenkinShoushoNo を返します。
	* @return nenkinShoushoNo
	*/
	public String getNenkinShoushoNo(){
		return nenkinShoushoNo;
	}

	/**
	* プロパティー：nenkinShoushoNo を設定します。
	* @param param  String nenkinShoushoNo
	*/
	public void setNenkinShoushoNo(String nenkinShoushoNo){
		this.nenkinShoushoNo = nenkinShoushoNo;
	}

	/**
	* プロパティー：rousaiSeikyuuKbn を返します。
	* @return rousaiSeikyuuKbn
	*/
	public String getRousaiSeikyuuKbn(){
		return rousaiSeikyuuKbn;
	}

	/**
	* プロパティー：rousaiSeikyuuKbn を設定します。
	* @param param  String rousaiSeikyuuKbn
	*/
	public void setRousaiSeikyuuKbn(String rousaiSeikyuuKbn){
		this.rousaiSeikyuuKbn = rousaiSeikyuuKbn;
	}

	/**
	* プロパティー：jigyoushoSeq を返します。
	* @return jigyoushoSeq
	*/
	public int getJigyoushoSeq(){
		return jigyoushoSeq;
	}

	/**
	* プロパティー：jigyoushoSeq を設定します。
	* @param param  int jigyoushoSeq
	*/
	public void setJigyoushoSeq(int jigyoushoSeq){
		this.jigyoushoSeq = jigyoushoSeq;
	}

	/**
	* プロパティー：ryouyouStartDate を返します。
	* @return ryouyouStartDate
	*/
	public java.sql.Date getRyouyouStartDate(){
		return ryouyouStartDate;
	}

	/**
	* プロパティー：ryouyouStartDate を設定します。
	* @param param  java.sql.Date ryouyouStartDate
	*/
	public void setRyouyouStartDate(java.sql.Date ryouyouStartDate){
		this.ryouyouStartDate = ryouyouStartDate;
	}

	/**
	* プロパティー：ryouyouEndDate を返します。
	* @return ryouyouEndDate
	*/
	public java.sql.Date getRyouyouEndDate(){
		return ryouyouEndDate;
	}

	/**
	* プロパティー：ryouyouEndDate を設定します。
	* @param param  java.sql.Date ryouyouEndDate
	*/
	public void setRyouyouEndDate(java.sql.Date ryouyouEndDate){
		this.ryouyouEndDate = ryouyouEndDate;
	}

	/**
	* プロパティー：healthKanriHandbookNo を返します。
	* @return healthKanriHandbookNo
	*/
	public String getHealthKanriHandbookNo(){
		return healthKanriHandbookNo;
	}

	/**
	* プロパティー：healthKanriHandbookNo を設定します。
	* @param param  String healthKanriHandbookNo
	*/
	public void setHealthKanriHandbookNo(String healthKanriHandbookNo){
		this.healthKanriHandbookNo = healthKanriHandbookNo;
	}

	/**
	* プロパティー：shoubyouCode を返します。
	* @return shoubyouCode
	*/
	public String getShoubyouCode(){
		return shoubyouCode;
	}

	/**
	* プロパティー：shoubyouCode を設定します。
	* @param param  String shoubyouCode
	*/
	public void setShoubyouCode(String shoubyouCode){
		this.shoubyouCode = shoubyouCode;
	}

	/**
	* プロパティー：densanSeikyuuKanaName を返します。
	* @return densanSeikyuuKanaName
	*/
	public String getDensanSeikyuuKanaName(){
		return densanSeikyuuKanaName;
	}

	/**
	* プロパティー：densanSeikyuuKanaName を設定します。
	* @param param  String densanSeikyuuKanaName
	*/
	public void setDensanSeikyuuKanaName(String densanSeikyuuKanaName){
		this.densanSeikyuuKanaName = densanSeikyuuKanaName;
	}

	/**
	* プロパティー：jibaisekiTypeKbn を返します。
	* @return jibaisekiTypeKbn
	*/
	public String getJibaisekiTypeKbn(){
		return jibaisekiTypeKbn;
	}

	/**
	* プロパティー：jibaisekiTypeKbn を設定します。
	* @param param  String jibaisekiTypeKbn
	*/
	public void setJibaisekiTypeKbn(String jibaisekiTypeKbn){
		this.jibaisekiTypeKbn = jibaisekiTypeKbn;
	}

	/**
	* プロパティー：santeiKijunKbn を返します。
	* @return santeiKijunKbn
	*/
	public String getSanteiKijunKbn(){
		return santeiKijunKbn;
	}

	/**
	* プロパティー：santeiKijunKbn を設定します。
	* @param param  String santeiKijunKbn
	*/
	public void setSanteiKijunKbn(String santeiKijunKbn){
		this.santeiKijunKbn = santeiKijunKbn;
	}

	/**
	* プロパティー：kaikeiKbn を返します。
	* @return kaikeiKbn
	*/
	public String getKaikeiKbn(){
		return kaikeiKbn;
	}

	/**
	* プロパティー：kaikeiKbn を設定します。
	* @param param  String kaikeiKbn
	*/
	public void setKaikeiKbn(String kaikeiKbn){
		this.kaikeiKbn = kaikeiKbn;
	}

	/**
	* プロパティー：ihoSeq を返します。
	* @return ihoSeq
	*/
	public int getIhoSeq(){
		return ihoSeq;
	}

	/**
	* プロパティー：ihoSeq を設定します。
	* @param param  int ihoSeq
	*/
	public void setIhoSeq(int ihoSeq){
		this.ihoSeq = ihoSeq;
	}

	/**
	* プロパティー：isTensuuKobetsuConfig を返します。
	* @return isTensuuKobetsuConfig
	*/
	public boolean getIsTensuuKobetsuConfig(){
		return isTensuuKobetsuConfig;
	}

	/**
	* プロパティー：isTensuuKobetsuConfig を設定します。
	* @param param  boolean isTensuuKobetsuConfig
	*/
	public void setIsTensuuKobetsuConfig(boolean isTensuuKobetsuConfig){
		this.isTensuuKobetsuConfig = isTensuuKobetsuConfig;
	}

	/**
	* プロパティー：tensuuKobetsuConfigKingaku を返します。
	* @return tensuuKobetsuConfigKingaku
	*/
	public java.math.BigDecimal getTensuuKobetsuConfigKingaku(){
		return tensuuKobetsuConfigKingaku;
	}

	/**
	* プロパティー：tensuuKobetsuConfigKingaku を設定します。
	* @param param  java.math.BigDecimal tensuuKobetsuConfigKingaku
	*/
	public void setTensuuKobetsuConfigKingaku(java.math.BigDecimal tensuuKobetsuConfigKingaku){
		this.tensuuKobetsuConfigKingaku = tensuuKobetsuConfigKingaku;
	}

	/**
	* プロパティー：jushouDate を返します。
	* @return jushouDate
	*/
	public java.sql.Date getJushouDate(){
		return jushouDate;
	}

	/**
	* プロパティー：jushouDate を設定します。
	* @param param  java.sql.Date jushouDate
	*/
	public void setJushouDate(java.sql.Date jushouDate){
		this.jushouDate = jushouDate;
	}

	/**
	* プロパティー：shoshinDate を返します。
	* @return shoshinDate
	*/
	public java.sql.Date getShoshinDate(){
		return shoshinDate;
	}

	/**
	* プロパティー：shoshinDate を設定します。
	* @param param  java.sql.Date shoshinDate
	*/
	public void setShoshinDate(java.sql.Date shoshinDate){
		this.shoshinDate = shoshinDate;
	}

	/**
	* プロパティー：shoubyouCause を返します。
	* @return shoubyouCause
	*/
	public int getShoubyouCause(){
		return shoubyouCause;
	}

	/**
	* プロパティー：shoubyouCause を設定します。
	* @param param  int shoubyouCause
	*/
	public void setShoubyouCause(int shoubyouCause){
		this.shoubyouCause = shoubyouCause;
	}

	/**
	* プロパティー：seikyuusaki1Kbn を返します。
	* @return seikyuusaki1Kbn
	*/
	public String getSeikyuusaki1Kbn(){
		return seikyuusaki1Kbn;
	}

	/**
	* プロパティー：seikyuusaki1Kbn を設定します。
	* @param param  String seikyuusaki1Kbn
	*/
	public void setSeikyuusaki1Kbn(String seikyuusaki1Kbn){
		this.seikyuusaki1Kbn = seikyuusaki1Kbn;
	}

	/**
	* プロパティー：seikyuusaki1Seq を返します。
	* @return seikyuusaki1Seq
	*/
	public int getSeikyuusaki1Seq(){
		return seikyuusaki1Seq;
	}

	/**
	* プロパティー：seikyuusaki1Seq を設定します。
	* @param param  int seikyuusaki1Seq
	*/
	public void setSeikyuusaki1Seq(int seikyuusaki1Seq){
		this.seikyuusaki1Seq = seikyuusaki1Seq;
	}

	/**
	* プロパティー：seikyuusaki1Memo を返します。
	* @return seikyuusaki1Memo
	*/
	public String getSeikyuusaki1Memo(){
		return seikyuusaki1Memo;
	}

	/**
	* プロパティー：seikyuusaki1Memo を設定します。
	* @param param  String seikyuusaki1Memo
	*/
	public void setSeikyuusaki1Memo(String seikyuusaki1Memo){
		this.seikyuusaki1Memo = seikyuusaki1Memo;
	}

	/**
	* プロパティー：seikyuusaki2Kbn を返します。
	* @return seikyuusaki2Kbn
	*/
	public String getSeikyuusaki2Kbn(){
		return seikyuusaki2Kbn;
	}

	/**
	* プロパティー：seikyuusaki2Kbn を設定します。
	* @param param  String seikyuusaki2Kbn
	*/
	public void setSeikyuusaki2Kbn(String seikyuusaki2Kbn){
		this.seikyuusaki2Kbn = seikyuusaki2Kbn;
	}

	/**
	* プロパティー：seikyuusaki2Seq を返します。
	* @return seikyuusaki2Seq
	*/
	public int getSeikyuusaki2Seq(){
		return seikyuusaki2Seq;
	}

	/**
	* プロパティー：seikyuusaki2Seq を設定します。
	* @param param  int seikyuusaki2Seq
	*/
	public void setSeikyuusaki2Seq(int seikyuusaki2Seq){
		this.seikyuusaki2Seq = seikyuusaki2Seq;
	}

	/**
	* プロパティー：seikyuusaki2Memo を返します。
	* @return seikyuusaki2Memo
	*/
	public String getSeikyuusaki2Memo(){
		return seikyuusaki2Memo;
	}

	/**
	* プロパティー：seikyuusaki2Memo を設定します。
	* @param param  String seikyuusaki2Memo
	*/
	public void setSeikyuusaki2Memo(String seikyuusaki2Memo){
		this.seikyuusaki2Memo = seikyuusaki2Memo;
	}

	/**
	* プロパティー：seikyuusaki3Kbn を返します。
	* @return seikyuusaki3Kbn
	*/
	public String getSeikyuusaki3Kbn(){
		return seikyuusaki3Kbn;
	}

	/**
	* プロパティー：seikyuusaki3Kbn を設定します。
	* @param param  String seikyuusaki3Kbn
	*/
	public void setSeikyuusaki3Kbn(String seikyuusaki3Kbn){
		this.seikyuusaki3Kbn = seikyuusaki3Kbn;
	}

	/**
	* プロパティー：seikyuusaki3Seq を返します。
	* @return seikyuusaki3Seq
	*/
	public int getSeikyuusaki3Seq(){
		return seikyuusaki3Seq;
	}

	/**
	* プロパティー：seikyuusaki3Seq を設定します。
	* @param param  int seikyuusaki3Seq
	*/
	public void setSeikyuusaki3Seq(int seikyuusaki3Seq){
		this.seikyuusaki3Seq = seikyuusaki3Seq;
	}

	/**
	* プロパティー：seikyuusaki3Memo を返します。
	* @return seikyuusaki3Memo
	*/
	public String getSeikyuusaki3Memo(){
		return seikyuusaki3Memo;
	}

	/**
	* プロパティー：seikyuusaki3Memo を設定します。
	* @param param  String seikyuusaki3Memo
	*/
	public void setSeikyuusaki3Memo(String seikyuusaki3Memo){
		this.seikyuusaki3Memo = seikyuusaki3Memo;
	}
}
