package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;
@Component
public class IryoukikanIkaMWebDto extends CustomerWebDtoBase {

    /** プロパティ iryoukikanCode */
    private String iryoukikanCode = null;

    /** プロパティ startDate */
    private java.sql.Date startDate = null;

    /** プロパティ shisetsuNo */
    private String shisetsuNo = null;

    /** プロパティ iryoukikanKanjiName */
    private String iryoukikanKanjiName = null;

    /** プロパティ iryoukikanKanaName */
    private String iryoukikanKanaName = null;

    /** プロパティ seikyuuIryoukikanName */
    private String seikyuuIryoukikanName = null;

    /** プロパティ hokenKbn */
    private String hokenKbn = null;

    /** プロパティ endDate */
    private java.sql.Date endDate = null;

    /** プロパティ kaisetsushaKanjiName */
    private String kaisetsushaKanjiName = null;

    /** プロパティ kaisetsushaKanaName */
    private String kaisetsushaKanaName = null;

    /** プロパティ postalNo */
    private String postalNo = null;

    /** プロパティ prefectureCode */
    private String prefectureCode = null;

    /** プロパティ shikuchousonCode */
    private String shikuchousonCode = null;

    /** プロパティ iryoukikanShozaichi */
    private String iryoukikanShozaichi = null;

    /** プロパティ iryoukikanBanchi */
    private String iryoukikanBanchi = null;

    /** プロパティ phoneNo */
    private String phoneNo = null;

    /** プロパティ faxNo */
    private String faxNo = null;

    /** プロパティ emailAddress */
    private String emailAddress = null;

    /** プロパティ isSokyushitei */
    private boolean isSokyushitei;

    /** プロパティ tekikakuSeikyuushoHakkouJigyoushaNo */
    private String tekikakuSeikyuushoHakkouJigyoushaNo = null;

    /** プロパティ tourokuDate */
    private java.sql.Date tourokuDate = null;

    /**
     * デフォルトのコンストラクタ
     */
    public IryoukikanIkaMWebDto() {
        super();
    }

    /**
     * プロパティー：iryoukikanCode を返します。
     *
     * @return iryoukikanCode
     */
    public String getIryoukikanCode() {
        return iryoukikanCode;
    }

    /**
     * プロパティー：iryoukikanCode を設定します。
     *
     * @param iryoukikanCode iryoukikanCodeを設定。
     */
    public void setIryoukikanCode(String iryoukikanCode) {
        this.iryoukikanCode = iryoukikanCode;
    }

    /**
     * プロパティー：startDate を返します。
     *
     * @return startDate
     */
    public java.sql.Date getStartDate() {
        return startDate;
    }

    /**
     * プロパティー：startDate を設定します。
     *
     * @param startDate startDateを設定。
     */
    public void setStartDate(java.sql.Date startDate) {
        this.startDate = startDate;
    }

    /**
     * プロパティー：shisetsuNo を返します。
     *
     * @return shisetsuNo
     */
    public String getShisetsuNo() {
        return shisetsuNo;
    }

    /**
     * プロパティー：shisetsuNo を設定します。
     *
     * @param shisetsuNo shisetsuNoを設定。
     */
    public void setShisetsuNo(String shisetsuNo) {
        this.shisetsuNo = shisetsuNo;
    }

    /**
     * プロパティー：iryoukikanKanjiName を返します。
     *
     * @return iryoukikanKanjiName
     */
    public String getIryoukikanKanjiName() {
        return iryoukikanKanjiName;
    }

    /**
     * プロパティー：iryoukikanKanjiName を設定します。
     *
     * @param iryoukikanKanjiName iryoukikanKanjiNameを設定。
     */
    public void setIryoukikanKanjiName(String iryoukikanKanjiName) {
        this.iryoukikanKanjiName = iryoukikanKanjiName;
    }

    /**
     * プロパティー：iryoukikanKanaName を返します。
     *
     * @return iryoukikanKanaName
     */
    public String getIryoukikanKanaName() {
        return iryoukikanKanaName;
    }

    /**
     * プロパティー：iryoukikanKanaName を設定します。
     *
     * @param iryoukikanKanaName iryoukikanKanaNameを設定。
     */
    public void setIryoukikanKanaName(String iryoukikanKanaName) {
        this.iryoukikanKanaName = iryoukikanKanaName;
    }

    /**
     * プロパティー：seikyuuIryoukikanName を返します。
     *
     * @return seikyuuIryoukikanName
     */
    public String getSeikyuuIryoukikanName() {
        return seikyuuIryoukikanName;
    }

    /**
     * プロパティー：seikyuuIryoukikanName を設定します。
     *
     * @param seikyuuIryoukikanName seikyuuIryoukikanNameを設定。
     */
    public void setSeikyuuIryoukikanName(String seikyuuIryoukikanName) {
        this.seikyuuIryoukikanName = seikyuuIryoukikanName;
    }

    /**
     * プロパティー：hokenKbn を返します。
     *
     * @return hokenKbn
     */
    public String getHokenKbn() {
        return hokenKbn;
    }

    /**
     * プロパティー：hokenKbn を設定します。
     *
     * @param hokenKbn hokenKbnを設定。
     */
    public void setHokenKbn(String hokenKbn) {
        this.hokenKbn = hokenKbn;
    }

    /**
     * プロパティー：endDate を返します。
     *
     * @return endDate
     */
    public java.sql.Date getEndDate() {
        return endDate;
    }

    /**
     * プロパティー：endDate を設定します。
     *
     * @param endDate endDateを設定。
     */
    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    /**
     * プロパティー：kaisetsushaKanjiName を返します。
     *
     * @return kaisetsushaKanjiName
     */
    public String getKaisetsushaKanjiName() {
        return kaisetsushaKanjiName;
    }

    /**
     * プロパティー：kaisetsushaKanjiName を設定します。
     *
     * @param kaisetsushaKanjiName kaisetsushaKanjiNameを設定。
     */
    public void setKaisetsushaKanjiName(String kaisetsushaKanjiName) {
        this.kaisetsushaKanjiName = kaisetsushaKanjiName;
    }

    /**
     * プロパティー：kaisetsushaKanaName を返します。
     *
     * @return kaisetsushaKanaName
     */
    public String getKaisetsushaKanaName() {
        return kaisetsushaKanaName;
    }

    /**
     * プロパティー：kaisetsushaKanaName を設定します。
     *
     * @param kaisetsushaKanaName kaisetsushaKanaNameを設定。
     */
    public void setKaisetsushaKanaName(String kaisetsushaKanaName) {
        this.kaisetsushaKanaName = kaisetsushaKanaName;
    }

    /**
     * プロパティー：postalNo を返します。
     *
     * @return postalNo
     */
    public String getPostalNo() {
        return postalNo;
    }

    /**
     * プロパティー：postalNo を設定します。
     *
     * @param postalNo postalNoを設定。
     */
    public void setPostalNo(String postalNo) {
        this.postalNo = postalNo;
    }

    /**
     * プロパティー：prefectureCode を返します。
     *
     * @return prefectureCode
     */
    public String getPrefectureCode() {
        return prefectureCode;
    }

    /**
     * プロパティー：prefectureCode を設定します。
     *
     * @param prefectureCode prefectureCodeを設定。
     */
    public void setPrefectureCode(String prefectureCode) {
        this.prefectureCode = prefectureCode;
    }

    /**
     * プロパティー：shikuchousonCode を返します。
     *
     * @return shikuchousonCode
     */
    public String getShikuchousonCode() {
        return shikuchousonCode;
    }

    /**
     * プロパティー：shikuchousonCode を設定します。
     *
     * @param shikuchousonCode shikuchousonCodeを設定。
     */
    public void setShikuchousonCode(String shikuchousonCode) {
        this.shikuchousonCode = shikuchousonCode;
    }

    /**
     * プロパティー：iryoukikanShozaichi を返します。
     *
     * @return iryoukikanShozaichi
     */
    public String getIryoukikanShozaichi() {
        return iryoukikanShozaichi;
    }

    /**
     * プロパティー：iryoukikanShozaichi を設定します。
     *
     * @param iryoukikanShozaichi iryoukikanShozaichiを設定。
     */
    public void setIryoukikanShozaichi(String iryoukikanShozaichi) {
        this.iryoukikanShozaichi = iryoukikanShozaichi;
    }

    /**
     * プロパティー：iryoukikanBanchi を返します。
     *
     * @return iryoukikanBanchi
     */
    public String getIryoukikanBanchi() {
        return iryoukikanBanchi;
    }

    /**
     * プロパティー：iryoukikanBanchi を設定します。
     *
     * @param iryoukikanBanchi iryoukikanBanchiを設定。
     */
    public void setIryoukikanBanchi(String iryoukikanBanchi) {
        this.iryoukikanBanchi = iryoukikanBanchi;
    }

    /**
     * プロパティー：phoneNo を返します。
     *
     * @return phoneNo
     */
    public String getPhoneNo() {
        return phoneNo;
    }

    /**
     * プロパティー：phoneNo を設定します。
     *
     * @param phoneNo phoneNoを設定。
     */
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    /**
     * プロパティー：faxNo を返します。
     *
     * @return faxNo
     */
    public String getFaxNo() {
        return faxNo;
    }

    /**
     * プロパティー：faxNo を設定します。
     *
     * @param faxNo faxNoを設定。
     */
    public void setFaxNo(String faxNo) {
        this.faxNo = faxNo;
    }

    /**
     * プロパティー：emailAddress を返します。
     *
     * @return emailAddress
     */
    public String getEmailAddress() {
        return emailAddress;
    }

    /**
     * プロパティー：emailAddress を設定します。
     *
     * @param emailAddress emailAddressを設定。
     */
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    /**
     * プロパティー：isSokyushitei を返します。
     *
     * @return isSokyushitei
     */
    public boolean getIsSokyushitei() {
        return isSokyushitei;
    }

    /**
     * プロパティー：isSokyushitei を設定します。
     *
     * @param isSokyushitei isSokyushiteiを設定。
     */
    public void setIsSokyushitei(boolean isSokyushitei) {
        this.isSokyushitei = isSokyushitei;
    }

    /**
     * プロパティー：tekikakuSeikyuushoHakkouJigyoushaNo を返します。
     *
     * @return tekikakuSeikyuushoHakkouJigyoushaNo
     */
    public String getTekikakuSeikyuushoHakkouJigyoushaNo() {
        return tekikakuSeikyuushoHakkouJigyoushaNo;
    }

    /**
     * プロパティー：tekikakuSeikyuushoHakkouJigyoushaNo を設定します。
     *
     * @param tekikakuSeikyuushoHakkouJigyoushaNo tekikakuSeikyuushoHakkouJigyoushaNoを設定。
     */
    public void setTekikakuSeikyuushoHakkouJigyoushaNo(String tekikakuSeikyuushoHakkouJigyoushaNo) {
        this.tekikakuSeikyuushoHakkouJigyoushaNo = tekikakuSeikyuushoHakkouJigyoushaNo;
    }

    /**
     * プロパティー：tourokuDate を返します。
     *
     * @return tourokuDate
     */
    public java.sql.Date getTourokuDate() {
        return tourokuDate;
    }

    /**
     * プロパティー：tourokuDate を設定します。
     *
     * @param tourokuDate tourokuDateを設定。
     */
    public void setTourokuDate(java.sql.Date tourokuDate) {
        this.tourokuDate = tourokuDate;
    }
}
