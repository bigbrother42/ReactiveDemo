package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

public class ShouhizeiritsuMWebDto extends CustomerWebDtoBase {

    /** プロパティ startDate */
    private java.sql.Date startDate = null;

    /** プロパティ endDate */
    private java.sql.Date endDate = null;

    /** プロパティ shouhizeiType */
    private String shouhizeiType = null;

    /** プロパティ shouhizeiRate */
    private java.math.BigDecimal shouhizeiRate = null;

    /**
     * デフォルトのコンストラクタ
     */
    public ShouhizeiritsuMWebDto() {
        super();
    }

    /**
     * プロパティー：startDate を返します。
     *
     * @return startDate
     */
    public java.sql.Date getStartDate() {
        return startDate;
    }

    /**
     * プロパティー：startDate を設定します。
     *
     * @param startDate startDateを設定。
     */
    public void setStartDate(java.sql.Date startDate) {
        this.startDate = startDate;
    }

    /**
     * プロパティー：endDate を返します。
     *
     * @return endDate
     */
    public java.sql.Date getEndDate() {
        return endDate;
    }

    /**
     * プロパティー：endDate を設定します。
     *
     * @param endDate endDateを設定。
     */
    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    /**
     * プロパティー：shouhizeiType を返します。
     *
     * @return shouhizeiType
     */
    public String getShouhizeiType() {
        return shouhizeiType;
    }

    /**
     * プロパティー：shouhizeiType を設定します。
     *
     * @param shouhizeiType shouhizeiTypeを設定。
     */
    public void setShouhizeiType(String shouhizeiType) {
        this.shouhizeiType = shouhizeiType;
    }

    /**
     * プロパティー：shouhizeiRate を返します。
     *
     * @return shouhizeiRate
     */
    public java.math.BigDecimal getShouhizeiRate() {
        return shouhizeiRate;
    }

    /**
     * プロパティー：shouhizeiRate を設定します。
     *
     * @param shouhizeiRate shouhizeiRateを設定。
     */
    public void setShouhizeiRate(java.math.BigDecimal shouhizeiRate) {
        this.shouhizeiRate = shouhizeiRate;
    }
}
