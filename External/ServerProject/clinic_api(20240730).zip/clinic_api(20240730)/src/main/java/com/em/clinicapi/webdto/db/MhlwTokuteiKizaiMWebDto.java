package com.em.clinicapi.webdto.db;


import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

import java.math.BigDecimal;
import java.sql.Date;

public class MhlwTokuteiKizaiMWebDto extends CustomerWebDtoBase {
    private String tokuteiKizaiCode = null;
    private Date startDate = null;
    private String changeKbn = null;
    private String masterType = null;
    private Integer tokuteiKizaiKanjiValidCharCount = null;
    private String tokuteiKizaiKanjiName = null;
    private Integer tokuteiKizaiKanaValidCharCount = null;
    private String tokuteiKizaiKanaName = null;
    private String unitCode = null;
    private Integer unitNameValidCharCount = null;
    private String unitName = null;
    private String kingakuType = null;
    private BigDecimal kingaku = null;
    private String yobi1 = null;
    private String ageKasanKbn = null;
    private String kagenAge = null;
    private String jougenAge = null;
    private String formerKingakuType = null;
    private BigDecimal formerKingaku = null;
    private String kanjiNameChangeKbn = null;
    private String kanaNameChangeKbn = null;
    private String sansoRateKbn = null;
    private String tokuteiKizaiType = null;
    private String jougenKakakuKbn = null;
    private BigDecimal jougenTensuu = null;
    private String yobi2 = null;
    private String kouhyouOrderNo = null;
    private String haishiShinsetsuKanrenNo = null;
    private Date changeDate = null;
    private Date keikaSochiDate = null;
    private Date endDate = null;
    private String beppyouNo = null;
    private String kbnNo = null;
    private String dpcTekiyouKbn = null;
    private String yobi3 = null;
    private String yobi4 = null;
    private String yobi5 = null;
    private String basicKanjiName = null;
    private Integer filmBunkatsu = null;
    private String tekiyouHokenKbn = null;
    private String shinryouKbn = null;
    private String filmId = null;
    private String seikyuuMasterCode = null;
    private String saiseizouTankaiShiyouIryoukikiKbn = null;

    public MhlwTokuteiKizaiMWebDto() {
    }

    public String getTokuteiKizaiCode() {
        return this.tokuteiKizaiCode;
    }

    public void setTokuteiKizaiCode(String tokuteiKizaiCode) {
        this.tokuteiKizaiCode = tokuteiKizaiCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getChangeKbn() {
        return this.changeKbn;
    }

    public void setChangeKbn(String changeKbn) {
        this.changeKbn = changeKbn;
    }

    public String getMasterType() {
        return this.masterType;
    }

    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }

    public Integer getTokuteiKizaiKanjiValidCharCount() {
        return this.tokuteiKizaiKanjiValidCharCount;
    }

    public void setTokuteiKizaiKanjiValidCharCount(Integer tokuteiKizaiKanjiValidCharCount) {
        this.tokuteiKizaiKanjiValidCharCount = tokuteiKizaiKanjiValidCharCount;
    }

    public String getTokuteiKizaiKanjiName() {
        return this.tokuteiKizaiKanjiName;
    }

    public void setTokuteiKizaiKanjiName(String tokuteiKizaiKanjiName) {
        this.tokuteiKizaiKanjiName = tokuteiKizaiKanjiName;
    }

    public Integer getTokuteiKizaiKanaValidCharCount() {
        return this.tokuteiKizaiKanaValidCharCount;
    }

    public void setTokuteiKizaiKanaValidCharCount(Integer tokuteiKizaiKanaValidCharCount) {
        this.tokuteiKizaiKanaValidCharCount = tokuteiKizaiKanaValidCharCount;
    }

    public String getTokuteiKizaiKanaName() {
        return this.tokuteiKizaiKanaName;
    }

    public void setTokuteiKizaiKanaName(String tokuteiKizaiKanaName) {
        this.tokuteiKizaiKanaName = tokuteiKizaiKanaName;
    }

    public String getUnitCode() {
        return this.unitCode;
    }

    public void setUnitCode(String unitCode) {
        this.unitCode = unitCode;
    }

    public Integer getUnitNameValidCharCount() {
        return this.unitNameValidCharCount;
    }

    public void setUnitNameValidCharCount(Integer unitNameValidCharCount) {
        this.unitNameValidCharCount = unitNameValidCharCount;
    }

    public String getUnitName() {
        return this.unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getKingakuType() {
        return this.kingakuType;
    }

    public void setKingakuType(String kingakuType) {
        this.kingakuType = kingakuType;
    }

    public BigDecimal getKingaku() {
        return this.kingaku;
    }

    public void setKingaku(BigDecimal kingaku) {
        this.kingaku = kingaku;
    }

    public String getYobi1() {
        return this.yobi1;
    }

    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    public String getAgeKasanKbn() {
        return this.ageKasanKbn;
    }

    public void setAgeKasanKbn(String ageKasanKbn) {
        this.ageKasanKbn = ageKasanKbn;
    }

    public String getKagenAge() {
        return this.kagenAge;
    }

    public void setKagenAge(String kagenAge) {
        this.kagenAge = kagenAge;
    }

    public String getJougenAge() {
        return this.jougenAge;
    }

    public void setJougenAge(String jougenAge) {
        this.jougenAge = jougenAge;
    }

    public String getFormerKingakuType() {
        return this.formerKingakuType;
    }

    public void setFormerKingakuType(String formerKingakuType) {
        this.formerKingakuType = formerKingakuType;
    }

    public BigDecimal getFormerKingaku() {
        return this.formerKingaku;
    }

    public void setFormerKingaku(BigDecimal formerKingaku) {
        this.formerKingaku = formerKingaku;
    }

    public String getKanjiNameChangeKbn() {
        return this.kanjiNameChangeKbn;
    }

    public void setKanjiNameChangeKbn(String kanjiNameChangeKbn) {
        this.kanjiNameChangeKbn = kanjiNameChangeKbn;
    }

    public String getKanaNameChangeKbn() {
        return this.kanaNameChangeKbn;
    }

    public void setKanaNameChangeKbn(String kanaNameChangeKbn) {
        this.kanaNameChangeKbn = kanaNameChangeKbn;
    }

    public String getSansoRateKbn() {
        return this.sansoRateKbn;
    }

    public void setSansoRateKbn(String sansoRateKbn) {
        this.sansoRateKbn = sansoRateKbn;
    }

    public String getTokuteiKizaiType() {
        return this.tokuteiKizaiType;
    }

    public void setTokuteiKizaiType(String tokuteiKizaiType) {
        this.tokuteiKizaiType = tokuteiKizaiType;
    }

    public String getJougenKakakuKbn() {
        return this.jougenKakakuKbn;
    }

    public void setJougenKakakuKbn(String jougenKakakuKbn) {
        this.jougenKakakuKbn = jougenKakakuKbn;
    }

    public BigDecimal getJougenTensuu() {
        return this.jougenTensuu;
    }

    public void setJougenTensuu(BigDecimal jougenTensuu) {
        this.jougenTensuu = jougenTensuu;
    }

    public String getYobi2() {
        return this.yobi2;
    }

    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    public String getKouhyouOrderNo() {
        return this.kouhyouOrderNo;
    }

    public void setKouhyouOrderNo(String kouhyouOrderNo) {
        this.kouhyouOrderNo = kouhyouOrderNo;
    }

    public String getHaishiShinsetsuKanrenNo() {
        return this.haishiShinsetsuKanrenNo;
    }

    public void setHaishiShinsetsuKanrenNo(String haishiShinsetsuKanrenNo) {
        this.haishiShinsetsuKanrenNo = haishiShinsetsuKanrenNo;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getKeikaSochiDate() {
        return this.keikaSochiDate;
    }

    public void setKeikaSochiDate(Date keikaSochiDate) {
        this.keikaSochiDate = keikaSochiDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getBeppyouNo() {
        return this.beppyouNo;
    }

    public void setBeppyouNo(String beppyouNo) {
        this.beppyouNo = beppyouNo;
    }

    public String getKbnNo() {
        return this.kbnNo;
    }

    public void setKbnNo(String kbnNo) {
        this.kbnNo = kbnNo;
    }

    public String getDpcTekiyouKbn() {
        return this.dpcTekiyouKbn;
    }

    public void setDpcTekiyouKbn(String dpcTekiyouKbn) {
        this.dpcTekiyouKbn = dpcTekiyouKbn;
    }

    public String getYobi3() {
        return this.yobi3;
    }

    public void setYobi3(String yobi3) {
        this.yobi3 = yobi3;
    }

    public String getYobi4() {
        return this.yobi4;
    }

    public void setYobi4(String yobi4) {
        this.yobi4 = yobi4;
    }

    public String getYobi5() {
        return this.yobi5;
    }

    public void setYobi5(String yobi5) {
        this.yobi5 = yobi5;
    }

    public String getBasicKanjiName() {
        return this.basicKanjiName;
    }

    public void setBasicKanjiName(String basicKanjiName) {
        this.basicKanjiName = basicKanjiName;
    }

    public Integer getFilmBunkatsu() {
        return this.filmBunkatsu;
    }

    public void setFilmBunkatsu(Integer filmBunkatsu) {
        this.filmBunkatsu = filmBunkatsu;
    }

    public String getTekiyouHokenKbn() {
        return this.tekiyouHokenKbn;
    }

    public void setTekiyouHokenKbn(String tekiyouHokenKbn) {
        this.tekiyouHokenKbn = tekiyouHokenKbn;
    }

    public String getShinryouKbn() {
        return this.shinryouKbn;
    }

    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }

    public String getFilmId() {
        return this.filmId;
    }

    public void setFilmId(String filmId) {
        this.filmId = filmId;
    }

    public String getSeikyuuMasterCode() {
        return this.seikyuuMasterCode;
    }

    public void setSeikyuuMasterCode(String seikyuuMasterCode) {
        this.seikyuuMasterCode = seikyuuMasterCode;
    }

    public String getSaiseizouTankaiShiyouIryoukikiKbn() {
        return this.saiseizouTankaiShiyouIryoukikiKbn;
    }

    public void setSaiseizouTankaiShiyouIryoukikiKbn(String saiseizouTankaiShiyouIryoukikiKbn) {
        this.saiseizouTankaiShiyouIryoukikiKbn = saiseizouTankaiShiyouIryoukikiKbn;
    }
}
