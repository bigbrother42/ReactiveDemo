package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class KarteWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ karteSeq */
	private int  karteSeq = 0;

	/**  プロパティ shinryoukaCode */
	private String  shinryoukaCode = null;

	/**  プロパティ doctorCode */
	private String  doctorCode = null;

	/**  プロパティ timeKbn */
	private String  timeKbn = null;

	/**  プロパティ ingaiTouyakuKbn */
	private String  ingaiTouyakuKbn = null;

	/**  プロパティ markKbn */
	private String  markKbn = null;

	/**  プロパティ shusoShokenChuushutsuWord */
	private String  shusoShokenChuushutsuWord = null;

	/**  プロパティ shochiChuushutsuWord */
	private String  shochiChuushutsuWord = null;

	/**  プロパティ shouninKbn */
	private String  shouninKbn = null;

	/**  プロパティ shouninsha */
	private String  shouninsha = null;

	/**  プロパティ shouninDateTime */
	private java.sql.Timestamp  shouninDateTime = null;

	/**  プロパティ kakuteiKbn */
	private String  kakuteiKbn = null;

	/**  プロパティ kakuteisha */
	private String  kakuteisha = null;

	/**  プロパティ kakuteiDateTime */
	private java.sql.Timestamp  kakuteiDateTime = null;

	/**  プロパティ thirdPartyNinshouKbn */
	private String  thirdPartyNinshouKbn = null;

	/**  プロパティ isIppoukaTaishougai */
	private boolean  isIppoukaTaishougai;

	/**  プロパティ shosaishinKbn */
	private String  shosaishinKbn = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public KarteWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：karteSeq を返します。
	* @return karteSeq
	*/
	public int getKarteSeq(){
		return karteSeq;
	}

	/**
	* プロパティー：karteSeq を設定します。
	* @param param  int karteSeq
	*/
	public void setKarteSeq(int karteSeq){
		this.karteSeq = karteSeq;
	}

	/**
	* プロパティー：shinryoukaCode を返します。
	* @return shinryoukaCode
	*/
	public String getShinryoukaCode(){
		return shinryoukaCode;
	}

	/**
	* プロパティー：shinryoukaCode を設定します。
	* @param param  String shinryoukaCode
	*/
	public void setShinryoukaCode(String shinryoukaCode){
		this.shinryoukaCode = shinryoukaCode;
	}

	/**
	* プロパティー：doctorCode を返します。
	* @return doctorCode
	*/
	public String getDoctorCode(){
		return doctorCode;
	}

	/**
	* プロパティー：doctorCode を設定します。
	* @param param  String doctorCode
	*/
	public void setDoctorCode(String doctorCode){
		this.doctorCode = doctorCode;
	}

	/**
	* プロパティー：timeKbn を返します。
	* @return timeKbn
	*/
	public String getTimeKbn(){
		return timeKbn;
	}

	/**
	* プロパティー：timeKbn を設定します。
	* @param param  String timeKbn
	*/
	public void setTimeKbn(String timeKbn){
		this.timeKbn = timeKbn;
	}

	/**
	* プロパティー：ingaiTouyakuKbn を返します。
	* @return ingaiTouyakuKbn
	*/
	public String getIngaiTouyakuKbn(){
		return ingaiTouyakuKbn;
	}

	/**
	* プロパティー：ingaiTouyakuKbn を設定します。
	* @param param  String ingaiTouyakuKbn
	*/
	public void setIngaiTouyakuKbn(String ingaiTouyakuKbn){
		this.ingaiTouyakuKbn = ingaiTouyakuKbn;
	}

	/**
	* プロパティー：markKbn を返します。
	* @return markKbn
	*/
	public String getMarkKbn(){
		return markKbn;
	}

	/**
	* プロパティー：markKbn を設定します。
	* @param param  String markKbn
	*/
	public void setMarkKbn(String markKbn){
		this.markKbn = markKbn;
	}

	/**
	* プロパティー：shusoShokenChuushutsuWord を返します。
	* @return shusoShokenChuushutsuWord
	*/
	public String getShusoShokenChuushutsuWord(){
		return shusoShokenChuushutsuWord;
	}

	/**
	* プロパティー：shusoShokenChuushutsuWord を設定します。
	* @param param  String shusoShokenChuushutsuWord
	*/
	public void setShusoShokenChuushutsuWord(String shusoShokenChuushutsuWord){
		this.shusoShokenChuushutsuWord = shusoShokenChuushutsuWord;
	}

	/**
	* プロパティー：shochiChuushutsuWord を返します。
	* @return shochiChuushutsuWord
	*/
	public String getShochiChuushutsuWord(){
		return shochiChuushutsuWord;
	}

	/**
	* プロパティー：shochiChuushutsuWord を設定します。
	* @param param  String shochiChuushutsuWord
	*/
	public void setShochiChuushutsuWord(String shochiChuushutsuWord){
		this.shochiChuushutsuWord = shochiChuushutsuWord;
	}

	/**
	* プロパティー：shouninKbn を返します。
	* @return shouninKbn
	*/
	public String getShouninKbn(){
		return shouninKbn;
	}

	/**
	* プロパティー：shouninKbn を設定します。
	* @param param  String shouninKbn
	*/
	public void setShouninKbn(String shouninKbn){
		this.shouninKbn = shouninKbn;
	}

	/**
	* プロパティー：shouninsha を返します。
	* @return shouninsha
	*/
	public String getShouninsha(){
		return shouninsha;
	}

	/**
	* プロパティー：shouninsha を設定します。
	* @param param  String shouninsha
	*/
	public void setShouninsha(String shouninsha){
		this.shouninsha = shouninsha;
	}

	/**
	* プロパティー：shouninDateTime を返します。
	* @return shouninDateTime
	*/
	public java.sql.Timestamp getShouninDateTime(){
		return shouninDateTime;
	}

	/**
	* プロパティー：shouninDateTime を設定します。
	* @param param  java.sql.Timestamp shouninDateTime
	*/
	public void setShouninDateTime(java.sql.Timestamp shouninDateTime){
		this.shouninDateTime = shouninDateTime;
	}

	/**
	* プロパティー：kakuteiKbn を返します。
	* @return kakuteiKbn
	*/
	public String getKakuteiKbn(){
		return kakuteiKbn;
	}

	/**
	* プロパティー：kakuteiKbn を設定します。
	* @param param  String kakuteiKbn
	*/
	public void setKakuteiKbn(String kakuteiKbn){
		this.kakuteiKbn = kakuteiKbn;
	}

	/**
	* プロパティー：kakuteisha を返します。
	* @return kakuteisha
	*/
	public String getKakuteisha(){
		return kakuteisha;
	}

	/**
	* プロパティー：kakuteisha を設定します。
	* @param param  String kakuteisha
	*/
	public void setKakuteisha(String kakuteisha){
		this.kakuteisha = kakuteisha;
	}

	/**
	* プロパティー：kakuteiDateTime を返します。
	* @return kakuteiDateTime
	*/
	public java.sql.Timestamp getKakuteiDateTime(){
		return kakuteiDateTime;
	}

	/**
	* プロパティー：kakuteiDateTime を設定します。
	* @param param  java.sql.Timestamp kakuteiDateTime
	*/
	public void setKakuteiDateTime(java.sql.Timestamp kakuteiDateTime){
		this.kakuteiDateTime = kakuteiDateTime;
	}

	/**
	* プロパティー：thirdPartyNinshouKbn を返します。
	* @return thirdPartyNinshouKbn
	*/
	public String getThirdPartyNinshouKbn(){
		return thirdPartyNinshouKbn;
	}

	/**
	* プロパティー：thirdPartyNinshouKbn を設定します。
	* @param param  String thirdPartyNinshouKbn
	*/
	public void setThirdPartyNinshouKbn(String thirdPartyNinshouKbn){
		this.thirdPartyNinshouKbn = thirdPartyNinshouKbn;
	}

	/**
	* プロパティー：isIppoukaTaishougai を返します。
	* @return isIppoukaTaishougai
	*/
	public boolean getIsIppoukaTaishougai(){
		return isIppoukaTaishougai;
	}

	/**
	* プロパティー：isIppoukaTaishougai を設定します。
	* @param param  boolean isIppoukaTaishougai
	*/
	public void setIsIppoukaTaishougai(boolean isIppoukaTaishougai){
		this.isIppoukaTaishougai = isIppoukaTaishougai;
	}

	/**
	* プロパティー：shosaishinKbn を返します。
	* @return shosaishinKbn
	*/
	public String getShosaishinKbn(){
		return shosaishinKbn;
	}

	/**
	* プロパティー：shosaishinKbn を設定します。
	* @param param  String shosaishinKbn
	*/
	public void setShosaishinKbn(String shosaishinKbn){
		this.shosaishinKbn = shosaishinKbn;
	}
}
