package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

import java.sql.Date;
@Component
public class EmsUnitCodeMWebDto extends CustomerWebDtoBase {
    private String unitCode = null;
    private Date startDate = null;
    private Date endDate = null;
    private String unitName = null;
    private String madoguchiName = null;
    private String rezeptName = null;
    private String yakuzaiDisplayName = null;
    private boolean isKansan;

    public EmsUnitCodeMWebDto() {
    }

    public String getUnitCode() {
        return this.unitCode;
    }

    public void setUnitCode(String unitCode) {
        this.unitCode = unitCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getUnitName() {
        return this.unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getMadoguchiName() {
        return this.madoguchiName;
    }

    public void setMadoguchiName(String madoguchiName) {
        this.madoguchiName = madoguchiName;
    }

    public String getRezeptName() {
        return this.rezeptName;
    }

    public void setRezeptName(String rezeptName) {
        this.rezeptName = rezeptName;
    }

    public String getYakuzaiDisplayName() {
        return this.yakuzaiDisplayName;
    }

    public void setYakuzaiDisplayName(String yakuzaiDisplayName) {
        this.yakuzaiDisplayName = yakuzaiDisplayName;
    }

    public boolean getIsKansan() {
        return this.isKansan;
    }

    public void setIsKansan(boolean isKansan) {
        this.isKansan = isKansan;
    }
}
