package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2019
/****************************************************************************/

/**
 * WebDto : KouhiMWebDto クラス<br>
 *
 * 自動生成クラス<br>
 *
 * 作成日 ： 2019/03/20<br>
 *
 * @author DAOGenerator4Smart
 */
//***************************************************************************
@Component
public class KouhiMWebDto extends CustomerWebDtoBase {

	/** プロパティ houbetsuNo */
	private String houbetsuNo = null;

	/** プロパティ seidoKbn */
	private String seidoKbn = null;

	/** プロパティ startDate */
	private java.sql.Date startDate = null;

	/** プロパティ endDate */
	private java.sql.Date endDate = null;

	/** プロパティ kouhiName */
	private String kouhiName = null;

	/** プロパティ kouhiShortName */
	private String kouhiShortName = null;

	/** プロパティ kouhiPriorityOrder */
	private int kouhiPriorityOrder = 0;

	/** プロパティ tekiyouKbn */
	private String tekiyouKbn = null;

	/** プロパティ tsukigendogakuConfigKbn */
	private String tsukigendogakuConfigKbn = null;

	/** プロパティ futanWariaiKbn */
	private String futanWariaiKbn = null;

	/** プロパティ futanWariai */
	private java.math.BigDecimal futanWariai = null;

	/** プロパティ patientFutanGendogakuKbn */
	private String patientFutanGendogakuKbn = null;

	/** プロパティ taishouHokenKbn */
	private String taishouHokenKbn = null;

	/** プロパティ taishouHokenGendogakuKbn */
	private String taishouHokenGendogakuKbn = null;

	/** プロパティ isShotokuKbnTokkijikouHitsuyou */
	private boolean isShotokuKbnTokkijikouHitsuyou;

	/**
	 * デフォルトのコンストラクタ
	 */
	public KouhiMWebDto() {
		super();
	}

	/**
	 * プロパティー：houbetsuNo を返します。
	 *
	 * @return houbetsuNo
	 */
	public String getHoubetsuNo() {
		return houbetsuNo;
	}

	/**
	 * プロパティー：houbetsuNo を設定します。
	 *
	 * @param houbetsuNo houbetsuNoを設定。
	 */
	public void setHoubetsuNo(String houbetsuNo) {
		this.houbetsuNo = houbetsuNo;
	}

	/**
	 * プロパティー：seidoKbn を返します。
	 *
	 * @return seidoKbn
	 */
	public String getSeidoKbn() {
		return seidoKbn;
	}

	/**
	 * プロパティー：seidoKbn を設定します。
	 *
	 * @param seidoKbn seidoKbnを設定。
	 */
	public void setSeidoKbn(String seidoKbn) {
		this.seidoKbn = seidoKbn;
	}

	/**
	 * プロパティー：startDate を返します。
	 *
	 * @return startDate
	 */
	public java.sql.Date getStartDate() {
		return startDate;
	}

	/**
	 * プロパティー：startDate を設定します。
	 *
	 * @param startDate startDateを設定。
	 */
	public void setStartDate(java.sql.Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * プロパティー：endDate を返します。
	 *
	 * @return endDate
	 */
	public java.sql.Date getEndDate() {
		return endDate;
	}

	/**
	 * プロパティー：endDate を設定します。
	 *
	 * @param endDate endDateを設定。
	 */
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * プロパティー：kouhiName を返します。
	 *
	 * @return kouhiName
	 */
	public String getKouhiName() {
		return kouhiName;
	}

	/**
	 * プロパティー：kouhiName を設定します。
	 *
	 * @param kouhiName kouhiNameを設定。
	 */
	public void setKouhiName(String kouhiName) {
		this.kouhiName = kouhiName;
	}

	/**
	 * プロパティー：kouhiShortName を返します。
	 *
	 * @return kouhiShortName
	 */
	public String getKouhiShortName() {
		return kouhiShortName;
	}

	/**
	 * プロパティー：kouhiShortName を設定します。
	 *
	 * @param kouhiShortName kouhiShortNameを設定。
	 */
	public void setKouhiShortName(String kouhiShortName) {
		this.kouhiShortName = kouhiShortName;
	}

	/**
	 * プロパティー：kouhiPriorityOrder を返します。
	 *
	 * @return kouhiPriorityOrder
	 */
	public int getKouhiPriorityOrder() {
		return kouhiPriorityOrder;
	}

	/**
	 * プロパティー：kouhiPriorityOrder を設定します。
	 *
	 * @param kouhiPriorityOrder kouhiPriorityOrderを設定。
	 */
	public void setKouhiPriorityOrder(int kouhiPriorityOrder) {
		this.kouhiPriorityOrder = kouhiPriorityOrder;
	}

	/**
	 * プロパティー：tekiyouKbn を返します。
	 *
	 * @return tekiyouKbn
	 */
	public String getTekiyouKbn() {
		return tekiyouKbn;
	}

	/**
	 * プロパティー：tekiyouKbn を設定します。
	 *
	 * @param tekiyouKbn tekiyouKbnを設定。
	 */
	public void setTekiyouKbn(String tekiyouKbn) {
		this.tekiyouKbn = tekiyouKbn;
	}

	/**
	 * プロパティー：tsukigendogakuConfigKbn を返します。
	 *
	 * @return tsukigendogakuConfigKbn
	 */
	public String getTsukigendogakuConfigKbn() {
		return tsukigendogakuConfigKbn;
	}

	/**
	 * プロパティー：tsukigendogakuConfigKbn を設定します。
	 *
	 * @param tsukigendogakuConfigKbn tsukigendogakuConfigKbnを設定。
	 */
	public void setTsukigendogakuConfigKbn(String tsukigendogakuConfigKbn) {
		this.tsukigendogakuConfigKbn = tsukigendogakuConfigKbn;
	}

	/**
	 * プロパティー：futanWariaiKbn を返します。
	 *
	 * @return futanWariaiKbn
	 */
	public String getFutanWariaiKbn() {
		return futanWariaiKbn;
	}

	/**
	 * プロパティー：futanWariaiKbn を設定します。
	 *
	 * @param futanWariaiKbn futanWariaiKbnを設定。
	 */
	public void setFutanWariaiKbn(String futanWariaiKbn) {
		this.futanWariaiKbn = futanWariaiKbn;
	}

	/**
	 * プロパティー：futanWariai を返します。
	 *
	 * @return futanWariai
	 */
	public java.math.BigDecimal getFutanWariai() {
		return futanWariai;
	}

	/**
	 * プロパティー：futanWariai を設定します。
	 *
	 * @param futanWariai futanWariaiを設定。
	 */
	public void setFutanWariai(java.math.BigDecimal futanWariai) {
		this.futanWariai = futanWariai;
	}

	/**
	 * プロパティー：patientFutanGendogakuKbn を返します。
	 *
	 * @return patientFutanGendogakuKbn
	 */
	public String getPatientFutanGendogakuKbn() {
		return patientFutanGendogakuKbn;
	}

	/**
	 * プロパティー：patientFutanGendogakuKbn を設定します。
	 *
	 * @param patientFutanGendogakuKbn patientFutanGendogakuKbnを設定。
	 */
	public void setPatientFutanGendogakuKbn(String patientFutanGendogakuKbn) {
		this.patientFutanGendogakuKbn = patientFutanGendogakuKbn;
	}

	/**
	 * プロパティー：taishouHokenKbn を返します。
	 *
	 * @return taishouHokenKbn
	 */
	public String getTaishouHokenKbn() {
		return taishouHokenKbn;
	}

	/**
	 * プロパティー：taishouHokenKbn を設定します。
	 *
	 * @param taishouHokenKbn taishouHokenKbnを設定。
	 */
	public void setTaishouHokenKbn(String taishouHokenKbn) {
		this.taishouHokenKbn = taishouHokenKbn;
	}

	/**
	 * プロパティー：taishouHokenGendogakuKbn を返します。
	 *
	 * @return taishouHokenGendogakuKbn
	 */
	public String getTaishouHokenGendogakuKbn() {
		return taishouHokenGendogakuKbn;
	}

	/**
	 * プロパティー：taishouHokenGendogakuKbn を設定します。
	 *
	 * @param taishouHokenGendogakuKbn taishouHokenGendogakuKbnを設定。
	 */
	public void setTaishouHokenGendogakuKbn(String taishouHokenGendogakuKbn) {
		this.taishouHokenGendogakuKbn = taishouHokenGendogakuKbn;
	}

	/**
	 * プロパティー：isShotokuKbnTokkijikouHitsuyou を返します。
	 *
	 * @return isShotokuKbnTokkijikouHitsuyou
	 */
	public boolean getIsShotokuKbnTokkijikouHitsuyou() {
		return isShotokuKbnTokkijikouHitsuyou;
	}

	/**
	 * プロパティー：isShotokuKbnTokkijikouHitsuyou を設定します。
	 *
	 * @param isShotokuKbnTokkijikouHitsuyou isShotokuKbnTokkijikouHitsuyouを設定。
	 */
	public void setIsShotokuKbnTokkijikouHitsuyou(boolean isShotokuKbnTokkijikouHitsuyou) {
		this.isShotokuKbnTokkijikouHitsuyou = isShotokuKbnTokkijikouHitsuyou;
	}
}
