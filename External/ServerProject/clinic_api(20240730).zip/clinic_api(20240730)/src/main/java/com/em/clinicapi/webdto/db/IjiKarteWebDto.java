package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class IjiKarteWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ isJidouSanteiSelectedHoryuu */
	private boolean  isJidouSanteiSelectedHoryuu;

	/**  プロパティ isFutanKbnSelectedHoryuu */
	private boolean  isFutanKbnSelectedHoryuu;

	/**  プロパティ timeKbn */
	private String  timeKbn = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiKarteWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：isJidouSanteiSelectedHoryuu を返します。
	* @return isJidouSanteiSelectedHoryuu
	*/
	public boolean getIsJidouSanteiSelectedHoryuu(){
		return isJidouSanteiSelectedHoryuu;
	}

	/**
	* プロパティー：isJidouSanteiSelectedHoryuu を設定します。
	* @param param  boolean isJidouSanteiSelectedHoryuu
	*/
	public void setIsJidouSanteiSelectedHoryuu(boolean isJidouSanteiSelectedHoryuu){
		this.isJidouSanteiSelectedHoryuu = isJidouSanteiSelectedHoryuu;
	}

	/**
	* プロパティー：isFutanKbnSelectedHoryuu を返します。
	* @return isFutanKbnSelectedHoryuu
	*/
	public boolean getIsFutanKbnSelectedHoryuu(){
		return isFutanKbnSelectedHoryuu;
	}

	/**
	* プロパティー：isFutanKbnSelectedHoryuu を設定します。
	* @param param  boolean isFutanKbnSelectedHoryuu
	*/
	public void setIsFutanKbnSelectedHoryuu(boolean isFutanKbnSelectedHoryuu){
		this.isFutanKbnSelectedHoryuu = isFutanKbnSelectedHoryuu;
	}

	/**
	* プロパティー：timeKbn を返します。
	* @return timeKbn
	*/
	public String getTimeKbn(){
		return timeKbn;
	}

	/**
	* プロパティー：timeKbn を設定します。
	* @param param  String timeKbn
	*/
	public void setTimeKbn(String timeKbn){
		this.timeKbn = timeKbn;
	}
}
