package com.em.clinicapi.common.constants;

public class StringConstants {

    public static final String EMPTY_STRING = "";
    public static final String NULL_STRING = "null";
    public static final String N = "N";

    public static final String NUMBER_0 = "0";
    public static final String NUMBER_1 = "1";
    public static final String NUMBER_2 = "2";
    public static final String NUMBER_3 = "3";
    public static final String NUMBER_4 = "4";
    public static final String NUMBER_5 = "5";
    public static final String NUMBER_6 = "6";
    public static final String NUMBER_7 = "7";
    public static final String NUMBER_8 = "8";
    public static final String NUMBER_9 = "9";

    public static final String BOOLEAN_TRUE = "True";
    public static final String BOOLEAN_FALSE = "False";

    public static final String DATE_00010103 = "0001-01-03";
    public static final String DATE_19000101 = "1900-01-01";
    public static final String DATE_99991231 = "9999-12-31";

    public static final String CLASS_TYPE_RECORD = "record";
    public static final String CLASS_TYPE_ARRAY = "array";
    public static final String SPRING_SECURITY_LAST_EXCEPTION = "SPRING_SECURITY_LAST_EXCEPTION";
    public static final String Error = "Error";
    public static final String ErrorCode = "ErrorCode";
    public static final String Unauthorized = "Unauthorized";
    public static final String Message = "Message";
    public static final String ContentTypeJson = "application/json; charset=UTF-8";
    public static final String ContentTypeXml = "application/xml";
}
