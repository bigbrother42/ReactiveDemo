package com.em.clinicapi.service;

import com.em.clinicapi.logic.EmReplicationLogic;
import com.em.clinicapi.webdto.ReplicationMCustomWebDto;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



/****************************************************************************/
/*                      (C) EM Systems Ltd. 2018
/****************************************************************************/
/**
 * MAPsシリーズ製品のデータ構築に関連する操作を提供するサービスクラス<br>
 * 
 * @author S.M.Busque(AWS)
 * @since 0.0.1-r3
 * @version 1.2.2021.05210
 * @date 2018/11/26
 */
// ***************************************************************************
@Service
public class EmReplicationService {

	@Autowired
	private EmReplicationLogic logic;

	/**
	 * 指定されたグループの一意の識別子SEQに該当するレプリケーション情報を取得します。
	 * 
	 * @param groupSeq グループの一意の識別子SEQ
	 * @param customerSeq 顧客の一意の識別子SEQ
	 * @return グループの一意の識別子SEQに該当するレプリケーション情報<br>
	 *         グループの一意の識別子SEQに該当するレプリケーション情報が存在していない場合、NULLが返却します。
	 */
	@Transactional
	public ReplicationMCustomWebDto loadGroupCustomerReplication(Integer groupSeq, Integer customerSeq) {
		return logic.selectGroupCustomerReplication(groupSeq, customerSeq);
	}
}