package com.em.clinicapi.config;

import com.em.clinicapi.config.auth.*;
import com.em.clinicapi.filter.ApiKeyAuthFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.access.ExceptionTranslationFilter;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final static String URI_CLINIC_API = "/clinic/api/**";

    @Value("${api.key.header}")
    private String apiKeyHeader;

    @Value("${api.key.value}")
    private String apiKeyValue;

    @Autowired
    private CustomUserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private CustomAuthenticationEntryPoint customAuthenticationEntryPoint;

    @Bean
    public ApiKeyAuthFilter apiKeyAuthFilter() throws Exception {
        ApiKeyAuthFilter filter = new ApiKeyAuthFilter(apiKeyHeader, customAuthenticationEntryPoint);
        filter.setContinueFilterChainOnUnsuccessfulAuthentication(false);
        filter.setAuthenticationManager(super.authenticationManagerBean());

        return filter;
    }

    /**
     * ユーザーのパスワードエンコードクラスの取得処理
     *
     * @return PasswordEncoderインスタンス
     */
    @Bean
    public PasswordEncoder userPasswordEncoder() {
        return new BCryptPasswordEncoder(8);
    }

    @Override
    protected void configure(AuthenticationManagerBuilder auth) {
        ApiKeyAuthProvider authProvider = new ApiKeyAuthProvider(apiKeyValue, userDetailsService, passwordEncoder);
        auth.authenticationProvider(authProvider);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {

        http
            .addFilterBefore(apiKeyAuthFilter(), AbstractPreAuthenticatedProcessingFilter.class)
            .authorizeRequests() // AuthorizationFilter
                .antMatchers(URI_CLINIC_API).permitAll()
                .anyRequest().authenticated()
                .and()
            .formLogin().disable() // UsernamePasswordAuthenticationFilter
            .httpBasic() // BasicAuthenticationFilter
                //.authenticationEntryPoint(customAuthenticationEntryPoint)
                .and()
            .csrf().disable() // CsrfFilter
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
        ;


    }
}
