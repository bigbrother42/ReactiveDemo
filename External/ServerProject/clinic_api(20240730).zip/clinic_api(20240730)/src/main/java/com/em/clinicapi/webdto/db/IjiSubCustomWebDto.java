package com.em.clinicapi.webdto.db;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2019
/****************************************************************************/
/**
* WebDto : 医事サブ情報 クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2019/05/24 <BR>
*
* @author WebDtoGen4Smart
*/
//***************************************************************************

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class IjiSubCustomWebDto extends CustomerWebDtoBase {
	private IjiSubWebDto ijiSubWebDto;
	private List<IjiItemCustomWebDto> ijiItemCustomWebDtoList = new ArrayList<IjiItemCustomWebDto>();
	
	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiSubCustomWebDto(){
		super();
	}

    /**
     * @return IjiSubWebDto 医事サブ
     */
    public IjiSubWebDto getIjiSubWebDto() {
        return ijiSubWebDto;
    }
    /**
     * @param ijiSubWebDto セットする IjiSubWebDto 医事サブ
     */
    public void setIjiSubWebDto(IjiSubWebDto ijiSubWebDto) {
        this.ijiSubWebDto = ijiSubWebDto;
    }
	/**
     * @return IjiItemCustomWebDtoList 医事項目リスト
     */
    public List<IjiItemCustomWebDto> getIjiItemCustomWebDtoList() {
        return ijiItemCustomWebDtoList;
    }
    /**
     * @param ijiItemCustomWebDtoList セットする IjiItemCustomWebDtoList 医事項目リスト
     */
    public void setIjiItemCustomWebDtoList(List<IjiItemCustomWebDto> ijiItemCustomWebDtoList) {
        this.ijiItemCustomWebDtoList = ijiItemCustomWebDtoList;
    }
	
}
