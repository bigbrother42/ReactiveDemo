package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

public class EmsRousaiAfterCareShoubyouCodeMWebDto extends CustomerWebDtoBase {

    /** プロパティ shoubyouCode */
    private String shoubyouCode = null;

    /** プロパティ shoubyouName */
    private String shoubyouName = null;

    /** プロパティ startDate */
    private java.sql.Date startDate = null;

    /** プロパティ endDate */
    private java.sql.Date endDate = null;

    /**
     * デフォルトのコンストラクタ
     */
    public EmsRousaiAfterCareShoubyouCodeMWebDto() {
        super();
    }

    /**
     * プロパティー：shoubyouCode を返します。
     *
     * @return shoubyouCode
     */
    public String getShoubyouCode() {
        return shoubyouCode;
    }

    /**
     * プロパティー：shoubyouCode を設定します。
     *
     * @param shoubyouCode shoubyouCodeを設定。
     */
    public void setShoubyouCode(String shoubyouCode) {
        this.shoubyouCode = shoubyouCode;
    }

    /**
     * プロパティー：shoubyouName を返します。
     *
     * @return shoubyouName
     */
    public String getShoubyouName() {
        return shoubyouName;
    }

    /**
     * プロパティー：shoubyouName を設定します。
     *
     * @param shoubyouName shoubyouNameを設定。
     */
    public void setShoubyouName(String shoubyouName) {
        this.shoubyouName = shoubyouName;
    }

    /**
     * プロパティー：startDate を返します。
     *
     * @return startDate
     */
    public java.sql.Date getStartDate() {
        return startDate;
    }

    /**
     * プロパティー：startDate を設定します。
     *
     * @param startDate startDateを設定。
     */
    public void setStartDate(java.sql.Date startDate) {
        this.startDate = startDate;
    }

    /**
     * プロパティー：endDate を返します。
     *
     * @return endDate
     */
    public java.sql.Date getEndDate() {
        return endDate;
    }

    /**
     * プロパティー：endDate を設定します。
     *
     * @param endDate endDateを設定。
     */
    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }
}
