package com.em.clinicapi.config.auth;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.exception.CustomAuthenticationException;
import com.em.clinicapi.common.exception.ErrorResponse;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {
        CustomAuthenticationException lastException = RequestCacheHolder.get(StringConstants.SPRING_SECURITY_LAST_EXCEPTION);
        String errorCode = StringConstants.EMPTY_STRING;
        String errorMessage = authException.getMessage();
        if (lastException != null) {
            errorCode = lastException.getErrorCode();
            errorMessage = lastException.getMessage();
        }

        ErrorResponse errorResponse = new ErrorResponse(errorCode, StringConstants.Unauthorized, errorMessage);

        response.setContentType(StringConstants.ContentTypeJson);
        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
    }
}
