package com.em.clinicapi.common.constants.enumerations;

public enum ApiResultSystemInfoEnum {
    Success("00", "処理終了"),
    Over100Objects("10", "対象が１００件以上となります"),
    HasNoObject("11", "対象がありません"),
    UnableGetShouhizei("87", "消費税端数区分がありません"),
    UnableGetJihiHasuu("88", "自費端数がありません"),
    UnableGetStaff("89", "職員情報が取得できません"),
    UnableGetInstitutionInfo("89", "医療機関情報が取得できません"),
    UnableGetSystemDate("89", "システム日付が取得できません"),
    UnableGetPatientNumberConfiguration("89", "患者番号構成情報が取得できません"),
    GroupInstitutionInfoError("89", "グループ医療機関が不整合です。"),
    UnableSetSystemProject("89", "システム項目が設定できません"),
    ShinrkaikMGetStaff("89", "診療科情報が取得できない"),
    AnotherTerminalInUse("90", "他端末使用中"),
    OperationTypeNotSet("91", "処理区分未設定"),
    SendContentError("97", "送信内容に誤りがあります"),
    UnableReadSendContent("98", "送信内容の読込ができませんでした"),
    UserIdNotRegister("99", "ユーザID未登録"),
    UnableGetNyuukyoShisetsuInfo("100", "入居施設情報が取得できません")
    ;

    private final String code;
    private final String description;

    ApiResultSystemInfoEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return code;
    }

    public String getDescription() { return description; }
}
