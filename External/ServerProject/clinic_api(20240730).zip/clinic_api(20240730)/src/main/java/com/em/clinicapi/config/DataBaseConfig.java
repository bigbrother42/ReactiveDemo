package com.em.clinicapi.config;

import com.em.clinicapi.common.db.DynamicDataSource;
import com.em.clinicapi.common.db.CustomDataSourceLookup;
import org.apache.commons.lang3.ArrayUtils;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.util.Assert;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@ComponentScan(basePackages = { "com.em.clinicapi" })
@MapperScan(basePackages = { "com.em.clinicapi" })
public class DataBaseConfig {

    private static final String CLASSPATH_MYBATIS_CONFIG_FILE = "classpath*:config/mybatis-config.xml";
    private static final String CLASSPATH_MYBATIS_SQL_STANDARD = "classpath*:sql/*.xml";
    private static final String CLASSPATH_MYBATIS_SQL_CUSTOM = "classpath*:sql/custom/*.xml";

    @Autowired
    private CustomDataSourceLookup dataSourceLookup;

    @Autowired
    @Bean
    public DataSourceTransactionManager transactionManager() {
        final DataSourceTransactionManager transactionManager = new DataSourceTransactionManager();
        transactionManager.setDataSource(dataSource());
        return transactionManager;
    }

    @Autowired
    @Bean
    public SqlSessionTemplate sqlSessionTemplate() throws Exception {
        final SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource());

        final ResourcePatternResolver resolver = ResourcePatternUtils
                .getResourcePatternResolver(new DefaultResourceLoader());

        final Resource[] config = resolver.getResources(CLASSPATH_MYBATIS_CONFIG_FILE);
        Assert.notEmpty(config, "MyBatis用設定ファイルが見つかりませんでした。");

        // MyBatis のコンフィグレーションファイル
        bean.setConfigLocation(config[0]);

        // MyBatis で使用する SQL ファイル群
        final Resource[] standardSql = resolver.getResources(CLASSPATH_MYBATIS_SQL_STANDARD);
        final Resource[] customSql = resolver.getResources(CLASSPATH_MYBATIS_SQL_CUSTOM);
        final Resource[] allSql = ArrayUtils.addAll(standardSql, customSql);
        bean.setMapperLocations(allSql);

        return new SqlSessionTemplate(bean.getObject());
    }

    @Primary
    @Autowired
    @Bean
    public DataSource dataSource() {
        //DataSource dataSource = dataSourceLookup.getDataSourceOfReplication();

        //return dataSource;

        Map<Object, Object> targetDataSources = new HashMap<>();
        targetDataSources.put(CustomDataSourceLookup.DEFAULT_DATA_SOURCE_NAME, dataSourceLookup.getDataSourceOfReplication());

        DynamicDataSource dynamicDataSource = new DynamicDataSource();
        dynamicDataSource.setTargetDataSources(targetDataSources);
        dynamicDataSource.setDefaultTargetDataSource(CustomDataSourceLookup.DEFAULT_DATA_SOURCE_NAME);
        dynamicDataSource.setDataSourceLookup(this.dataSourceLookup);

        return dynamicDataSource;
    }
}
