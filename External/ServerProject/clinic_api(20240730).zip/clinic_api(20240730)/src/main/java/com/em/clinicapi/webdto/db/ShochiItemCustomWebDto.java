package com.em.clinicapi.webdto.db;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2020
/****************************************************************************/
/**
* WebDto : 処方項目情報 クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2020/01/10 <BR>
*
* @author WebDtoGen4Smart
*/
//***************************************************************************

import org.springframework.stereotype.Component;
import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

@Component
public class ShochiItemCustomWebDto extends CustomerWebDtoBase {
	private ShochiItemWebDto shochiItemWebDto;
	//private SaiyouMCustomWebDto saiyouMCustomWebDto;
	private java.sql.Date firstJisshiDate;
	private java.sql.Date zenkaiJisshiDate;
	private RehabilitationJisshiInfoWebDto rehabilitationJisshiInfoWebDto;
	
	/**
	*  デフォルトのコンストラクタ
	*/
	public ShochiItemCustomWebDto(){
		super();
	}

    /**
     * @return ShochiItemWebDto 診療項目情報
     */
    public ShochiItemWebDto getShochiItemWebDto() {
        return shochiItemWebDto;
    }
    /**
     * @param ShochiItemWebDto セットする ShochiItemWebDto 診療項目情報
     */
    public void setShochiItemWebDto(ShochiItemWebDto shochiItemWebDto) {
        this.shochiItemWebDto = shochiItemWebDto;
    }
	/**
     * @return SaiyouMCustomWebDto 採用情報
     */
//    public SaiyouMCustomWebDto getSaiyouMCustomWebDto() {
//        return saiyouMCustomWebDto;
//    }
    /**
     * @param SaiyouMCustomWebDto セットする SaiyouMCustomWebDto 採用情報
     */
//    public void setSaiyouMCustomWebDto(SaiyouMCustomWebDto saiyouMCustomWebDto) {
//        this.saiyouMCustomWebDto = saiyouMCustomWebDto;
//    }
	/**
     * @return FirstJisshiDate 初回実施日
     */
    public java.sql.Date getFirstJisshiDate() {
        return firstJisshiDate;
    }
    /**
     * @param FirstJisshiDate セットする FirstJisshiDate 初回実施日
     */
    public void setFirstJisshiDate(java.sql.Date firstJisshiDate) {
        this.firstJisshiDate = firstJisshiDate;
    }
	/**
     * @return ZenkaiJisshiDate 前回実施日
     */
    public java.sql.Date getZenkaiJisshiDate() {
        return zenkaiJisshiDate;
    }
    /**
     * @param ZenkaiJisshiDate セットする ZenkaiJisshiDate 前回実施日
     */
    public void setZenkaiJisshiDate(java.sql.Date zenkaiJisshiDate) {
        this.zenkaiJisshiDate = zenkaiJisshiDate;
    }
	/**
     * @return RehabilitationJisshiInfoWebDto リハビリマスター実施情報
     */
    public RehabilitationJisshiInfoWebDto getRehabilitationJisshiInfoWebDto() {
        return rehabilitationJisshiInfoWebDto;
    }
    /**
     * @param RehabilitationJisshiInfoWebDto セットする RehabilitationJisshiInfoWebDto リハビリマスター実施情報
     */
    public void setRehabilitationJisshiInfoWebDto(RehabilitationJisshiInfoWebDto rehabilitationJisshiInfoWebDto) {
        this.rehabilitationJisshiInfoWebDto = rehabilitationJisshiInfoWebDto;
    }
	
}
