package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class ShuhokenRekiWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ startDate */
	private java.sql.Date  startDate = null;

	/**  プロパティ shotokuKbn */
	private String  shotokuKbn = null;

	/**  プロパティ gendogakuTekiyouKbn */
	private String  gendogakuTekiyouKbn = null;

	/**  プロパティ isGendogakuNinteishou */
	private boolean  isGendogakuNinteishou;

	/**  プロパティ patientFutanRate */
	private java.math.BigDecimal  patientFutanRate = null;

	/**  プロパティ kyuufuWariai */
	private java.math.BigDecimal  kyuufuWariai = null;

	/**  プロパティ genmenKbn */
	private String  genmenKbn = null;

	/**  プロパティ gengakuWariai */
	private java.math.BigDecimal  gengakuWariai = null;

	/**  プロパティ gengakuKingaku */
	private java.math.BigDecimal  gengakuKingaku = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public ShuhokenRekiWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：startDate を返します。
	* @return startDate
	*/
	public java.sql.Date getStartDate(){
		return startDate;
	}

	/**
	* プロパティー：startDate を設定します。
	* @param param  java.sql.Date startDate
	*/
	public void setStartDate(java.sql.Date startDate){
		this.startDate = startDate;
	}

	/**
	* プロパティー：shotokuKbn を返します。
	* @return shotokuKbn
	*/
	public String getShotokuKbn(){
		return shotokuKbn;
	}

	/**
	* プロパティー：shotokuKbn を設定します。
	* @param param  String shotokuKbn
	*/
	public void setShotokuKbn(String shotokuKbn){
		this.shotokuKbn = shotokuKbn;
	}

	/**
	* プロパティー：gendogakuTekiyouKbn を返します。
	* @return gendogakuTekiyouKbn
	*/
	public String getGendogakuTekiyouKbn(){
		return gendogakuTekiyouKbn;
	}

	/**
	* プロパティー：gendogakuTekiyouKbn を設定します。
	* @param param  String gendogakuTekiyouKbn
	*/
	public void setGendogakuTekiyouKbn(String gendogakuTekiyouKbn){
		this.gendogakuTekiyouKbn = gendogakuTekiyouKbn;
	}

	/**
	* プロパティー：isGendogakuNinteishou を返します。
	* @return isGendogakuNinteishou
	*/
	public boolean getIsGendogakuNinteishou(){
		return isGendogakuNinteishou;
	}

	/**
	* プロパティー：isGendogakuNinteishou を設定します。
	* @param param  boolean isGendogakuNinteishou
	*/
	public void setIsGendogakuNinteishou(boolean isGendogakuNinteishou){
		this.isGendogakuNinteishou = isGendogakuNinteishou;
	}

	/**
	* プロパティー：patientFutanRate を返します。
	* @return patientFutanRate
	*/
	public java.math.BigDecimal getPatientFutanRate(){
		return patientFutanRate;
	}

	/**
	* プロパティー：patientFutanRate を設定します。
	* @param param  java.math.BigDecimal patientFutanRate
	*/
	public void setPatientFutanRate(java.math.BigDecimal patientFutanRate){
		this.patientFutanRate = patientFutanRate;
	}

	/**
	* プロパティー：kyuufuWariai を返します。
	* @return kyuufuWariai
	*/
	public java.math.BigDecimal getKyuufuWariai(){
		return kyuufuWariai;
	}

	/**
	* プロパティー：kyuufuWariai を設定します。
	* @param param  java.math.BigDecimal kyuufuWariai
	*/
	public void setKyuufuWariai(java.math.BigDecimal kyuufuWariai){
		this.kyuufuWariai = kyuufuWariai;
	}

	/**
	* プロパティー：genmenKbn を返します。
	* @return genmenKbn
	*/
	public String getGenmenKbn(){
		return genmenKbn;
	}

	/**
	* プロパティー：genmenKbn を設定します。
	* @param param  String genmenKbn
	*/
	public void setGenmenKbn(String genmenKbn){
		this.genmenKbn = genmenKbn;
	}

	/**
	* プロパティー：gengakuWariai を返します。
	* @return gengakuWariai
	*/
	public java.math.BigDecimal getGengakuWariai(){
		return gengakuWariai;
	}

	/**
	* プロパティー：gengakuWariai を設定します。
	* @param param  java.math.BigDecimal gengakuWariai
	*/
	public void setGengakuWariai(java.math.BigDecimal gengakuWariai){
		this.gengakuWariai = gengakuWariai;
	}

	/**
	* プロパティー：gengakuKingaku を返します。
	* @return gengakuKingaku
	*/
	public java.math.BigDecimal getGengakuKingaku(){
		return gengakuKingaku;
	}

	/**
	* プロパティー：gengakuKingaku を設定します。
	* @param param  java.math.BigDecimal gengakuKingaku
	*/
	public void setGengakuKingaku(java.math.BigDecimal gengakuKingaku){
		this.gengakuKingaku = gengakuKingaku;
	}
}
