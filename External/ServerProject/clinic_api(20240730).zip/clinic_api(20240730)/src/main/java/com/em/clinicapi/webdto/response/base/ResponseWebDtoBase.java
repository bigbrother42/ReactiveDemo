package com.em.clinicapi.webdto.response.base;

import com.em.clinicapi.common.constants.enumerations.ClassTypeEnum;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class ResponseWebDtoBase {

    @JacksonXmlProperty(isAttribute = true)
    private ClassTypeEnum type = ClassTypeEnum.record;

    public ClassTypeEnum getType() {
        return type;
    }

    public void setType(ClassTypeEnum type) {
        this.type = type;
    }

    public ResponseWebDtoBase type(ClassTypeEnum type) {
        this.type = type;
        return this;
    }
}
