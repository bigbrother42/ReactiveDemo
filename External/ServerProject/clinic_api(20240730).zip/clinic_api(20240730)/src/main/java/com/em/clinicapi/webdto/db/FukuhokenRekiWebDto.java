package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class FukuhokenRekiWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ fukuhokenSeq */
	private int  fukuhokenSeq = 0;

	/**  プロパティ startDate */
	private java.sql.Date  startDate = null;

	/**  プロパティ patientFutanRate */
	private java.math.BigDecimal  patientFutanRate = null;

	/**  プロパティ kyuufuWariai */
	private java.math.BigDecimal  kyuufuWariai = null;

	/**  プロパティ gendogaku */
	private java.math.BigDecimal  gendogaku = null;

	/**  プロパティ genmenKbn */
	private String  genmenKbn = null;

	/**  プロパティ gengakuWariai */
	private java.math.BigDecimal  gengakuWariai = null;

	/**  プロパティ gengakuKingaku */
	private java.math.BigDecimal  gengakuKingaku = null;

	/**  プロパティ prescriptionKigouPrint */
	private String  prescriptionKigouPrint = null;

	/**  プロパティ shotokuKbn */
	private String  shotokuKbn = null;

	/**  プロパティ shikuchousonCode */
	private String  shikuchousonCode = null;

	/**  プロパティ jigyouNo */
	private String  jigyouNo = null;

	/**  プロパティ specialFutanKbn */
	private String  specialFutanKbn = null;

	/**  プロパティ kouhiGendoInputKbn */
	private String  kouhiGendoInputKbn = null;

	/**  プロパティ koufuNo */
	private String  koufuNo = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public FukuhokenRekiWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：fukuhokenSeq を返します。
	* @return fukuhokenSeq
	*/
	public int getFukuhokenSeq(){
		return fukuhokenSeq;
	}

	/**
	* プロパティー：fukuhokenSeq を設定します。
	* @param param  int fukuhokenSeq
	*/
	public void setFukuhokenSeq(int fukuhokenSeq){
		this.fukuhokenSeq = fukuhokenSeq;
	}

	/**
	* プロパティー：startDate を返します。
	* @return startDate
	*/
	public java.sql.Date getStartDate(){
		return startDate;
	}

	/**
	* プロパティー：startDate を設定します。
	* @param param  java.sql.Date startDate
	*/
	public void setStartDate(java.sql.Date startDate){
		this.startDate = startDate;
	}

	/**
	* プロパティー：patientFutanRate を返します。
	* @return patientFutanRate
	*/
	public java.math.BigDecimal getPatientFutanRate(){
		return patientFutanRate;
	}

	/**
	* プロパティー：patientFutanRate を設定します。
	* @param param  java.math.BigDecimal patientFutanRate
	*/
	public void setPatientFutanRate(java.math.BigDecimal patientFutanRate){
		this.patientFutanRate = patientFutanRate;
	}

	/**
	* プロパティー：kyuufuWariai を返します。
	* @return kyuufuWariai
	*/
	public java.math.BigDecimal getKyuufuWariai(){
		return kyuufuWariai;
	}

	/**
	* プロパティー：kyuufuWariai を設定します。
	* @param param  java.math.BigDecimal kyuufuWariai
	*/
	public void setKyuufuWariai(java.math.BigDecimal kyuufuWariai){
		this.kyuufuWariai = kyuufuWariai;
	}

	/**
	* プロパティー：gendogaku を返します。
	* @return gendogaku
	*/
	public java.math.BigDecimal getGendogaku(){
		return gendogaku;
	}

	/**
	* プロパティー：gendogaku を設定します。
	* @param param  java.math.BigDecimal gendogaku
	*/
	public void setGendogaku(java.math.BigDecimal gendogaku){
		this.gendogaku = gendogaku;
	}

	/**
	* プロパティー：genmenKbn を返します。
	* @return genmenKbn
	*/
	public String getGenmenKbn(){
		return genmenKbn;
	}

	/**
	* プロパティー：genmenKbn を設定します。
	* @param param  String genmenKbn
	*/
	public void setGenmenKbn(String genmenKbn){
		this.genmenKbn = genmenKbn;
	}

	/**
	* プロパティー：gengakuWariai を返します。
	* @return gengakuWariai
	*/
	public java.math.BigDecimal getGengakuWariai(){
		return gengakuWariai;
	}

	/**
	* プロパティー：gengakuWariai を設定します。
	* @param param  java.math.BigDecimal gengakuWariai
	*/
	public void setGengakuWariai(java.math.BigDecimal gengakuWariai){
		this.gengakuWariai = gengakuWariai;
	}

	/**
	* プロパティー：gengakuKingaku を返します。
	* @return gengakuKingaku
	*/
	public java.math.BigDecimal getGengakuKingaku(){
		return gengakuKingaku;
	}

	/**
	* プロパティー：gengakuKingaku を設定します。
	* @param param  java.math.BigDecimal gengakuKingaku
	*/
	public void setGengakuKingaku(java.math.BigDecimal gengakuKingaku){
		this.gengakuKingaku = gengakuKingaku;
	}

	/**
	* プロパティー：prescriptionKigouPrint を返します。
	* @return prescriptionKigouPrint
	*/
	public String getPrescriptionKigouPrint(){
		return prescriptionKigouPrint;
	}

	/**
	* プロパティー：prescriptionKigouPrint を設定します。
	* @param param  String prescriptionKigouPrint
	*/
	public void setPrescriptionKigouPrint(String prescriptionKigouPrint){
		this.prescriptionKigouPrint = prescriptionKigouPrint;
	}

	/**
	* プロパティー：shotokuKbn を返します。
	* @return shotokuKbn
	*/
	public String getShotokuKbn(){
		return shotokuKbn;
	}

	/**
	* プロパティー：shotokuKbn を設定します。
	* @param param  String shotokuKbn
	*/
	public void setShotokuKbn(String shotokuKbn){
		this.shotokuKbn = shotokuKbn;
	}

	/**
	* プロパティー：shikuchousonCode を返します。
	* @return shikuchousonCode
	*/
	public String getShikuchousonCode(){
		return shikuchousonCode;
	}

	/**
	* プロパティー：shikuchousonCode を設定します。
	* @param param  String shikuchousonCode
	*/
	public void setShikuchousonCode(String shikuchousonCode){
		this.shikuchousonCode = shikuchousonCode;
	}

	/**
	* プロパティー：jigyouNo を返します。
	* @return jigyouNo
	*/
	public String getJigyouNo(){
		return jigyouNo;
	}

	/**
	* プロパティー：jigyouNo を設定します。
	* @param param  String jigyouNo
	*/
	public void setJigyouNo(String jigyouNo){
		this.jigyouNo = jigyouNo;
	}

	/**
	* プロパティー：specialFutanKbn を返します。
	* @return specialFutanKbn
	*/
	public String getSpecialFutanKbn(){
		return specialFutanKbn;
	}

	/**
	* プロパティー：specialFutanKbn を設定します。
	* @param param  String specialFutanKbn
	*/
	public void setSpecialFutanKbn(String specialFutanKbn){
		this.specialFutanKbn = specialFutanKbn;
	}

	/**
	* プロパティー：kouhiGendoInputKbn を返します。
	* @return kouhiGendoInputKbn
	*/
	public String getKouhiGendoInputKbn(){
		return kouhiGendoInputKbn;
	}

	/**
	* プロパティー：kouhiGendoInputKbn を設定します。
	* @param param  String kouhiGendoInputKbn
	*/
	public void setKouhiGendoInputKbn(String kouhiGendoInputKbn){
		this.kouhiGendoInputKbn = kouhiGendoInputKbn;
	}

	/**
	* プロパティー：koufuNo を返します。
	* @return koufuNo
	*/
	public String getKoufuNo(){
		return koufuNo;
	}

	/**
	* プロパティー：koufuNo を設定します。
	* @param param  String koufuNo
	*/
	public void setKoufuNo(String koufuNo){
		this.koufuNo = koufuNo;
	}
}
