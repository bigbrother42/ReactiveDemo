package com.em.clinicapi.mapper;

import com.em.clinicapi.webdto.AuditTrailWebDto;
import org.apache.ibatis.annotations.Mapper;

import java.sql.Timestamp;
import java.util.List;

@Mapper
public interface AuditTrailMapper {

    /**
     * 検索結果件数取得実行用メソッド
     *
     * @param auditTrailDto 検索条件を格納したAuditTrailDtoオブジェクト
     * @return 検索結果件数
     */
    public int selectCountByPK(AuditTrailWebDto auditTrailDto);

    /**
     * テーブル内の全レコードの最新更新日時取得実行用メソッド
     *
     * @return テーブル内の全レコードの最新更新日時
     */
    public Timestamp selectLastUpdatedAt();

    /**
     * デフォルトの検索実行用メソッド
     *
     * @param auditTrailDto 検索条件を格納したAuditTrailDtoオブジェクト
     * @return 検索結果のリストオブジェクト
     */
    public List<AuditTrailWebDto> selectAuditTrailDtos(AuditTrailWebDto auditTrailDto);

    /**
     * デフォルトの削除実行用メソッド
     *
     * @param auditTrailDto 削除条件を格納したAuditTrailDtoオブジェクト
     * @return 検索結果のリストオブジェクト
     */
    public int deleteAuditTrailDto(AuditTrailWebDto auditTrailDto);

    /**
     * デフォルトの更新実行用メソッド
     *
     * @param auditTrailDto 更新するAuditTrailDtoオブジェクト
     * @return 更新件数
     */
    public int updateAuditTrailDto(AuditTrailWebDto auditTrailDto);

    /**
     * デフォルトの挿入実行用メソッド
     *
     * @param auditTrailDto 挿入するAuditTrailDtoオブジェクト
     * @return 挿入件数
     */
    public int insertAuditTrailDto(AuditTrailWebDto auditTrailDto);
}
