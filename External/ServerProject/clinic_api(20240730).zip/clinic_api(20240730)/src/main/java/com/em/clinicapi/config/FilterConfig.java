package com.em.clinicapi.config;

import com.em.clinicapi.filter.*;
import com.em.clinicapi.filter.gzip.GZipFilter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.servlet.Filter;

@Configuration
public class FilterConfig {

    @Value("${api.request.limit:100}")
    private int limitNum;

    @Value("${compression.enabled:false}")
    private boolean compressEnable;

    @Bean
    public FilterRegistrationBean<Filter> clearCacheFilterRegistration() {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new ClearCacheFilter());
        registration.setName(ClearCacheFilter.class.getSimpleName());
        registration.setOrder(3);

        return registration;
    }

    /*@Bean
    public FilterRegistrationBean<Filter> gZipFilterRegistration() {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<>();
        registration.setFilter(new GZipFilter(this.compressEnable));
        registration.setName(GZipFilter.class.getSimpleName());
        registration.setOrder(2);

        return registration;
    }*/

    @Bean
    public FilterRegistrationBean<Filter> serverReplicationRoutingFilterRegistration() {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<Filter>();
        registration.setFilter(new ServerReplicationRoutingFilter());
        registration.setName(ServerReplicationRoutingFilter.class.getSimpleName());
        registration.setOrder(1);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<Filter> clientRequestFilterFilterRegistration() {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<Filter>();
        registration.setFilter(new ApiRequestFilter());
        registration.setName(ApiRequestFilter.class.getSimpleName());
        registration.setOrder(0);
        return registration;
    }

    @Bean
    public FilterRegistrationBean<Filter> requestLimitFilterRegistration() {
        FilterRegistrationBean<Filter> registration = new FilterRegistrationBean<Filter>();
        registration.setFilter(new ApiRequestLimitFilter(limitNum));
        registration.setName(ApiRequestLimitFilter.class.getSimpleName());
        registration.setOrder(-1);
        return registration;
    }
}
