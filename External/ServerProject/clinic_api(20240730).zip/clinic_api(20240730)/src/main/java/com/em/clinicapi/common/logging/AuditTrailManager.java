package com.em.clinicapi.common.logging;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.cache.ServerReplicationContextHolder;
import com.em.clinicapi.common.cache.ServerReplicationManager;
import com.em.clinicapi.service.AuditTrailService;
import com.em.clinicapi.service.EmReplicationService;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

@Component
public class AuditTrailManager implements InitializingBean {

    private static AuditTrailManager instance;

    @Autowired
    private AuditTrailService auditTrailService;

    @Override
    public void afterPropertiesSet() throws Exception {
        setInstance(this);
    }

    public static synchronized void setInstance(AuditTrailManager objectInstance) {
        instance = objectInstance;
    }

    /**
     * @param request
     * @param response
     */
    public static void writeAuditTrailLog(ServletRequest request, ServletResponse response) {

        ReplicationMWebDto customerReplication = ServerReplicationManager.getCurrentCustomerReplication();
        if (customerReplication != null) {
            if (request instanceof HttpServletRequest) {
                HttpServletRequest t = (HttpServletRequest) request;

                String addr = getAddr(t);
                String uri = t.getRequestURI();
                String xml = RequestCacheHolder.get(RequestCacheHolder.REQUEST_BODY_XML);

                if (response instanceof HttpServletResponse) {
                    HttpServletResponse t1 = (HttpServletResponse) response;
                    t1.getStatus();
                }

                instance.auditTrailService.createAuditTrail(customerReplication.getCustomerId(), addr, uri, xml);
            }
        }
    }

    public static String getAddr(HttpServletRequest request) {
        String ip = request.getHeader("x-forwarded-for");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        return ip;

    }
}

