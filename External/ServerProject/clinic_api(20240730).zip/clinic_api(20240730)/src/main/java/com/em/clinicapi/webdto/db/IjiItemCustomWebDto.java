package com.em.clinicapi.webdto.db;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2019
/****************************************************************************/
/**
* WebDto : 医事項目情報 クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2019/05/24 <BR>
*
* @author WebDtoGen4Smart
*/
//***************************************************************************


import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class IjiItemCustomWebDto extends CustomerWebDtoBase {
	private IjiItemWebDto ijiItemWebDto;
    private ShinryoukouiMCustomWebDto shinryoukouiMCustomWebDto;
	
	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiItemCustomWebDto(){
		super();
	}

    /**
     * @return IjiItemWebDto 医事項目
     */
    public IjiItemWebDto getIjiItemWebDto() {
        return ijiItemWebDto;
    }
    /**
     * @param ijiItemWebDto セットする IjiItemWebDto 医事項目
     */
    public void setIjiItemWebDto(IjiItemWebDto ijiItemWebDto) {
        this.ijiItemWebDto = ijiItemWebDto;
    }


    /**
     * @param shinryoukouiMCustomWebDto セットする ShinryoukouiMCustomWebDto 医事項目
     */
    public void setShinryoukouiMCustomWebDto(ShinryoukouiMCustomWebDto shinryoukouiMCustomWebDto) {
        this.shinryoukouiMCustomWebDto = shinryoukouiMCustomWebDto;
    }

    /**
     * @return ShinryoukouiMCustomWebDto 医事項目
     */
    public ShinryoukouiMCustomWebDto getShinryoukouiMCustomWebDto() {
        return shinryoukouiMCustomWebDto;
    }


	
}
