package com.em.clinicapi.filter;

import com.em.clinicapi.filter.gzip.GZIPResponseStream;
import org.springframework.http.HttpHeaders;

import javax.servlet.ServletOutputStream;
import javax.servlet.WriteListener;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import java.io.*;

public class ResponseWrapper extends HttpServletResponseWrapper {

    private final HttpServletResponse response;
    private ServletOutputStream outputStream = null;
    private ServletOutputStream newOutputStream = null;
    private PrintWriter printWriter = null;


    /**
     * Constructs a response adaptor wrapping the given response.
     *
     * @param response The response to be wrapped
     * @throws IllegalArgumentException if the response is null
     */
    public ResponseWrapper(HttpServletResponse response) throws IOException {
        super(response);
        this.response = (HttpServletResponse) getResponse();
    }

    public void finish() throws IOException {
        if (outputStream != null) {
            outputStream.close();
        }
        if (newOutputStream != null) {
            newOutputStream.close();
        }
        if (printWriter != null) {
            printWriter.close();
        }
    }

    @Override
    public ServletOutputStream getOutputStream() throws IOException {
        if (printWriter != null) {
            throw new IllegalStateException("printWriter already defined");
        }
        if (outputStream == null) {
            //initGzip();
            newOutputStream = getResponse().getOutputStream();
            outputStream = newOutputStream;
        }

        return outputStream;
    }

    @Override
    public PrintWriter getWriter() throws IOException {
        if (outputStream != null) {
            throw new IllegalStateException("printWriter already defined");
        }
        if (printWriter == null) {
            initGzip();
            printWriter = new PrintWriter(
                    new OutputStreamWriter(newOutputStream, getResponse().getCharacterEncoding()));
        }

        return printWriter;
    }

    @Override
    public void flushBuffer() throws IOException {
        if (printWriter != null) {
            printWriter.flush();
        }
        if (outputStream != null) {
            outputStream.flush();
        }

        super.flushBuffer();
    }

    private void initGzip() throws IOException {
        if (getContentType().contains("json")) {
            response.addHeader(HttpHeaders.CONTENT_ENCODING, "gzip");
            newOutputStream = new GZIPResponseStream(getResponse().getOutputStream());
        } else {
            newOutputStream = getResponse().getOutputStream();
        }
    }
}
