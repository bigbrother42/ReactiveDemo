package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class PatientRenrakusakiWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ contactInfoSeq */
	private int  contactInfoSeq = 0;

	/**  プロパティ contactInfoName */
	private String  contactInfoName = null;

	/**  プロパティ postalNo */
	private String  postalNo = null;

	/**  プロパティ prefectureCode */
	private String  prefectureCode = null;

	/**  プロパティ shikuchousonCode */
	private String  shikuchousonCode = null;

	/**  プロパティ address */
	private String  address = null;

	/**  プロパティ banchi */
	private String  banchi = null;

	/**  プロパティ phoneNo */
	private String  phoneNo = null;

	/**  プロパティ faxNo */
	private String  faxNo = null;

	/**  プロパティ mobileNo */
	private String  mobileNo = null;

	/**  プロパティ homeMail */
	private String  homeMail = null;

	/**  プロパティ mobileMail */
	private String  mobileMail = null;

	/**  プロパティ bikou */
	private String  bikou = null;

	/**  プロパティ isPriority */
	private boolean  isPriority;


	/**
	*  デフォルトのコンストラクタ
	*/
	public PatientRenrakusakiWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：contactInfoSeq を返します。
	* @return contactInfoSeq
	*/
	public int getContactInfoSeq(){
		return contactInfoSeq;
	}

	/**
	* プロパティー：contactInfoSeq を設定します。
	* @param param  int contactInfoSeq
	*/
	public void setContactInfoSeq(int contactInfoSeq){
		this.contactInfoSeq = contactInfoSeq;
	}

	/**
	* プロパティー：contactInfoName を返します。
	* @return contactInfoName
	*/
	public String getContactInfoName(){
		return contactInfoName;
	}

	/**
	* プロパティー：contactInfoName を設定します。
	* @param param  String contactInfoName
	*/
	public void setContactInfoName(String contactInfoName){
		this.contactInfoName = contactInfoName;
	}

	/**
	* プロパティー：postalNo を返します。
	* @return postalNo
	*/
	public String getPostalNo(){
		return postalNo;
	}

	/**
	* プロパティー：postalNo を設定します。
	* @param param  String postalNo
	*/
	public void setPostalNo(String postalNo){
		this.postalNo = postalNo;
	}

	/**
	* プロパティー：prefectureCode を返します。
	* @return prefectureCode
	*/
	public String getPrefectureCode(){
		return prefectureCode;
	}

	/**
	* プロパティー：prefectureCode を設定します。
	* @param param  String prefectureCode
	*/
	public void setPrefectureCode(String prefectureCode){
		this.prefectureCode = prefectureCode;
	}

	/**
	* プロパティー：shikuchousonCode を返します。
	* @return shikuchousonCode
	*/
	public String getShikuchousonCode(){
		return shikuchousonCode;
	}

	/**
	* プロパティー：shikuchousonCode を設定します。
	* @param param  String shikuchousonCode
	*/
	public void setShikuchousonCode(String shikuchousonCode){
		this.shikuchousonCode = shikuchousonCode;
	}

	/**
	* プロパティー：address を返します。
	* @return address
	*/
	public String getAddress(){
		return address;
	}

	/**
	* プロパティー：address を設定します。
	* @param param  String address
	*/
	public void setAddress(String address){
		this.address = address;
	}

	/**
	* プロパティー：banchi を返します。
	* @return banchi
	*/
	public String getBanchi(){
		return banchi;
	}

	/**
	* プロパティー：banchi を設定します。
	* @param param  String banchi
	*/
	public void setBanchi(String banchi){
		this.banchi = banchi;
	}

	/**
	* プロパティー：phoneNo を返します。
	* @return phoneNo
	*/
	public String getPhoneNo(){
		return phoneNo;
	}

	/**
	* プロパティー：phoneNo を設定します。
	* @param param  String phoneNo
	*/
	public void setPhoneNo(String phoneNo){
		this.phoneNo = phoneNo;
	}

	/**
	* プロパティー：faxNo を返します。
	* @return faxNo
	*/
	public String getFaxNo(){
		return faxNo;
	}

	/**
	* プロパティー：faxNo を設定します。
	* @param param  String faxNo
	*/
	public void setFaxNo(String faxNo){
		this.faxNo = faxNo;
	}

	/**
	* プロパティー：mobileNo を返します。
	* @return mobileNo
	*/
	public String getMobileNo(){
		return mobileNo;
	}

	/**
	* プロパティー：mobileNo を設定します。
	* @param param  String mobileNo
	*/
	public void setMobileNo(String mobileNo){
		this.mobileNo = mobileNo;
	}

	/**
	* プロパティー：homeMail を返します。
	* @return homeMail
	*/
	public String getHomeMail(){
		return homeMail;
	}

	/**
	* プロパティー：homeMail を設定します。
	* @param param  String homeMail
	*/
	public void setHomeMail(String homeMail){
		this.homeMail = homeMail;
	}

	/**
	* プロパティー：mobileMail を返します。
	* @return mobileMail
	*/
	public String getMobileMail(){
		return mobileMail;
	}

	/**
	* プロパティー：mobileMail を設定します。
	* @param param  String mobileMail
	*/
	public void setMobileMail(String mobileMail){
		this.mobileMail = mobileMail;
	}

	/**
	* プロパティー：bikou を返します。
	* @return bikou
	*/
	public String getBikou(){
		return bikou;
	}

	/**
	* プロパティー：bikou を設定します。
	* @param param  String bikou
	*/
	public void setBikou(String bikou){
		this.bikou = bikou;
	}

	/**
	* プロパティー：isPriority を返します。
	* @return isPriority
	*/
	public boolean getIsPriority(){
		return isPriority;
	}

	/**
	* プロパティー：isPriority を設定します。
	* @param param  boolean isPriority
	*/
	public void setIsPriority(boolean isPriority){
		this.isPriority = isPriority;
	}
}
