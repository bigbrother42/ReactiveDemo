package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class SaiyouMWebDto extends CustomerWebDtoBase {
	/**  プロパティ masterType */
	private String  masterType = null;

	/**  プロパティ masterCode */
	private String  masterCode = null;

	/**  プロパティ startDate */
	private java.sql.Date  startDate = null;

	/**  プロパティ searchCode */
	private String  searchCode = null;

	/**  プロパティ saiyouKanjiName */
	private String  saiyouKanjiName = null;

	/**  プロパティ saiyouKanaName */
	private String  saiyouKanaName = null;

	/**  プロパティ rezeptName */
	private String  rezeptName = null;

	/**  プロパティ suuryouUsedQty */
	private java.math.BigDecimal  suuryouUsedQty = null;

	/**  プロパティ suuryouInputKbn */
	private String  suuryouInputKbn = null;

	/**  プロパティ bvJidouSanteiKbn */
	private String  bvJidouSanteiKbn = null;

	/**  プロパティ kouhatsuhinChangeKbn */
	private String  kouhatsuhinChangeKbn = null;

	/**  プロパティ zanryouHaikiKbn */
	private String  zanryouHaikiKbn = null;

	/**  プロパティ chuushaYouryouMl */
	private java.math.BigDecimal  chuushaYouryouMl = null;

	/**  プロパティ unitCode */
	private String  unitCode = null;

	/**  プロパティ unitNameValidCharCount */
	private int  unitNameValidCharCount = 0;

	/**  プロパティ unitName */
	private String  unitName = null;

	/**  プロパティ kingaku */
	private java.math.BigDecimal  kingaku = null;

	/**  プロパティ productNameOyobiKikaku */
	private String  productNameOyobiKikaku = null;

	/**  プロパティ shindanryouKbn */
	private String  shindanryouKbn = null;

	/**  プロパティ youhouSelectedKbn */
	private String  youhouSelectedKbn = null;

	/**  プロパティ zaitakuPrintKbn */
	private String  zaitakuPrintKbn = null;

	/**  プロパティ seishinTeigenIppanNameSeq */
	private int  seishinTeigenIppanNameSeq = 0;

	/**  プロパティ isShippuyaku */
	private boolean  isShippuyaku;

	/**  プロパティ isBzdYakuzai */
	private boolean  isBzdYakuzai;

	/**  プロパティ iyakuhinCode */
	private String  iyakuhinCode = null;

	/**  プロパティ zaikeiKbn */
	private String  zaikeiKbn = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public SaiyouMWebDto()	{
		super();
	}


	/**
	* プロパティー：masterType を返します。
	* @return masterType
	*/
	public String getMasterType(){
		return masterType;
	}

	/**
	* プロパティー：masterType を設定します。
	* @param param  String masterType
	*/
	public void setMasterType(String masterType){
		this.masterType = masterType;
	}

	/**
	* プロパティー：masterCode を返します。
	* @return masterCode
	*/
	public String getMasterCode(){
		return masterCode;
	}

	/**
	* プロパティー：masterCode を設定します。
	* @param param  String masterCode
	*/
	public void setMasterCode(String masterCode){
		this.masterCode = masterCode;
	}

	/**
	* プロパティー：startDate を返します。
	* @return startDate
	*/
	public java.sql.Date getStartDate(){
		return startDate;
	}

	/**
	* プロパティー：startDate を設定します。
	* @param param  java.sql.Date startDate
	*/
	public void setStartDate(java.sql.Date startDate){
		this.startDate = startDate;
	}

	/**
	* プロパティー：searchCode を返します。
	* @return searchCode
	*/
	public String getSearchCode(){
		return searchCode;
	}

	/**
	* プロパティー：searchCode を設定します。
	* @param param  String searchCode
	*/
	public void setSearchCode(String searchCode){
		this.searchCode = searchCode;
	}

	/**
	* プロパティー：saiyouKanjiName を返します。
	* @return saiyouKanjiName
	*/
	public String getSaiyouKanjiName(){
		return saiyouKanjiName;
	}

	/**
	* プロパティー：saiyouKanjiName を設定します。
	* @param param  String saiyouKanjiName
	*/
	public void setSaiyouKanjiName(String saiyouKanjiName){
		this.saiyouKanjiName = saiyouKanjiName;
	}

	/**
	* プロパティー：saiyouKanaName を返します。
	* @return saiyouKanaName
	*/
	public String getSaiyouKanaName(){
		return saiyouKanaName;
	}

	/**
	* プロパティー：saiyouKanaName を設定します。
	* @param param  String saiyouKanaName
	*/
	public void setSaiyouKanaName(String saiyouKanaName){
		this.saiyouKanaName = saiyouKanaName;
	}

	/**
	* プロパティー：rezeptName を返します。
	* @return rezeptName
	*/
	public String getRezeptName(){
		return rezeptName;
	}

	/**
	* プロパティー：rezeptName を設定します。
	* @param param  String rezeptName
	*/
	public void setRezeptName(String rezeptName){
		this.rezeptName = rezeptName;
	}

	/**
	* プロパティー：suuryouUsedQty を返します。
	* @return suuryouUsedQty
	*/
	public java.math.BigDecimal getSuuryouUsedQty(){
		return suuryouUsedQty;
	}

	/**
	* プロパティー：suuryouUsedQty を設定します。
	* @param param  java.math.BigDecimal suuryouUsedQty
	*/
	public void setSuuryouUsedQty(java.math.BigDecimal suuryouUsedQty){
		this.suuryouUsedQty = suuryouUsedQty;
	}

	/**
	* プロパティー：suuryouInputKbn を返します。
	* @return suuryouInputKbn
	*/
	public String getSuuryouInputKbn(){
		return suuryouInputKbn;
	}

	/**
	* プロパティー：suuryouInputKbn を設定します。
	* @param param  String suuryouInputKbn
	*/
	public void setSuuryouInputKbn(String suuryouInputKbn){
		this.suuryouInputKbn = suuryouInputKbn;
	}

	/**
	* プロパティー：bvJidouSanteiKbn を返します。
	* @return bvJidouSanteiKbn
	*/
	public String getBvJidouSanteiKbn(){
		return bvJidouSanteiKbn;
	}

	/**
	* プロパティー：bvJidouSanteiKbn を設定します。
	* @param param  String bvJidouSanteiKbn
	*/
	public void setBvJidouSanteiKbn(String bvJidouSanteiKbn){
		this.bvJidouSanteiKbn = bvJidouSanteiKbn;
	}

	/**
	* プロパティー：kouhatsuhinChangeKbn を返します。
	* @return kouhatsuhinChangeKbn
	*/
	public String getKouhatsuhinChangeKbn(){
		return kouhatsuhinChangeKbn;
	}

	/**
	* プロパティー：kouhatsuhinChangeKbn を設定します。
	* @param param  String kouhatsuhinChangeKbn
	*/
	public void setKouhatsuhinChangeKbn(String kouhatsuhinChangeKbn){
		this.kouhatsuhinChangeKbn = kouhatsuhinChangeKbn;
	}

	/**
	* プロパティー：zanryouHaikiKbn を返します。
	* @return zanryouHaikiKbn
	*/
	public String getZanryouHaikiKbn(){
		return zanryouHaikiKbn;
	}

	/**
	* プロパティー：zanryouHaikiKbn を設定します。
	* @param param  String zanryouHaikiKbn
	*/
	public void setZanryouHaikiKbn(String zanryouHaikiKbn){
		this.zanryouHaikiKbn = zanryouHaikiKbn;
	}

	/**
	* プロパティー：chuushaYouryouMl を返します。
	* @return chuushaYouryouMl
	*/
	public java.math.BigDecimal getChuushaYouryouMl(){
		return chuushaYouryouMl;
	}

	/**
	* プロパティー：chuushaYouryouMl を設定します。
	* @param param  java.math.BigDecimal chuushaYouryouMl
	*/
	public void setChuushaYouryouMl(java.math.BigDecimal chuushaYouryouMl){
		this.chuushaYouryouMl = chuushaYouryouMl;
	}

	/**
	* プロパティー：unitCode を返します。
	* @return unitCode
	*/
	public String getUnitCode(){
		return unitCode;
	}

	/**
	* プロパティー：unitCode を設定します。
	* @param param  String unitCode
	*/
	public void setUnitCode(String unitCode){
		this.unitCode = unitCode;
	}

	/**
	* プロパティー：unitNameValidCharCount を返します。
	* @return unitNameValidCharCount
	*/
	public int getUnitNameValidCharCount(){
		return unitNameValidCharCount;
	}

	/**
	* プロパティー：unitNameValidCharCount を設定します。
	* @param param  int unitNameValidCharCount
	*/
	public void setUnitNameValidCharCount(int unitNameValidCharCount){
		this.unitNameValidCharCount = unitNameValidCharCount;
	}

	/**
	* プロパティー：unitName を返します。
	* @return unitName
	*/
	public String getUnitName(){
		return unitName;
	}

	/**
	* プロパティー：unitName を設定します。
	* @param param  String unitName
	*/
	public void setUnitName(String unitName){
		this.unitName = unitName;
	}

	/**
	* プロパティー：kingaku を返します。
	* @return kingaku
	*/
	public java.math.BigDecimal getKingaku(){
		return kingaku;
	}

	/**
	* プロパティー：kingaku を設定します。
	* @param param  java.math.BigDecimal kingaku
	*/
	public void setKingaku(java.math.BigDecimal kingaku){
		this.kingaku = kingaku;
	}

	/**
	* プロパティー：productNameOyobiKikaku を返します。
	* @return productNameOyobiKikaku
	*/
	public String getProductNameOyobiKikaku(){
		return productNameOyobiKikaku;
	}

	/**
	* プロパティー：productNameOyobiKikaku を設定します。
	* @param param  String productNameOyobiKikaku
	*/
	public void setProductNameOyobiKikaku(String productNameOyobiKikaku){
		this.productNameOyobiKikaku = productNameOyobiKikaku;
	}

	/**
	* プロパティー：shindanryouKbn を返します。
	* @return shindanryouKbn
	*/
	public String getShindanryouKbn(){
		return shindanryouKbn;
	}

	/**
	* プロパティー：shindanryouKbn を設定します。
	* @param param  String shindanryouKbn
	*/
	public void setShindanryouKbn(String shindanryouKbn){
		this.shindanryouKbn = shindanryouKbn;
	}

	/**
	* プロパティー：youhouSelectedKbn を返します。
	* @return youhouSelectedKbn
	*/
	public String getYouhouSelectedKbn(){
		return youhouSelectedKbn;
	}

	/**
	* プロパティー：youhouSelectedKbn を設定します。
	* @param param  String youhouSelectedKbn
	*/
	public void setYouhouSelectedKbn(String youhouSelectedKbn){
		this.youhouSelectedKbn = youhouSelectedKbn;
	}

	/**
	* プロパティー：zaitakuPrintKbn を返します。
	* @return zaitakuPrintKbn
	*/
	public String getZaitakuPrintKbn(){
		return zaitakuPrintKbn;
	}

	/**
	* プロパティー：zaitakuPrintKbn を設定します。
	* @param param  String zaitakuPrintKbn
	*/
	public void setZaitakuPrintKbn(String zaitakuPrintKbn){
		this.zaitakuPrintKbn = zaitakuPrintKbn;
	}

	/**
	* プロパティー：seishinTeigenIppanNameSeq を返します。
	* @return seishinTeigenIppanNameSeq
	*/
	public int getSeishinTeigenIppanNameSeq(){
		return seishinTeigenIppanNameSeq;
	}

	/**
	* プロパティー：seishinTeigenIppanNameSeq を設定します。
	* @param param  int seishinTeigenIppanNameSeq
	*/
	public void setSeishinTeigenIppanNameSeq(int seishinTeigenIppanNameSeq){
		this.seishinTeigenIppanNameSeq = seishinTeigenIppanNameSeq;
	}

	/**
	* プロパティー：isShippuyaku を返します。
	* @return isShippuyaku
	*/
	public boolean getIsShippuyaku(){
		return isShippuyaku;
	}

	/**
	* プロパティー：isShippuyaku を設定します。
	* @param param  boolean isShippuyaku
	*/
	public void setIsShippuyaku(boolean isShippuyaku){
		this.isShippuyaku = isShippuyaku;
	}

	/**
	* プロパティー：isBzdYakuzai を返します。
	* @return isBzdYakuzai
	*/
	public boolean getIsBzdYakuzai(){
		return isBzdYakuzai;
	}

	/**
	* プロパティー：isBzdYakuzai を設定します。
	* @param param  boolean isBzdYakuzai
	*/
	public void setIsBzdYakuzai(boolean isBzdYakuzai){
		this.isBzdYakuzai = isBzdYakuzai;
	}

	/**
	* プロパティー：iyakuhinCode を返します。
	* @return iyakuhinCode
	*/
	public String getIyakuhinCode(){
		return iyakuhinCode;
	}

	/**
	* プロパティー：iyakuhinCode を設定します。
	* @param param  String iyakuhinCode
	*/
	public void setIyakuhinCode(String iyakuhinCode){
		this.iyakuhinCode = iyakuhinCode;
	}

	/**
	* プロパティー：zaikeiKbn を返します。
	* @return zaikeiKbn
	*/
	public String getZaikeiKbn(){
		return zaikeiKbn;
	}

	/**
	* プロパティー：zaikeiKbn を設定します。
	* @param param  String zaikeiKbn
	*/
	public void setZaikeiKbn(String zaikeiKbn){
		this.zaikeiKbn = zaikeiKbn;
	}
}
