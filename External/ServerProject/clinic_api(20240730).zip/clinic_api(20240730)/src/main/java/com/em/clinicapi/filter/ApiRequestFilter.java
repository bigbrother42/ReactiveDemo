package com.em.clinicapi.filter;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.util.ListUtil;
import com.em.clinicapi.common.util.LogUtil;
import org.apache.logging.log4j.ThreadContext;
import org.apache.logging.log4j.Logger;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

public class ApiRequestFilter extends OncePerRequestFilter {

    private static final Logger LOG = LogUtil.getLogger(ApiRequestFilter.class);

    private static final String MDC_REQUEST_HEADER_PREFIX = "request.header";

    public static final String HEADER_REQUEST_ID = "requestid";

    public static final String MDC_REQUEST_HEADER_REQUEST_ID = MDC_REQUEST_HEADER_PREFIX + "." + HEADER_REQUEST_ID;

    /*
     * (non-Javadoc)
     *
     * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
     * javax.servlet.ServletResponse, javax.servlet.FilterChain)
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException{
        Map<String, String> headers = null;
        try {
            LOG.debug("Client Request Information Processing Filter START");

            headers = getHeaders(request);
            if (ListUtil.nonEmpty(headers)) {
                appendToMappedDiagnosticContext(headers);
                RequestCacheHolder.initialize();
                RequestCacheHolder.put(MDC_REQUEST_HEADER_PREFIX, headers);
            }

            RequestWrapper requestWrapper = new RequestWrapper(request);
            //ResponseWrapper responseWrapper = new ResponseWrapper(response);
            if (requestWrapper != null) {
                filterChain.doFilter(requestWrapper, response);
            } else {
                filterChain.doFilter(request, response);
            }
        } finally {
            if (ListUtil.nonEmpty(headers)) {
                clearMappedDiagnosticContext(headers);
                RequestCacheHolder.initialize();
                RequestCacheHolder.remove(MDC_REQUEST_HEADER_PREFIX);
            }
            LOG.debug("Client Request Information Processing Filter END");
        }
    }

    private Map<String, String> getHeaders(HttpServletRequest request) {
        Map<String, String> headerMap = new HashMap<String, String>();
        Enumeration<String> headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = headerNames.nextElement();
            String value = request.getHeader(key);
            headerMap.put(key, value);
        }
        return headerMap;
    }

    private void appendToMappedDiagnosticContext(Map<String, String> headers) {
        for (Map.Entry<String, String> entry : headers.entrySet()) {
            String mdcKey = String.format("%s.%s", MDC_REQUEST_HEADER_PREFIX, entry.getKey());
            ThreadContext.put(mdcKey, entry.getValue());
        }
    }

    private void clearMappedDiagnosticContext(Map<String, String> headers) {
        for (String key : headers.keySet()) {
            String mdcKey = String.format("%s.%s", MDC_REQUEST_HEADER_PREFIX, key);
            ThreadContext.remove(mdcKey);
        }
    }
}
