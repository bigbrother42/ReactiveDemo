package com.em.clinicapi.webdto.db;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2019
/****************************************************************************/
/**
* WebDto : 医事処方情報 クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2019/05/24 <BR>
*
* @author WebDtoGen4Smart
*/
//***************************************************************************

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class IjiCustomWebDto extends CustomerWebDtoBase {
	private IjiWebDto ijiWebDto;
	private List<IjiSubCustomWebDto> ijiSubCustomWebDtoList = new ArrayList<IjiSubCustomWebDto>();
    private boolean isTaishougai = false;
	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiCustomWebDto(){
		super();
	}

    /**
     * @return IjiWebDto 医事処方
     */
    public IjiWebDto getIjiWebDto() {
        return ijiWebDto;
    }
    /**
     * @param ijiWebDto セットする IjiWebDto 医事処方
     */
    public void setIjiWebDto(IjiWebDto ijiWebDto) {
        this.ijiWebDto = ijiWebDto;
    }
	/**
     * @return IjiSubCustomWebDtoList 医事サブリスト
     */
    public List<IjiSubCustomWebDto> getIjiSubCustomWebDtoList() {
        return ijiSubCustomWebDtoList;
    }
    /**
     * @param ijiSubCustomWebDtoList セットする IjiSubCustomWebDtoList 医事サブリスト
     */
    public void setIjiSubCustomWebDtoList(List<IjiSubCustomWebDto> ijiSubCustomWebDtoList) {
        this.ijiSubCustomWebDtoList = ijiSubCustomWebDtoList;
    }

    public boolean isTaishougai() {
        return isTaishougai;
    }

    public void setTaishougai(boolean taishougai) {
        isTaishougai = taishougai;
    }
}
