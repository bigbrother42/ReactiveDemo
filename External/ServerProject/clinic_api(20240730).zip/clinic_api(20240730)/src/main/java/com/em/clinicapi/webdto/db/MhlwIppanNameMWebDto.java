package com.em.clinicapi.webdto.db;

import java.math.BigDecimal;
import java.sql.Date;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class MhlwIppanNameMWebDto extends CustomerWebDtoBase {
    private String ippanNameCode = null;
    private Date startDate = null;
    private String masterType = null;
    private String shinryouKbn = null;
    private String seibunName = null;
    private String kikaku = null;
    private String ippanNamePrescriptionKanjiName = null;
    private String ippanNamePrescriptionKanaName = null;
    private BigDecimal kingaku = null;
    private String unitCode = null;
    private Date endDate = null;
    private String bikou = null;
    private boolean isShippuyaku;
    private String ippanNamePrescriptionKasanKbn = null;
    private boolean isUser;
    private boolean isBzdYakuzai;

    public MhlwIppanNameMWebDto() {
    }

    public String getIppanNameCode() {
        return this.ippanNameCode;
    }

    public void setIppanNameCode(String ippanNameCode) {
        this.ippanNameCode = ippanNameCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getMasterType() {
        return this.masterType;
    }

    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }

    public String getShinryouKbn() {
        return this.shinryouKbn;
    }

    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }

    public String getSeibunName() {
        return this.seibunName;
    }

    public void setSeibunName(String seibunName) {
        this.seibunName = seibunName;
    }

    public String getKikaku() {
        return this.kikaku;
    }

    public void setKikaku(String kikaku) {
        this.kikaku = kikaku;
    }

    public String getIppanNamePrescriptionKanjiName() {
        return this.ippanNamePrescriptionKanjiName;
    }

    public void setIppanNamePrescriptionKanjiName(String ippanNamePrescriptionKanjiName) {
        this.ippanNamePrescriptionKanjiName = ippanNamePrescriptionKanjiName;
    }

    public String getIppanNamePrescriptionKanaName() {
        return this.ippanNamePrescriptionKanaName;
    }

    public void setIppanNamePrescriptionKanaName(String ippanNamePrescriptionKanaName) {
        this.ippanNamePrescriptionKanaName = ippanNamePrescriptionKanaName;
    }

    public BigDecimal getKingaku() {
        return this.kingaku;
    }

    public void setKingaku(BigDecimal kingaku) {
        this.kingaku = kingaku;
    }

    public String getUnitCode() {
        return this.unitCode;
    }

    public void setUnitCode(String unitCode) {
        this.unitCode = unitCode;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getBikou() {
        return this.bikou;
    }

    public void setBikou(String bikou) {
        this.bikou = bikou;
    }

    public boolean getIsShippuyaku() {
        return this.isShippuyaku;
    }

    public void setIsShippuyaku(boolean isShippuyaku) {
        this.isShippuyaku = isShippuyaku;
    }

    public String getIppanNamePrescriptionKasanKbn() {
        return this.ippanNamePrescriptionKasanKbn;
    }

    public void setIppanNamePrescriptionKasanKbn(String ippanNamePrescriptionKasanKbn) {
        this.ippanNamePrescriptionKasanKbn = ippanNamePrescriptionKasanKbn;
    }

    public boolean getIsUser() {
        return this.isUser;
    }

    public void setIsUser(boolean isUser) {
        this.isUser = isUser;
    }

    public boolean getIsBzdYakuzai() {
        return this.isBzdYakuzai;
    }

    public void setIsBzdYakuzai(boolean isBzdYakuzai) {
        this.isBzdYakuzai = isBzdYakuzai;
    }
}
