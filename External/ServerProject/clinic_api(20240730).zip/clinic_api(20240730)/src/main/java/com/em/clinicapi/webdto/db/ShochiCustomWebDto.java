package com.em.clinicapi.webdto.db;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2019
/****************************************************************************/
/**
* WebDto : 処方情報 クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2019/05/24 <BR>
*
* @author WebDtoGen4Smart
*/
//***************************************************************************

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
@Component
public class ShochiCustomWebDto extends CustomerWebDtoBase{
	private ShochiWebDto shochiWebDto;
	private List<ShochiItemCustomWebDto> shochiItemCustomWebDtoList = new ArrayList<ShochiItemCustomWebDto>();
	
	/**
	*  デフォルトのコンストラクタ
	*/
	public ShochiCustomWebDto(){
		super();
	}

    /**
     * @return ShochiWebDto 処方情報
     */
    public ShochiWebDto getShochiWebDto() {
        return shochiWebDto;
    }
    /**
     * @param ShochiWebDto セットする ShochiWebDto 処方情報
     */
    public void setShochiWebDto(ShochiWebDto shochiWebDto) {
        this.shochiWebDto = shochiWebDto;
    }
	/**
     * @return ShochiItemCustomWebDtoList 処方項目リスト情報
     */
    public List<ShochiItemCustomWebDto> getShochiItemCustomWebDtoList() {
        return shochiItemCustomWebDtoList;
    }
    /**
     * @param ShochiItemCustomWebDtoList セットする ShochiItemCustomWebDtoList 処方項目リスト情報
     */
    public void setShochiItemCustomWebDtoList(List<ShochiItemCustomWebDto> shochiItemCustomWebDtoList) {
        this.shochiItemCustomWebDtoList = shochiItemCustomWebDtoList;
    }
	
}
