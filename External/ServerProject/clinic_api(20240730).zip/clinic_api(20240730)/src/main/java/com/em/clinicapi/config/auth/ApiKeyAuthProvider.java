package com.em.clinicapi.config.auth;

import com.em.clinicapi.common.cache.RequestCacheHolder;
import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.constants.enumerations.ErrorEnum;
import com.em.clinicapi.common.exception.CustomAuthenticationException;
import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.filter.ApiKeyAuthFilter;
import org.apache.logging.log4j.Logger;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;

import java.util.Collections;

public class ApiKeyAuthProvider implements AuthenticationProvider {

    private static final Logger LOG = LogUtil.getLogger(ApiKeyAuthProvider.class);

    private String apiKeyValue;
    private final CustomUserDetailsService userDetailsService;
    private final PasswordEncoder passwordEncoder;

    public ApiKeyAuthProvider(String apiKeyValue, CustomUserDetailsService userDetailsService, PasswordEncoder passwordEncoder) {
        this.apiKeyValue = apiKeyValue;
        this.userDetailsService = userDetailsService;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
        if (authentication.getCredentials() == null) {
            LOG.error(ErrorEnum.IDPassAuthenticationError.getDescription());

            AuthenticationException exception = new CustomAuthenticationException(
                    ErrorEnum.IDPassAuthenticationError.value(), ErrorEnum.IDPassAuthenticationError.getDescription());
            RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, exception);
            throw exception;
        }

        Object principal = null;
        if (authentication instanceof PreAuthenticatedAuthenticationToken) {
            principal = authentication.getPrincipal();
            String apiKey = (String) principal;

            if (apiKeyValue.equals(apiKey)) {
                if (authentication.getCredentials() instanceof UserModel) {
                    UserModel user = (UserModel) authentication.getCredentials();
                    checkUser(user.getUsername(), user.getPassword());
                } else {
                    LOG.error(ErrorEnum.IDPassAuthenticationError.getDescription());

                    AuthenticationException exception = new CustomAuthenticationException(
                            ErrorEnum.IDPassAuthenticationError.value(), ErrorEnum.IDPassAuthenticationError.getDescription());
                    RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, exception);
                    throw exception;
                }

                return new PreAuthenticatedAuthenticationToken(apiKey, null, Collections.emptyList());
            } else {
                LOG.error(ErrorEnum.TokenAuthenticationError.getDescription());

                AuthenticationException exception = new CustomAuthenticationException(
                        ErrorEnum.TokenAuthenticationError.value(), ErrorEnum.TokenAuthenticationError.getDescription());
                RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, exception);
                throw exception;
            }
        } else if (authentication instanceof UsernamePasswordAuthenticationToken) {
            checkUser(String.valueOf(authentication.getPrincipal()), String.valueOf(authentication.getCredentials()));
        }

        return new PreAuthenticatedAuthenticationToken(principal, null, Collections.emptyList());
    }

    private void checkUser(String userName, String password){
        try {
            UserDetails userDetails = userDetailsService.loadUserByUsername(userName);
            if (userDetails != null) {
                //String passCodeEncode = passwordEncoder.encode(password);
                if (!passwordEncoder.matches(password, userDetails.getPassword())) {
                    LOG.error(ErrorEnum.PasswordAuthenticationError.getDescription());

                    AuthenticationException exception = new CustomAuthenticationException(
                            ErrorEnum.PasswordAuthenticationError.value(), ErrorEnum.PasswordAuthenticationError.getDescription());
                    RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, exception);
                    throw exception;
                }
            }
        } catch (CustomAuthenticationException usernameNotFoundException) {
            LOG.error(ErrorEnum.IDAuthenticationError.getDescription());

            RequestCacheHolder.put(StringConstants.SPRING_SECURITY_LAST_EXCEPTION, usernameNotFoundException);
            throw usernameNotFoundException;
        }
    }

    @Override
    public boolean supports(Class<?> authentication) {
        return PreAuthenticatedAuthenticationToken.class.isAssignableFrom(authentication)
                || UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication);
    }
}
