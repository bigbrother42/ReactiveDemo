package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class IjiSubWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ prescriptionSeq */
	private int  prescriptionSeq = 0;

	/**  プロパティ subSeq */
	private int  subSeq = 0;

	/**  プロパティ shinryouShikibetsuKbn */
	private String  shinryouShikibetsuKbn = null;

	/**  プロパティ shinryouShikibetsuTensuu */
	private java.math.BigDecimal  shinryouShikibetsuTensuu = null;

	/**  プロパティ shinryouShikibetsuKingaku */
	private java.math.BigDecimal  shinryouShikibetsuKingaku = null;

	/**  プロパティ houkatsumaeTensuu */
	private java.math.BigDecimal  houkatsumaeTensuu = null;

	/**  プロパティ isHoukatsu */
	private boolean  isHoukatsu;

	/**  プロパティ isMarume */
	private boolean  isMarume;

	/**  プロパティ futanKbn */
	private String  futanKbn = null;

	/**  プロパティ fukushiFutanKbn */
	private String  fukushiFutanKbn = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiSubWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：prescriptionSeq を返します。
	* @return prescriptionSeq
	*/
	public int getPrescriptionSeq(){
		return prescriptionSeq;
	}

	/**
	* プロパティー：prescriptionSeq を設定します。
	* @param param  int prescriptionSeq
	*/
	public void setPrescriptionSeq(int prescriptionSeq){
		this.prescriptionSeq = prescriptionSeq;
	}

	/**
	* プロパティー：subSeq を返します。
	* @return subSeq
	*/
	public int getSubSeq(){
		return subSeq;
	}

	/**
	* プロパティー：subSeq を設定します。
	* @param param  int subSeq
	*/
	public void setSubSeq(int subSeq){
		this.subSeq = subSeq;
	}

	/**
	* プロパティー：shinryouShikibetsuKbn を返します。
	* @return shinryouShikibetsuKbn
	*/
	public String getShinryouShikibetsuKbn(){
		return shinryouShikibetsuKbn;
	}

	/**
	* プロパティー：shinryouShikibetsuKbn を設定します。
	* @param param  String shinryouShikibetsuKbn
	*/
	public void setShinryouShikibetsuKbn(String shinryouShikibetsuKbn){
		this.shinryouShikibetsuKbn = shinryouShikibetsuKbn;
	}

	/**
	* プロパティー：shinryouShikibetsuTensuu を返します。
	* @return shinryouShikibetsuTensuu
	*/
	public java.math.BigDecimal getShinryouShikibetsuTensuu(){
		return shinryouShikibetsuTensuu;
	}

	/**
	* プロパティー：shinryouShikibetsuTensuu を設定します。
	* @param param  java.math.BigDecimal shinryouShikibetsuTensuu
	*/
	public void setShinryouShikibetsuTensuu(java.math.BigDecimal shinryouShikibetsuTensuu){
		this.shinryouShikibetsuTensuu = shinryouShikibetsuTensuu;
	}

	/**
	* プロパティー：shinryouShikibetsuKingaku を返します。
	* @return shinryouShikibetsuKingaku
	*/
	public java.math.BigDecimal getShinryouShikibetsuKingaku(){
		return shinryouShikibetsuKingaku;
	}

	/**
	* プロパティー：shinryouShikibetsuKingaku を設定します。
	* @param param  java.math.BigDecimal shinryouShikibetsuKingaku
	*/
	public void setShinryouShikibetsuKingaku(java.math.BigDecimal shinryouShikibetsuKingaku){
		this.shinryouShikibetsuKingaku = shinryouShikibetsuKingaku;
	}

	/**
	* プロパティー：houkatsumaeTensuu を返します。
	* @return houkatsumaeTensuu
	*/
	public java.math.BigDecimal getHoukatsumaeTensuu(){
		return houkatsumaeTensuu;
	}

	/**
	* プロパティー：houkatsumaeTensuu を設定します。
	* @param param  java.math.BigDecimal houkatsumaeTensuu
	*/
	public void setHoukatsumaeTensuu(java.math.BigDecimal houkatsumaeTensuu){
		this.houkatsumaeTensuu = houkatsumaeTensuu;
	}

	/**
	* プロパティー：isHoukatsu を返します。
	* @return isHoukatsu
	*/
	public boolean getIsHoukatsu(){
		return isHoukatsu;
	}

	/**
	* プロパティー：isHoukatsu を設定します。
	* @param param  boolean isHoukatsu
	*/
	public void setIsHoukatsu(boolean isHoukatsu){
		this.isHoukatsu = isHoukatsu;
	}

	/**
	* プロパティー：isMarume を返します。
	* @return isMarume
	*/
	public boolean getIsMarume(){
		return isMarume;
	}

	/**
	* プロパティー：isMarume を設定します。
	* @param param  boolean isMarume
	*/
	public void setIsMarume(boolean isMarume){
		this.isMarume = isMarume;
	}

	/**
	* プロパティー：futanKbn を返します。
	* @return futanKbn
	*/
	public String getFutanKbn(){
		return futanKbn;
	}

	/**
	* プロパティー：futanKbn を設定します。
	* @param param  String futanKbn
	*/
	public void setFutanKbn(String futanKbn){
		this.futanKbn = futanKbn;
	}

	/**
	* プロパティー：fukushiFutanKbn を返します。
	* @return fukushiFutanKbn
	*/
	public String getFukushiFutanKbn(){
		return fukushiFutanKbn;
	}

	/**
	* プロパティー：fukushiFutanKbn を設定します。
	* @param param  String fukushiFutanKbn
	*/
	public void setFukushiFutanKbn(String fukushiFutanKbn){
		this.fukushiFutanKbn = fukushiFutanKbn;
	}
}
