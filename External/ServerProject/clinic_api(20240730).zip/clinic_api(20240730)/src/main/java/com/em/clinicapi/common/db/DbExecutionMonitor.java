package com.em.clinicapi.common.db;

import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

@Component
public class DbExecutionMonitor {

    // ①少なくとも、PgConnectionにおいては、equals(Object) の実装はObject#equals(Object)となっており、
    // 　hashCode() が一致するかどうかでの比較となっている（ this == other での比較）。
    // 　したがって、Connection オブジェクトの代わりに、 Connection#hashCode() をキーにすることが可能。
    // ②ステートメント数も、重複を考慮せずにカウントアップしているだけなので、List<Pair<String, Statement>> ではなく、Integerで表現可能。
    // 　ただ、JavaDocによると、カウンタとして使用する場合は、 LongAdder が適切らしい？
    // 　>　ConcurrentHashMapは、LongAdderの値を使用し、computeIfAbsentで初期化することにより、
    // 　>　スケーラブルな頻度マップ(ヒストグラムやマルチセットの形式)として使用できます。
    // 　>　たとえば、ConcurrentHashMap<String,LongAdder> freqsにカウントを追加するには、
    // 　>　freqs.computeIfAbsent(k -> new LongAdder()).increment();を使用できます。
//	private Map<Connection, List<Pair<String, Statement>>> statements = new ConcurrentHashMap<>();
    private Map<Integer, LongAdder> statements = new ConcurrentHashMap<>();

    /**
     * 新しいステートメントを追加する。
     * なお、この際、新しいコネクションだった場合は、コネクションのカウントも追加する。
     * @param stmt
     * @param sql
     * @throws SQLException
     */
    public void add(final Statement stmt, final String sql) throws SQLException {
//		this.statements.computeIfAbsent(stmt.getConnection(), k -> new ArrayList<>()).add(Pair.of(sql, stmt));
        this.statements.computeIfAbsent(stmt.getConnection().hashCode(), k -> new LongAdder()).increment();
    }

    /**
     * コネクションカウントを減らす。
     * 該当のコネクションに紐づいていたステートメントも減ることとなる。
     * @param con
     */
    public void remove(final Connection con) {
        if (con == null)
            return;
        @SuppressWarnings("unused")
        LongAdder counter = this.statements.remove(con.hashCode());
        // 以前(2000年代初頭・・・JDK1.2あたりの時代)は、明示的にnullをセットすることでGCの対処となりやすくなる、
        // という話だったが、今はどうなんだろう？
        counter = null;
//		this.statements.remove(con);
    }

    /**
     * 利用中のステートメント数を取得する。
     * なお、利用し終わったステートメントであっても、
     * 親コネクションが残っている間はカウント対象となるので注意。
     * （したがって、「実際にOpenされている」ステートメント数とは限らない。
     *
     * @return
     */
    public int getActiveStatementCount() {
        int count = 0;
//		for (List<Pair<String, Statement>> stmt : statements.values()) {
//			count += stmt.size();
//		}
        // LongAdderはその名の通り内部的にはlongとなっているが、
        // 今回の用途としては int の範囲内で事足りる（21億ステートメント以上蓄積されるような状態は、それはそれで異常）
        for (LongAdder counter : statements.values()) {
            count += counter.intValue();
        }
        return count;
    }

    /**
     * 利用中のコネクション数を取得する。
     *
     * @return
     */
    public int getActiveConnectionCount() {
        return statements.size();
    }
}
