package com.em.clinicapi.common.constants.enumerations;

public enum ReskeyEnum {

    PatientInfo("PatientInfo"),
    MedicalInfo("Medical Info");


    private final String key;

    ReskeyEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
