package com.em.clinicapi.webdto.request.basicinfo;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import javax.validation.Valid;

@JacksonXmlRootElement(localName = "data")
public class BasicInfoRequestWebDto {
    @Valid
    @JsonProperty("system01_managereq")
    private BasicInfoRequest basicInfoRequest;

    @JsonProperty("system01_managereq")
    public BasicInfoRequest getBasicInfoRequest() {
        return basicInfoRequest;
    }

    @JsonProperty("system01_managereq")
    public void setBasicInfoRequest(BasicInfoRequest basicInfoRequest) {
        this.basicInfoRequest = basicInfoRequest;
    }
}
