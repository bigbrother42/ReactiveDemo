package com.em.clinicapi.mapper;

import com.em.clinicapi.webdto.db.JihiHasuuMWebDto;
import com.em.clinicapi.webdto.db.ShouhizeiritsuMWebDto;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequest;
import com.em.clinicapi.webdto.response.basicinfo.PhysicianInformation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Mapper
public interface BasicInfoMapper {

    public List<PhysicianInformation> selectDoctorBasicInfo(@Param("customerSeq") Integer customerSeq);

    public List<PhysicianInformation> selectStaffBasicInfo(@Param("customerSeq") Integer customerSeq);

    public List<ShouhizeiritsuMWebDto> selectShouhizeiritsuMDtos(@Param("baseDate") Date baseDate);

    public List<JihiHasuuMWebDto> selectJihiHasuuMDtos(@Param("baseDate") Date baseDate, @Param("customerSeq") Integer customerSeq);
}
