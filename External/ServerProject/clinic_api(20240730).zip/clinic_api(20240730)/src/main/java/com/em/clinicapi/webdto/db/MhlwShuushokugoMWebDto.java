package com.em.clinicapi.webdto.db;



import java.sql.Date;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class MhlwShuushokugoMWebDto extends CustomerWebDtoBase {
    private String shuushokugoCode = null;
    private Date startDate = null;
    private String changeKbn = null;
    private String masterType = null;
    private String yobi1 = null;
    private String yobi2 = null;
    private int shuushokugoKanjiCharCount = 0;
    private String shuushokugoKanjiName = null;
    private String yobi3 = null;
    private int shuushokugoKanaCharCount = 0;
    private String shuushokugoKanaName = null;
    private String yobi4 = null;
    private String shuushokugoNameChangeKbn = null;
    private String shuushokugoKanaNameChangeKbn = null;
    private Date shuusaiDate = null;
    private Date changeDate = null;
    private Date endDate = null;
    private String shuushokugoKanriNo = null;
    private String shuushokugoExchangeCode = null;
    private String shuushokugoKbn = null;
    private String shinryouKbn = null;
    private String shushiKbn = null;

    public MhlwShuushokugoMWebDto() {
    }

    public String getShuushokugoCode() {
        return this.shuushokugoCode;
    }

    public void setShuushokugoCode(String shuushokugoCode) {
        this.shuushokugoCode = shuushokugoCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getChangeKbn() {
        return this.changeKbn;
    }

    public void setChangeKbn(String changeKbn) {
        this.changeKbn = changeKbn;
    }

    public String getMasterType() {
        return this.masterType;
    }

    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }

    public String getYobi1() {
        return this.yobi1;
    }

    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    public String getYobi2() {
        return this.yobi2;
    }

    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    public int getShuushokugoKanjiCharCount() {
        return this.shuushokugoKanjiCharCount;
    }

    public void setShuushokugoKanjiCharCount(int shuushokugoKanjiCharCount) {
        this.shuushokugoKanjiCharCount = shuushokugoKanjiCharCount;
    }

    public String getShuushokugoKanjiName() {
        return this.shuushokugoKanjiName;
    }

    public void setShuushokugoKanjiName(String shuushokugoKanjiName) {
        this.shuushokugoKanjiName = shuushokugoKanjiName;
    }

    public String getYobi3() {
        return this.yobi3;
    }

    public void setYobi3(String yobi3) {
        this.yobi3 = yobi3;
    }

    public int getShuushokugoKanaCharCount() {
        return this.shuushokugoKanaCharCount;
    }

    public void setShuushokugoKanaCharCount(int shuushokugoKanaCharCount) {
        this.shuushokugoKanaCharCount = shuushokugoKanaCharCount;
    }

    public String getShuushokugoKanaName() {
        return this.shuushokugoKanaName;
    }

    public void setShuushokugoKanaName(String shuushokugoKanaName) {
        this.shuushokugoKanaName = shuushokugoKanaName;
    }

    public String getYobi4() {
        return this.yobi4;
    }

    public void setYobi4(String yobi4) {
        this.yobi4 = yobi4;
    }

    public String getShuushokugoNameChangeKbn() {
        return this.shuushokugoNameChangeKbn;
    }

    public void setShuushokugoNameChangeKbn(String shuushokugoNameChangeKbn) {
        this.shuushokugoNameChangeKbn = shuushokugoNameChangeKbn;
    }

    public String getShuushokugoKanaNameChangeKbn() {
        return this.shuushokugoKanaNameChangeKbn;
    }

    public void setShuushokugoKanaNameChangeKbn(String shuushokugoKanaNameChangeKbn) {
        this.shuushokugoKanaNameChangeKbn = shuushokugoKanaNameChangeKbn;
    }

    public Date getShuusaiDate() {
        return this.shuusaiDate;
    }

    public void setShuusaiDate(Date shuusaiDate) {
        this.shuusaiDate = shuusaiDate;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getShuushokugoKanriNo() {
        return this.shuushokugoKanriNo;
    }

    public void setShuushokugoKanriNo(String shuushokugoKanriNo) {
        this.shuushokugoKanriNo = shuushokugoKanriNo;
    }

    public String getShuushokugoExchangeCode() {
        return this.shuushokugoExchangeCode;
    }

    public void setShuushokugoExchangeCode(String shuushokugoExchangeCode) {
        this.shuushokugoExchangeCode = shuushokugoExchangeCode;
    }

    public String getShuushokugoKbn() {
        return this.shuushokugoKbn;
    }

    public void setShuushokugoKbn(String shuushokugoKbn) {
        this.shuushokugoKbn = shuushokugoKbn;
    }

    public String getShinryouKbn() {
        return this.shinryouKbn;
    }

    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }

    public String getShushiKbn() {
        return this.shushiKbn;
    }

    public void setShushiKbn(String shushiKbn) {
        this.shushiKbn = shushiKbn;
    }
}
