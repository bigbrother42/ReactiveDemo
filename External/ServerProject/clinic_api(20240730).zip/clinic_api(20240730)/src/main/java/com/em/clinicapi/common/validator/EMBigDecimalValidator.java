package com.em.clinicapi.common.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.math.BigDecimal;

public class EMBigDecimalValidator  implements ConstraintValidator<EMBigDecimal,String> {
    String message;
    String fieldName;
    @Override
    public void initialize(EMBigDecimal constraintAnnotation) {
        this.message = constraintAnnotation.message();
        this.fieldName = constraintAnnotation.fieldName();
        ConstraintValidator.super.initialize(constraintAnnotation);
    }
    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        try{
            BigDecimal tmp = new BigDecimal(value);
            return true;
        }
        catch (Exception e){
            message =  fieldName + "の入力は不正です。入力値:" + value;
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
            return false;
        }
    }

}
