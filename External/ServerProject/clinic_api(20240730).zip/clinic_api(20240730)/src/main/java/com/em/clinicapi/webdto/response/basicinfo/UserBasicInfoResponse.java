package com.em.clinicapi.webdto.response.basicinfo;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : DoctorBasicInfoWebDto クラス <br/>
 * 項目：  <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************

public class UserBasicInfoResponse extends ResponseWebDtoBase {
    /**
     * 項目： Information_Date <br/>
     * 説明： <br/>
     *       レスポンスを返す時点の日付 <br/>
     * 備考： <br/>
     *       "2024-03-03" <br/>
     */
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Information_Date")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String informationDate;
    /**
     * 項目： Information_Time <br/>
     * 説明： <br/>
     *       レスポンスを返す時点の時刻 <br/>
     * 備考： <br/>
     *       "13:35:52" <br/>
     */
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Information_Time")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String informationTime;
    /**
     * 項目： Api_Result <br/>
     * 説明： <br/>
     *       成功時は"00"を返す <br/>
     *       それ以外は要検討 <br/>
     * 備考： <br/>
     *       ”00" <br/>
     */
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Api_Result")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String apiResult;
    /**
     * 項目： Api_Result_Message <br/>
     * 備考： <br/>
     *       "処理終了" <br/>
     */
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Api_Result_Message")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String apiResultMessage;
    /**
     * 項目： Reskey <br/>
     */
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Reskey")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String reskey;

    /**
     * 項目： Base_Date <br/>
     * 説明： <br/>
     *       リクエスト側のBase_Dateを返却 <br/>
     */
    @JsonProperty("Base_Date")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String baseDate;

    /**
     * 項目： Physician_Information <br/>
     */
    @JsonProperty("Physician_Information")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private PhysicianInformationArr physicianInformationArr;

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Information_Date")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getInformationDate() {
        return informationDate;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Information_Date")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setInformationDate(String informationDate) {
        this.informationDate = informationDate;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Information_Time")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getInformationTime() {
        return informationTime;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Information_Time")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setInformationTime(String informationTime) {
        this.informationTime = informationTime;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Api_Result")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getApiResult() {
        return apiResult;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Api_Result")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setApiResult(String apiResult) {
        this.apiResult = apiResult;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Api_Result_Message")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getApiResultMessage() {
        return apiResultMessage;
    }

    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonProperty("Api_Result_Message")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setApiResultMessage(String apiResultMessage) {
        this.apiResultMessage = apiResultMessage;
    }

    /**
     * Reskeyを返事します。
     * @return Reskeyの値
     */
    @JsonProperty("Reskey")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getReskey() {
        return reskey;
    }

    /**
     * Reskeyを設定します。
     * @param reskey Reskey
     */
    @JsonProperty("Reskey")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setReskey(String reskey) {
        this.reskey = reskey;
    }

    /**
     * Base_Dateを返事します。
     * @return Base_Dateの値
     */
    @JsonProperty("Base_Date")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getBaseDate() {
        return baseDate;
    }

    /**
     * Base_Dateを設定します。
     * @param baseDate Base_Date
     */
    @JsonProperty("Base_Date")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setBaseDate(String baseDate) {
        this.baseDate = baseDate;
    }

    @JsonProperty("Physician_Information")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public PhysicianInformationArr getPhysicianInformationArr() {
        return physicianInformationArr;
    }

    @JsonProperty("Physician_Information")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setPhysicianInformationArr(PhysicianInformationArr physicianInformationArr) {
        this.physicianInformationArr = physicianInformationArr;
    }
}
