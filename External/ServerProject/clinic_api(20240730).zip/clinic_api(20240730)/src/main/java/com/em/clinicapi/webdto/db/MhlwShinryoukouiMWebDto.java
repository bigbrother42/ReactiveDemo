package com.em.clinicapi.webdto.db;


import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import java.math.BigDecimal;
import java.sql.Date;
import org.springframework.stereotype.Component;

@Component
public class MhlwShinryoukouiMWebDto extends CustomerWebDtoBase {
    private String shinryoukouiCode = null;
    private Date startDate = null;
    private String changeKbn = null;
    private String masterType = null;
    private int shinryoukouiShortKanjiValidCharCount = 0;
    private String shinryoukouiShortKanjiName = null;
    private int shinryoukouiShortKanaValidCharCount = 0;
    private String shinryoukouiShortKanaName = null;
    private String dataKikakuCode = null;
    private int dataKikakuKanjiValidCharCount = 0;
    private String dataKikakuKanjiName = null;
    private String tensuuShikibetsuKbn = null;
    private BigDecimal tensuu = null;
    private String nyuugaiTekiyouKbn = null;
    private String koukiKoureishaIryouTekiyouKbn = null;
    private String tensuuShuukeisakiShikibetsuNyuuingaiKbn = null;
    private String houkatsuTaishouKensaKbn = null;
    private String yobi1 = null;
    private String dpcTekiyouKbn = null;
    private String hospitalClinicKbn = null;
    private String imageShujutsuShienKasanKbn = null;
    private String iryouKansatsuhouTaishouKbn = null;
    private String kangoKasanCode = null;
    private String masuiShikibetsuKbn = null;
    private String nyuuinKihonryouKasanKbn = null;
    private String shoubyouNameKanrenKbn = null;
    private BigDecimal igakuKanriryou = null;
    private String jitsuNissuuSanteiKbn = null;
    private String nissuuKaisuuKbn = null;
    private String iyakuhinKanrenKbn = null;
    private String kizamiKeisanShikibetsuKbn = null;
    private int kizamiKagenValue = 0;
    private int kizamiJougenValue = 0;
    private int kizamiValue = 0;
    private BigDecimal kizamiTensuu = null;
    private String kizamiJoukagenErrorProcessKbn = null;
    private int jougenKaisuu = 0;
    private String jougenKaisuuErrorProcessKbn = null;
    private String chuukasanCode = null;
    private String chuukasanTsuubanKbn = null;
    private String tsuusokuAgeKbn = null;
    private String kagenAge = null;
    private String jougenAge = null;
    private String timeKasanKbn = null;
    private String tekigouKbn = null;
    private String taishouShisetsuKijunCode = null;
    private String shochiNyuuyoujiKasanKbn = null;
    private String lowShusseiTaijuujiKasanKbn = null;
    private String nyuuinKihonryouGenzanTaishouShikibetsuKbn = null;
    private String tonerPartShuukeiKbn = null;
    private String kensaJisshiHandanKbn = null;
    private String kensaJisshiHandanGroupKbn = null;
    private String teigenTaishouKbn = null;
    private String sekizuiYuuhatsuDeniSokuteiKasanKbn = null;
    private String keibuKakuseijutsuHeishiKasanKbn = null;
    private String autoHougoukiKasanKbn = null;
    private String gairaiKanriKasanKbn = null;
    private String formerTensuuShikibetsuKbn = null;
    private BigDecimal formerTensuu = null;
    private String kanjiNameChangeKbn = null;
    private String kanaNameChangeKbn = null;
    private String kentaiKensaCommentKbn = null;
    private String tsuusokuKasanShoteiTensuuTaishouKbn = null;
    private String houkatsuTeigenKbn = null;
    private String chouonpaNaishikyouKasanKbn = null;
    private String yobi2 = null;
    private String tensuuShuukeisakiShikibetsuNyuuinKbn = null;
    private String autoFungoukiKasanKbn = null;
    private String kokujiShikibetsu1Kbn = null;
    private String kokujiShikibetsu2Kbn = null;
    private String regionKasanKbn = null;
    private String byoushouCountKbn = null;
    private String shisetsuKijun01Code = null;
    private String shisetsuKijun02Code = null;
    private String shisetsuKijun03Code = null;
    private String shisetsuKijun04Code = null;
    private String shisetsuKijun05Code = null;
    private String shisetsuKijun06Code = null;
    private String shisetsuKijun07Code = null;
    private String shisetsuKijun08Code = null;
    private String shisetsuKijun09Code = null;
    private String shisetsuKijun10Code = null;
    private String chouonpaGyoukoSekkaiSouchiKasanKbn = null;
    private String tankiTaizaiShujutsuKbn = null;
    private String shikaTekiyouKbn = null;
    private String codehyouNoAlphabetPart = null;
    private String kokujiTsuuchiKanrenNoAlphabetPart = null;
    private Date changeDate = null;
    private Date endDate = null;
    private String kouhyouOrderNo = null;
    private String codehyouNoShou = null;
    private String codehyouNoPart = null;
    private String codehyouNoKbnNo = null;
    private String codehyouNoEdabanNo = null;
    private String codehyouNoKoubanNo = null;
    private String kokujiTsuuchiKanrenNoShou = null;
    private String kokujiTsuuchiKanrenNoPart = null;
    private String kokujiTsuuchiKanrenNoKbnNo = null;
    private String kokujiTsuuchiKanrenNoEdabanNo = null;
    private String kokujiTsuuchiKanrenNoKoubanNo = null;
    private String ageKasan01KagenAge = null;
    private String ageKasan01JougenAge = null;
    private String ageKasan01ChuukasanCode = null;
    private String ageKasan02KagenAge = null;
    private String ageKasan02JougenAge = null;
    private String ageKasan02ChuukasanCode = null;
    private String ageKasan03KagenAge = null;
    private String ageKasan03JougenAge = null;
    private String ageKasan03ChuukasanCode = null;
    private String ageKasan04KagenAge = null;
    private String ageKasan04JougenAge = null;
    private String ageKasan04ChuukasanCode = null;
    private String idouKanrenCode = null;
    private String shinryouKbn = null;
    private String imageShindanId = null;
    private String tekiyouHokenKbn = null;
    private BigDecimal shishiKasanBairitsu = null;
    private BigDecimal shushiKasanBairitsu = null;
    private String shouenChintsuuKbn = null;
    private String basicKanjiName = null;
    private String fukubikouShujutsuNaishikyouKasan = null;
    private String fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan = null;
    private String choujikanMasuiKanriKasan = null;
    private String tensuuhyouKbnNo = null;
    private String monitoringKasan = null;
    private String touketsuHozonDoushuSoshikiKasan = null;
    private String akuseiShuyouByouriSoshikiHyouhonKasan = null;
    private String yobi3 = null;
    private String yobi4 = null;
    private String yobi123 = null;
    private String yobi124 = null;
    private String yobi125 = null;
    private String yobi126 = null;
    private String yobi127 = null;
    private String yobi128 = null;
    private String yobi129 = null;
    private String yobi130 = null;
    private String yobi131 = null;
    private String yobi132 = null;
    private String yobi133 = null;
    private String yobi134 = null;
    private String yobi135 = null;
    private String yobi136 = null;
    private String yobi137 = null;
    private String yobi138 = null;
    private String yobi139 = null;
    private String yobi140 = null;
    private String yobi141 = null;
    private String yobi142 = null;
    private String yobi143 = null;
    private String yobi144 = null;
    private String yobi145 = null;
    private String yobi146 = null;
    private String yobi147 = null;
    private String yobi148 = null;
    private String yobi149 = null;
    private String yobi150 = null;

    public MhlwShinryoukouiMWebDto() {
    }

    public String getShinryoukouiCode() {
        return this.shinryoukouiCode;
    }

    public void setShinryoukouiCode(String shinryoukouiCode) {
        this.shinryoukouiCode = shinryoukouiCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getChangeKbn() {
        return this.changeKbn;
    }

    public void setChangeKbn(String changeKbn) {
        this.changeKbn = changeKbn;
    }

    public String getMasterType() {
        return this.masterType;
    }

    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }

    public int getShinryoukouiShortKanjiValidCharCount() {
        return this.shinryoukouiShortKanjiValidCharCount;
    }

    public void setShinryoukouiShortKanjiValidCharCount(int shinryoukouiShortKanjiValidCharCount) {
        this.shinryoukouiShortKanjiValidCharCount = shinryoukouiShortKanjiValidCharCount;
    }

    public String getShinryoukouiShortKanjiName() {
        return this.shinryoukouiShortKanjiName;
    }

    public void setShinryoukouiShortKanjiName(String shinryoukouiShortKanjiName) {
        this.shinryoukouiShortKanjiName = shinryoukouiShortKanjiName;
    }

    public int getShinryoukouiShortKanaValidCharCount() {
        return this.shinryoukouiShortKanaValidCharCount;
    }

    public void setShinryoukouiShortKanaValidCharCount(int shinryoukouiShortKanaValidCharCount) {
        this.shinryoukouiShortKanaValidCharCount = shinryoukouiShortKanaValidCharCount;
    }

    public String getShinryoukouiShortKanaName() {
        return this.shinryoukouiShortKanaName;
    }

    public void setShinryoukouiShortKanaName(String shinryoukouiShortKanaName) {
        this.shinryoukouiShortKanaName = shinryoukouiShortKanaName;
    }

    public String getDataKikakuCode() {
        return this.dataKikakuCode;
    }

    public void setDataKikakuCode(String dataKikakuCode) {
        this.dataKikakuCode = dataKikakuCode;
    }

    public int getDataKikakuKanjiValidCharCount() {
        return this.dataKikakuKanjiValidCharCount;
    }

    public void setDataKikakuKanjiValidCharCount(int dataKikakuKanjiValidCharCount) {
        this.dataKikakuKanjiValidCharCount = dataKikakuKanjiValidCharCount;
    }

    public String getDataKikakuKanjiName() {
        return this.dataKikakuKanjiName;
    }

    public void setDataKikakuKanjiName(String dataKikakuKanjiName) {
        this.dataKikakuKanjiName = dataKikakuKanjiName;
    }

    public String getTensuuShikibetsuKbn() {
        return this.tensuuShikibetsuKbn;
    }

    public void setTensuuShikibetsuKbn(String tensuuShikibetsuKbn) {
        this.tensuuShikibetsuKbn = tensuuShikibetsuKbn;
    }

    public BigDecimal getTensuu() {
        return this.tensuu;
    }

    public void setTensuu(BigDecimal tensuu) {
        this.tensuu = tensuu;
    }

    public String getNyuugaiTekiyouKbn() {
        return this.nyuugaiTekiyouKbn;
    }

    public void setNyuugaiTekiyouKbn(String nyuugaiTekiyouKbn) {
        this.nyuugaiTekiyouKbn = nyuugaiTekiyouKbn;
    }

    public String getKoukiKoureishaIryouTekiyouKbn() {
        return this.koukiKoureishaIryouTekiyouKbn;
    }

    public void setKoukiKoureishaIryouTekiyouKbn(String koukiKoureishaIryouTekiyouKbn) {
        this.koukiKoureishaIryouTekiyouKbn = koukiKoureishaIryouTekiyouKbn;
    }

    public String getTensuuShuukeisakiShikibetsuNyuuingaiKbn() {
        return this.tensuuShuukeisakiShikibetsuNyuuingaiKbn;
    }

    public void setTensuuShuukeisakiShikibetsuNyuuingaiKbn(String tensuuShuukeisakiShikibetsuNyuuingaiKbn) {
        this.tensuuShuukeisakiShikibetsuNyuuingaiKbn = tensuuShuukeisakiShikibetsuNyuuingaiKbn;
    }

    public String getHoukatsuTaishouKensaKbn() {
        return this.houkatsuTaishouKensaKbn;
    }

    public void setHoukatsuTaishouKensaKbn(String houkatsuTaishouKensaKbn) {
        this.houkatsuTaishouKensaKbn = houkatsuTaishouKensaKbn;
    }

    public String getYobi1() {
        return this.yobi1;
    }

    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    public String getDpcTekiyouKbn() {
        return this.dpcTekiyouKbn;
    }

    public void setDpcTekiyouKbn(String dpcTekiyouKbn) {
        this.dpcTekiyouKbn = dpcTekiyouKbn;
    }

    public String getHospitalClinicKbn() {
        return this.hospitalClinicKbn;
    }

    public void setHospitalClinicKbn(String hospitalClinicKbn) {
        this.hospitalClinicKbn = hospitalClinicKbn;
    }

    public String getImageShujutsuShienKasanKbn() {
        return this.imageShujutsuShienKasanKbn;
    }

    public void setImageShujutsuShienKasanKbn(String imageShujutsuShienKasanKbn) {
        this.imageShujutsuShienKasanKbn = imageShujutsuShienKasanKbn;
    }

    public String getIryouKansatsuhouTaishouKbn() {
        return this.iryouKansatsuhouTaishouKbn;
    }

    public void setIryouKansatsuhouTaishouKbn(String iryouKansatsuhouTaishouKbn) {
        this.iryouKansatsuhouTaishouKbn = iryouKansatsuhouTaishouKbn;
    }

    public String getKangoKasanCode() {
        return this.kangoKasanCode;
    }

    public void setKangoKasanCode(String kangoKasanCode) {
        this.kangoKasanCode = kangoKasanCode;
    }

    public String getMasuiShikibetsuKbn() {
        return this.masuiShikibetsuKbn;
    }

    public void setMasuiShikibetsuKbn(String masuiShikibetsuKbn) {
        this.masuiShikibetsuKbn = masuiShikibetsuKbn;
    }

    public String getNyuuinKihonryouKasanKbn() {
        return this.nyuuinKihonryouKasanKbn;
    }

    public void setNyuuinKihonryouKasanKbn(String nyuuinKihonryouKasanKbn) {
        this.nyuuinKihonryouKasanKbn = nyuuinKihonryouKasanKbn;
    }

    public String getShoubyouNameKanrenKbn() {
        return this.shoubyouNameKanrenKbn;
    }

    public void setShoubyouNameKanrenKbn(String shoubyouNameKanrenKbn) {
        this.shoubyouNameKanrenKbn = shoubyouNameKanrenKbn;
    }

    public BigDecimal getIgakuKanriryou() {
        return this.igakuKanriryou;
    }

    public void setIgakuKanriryou(BigDecimal igakuKanriryou) {
        this.igakuKanriryou = igakuKanriryou;
    }

    public String getJitsuNissuuSanteiKbn() {
        return this.jitsuNissuuSanteiKbn;
    }

    public void setJitsuNissuuSanteiKbn(String jitsuNissuuSanteiKbn) {
        this.jitsuNissuuSanteiKbn = jitsuNissuuSanteiKbn;
    }

    public String getNissuuKaisuuKbn() {
        return this.nissuuKaisuuKbn;
    }

    public void setNissuuKaisuuKbn(String nissuuKaisuuKbn) {
        this.nissuuKaisuuKbn = nissuuKaisuuKbn;
    }

    public String getIyakuhinKanrenKbn() {
        return this.iyakuhinKanrenKbn;
    }

    public void setIyakuhinKanrenKbn(String iyakuhinKanrenKbn) {
        this.iyakuhinKanrenKbn = iyakuhinKanrenKbn;
    }

    public String getKizamiKeisanShikibetsuKbn() {
        return this.kizamiKeisanShikibetsuKbn;
    }

    public void setKizamiKeisanShikibetsuKbn(String kizamiKeisanShikibetsuKbn) {
        this.kizamiKeisanShikibetsuKbn = kizamiKeisanShikibetsuKbn;
    }

    public int getKizamiKagenValue() {
        return this.kizamiKagenValue;
    }

    public void setKizamiKagenValue(int kizamiKagenValue) {
        this.kizamiKagenValue = kizamiKagenValue;
    }

    public int getKizamiJougenValue() {
        return this.kizamiJougenValue;
    }

    public void setKizamiJougenValue(int kizamiJougenValue) {
        this.kizamiJougenValue = kizamiJougenValue;
    }

    public int getKizamiValue() {
        return this.kizamiValue;
    }

    public void setKizamiValue(int kizamiValue) {
        this.kizamiValue = kizamiValue;
    }

    public BigDecimal getKizamiTensuu() {
        return this.kizamiTensuu;
    }

    public void setKizamiTensuu(BigDecimal kizamiTensuu) {
        this.kizamiTensuu = kizamiTensuu;
    }

    public String getKizamiJoukagenErrorProcessKbn() {
        return this.kizamiJoukagenErrorProcessKbn;
    }

    public void setKizamiJoukagenErrorProcessKbn(String kizamiJoukagenErrorProcessKbn) {
        this.kizamiJoukagenErrorProcessKbn = kizamiJoukagenErrorProcessKbn;
    }

    public int getJougenKaisuu() {
        return this.jougenKaisuu;
    }

    public void setJougenKaisuu(int jougenKaisuu) {
        this.jougenKaisuu = jougenKaisuu;
    }

    public String getJougenKaisuuErrorProcessKbn() {
        return this.jougenKaisuuErrorProcessKbn;
    }

    public void setJougenKaisuuErrorProcessKbn(String jougenKaisuuErrorProcessKbn) {
        this.jougenKaisuuErrorProcessKbn = jougenKaisuuErrorProcessKbn;
    }

    public String getChuukasanCode() {
        return this.chuukasanCode;
    }

    public void setChuukasanCode(String chuukasanCode) {
        this.chuukasanCode = chuukasanCode;
    }

    public String getChuukasanTsuubanKbn() {
        return this.chuukasanTsuubanKbn;
    }

    public void setChuukasanTsuubanKbn(String chuukasanTsuubanKbn) {
        this.chuukasanTsuubanKbn = chuukasanTsuubanKbn;
    }

    public String getTsuusokuAgeKbn() {
        return this.tsuusokuAgeKbn;
    }

    public void setTsuusokuAgeKbn(String tsuusokuAgeKbn) {
        this.tsuusokuAgeKbn = tsuusokuAgeKbn;
    }

    public String getKagenAge() {
        return this.kagenAge;
    }

    public void setKagenAge(String kagenAge) {
        this.kagenAge = kagenAge;
    }

    public String getJougenAge() {
        return this.jougenAge;
    }

    public void setJougenAge(String jougenAge) {
        this.jougenAge = jougenAge;
    }

    public String getTimeKasanKbn() {
        return this.timeKasanKbn;
    }

    public void setTimeKasanKbn(String timeKasanKbn) {
        this.timeKasanKbn = timeKasanKbn;
    }

    public String getTekigouKbn() {
        return this.tekigouKbn;
    }

    public void setTekigouKbn(String tekigouKbn) {
        this.tekigouKbn = tekigouKbn;
    }

    public String getTaishouShisetsuKijunCode() {
        return this.taishouShisetsuKijunCode;
    }

    public void setTaishouShisetsuKijunCode(String taishouShisetsuKijunCode) {
        this.taishouShisetsuKijunCode = taishouShisetsuKijunCode;
    }

    public String getShochiNyuuyoujiKasanKbn() {
        return this.shochiNyuuyoujiKasanKbn;
    }

    public void setShochiNyuuyoujiKasanKbn(String shochiNyuuyoujiKasanKbn) {
        this.shochiNyuuyoujiKasanKbn = shochiNyuuyoujiKasanKbn;
    }

    public String getLowShusseiTaijuujiKasanKbn() {
        return this.lowShusseiTaijuujiKasanKbn;
    }

    public void setLowShusseiTaijuujiKasanKbn(String lowShusseiTaijuujiKasanKbn) {
        this.lowShusseiTaijuujiKasanKbn = lowShusseiTaijuujiKasanKbn;
    }

    public String getNyuuinKihonryouGenzanTaishouShikibetsuKbn() {
        return this.nyuuinKihonryouGenzanTaishouShikibetsuKbn;
    }

    public void setNyuuinKihonryouGenzanTaishouShikibetsuKbn(String nyuuinKihonryouGenzanTaishouShikibetsuKbn) {
        this.nyuuinKihonryouGenzanTaishouShikibetsuKbn = nyuuinKihonryouGenzanTaishouShikibetsuKbn;
    }

    public String getTonerPartShuukeiKbn() {
        return this.tonerPartShuukeiKbn;
    }

    public void setTonerPartShuukeiKbn(String tonerPartShuukeiKbn) {
        this.tonerPartShuukeiKbn = tonerPartShuukeiKbn;
    }

    public String getKensaJisshiHandanKbn() {
        return this.kensaJisshiHandanKbn;
    }

    public void setKensaJisshiHandanKbn(String kensaJisshiHandanKbn) {
        this.kensaJisshiHandanKbn = kensaJisshiHandanKbn;
    }

    public String getKensaJisshiHandanGroupKbn() {
        return this.kensaJisshiHandanGroupKbn;
    }

    public void setKensaJisshiHandanGroupKbn(String kensaJisshiHandanGroupKbn) {
        this.kensaJisshiHandanGroupKbn = kensaJisshiHandanGroupKbn;
    }

    public String getTeigenTaishouKbn() {
        return this.teigenTaishouKbn;
    }

    public void setTeigenTaishouKbn(String teigenTaishouKbn) {
        this.teigenTaishouKbn = teigenTaishouKbn;
    }

    public String getSekizuiYuuhatsuDeniSokuteiKasanKbn() {
        return this.sekizuiYuuhatsuDeniSokuteiKasanKbn;
    }

    public void setSekizuiYuuhatsuDeniSokuteiKasanKbn(String sekizuiYuuhatsuDeniSokuteiKasanKbn) {
        this.sekizuiYuuhatsuDeniSokuteiKasanKbn = sekizuiYuuhatsuDeniSokuteiKasanKbn;
    }

    public String getKeibuKakuseijutsuHeishiKasanKbn() {
        return this.keibuKakuseijutsuHeishiKasanKbn;
    }

    public void setKeibuKakuseijutsuHeishiKasanKbn(String keibuKakuseijutsuHeishiKasanKbn) {
        this.keibuKakuseijutsuHeishiKasanKbn = keibuKakuseijutsuHeishiKasanKbn;
    }

    public String getAutoHougoukiKasanKbn() {
        return this.autoHougoukiKasanKbn;
    }

    public void setAutoHougoukiKasanKbn(String autoHougoukiKasanKbn) {
        this.autoHougoukiKasanKbn = autoHougoukiKasanKbn;
    }

    public String getGairaiKanriKasanKbn() {
        return this.gairaiKanriKasanKbn;
    }

    public void setGairaiKanriKasanKbn(String gairaiKanriKasanKbn) {
        this.gairaiKanriKasanKbn = gairaiKanriKasanKbn;
    }

    public String getFormerTensuuShikibetsuKbn() {
        return this.formerTensuuShikibetsuKbn;
    }

    public void setFormerTensuuShikibetsuKbn(String formerTensuuShikibetsuKbn) {
        this.formerTensuuShikibetsuKbn = formerTensuuShikibetsuKbn;
    }

    public BigDecimal getFormerTensuu() {
        return this.formerTensuu;
    }

    public void setFormerTensuu(BigDecimal formerTensuu) {
        this.formerTensuu = formerTensuu;
    }

    public String getKanjiNameChangeKbn() {
        return this.kanjiNameChangeKbn;
    }

    public void setKanjiNameChangeKbn(String kanjiNameChangeKbn) {
        this.kanjiNameChangeKbn = kanjiNameChangeKbn;
    }

    public String getKanaNameChangeKbn() {
        return this.kanaNameChangeKbn;
    }

    public void setKanaNameChangeKbn(String kanaNameChangeKbn) {
        this.kanaNameChangeKbn = kanaNameChangeKbn;
    }

    public String getKentaiKensaCommentKbn() {
        return this.kentaiKensaCommentKbn;
    }

    public void setKentaiKensaCommentKbn(String kentaiKensaCommentKbn) {
        this.kentaiKensaCommentKbn = kentaiKensaCommentKbn;
    }

    public String getTsuusokuKasanShoteiTensuuTaishouKbn() {
        return this.tsuusokuKasanShoteiTensuuTaishouKbn;
    }

    public void setTsuusokuKasanShoteiTensuuTaishouKbn(String tsuusokuKasanShoteiTensuuTaishouKbn) {
        this.tsuusokuKasanShoteiTensuuTaishouKbn = tsuusokuKasanShoteiTensuuTaishouKbn;
    }

    public String getHoukatsuTeigenKbn() {
        return this.houkatsuTeigenKbn;
    }

    public void setHoukatsuTeigenKbn(String houkatsuTeigenKbn) {
        this.houkatsuTeigenKbn = houkatsuTeigenKbn;
    }

    public String getChouonpaNaishikyouKasanKbn() {
        return this.chouonpaNaishikyouKasanKbn;
    }

    public void setChouonpaNaishikyouKasanKbn(String chouonpaNaishikyouKasanKbn) {
        this.chouonpaNaishikyouKasanKbn = chouonpaNaishikyouKasanKbn;
    }

    public String getYobi2() {
        return this.yobi2;
    }

    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    public String getTensuuShuukeisakiShikibetsuNyuuinKbn() {
        return this.tensuuShuukeisakiShikibetsuNyuuinKbn;
    }

    public void setTensuuShuukeisakiShikibetsuNyuuinKbn(String tensuuShuukeisakiShikibetsuNyuuinKbn) {
        this.tensuuShuukeisakiShikibetsuNyuuinKbn = tensuuShuukeisakiShikibetsuNyuuinKbn;
    }

    public String getAutoFungoukiKasanKbn() {
        return this.autoFungoukiKasanKbn;
    }

    public void setAutoFungoukiKasanKbn(String autoFungoukiKasanKbn) {
        this.autoFungoukiKasanKbn = autoFungoukiKasanKbn;
    }

    public String getKokujiShikibetsu1Kbn() {
        return this.kokujiShikibetsu1Kbn;
    }

    public void setKokujiShikibetsu1Kbn(String kokujiShikibetsu1Kbn) {
        this.kokujiShikibetsu1Kbn = kokujiShikibetsu1Kbn;
    }

    public String getKokujiShikibetsu2Kbn() {
        return this.kokujiShikibetsu2Kbn;
    }

    public void setKokujiShikibetsu2Kbn(String kokujiShikibetsu2Kbn) {
        this.kokujiShikibetsu2Kbn = kokujiShikibetsu2Kbn;
    }

    public String getRegionKasanKbn() {
        return this.regionKasanKbn;
    }

    public void setRegionKasanKbn(String regionKasanKbn) {
        this.regionKasanKbn = regionKasanKbn;
    }

    public String getByoushouCountKbn() {
        return this.byoushouCountKbn;
    }

    public void setByoushouCountKbn(String byoushouCountKbn) {
        this.byoushouCountKbn = byoushouCountKbn;
    }

    public String getShisetsuKijun01Code() {
        return this.shisetsuKijun01Code;
    }

    public void setShisetsuKijun01Code(String shisetsuKijun01Code) {
        this.shisetsuKijun01Code = shisetsuKijun01Code;
    }

    public String getShisetsuKijun02Code() {
        return this.shisetsuKijun02Code;
    }

    public void setShisetsuKijun02Code(String shisetsuKijun02Code) {
        this.shisetsuKijun02Code = shisetsuKijun02Code;
    }

    public String getShisetsuKijun03Code() {
        return this.shisetsuKijun03Code;
    }

    public void setShisetsuKijun03Code(String shisetsuKijun03Code) {
        this.shisetsuKijun03Code = shisetsuKijun03Code;
    }

    public String getShisetsuKijun04Code() {
        return this.shisetsuKijun04Code;
    }

    public void setShisetsuKijun04Code(String shisetsuKijun04Code) {
        this.shisetsuKijun04Code = shisetsuKijun04Code;
    }

    public String getShisetsuKijun05Code() {
        return this.shisetsuKijun05Code;
    }

    public void setShisetsuKijun05Code(String shisetsuKijun05Code) {
        this.shisetsuKijun05Code = shisetsuKijun05Code;
    }

    public String getShisetsuKijun06Code() {
        return this.shisetsuKijun06Code;
    }

    public void setShisetsuKijun06Code(String shisetsuKijun06Code) {
        this.shisetsuKijun06Code = shisetsuKijun06Code;
    }

    public String getShisetsuKijun07Code() {
        return this.shisetsuKijun07Code;
    }

    public void setShisetsuKijun07Code(String shisetsuKijun07Code) {
        this.shisetsuKijun07Code = shisetsuKijun07Code;
    }

    public String getShisetsuKijun08Code() {
        return this.shisetsuKijun08Code;
    }

    public void setShisetsuKijun08Code(String shisetsuKijun08Code) {
        this.shisetsuKijun08Code = shisetsuKijun08Code;
    }

    public String getShisetsuKijun09Code() {
        return this.shisetsuKijun09Code;
    }

    public void setShisetsuKijun09Code(String shisetsuKijun09Code) {
        this.shisetsuKijun09Code = shisetsuKijun09Code;
    }

    public String getShisetsuKijun10Code() {
        return this.shisetsuKijun10Code;
    }

    public void setShisetsuKijun10Code(String shisetsuKijun10Code) {
        this.shisetsuKijun10Code = shisetsuKijun10Code;
    }

    public String getChouonpaGyoukoSekkaiSouchiKasanKbn() {
        return this.chouonpaGyoukoSekkaiSouchiKasanKbn;
    }

    public void setChouonpaGyoukoSekkaiSouchiKasanKbn(String chouonpaGyoukoSekkaiSouchiKasanKbn) {
        this.chouonpaGyoukoSekkaiSouchiKasanKbn = chouonpaGyoukoSekkaiSouchiKasanKbn;
    }

    public String getTankiTaizaiShujutsuKbn() {
        return this.tankiTaizaiShujutsuKbn;
    }

    public void setTankiTaizaiShujutsuKbn(String tankiTaizaiShujutsuKbn) {
        this.tankiTaizaiShujutsuKbn = tankiTaizaiShujutsuKbn;
    }

    public String getShikaTekiyouKbn() {
        return this.shikaTekiyouKbn;
    }

    public void setShikaTekiyouKbn(String shikaTekiyouKbn) {
        this.shikaTekiyouKbn = shikaTekiyouKbn;
    }

    public String getCodehyouNoAlphabetPart() {
        return this.codehyouNoAlphabetPart;
    }

    public void setCodehyouNoAlphabetPart(String codehyouNoAlphabetPart) {
        this.codehyouNoAlphabetPart = codehyouNoAlphabetPart;
    }

    public String getKokujiTsuuchiKanrenNoAlphabetPart() {
        return this.kokujiTsuuchiKanrenNoAlphabetPart;
    }

    public void setKokujiTsuuchiKanrenNoAlphabetPart(String kokujiTsuuchiKanrenNoAlphabetPart) {
        this.kokujiTsuuchiKanrenNoAlphabetPart = kokujiTsuuchiKanrenNoAlphabetPart;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getKouhyouOrderNo() {
        return this.kouhyouOrderNo;
    }

    public void setKouhyouOrderNo(String kouhyouOrderNo) {
        this.kouhyouOrderNo = kouhyouOrderNo;
    }

    public String getCodehyouNoShou() {
        return this.codehyouNoShou;
    }

    public void setCodehyouNoShou(String codehyouNoShou) {
        this.codehyouNoShou = codehyouNoShou;
    }

    public String getCodehyouNoPart() {
        return this.codehyouNoPart;
    }

    public void setCodehyouNoPart(String codehyouNoPart) {
        this.codehyouNoPart = codehyouNoPart;
    }

    public String getCodehyouNoKbnNo() {
        return this.codehyouNoKbnNo;
    }

    public void setCodehyouNoKbnNo(String codehyouNoKbnNo) {
        this.codehyouNoKbnNo = codehyouNoKbnNo;
    }

    public String getCodehyouNoEdabanNo() {
        return this.codehyouNoEdabanNo;
    }

    public void setCodehyouNoEdabanNo(String codehyouNoEdabanNo) {
        this.codehyouNoEdabanNo = codehyouNoEdabanNo;
    }

    public String getCodehyouNoKoubanNo() {
        return this.codehyouNoKoubanNo;
    }

    public void setCodehyouNoKoubanNo(String codehyouNoKoubanNo) {
        this.codehyouNoKoubanNo = codehyouNoKoubanNo;
    }

    public String getKokujiTsuuchiKanrenNoShou() {
        return this.kokujiTsuuchiKanrenNoShou;
    }

    public void setKokujiTsuuchiKanrenNoShou(String kokujiTsuuchiKanrenNoShou) {
        this.kokujiTsuuchiKanrenNoShou = kokujiTsuuchiKanrenNoShou;
    }

    public String getKokujiTsuuchiKanrenNoPart() {
        return this.kokujiTsuuchiKanrenNoPart;
    }

    public void setKokujiTsuuchiKanrenNoPart(String kokujiTsuuchiKanrenNoPart) {
        this.kokujiTsuuchiKanrenNoPart = kokujiTsuuchiKanrenNoPart;
    }

    public String getKokujiTsuuchiKanrenNoKbnNo() {
        return this.kokujiTsuuchiKanrenNoKbnNo;
    }

    public void setKokujiTsuuchiKanrenNoKbnNo(String kokujiTsuuchiKanrenNoKbnNo) {
        this.kokujiTsuuchiKanrenNoKbnNo = kokujiTsuuchiKanrenNoKbnNo;
    }

    public String getKokujiTsuuchiKanrenNoEdabanNo() {
        return this.kokujiTsuuchiKanrenNoEdabanNo;
    }

    public void setKokujiTsuuchiKanrenNoEdabanNo(String kokujiTsuuchiKanrenNoEdabanNo) {
        this.kokujiTsuuchiKanrenNoEdabanNo = kokujiTsuuchiKanrenNoEdabanNo;
    }

    public String getKokujiTsuuchiKanrenNoKoubanNo() {
        return this.kokujiTsuuchiKanrenNoKoubanNo;
    }

    public void setKokujiTsuuchiKanrenNoKoubanNo(String kokujiTsuuchiKanrenNoKoubanNo) {
        this.kokujiTsuuchiKanrenNoKoubanNo = kokujiTsuuchiKanrenNoKoubanNo;
    }

    public String getAgeKasan01KagenAge() {
        return this.ageKasan01KagenAge;
    }

    public void setAgeKasan01KagenAge(String ageKasan01KagenAge) {
        this.ageKasan01KagenAge = ageKasan01KagenAge;
    }

    public String getAgeKasan01JougenAge() {
        return this.ageKasan01JougenAge;
    }

    public void setAgeKasan01JougenAge(String ageKasan01JougenAge) {
        this.ageKasan01JougenAge = ageKasan01JougenAge;
    }

    public String getAgeKasan01ChuukasanCode() {
        return this.ageKasan01ChuukasanCode;
    }

    public void setAgeKasan01ChuukasanCode(String ageKasan01ChuukasanCode) {
        this.ageKasan01ChuukasanCode = ageKasan01ChuukasanCode;
    }

    public String getAgeKasan02KagenAge() {
        return this.ageKasan02KagenAge;
    }

    public void setAgeKasan02KagenAge(String ageKasan02KagenAge) {
        this.ageKasan02KagenAge = ageKasan02KagenAge;
    }

    public String getAgeKasan02JougenAge() {
        return this.ageKasan02JougenAge;
    }

    public void setAgeKasan02JougenAge(String ageKasan02JougenAge) {
        this.ageKasan02JougenAge = ageKasan02JougenAge;
    }

    public String getAgeKasan02ChuukasanCode() {
        return this.ageKasan02ChuukasanCode;
    }

    public void setAgeKasan02ChuukasanCode(String ageKasan02ChuukasanCode) {
        this.ageKasan02ChuukasanCode = ageKasan02ChuukasanCode;
    }

    public String getAgeKasan03KagenAge() {
        return this.ageKasan03KagenAge;
    }

    public void setAgeKasan03KagenAge(String ageKasan03KagenAge) {
        this.ageKasan03KagenAge = ageKasan03KagenAge;
    }

    public String getAgeKasan03JougenAge() {
        return this.ageKasan03JougenAge;
    }

    public void setAgeKasan03JougenAge(String ageKasan03JougenAge) {
        this.ageKasan03JougenAge = ageKasan03JougenAge;
    }

    public String getAgeKasan03ChuukasanCode() {
        return this.ageKasan03ChuukasanCode;
    }

    public void setAgeKasan03ChuukasanCode(String ageKasan03ChuukasanCode) {
        this.ageKasan03ChuukasanCode = ageKasan03ChuukasanCode;
    }

    public String getAgeKasan04KagenAge() {
        return this.ageKasan04KagenAge;
    }

    public void setAgeKasan04KagenAge(String ageKasan04KagenAge) {
        this.ageKasan04KagenAge = ageKasan04KagenAge;
    }

    public String getAgeKasan04JougenAge() {
        return this.ageKasan04JougenAge;
    }

    public void setAgeKasan04JougenAge(String ageKasan04JougenAge) {
        this.ageKasan04JougenAge = ageKasan04JougenAge;
    }

    public String getAgeKasan04ChuukasanCode() {
        return this.ageKasan04ChuukasanCode;
    }

    public void setAgeKasan04ChuukasanCode(String ageKasan04ChuukasanCode) {
        this.ageKasan04ChuukasanCode = ageKasan04ChuukasanCode;
    }

    public String getIdouKanrenCode() {
        return this.idouKanrenCode;
    }

    public void setIdouKanrenCode(String idouKanrenCode) {
        this.idouKanrenCode = idouKanrenCode;
    }

    public String getShinryouKbn() {
        return this.shinryouKbn;
    }

    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }

    public String getImageShindanId() {
        return this.imageShindanId;
    }

    public void setImageShindanId(String imageShindanId) {
        this.imageShindanId = imageShindanId;
    }

    public String getTekiyouHokenKbn() {
        return this.tekiyouHokenKbn;
    }

    public void setTekiyouHokenKbn(String tekiyouHokenKbn) {
        this.tekiyouHokenKbn = tekiyouHokenKbn;
    }

    public BigDecimal getShishiKasanBairitsu() {
        return this.shishiKasanBairitsu;
    }

    public void setShishiKasanBairitsu(BigDecimal shishiKasanBairitsu) {
        this.shishiKasanBairitsu = shishiKasanBairitsu;
    }

    public BigDecimal getShushiKasanBairitsu() {
        return this.shushiKasanBairitsu;
    }

    public void setShushiKasanBairitsu(BigDecimal shushiKasanBairitsu) {
        this.shushiKasanBairitsu = shushiKasanBairitsu;
    }

    public String getShouenChintsuuKbn() {
        return this.shouenChintsuuKbn;
    }

    public void setShouenChintsuuKbn(String shouenChintsuuKbn) {
        this.shouenChintsuuKbn = shouenChintsuuKbn;
    }

    public String getBasicKanjiName() {
        return this.basicKanjiName;
    }

    public void setBasicKanjiName(String basicKanjiName) {
        this.basicKanjiName = basicKanjiName;
    }

    public String getFukubikouShujutsuNaishikyouKasan() {
        return this.fukubikouShujutsuNaishikyouKasan;
    }

    public void setFukubikouShujutsuNaishikyouKasan(String fukubikouShujutsuNaishikyouKasan) {
        this.fukubikouShujutsuNaishikyouKasan = fukubikouShujutsuNaishikyouKasan;
    }

    public String getFukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan() {
        return this.fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan;
    }

    public void setFukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan(String fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan) {
        this.fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan = fukubikouShujutsuKotsunanbuSoshikiSetsujoKikiKasan;
    }

    public String getChoujikanMasuiKanriKasan() {
        return this.choujikanMasuiKanriKasan;
    }

    public void setChoujikanMasuiKanriKasan(String choujikanMasuiKanriKasan) {
        this.choujikanMasuiKanriKasan = choujikanMasuiKanriKasan;
    }

    public String getTensuuhyouKbnNo() {
        return this.tensuuhyouKbnNo;
    }

    public void setTensuuhyouKbnNo(String tensuuhyouKbnNo) {
        this.tensuuhyouKbnNo = tensuuhyouKbnNo;
    }

    public String getMonitoringKasan() {
        return this.monitoringKasan;
    }

    public void setMonitoringKasan(String monitoringKasan) {
        this.monitoringKasan = monitoringKasan;
    }

    public String getTouketsuHozonDoushuSoshikiKasan() {
        return this.touketsuHozonDoushuSoshikiKasan;
    }

    public void setTouketsuHozonDoushuSoshikiKasan(String touketsuHozonDoushuSoshikiKasan) {
        this.touketsuHozonDoushuSoshikiKasan = touketsuHozonDoushuSoshikiKasan;
    }

    public String getAkuseiShuyouByouriSoshikiHyouhonKasan() {
        return this.akuseiShuyouByouriSoshikiHyouhonKasan;
    }

    public void setAkuseiShuyouByouriSoshikiHyouhonKasan(String akuseiShuyouByouriSoshikiHyouhonKasan) {
        this.akuseiShuyouByouriSoshikiHyouhonKasan = akuseiShuyouByouriSoshikiHyouhonKasan;
    }

    public String getYobi3() {
        return this.yobi3;
    }

    public void setYobi3(String yobi3) {
        this.yobi3 = yobi3;
    }

    public String getYobi4() {
        return this.yobi4;
    }

    public void setYobi4(String yobi4) {
        this.yobi4 = yobi4;
    }

    public String getYobi123() {
        return this.yobi123;
    }

    public void setYobi123(String yobi123) {
        this.yobi123 = yobi123;
    }

    public String getYobi124() {
        return this.yobi124;
    }

    public void setYobi124(String yobi124) {
        this.yobi124 = yobi124;
    }

    public String getYobi125() {
        return this.yobi125;
    }

    public void setYobi125(String yobi125) {
        this.yobi125 = yobi125;
    }

    public String getYobi126() {
        return this.yobi126;
    }

    public void setYobi126(String yobi126) {
        this.yobi126 = yobi126;
    }

    public String getYobi127() {
        return this.yobi127;
    }

    public void setYobi127(String yobi127) {
        this.yobi127 = yobi127;
    }

    public String getYobi128() {
        return this.yobi128;
    }

    public void setYobi128(String yobi128) {
        this.yobi128 = yobi128;
    }

    public String getYobi129() {
        return this.yobi129;
    }

    public void setYobi129(String yobi129) {
        this.yobi129 = yobi129;
    }

    public String getYobi130() {
        return this.yobi130;
    }

    public void setYobi130(String yobi130) {
        this.yobi130 = yobi130;
    }

    public String getYobi131() {
        return this.yobi131;
    }

    public void setYobi131(String yobi131) {
        this.yobi131 = yobi131;
    }

    public String getYobi132() {
        return this.yobi132;
    }

    public void setYobi132(String yobi132) {
        this.yobi132 = yobi132;
    }

    public String getYobi133() {
        return this.yobi133;
    }

    public void setYobi133(String yobi133) {
        this.yobi133 = yobi133;
    }

    public String getYobi134() {
        return this.yobi134;
    }

    public void setYobi134(String yobi134) {
        this.yobi134 = yobi134;
    }

    public String getYobi135() {
        return this.yobi135;
    }

    public void setYobi135(String yobi135) {
        this.yobi135 = yobi135;
    }

    public String getYobi136() {
        return this.yobi136;
    }

    public void setYobi136(String yobi136) {
        this.yobi136 = yobi136;
    }

    public String getYobi137() {
        return this.yobi137;
    }

    public void setYobi137(String yobi137) {
        this.yobi137 = yobi137;
    }

    public String getYobi138() {
        return this.yobi138;
    }

    public void setYobi138(String yobi138) {
        this.yobi138 = yobi138;
    }

    public String getYobi139() {
        return this.yobi139;
    }

    public void setYobi139(String yobi139) {
        this.yobi139 = yobi139;
    }

    public String getYobi140() {
        return this.yobi140;
    }

    public void setYobi140(String yobi140) {
        this.yobi140 = yobi140;
    }

    public String getYobi141() {
        return this.yobi141;
    }

    public void setYobi141(String yobi141) {
        this.yobi141 = yobi141;
    }

    public String getYobi142() {
        return this.yobi142;
    }

    public void setYobi142(String yobi142) {
        this.yobi142 = yobi142;
    }

    public String getYobi143() {
        return this.yobi143;
    }

    public void setYobi143(String yobi143) {
        this.yobi143 = yobi143;
    }

    public String getYobi144() {
        return this.yobi144;
    }

    public void setYobi144(String yobi144) {
        this.yobi144 = yobi144;
    }

    public String getYobi145() {
        return this.yobi145;
    }

    public void setYobi145(String yobi145) {
        this.yobi145 = yobi145;
    }

    public String getYobi146() {
        return this.yobi146;
    }

    public void setYobi146(String yobi146) {
        this.yobi146 = yobi146;
    }

    public String getYobi147() {
        return this.yobi147;
    }

    public void setYobi147(String yobi147) {
        this.yobi147 = yobi147;
    }

    public String getYobi148() {
        return this.yobi148;
    }

    public void setYobi148(String yobi148) {
        this.yobi148 = yobi148;
    }

    public String getYobi149() {
        return this.yobi149;
    }

    public void setYobi149(String yobi149) {
        this.yobi149 = yobi149;
    }

    public String getYobi150() {
        return this.yobi150;
    }

    public void setYobi150(String yobi150) {
        this.yobi150 = yobi150;
    }
}
