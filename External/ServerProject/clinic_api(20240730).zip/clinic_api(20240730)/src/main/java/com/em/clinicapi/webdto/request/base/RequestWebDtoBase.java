package com.em.clinicapi.webdto.request.base;

import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.constants.enumerations.ClassTypeEnum;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

public class RequestWebDtoBase {

    @JacksonXmlProperty(isAttribute = true)
    private String type = StringConstants.CLASS_TYPE_RECORD;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
