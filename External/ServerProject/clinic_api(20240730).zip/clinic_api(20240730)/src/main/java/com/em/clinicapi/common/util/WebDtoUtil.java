package com.em.clinicapi.common.util;

import com.em.clinicapi.common.constants.enumerations.ApiResultEnum;
import com.em.clinicapi.common.constants.enumerations.ApiResultMessageEnum;
import com.em.clinicapi.common.constants.enumerations.errorcode.ApiError;
import com.em.clinicapi.webdto.base.ResponseBase;
import com.em.clinicapi.webdto.base.ResultInfo;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class WebDtoUtil {

    public static void setResponseBase(ResponseBase responseBase, ApiResultEnum apiResult, ApiResultMessageEnum apiResultMessage) {
       responseBase.setInformationDate( LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) );
       responseBase.setInformationTime( LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) );
       responseBase.setApiResult(apiResult.getCode());
       responseBase.setApiResultMessage(apiResultMessage.getMessage());
    }

    public static void setResultInfo(ResultInfo resultInfo, String code, String message) {
        resultInfo.setInformationDate( LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) );
        resultInfo.setInformationTime( LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) );
        resultInfo.setApiResult(code);
        resultInfo.setApiResultMessage(message);
    }

    public static void setResultSuccess(ResultInfo resultInfo) {
        resultInfo.setInformationDate( LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) );
        resultInfo.setInformationTime( LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) );
        resultInfo.setApiResult(ApiResultEnum.Success.getCode());
        resultInfo.setApiResultMessage(ApiResultMessageEnum.Success.getMessage());
    }

    public static void setErrorInfo(ResultInfo resultInfo, ApiError apiError) {
        resultInfo.setInformationDate( LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) );
        resultInfo.setInformationTime( LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) );
        resultInfo.setApiResult(apiError.getCode());
        resultInfo.setApiResultMessage(apiError.getMessage());
    }

    public static void setErrorInfo(ResponseBase resultInfo, ApiError apiError) {
        resultInfo.setInformationDate( LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd")) );
        resultInfo.setInformationTime( LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) );
        resultInfo.setApiResult(apiError.getCode());
        resultInfo.setApiResultMessage(apiError.getMessage());
    }

}
