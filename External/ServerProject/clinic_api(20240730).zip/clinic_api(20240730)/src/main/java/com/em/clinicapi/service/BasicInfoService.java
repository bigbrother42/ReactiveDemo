package com.em.clinicapi.service;

import com.em.clinicapi.logic.BasicInfoLogic;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequestWebDto;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponseWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BasicInfoService {

    @Autowired
    private BasicInfoLogic basicInfoLogic;

    /**
     * アカウント情報取得(医師)
     * @param dto
     * @return
     */
    public UserBasicInfoResponseWebDto getDoctorBasicInfo(BasicInfoRequestWebDto dto) {
        return basicInfoLogic.getDoctorBasicInfo(dto);
    }

    /**
     * アカウント情報取得(職員)
     * @param dto
     * @return
     */
    public UserBasicInfoResponseWebDto getStaffBasicInfo(BasicInfoRequestWebDto dto) {
        return basicInfoLogic.getStaffBasicInfo(dto);
    }
}
