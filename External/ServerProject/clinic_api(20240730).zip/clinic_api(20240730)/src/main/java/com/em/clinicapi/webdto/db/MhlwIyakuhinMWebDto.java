

package com.em.clinicapi.webdto.db;

import java.math.BigDecimal;
import java.sql.Date;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class MhlwIyakuhinMWebDto extends CustomerWebDtoBase{
    private String iyakuhinCode = null;
    private Date startDate = null;
    private String changeKbn = null;
    private String masterType = null;
    private int iyakuhinKanjiValidCharCount = 0;
    private String iyakuhinKanjiName = null;
    private int iyakuhinKanaValidCharCount = 0;
    private String iyakuhinKanaName = null;
    private String unitCode = null;
    private int unitNameValidCharCount = 0;
    private String unitName = null;
    private String kingakuType = null;
    private BigDecimal kingaku = null;
    private String yobi1 = null;
    private String madokuKbn = null;
    private String shinkeiHakaizaiKbn = null;
    private String biologicalSeizaiKbn = null;
    private String kouhatsuhinKbn = null;
    private String yobi2 = null;
    private String shikaTokuteiYakuzai = null;
    private String zoueiHojozaiKbn = null;
    private BigDecimal chuushaYouryouMl = null;
    private String shuusaiHoushikiShikibetsuKbn = null;
    private String productNameKanrenCode = null;
    private String formerKingakuType = null;
    private BigDecimal formerKingaku = null;
    private String kanjiNameChangeKbn = null;
    private String kanaNameChangeKbn = null;
    private String zaikeiKbn = null;
    private String yobi3 = null;
    private Date changeDate = null;
    private Date endDate = null;
    private String yakkaKijunShuusaiIyakuhinCode = null;
    private String kouhyouOrderNo = null;
    private Date keikaSochiDate = null;
    private String shinryouKbn = null;
    private String kikinSoutouMasterCode = null;
    private String dpcTekiyouKbn = null;
    private String anzenKanriShidouKasanKbn = null;
    private String basicKanjiName = null;
    private Date yakkaKijunShuusaiDate = null;
    private String ippanNameCode = null;
    private String ippanNamePrescriptionKanjiName = null;
    private String ippanNameShohouKasanTaishouKbn = null;
    private String kouHivKbn = null;

    public MhlwIyakuhinMWebDto() {
    }

    public String getIyakuhinCode() {
        return this.iyakuhinCode;
    }

    public void setIyakuhinCode(String iyakuhinCode) {
        this.iyakuhinCode = iyakuhinCode;
    }

    public Date getStartDate() {
        return this.startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public String getChangeKbn() {
        return this.changeKbn;
    }

    public void setChangeKbn(String changeKbn) {
        this.changeKbn = changeKbn;
    }

    public String getMasterType() {
        return this.masterType;
    }

    public void setMasterType(String masterType) {
        this.masterType = masterType;
    }

    public int getIyakuhinKanjiValidCharCount() {
        return this.iyakuhinKanjiValidCharCount;
    }

    public void setIyakuhinKanjiValidCharCount(int iyakuhinKanjiValidCharCount) {
        this.iyakuhinKanjiValidCharCount = iyakuhinKanjiValidCharCount;
    }

    public String getIyakuhinKanjiName() {
        return this.iyakuhinKanjiName;
    }

    public void setIyakuhinKanjiName(String iyakuhinKanjiName) {
        this.iyakuhinKanjiName = iyakuhinKanjiName;
    }

    public int getIyakuhinKanaValidCharCount() {
        return this.iyakuhinKanaValidCharCount;
    }

    public void setIyakuhinKanaValidCharCount(int iyakuhinKanaValidCharCount) {
        this.iyakuhinKanaValidCharCount = iyakuhinKanaValidCharCount;
    }

    public String getIyakuhinKanaName() {
        return this.iyakuhinKanaName;
    }

    public void setIyakuhinKanaName(String iyakuhinKanaName) {
        this.iyakuhinKanaName = iyakuhinKanaName;
    }

    public String getUnitCode() {
        return this.unitCode;
    }

    public void setUnitCode(String unitCode) {
        this.unitCode = unitCode;
    }

    public int getUnitNameValidCharCount() {
        return this.unitNameValidCharCount;
    }

    public void setUnitNameValidCharCount(int unitNameValidCharCount) {
        this.unitNameValidCharCount = unitNameValidCharCount;
    }

    public String getUnitName() {
        return this.unitName;
    }

    public void setUnitName(String unitName) {
        this.unitName = unitName;
    }

    public String getKingakuType() {
        return this.kingakuType;
    }

    public void setKingakuType(String kingakuType) {
        this.kingakuType = kingakuType;
    }

    public BigDecimal getKingaku() {
        return this.kingaku;
    }

    public void setKingaku(BigDecimal kingaku) {
        this.kingaku = kingaku;
    }

    public String getYobi1() {
        return this.yobi1;
    }

    public void setYobi1(String yobi1) {
        this.yobi1 = yobi1;
    }

    public String getMadokuKbn() {
        return this.madokuKbn;
    }

    public void setMadokuKbn(String madokuKbn) {
        this.madokuKbn = madokuKbn;
    }

    public String getShinkeiHakaizaiKbn() {
        return this.shinkeiHakaizaiKbn;
    }

    public void setShinkeiHakaizaiKbn(String shinkeiHakaizaiKbn) {
        this.shinkeiHakaizaiKbn = shinkeiHakaizaiKbn;
    }

    public String getBiologicalSeizaiKbn() {
        return this.biologicalSeizaiKbn;
    }

    public void setBiologicalSeizaiKbn(String biologicalSeizaiKbn) {
        this.biologicalSeizaiKbn = biologicalSeizaiKbn;
    }

    public String getKouhatsuhinKbn() {
        return this.kouhatsuhinKbn;
    }

    public void setKouhatsuhinKbn(String kouhatsuhinKbn) {
        this.kouhatsuhinKbn = kouhatsuhinKbn;
    }

    public String getYobi2() {
        return this.yobi2;
    }

    public void setYobi2(String yobi2) {
        this.yobi2 = yobi2;
    }

    public String getShikaTokuteiYakuzai() {
        return this.shikaTokuteiYakuzai;
    }

    public void setShikaTokuteiYakuzai(String shikaTokuteiYakuzai) {
        this.shikaTokuteiYakuzai = shikaTokuteiYakuzai;
    }

    public String getZoueiHojozaiKbn() {
        return this.zoueiHojozaiKbn;
    }

    public void setZoueiHojozaiKbn(String zoueiHojozaiKbn) {
        this.zoueiHojozaiKbn = zoueiHojozaiKbn;
    }

    public BigDecimal getChuushaYouryouMl() {
        return this.chuushaYouryouMl;
    }

    public void setChuushaYouryouMl(BigDecimal chuushaYouryouMl) {
        this.chuushaYouryouMl = chuushaYouryouMl;
    }

    public String getShuusaiHoushikiShikibetsuKbn() {
        return this.shuusaiHoushikiShikibetsuKbn;
    }

    public void setShuusaiHoushikiShikibetsuKbn(String shuusaiHoushikiShikibetsuKbn) {
        this.shuusaiHoushikiShikibetsuKbn = shuusaiHoushikiShikibetsuKbn;
    }

    public String getProductNameKanrenCode() {
        return this.productNameKanrenCode;
    }

    public void setProductNameKanrenCode(String productNameKanrenCode) {
        this.productNameKanrenCode = productNameKanrenCode;
    }

    public String getFormerKingakuType() {
        return this.formerKingakuType;
    }

    public void setFormerKingakuType(String formerKingakuType) {
        this.formerKingakuType = formerKingakuType;
    }

    public BigDecimal getFormerKingaku() {
        return this.formerKingaku;
    }

    public void setFormerKingaku(BigDecimal formerKingaku) {
        this.formerKingaku = formerKingaku;
    }

    public String getKanjiNameChangeKbn() {
        return this.kanjiNameChangeKbn;
    }

    public void setKanjiNameChangeKbn(String kanjiNameChangeKbn) {
        this.kanjiNameChangeKbn = kanjiNameChangeKbn;
    }

    public String getKanaNameChangeKbn() {
        return this.kanaNameChangeKbn;
    }

    public void setKanaNameChangeKbn(String kanaNameChangeKbn) {
        this.kanaNameChangeKbn = kanaNameChangeKbn;
    }

    public String getZaikeiKbn() {
        return this.zaikeiKbn;
    }

    public void setZaikeiKbn(String zaikeiKbn) {
        this.zaikeiKbn = zaikeiKbn;
    }

    public String getYobi3() {
        return this.yobi3;
    }

    public void setYobi3(String yobi3) {
        this.yobi3 = yobi3;
    }

    public Date getChangeDate() {
        return this.changeDate;
    }

    public void setChangeDate(Date changeDate) {
        this.changeDate = changeDate;
    }

    public Date getEndDate() {
        return this.endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getYakkaKijunShuusaiIyakuhinCode() {
        return this.yakkaKijunShuusaiIyakuhinCode;
    }

    public void setYakkaKijunShuusaiIyakuhinCode(String yakkaKijunShuusaiIyakuhinCode) {
        this.yakkaKijunShuusaiIyakuhinCode = yakkaKijunShuusaiIyakuhinCode;
    }

    public String getKouhyouOrderNo() {
        return this.kouhyouOrderNo;
    }

    public void setKouhyouOrderNo(String kouhyouOrderNo) {
        this.kouhyouOrderNo = kouhyouOrderNo;
    }

    public Date getKeikaSochiDate() {
        return this.keikaSochiDate;
    }

    public void setKeikaSochiDate(Date keikaSochiDate) {
        this.keikaSochiDate = keikaSochiDate;
    }

    public String getShinryouKbn() {
        return this.shinryouKbn;
    }

    public void setShinryouKbn(String shinryouKbn) {
        this.shinryouKbn = shinryouKbn;
    }

    public String getKikinSoutouMasterCode() {
        return this.kikinSoutouMasterCode;
    }

    public void setKikinSoutouMasterCode(String kikinSoutouMasterCode) {
        this.kikinSoutouMasterCode = kikinSoutouMasterCode;
    }

    public String getDpcTekiyouKbn() {
        return this.dpcTekiyouKbn;
    }

    public void setDpcTekiyouKbn(String dpcTekiyouKbn) {
        this.dpcTekiyouKbn = dpcTekiyouKbn;
    }

    public String getAnzenKanriShidouKasanKbn() {
        return this.anzenKanriShidouKasanKbn;
    }

    public void setAnzenKanriShidouKasanKbn(String anzenKanriShidouKasanKbn) {
        this.anzenKanriShidouKasanKbn = anzenKanriShidouKasanKbn;
    }

    public String getBasicKanjiName() {
        return this.basicKanjiName;
    }

    public void setBasicKanjiName(String basicKanjiName) {
        this.basicKanjiName = basicKanjiName;
    }

    public Date getYakkaKijunShuusaiDate() {
        return this.yakkaKijunShuusaiDate;
    }

    public void setYakkaKijunShuusaiDate(Date yakkaKijunShuusaiDate) {
        this.yakkaKijunShuusaiDate = yakkaKijunShuusaiDate;
    }

    public String getIppanNameCode() {
        return this.ippanNameCode;
    }

    public void setIppanNameCode(String ippanNameCode) {
        this.ippanNameCode = ippanNameCode;
    }

    public String getIppanNamePrescriptionKanjiName() {
        return this.ippanNamePrescriptionKanjiName;
    }

    public void setIppanNamePrescriptionKanjiName(String ippanNamePrescriptionKanjiName) {
        this.ippanNamePrescriptionKanjiName = ippanNamePrescriptionKanjiName;
    }

    public String getIppanNameShohouKasanTaishouKbn() {
        return this.ippanNameShohouKasanTaishouKbn;
    }

    public void setIppanNameShohouKasanTaishouKbn(String ippanNameShohouKasanTaishouKbn) {
        this.ippanNameShohouKasanTaishouKbn = ippanNameShohouKasanTaishouKbn;
    }

    public String getKouHivKbn() {
        return this.kouHivKbn;
    }

    public void setKouHivKbn(String kouHivKbn) {
        this.kouHivKbn = kouHivKbn;
    }
}
