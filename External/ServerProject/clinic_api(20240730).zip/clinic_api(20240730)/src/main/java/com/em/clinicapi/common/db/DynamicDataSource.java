package com.em.clinicapi.common.db;

import com.em.clinicapi.common.cache.DbMapperContextHolder;
import com.em.clinicapi.common.util.LogUtil;
import com.zaxxer.hikari.HikariConfigMXBean;
import com.zaxxer.hikari.HikariDataSource;
import com.zaxxer.hikari.HikariPoolMXBean;
import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;
import org.springframework.jdbc.datasource.lookup.DataSourceLookup;
import org.springframework.util.Assert;

import javax.sql.DataSource;

public class DynamicDataSource extends AbstractRoutingDataSource {

    /**
     * DB接続に要した時間をスレッド単位で保持する。
     */
    private static ThreadLocal<Long> CONNECT_WAIT_ELAPSED = new ThreadLocal<>();

    /**
     * PostgreSQL接続用ドライバーのプロパティ ApplicationName にセットするアプリケーション名。
     * どこから接続しているか？　という情報がわかるようにセットします。
     * （pgpoolを経由した場合、接続元の情報がすべて pgpool に置き換わってしまい、どのAPサーバーからの接続だったか？　というのがわからなくなるため）
     */
    private static String _connectionApplicationName;

    /**
     * DataSource検査機能
     */
    private DataSourceLookup dataSourceLookup;

    /**
     * DB接続所要時間を累計します。
     * （１回のリクエスト（＝同一スレッド）で複数回の接続処理が呼び出される可能性があるため、上書きではなく足しこみで処理を行う）
     * @param elapsed
     */
    private static void addElapsed(long elapsed) {
        if (CONNECT_WAIT_ELAPSED.get() == null) {
            CONNECT_WAIT_ELAPSED.set(Long.valueOf(0));
        }
        CONNECT_WAIT_ELAPSED.set(CONNECT_WAIT_ELAPSED.get() + elapsed);
    }

    /**
     * DB接続所要時間の情報を破棄します。
     */
    public static void clearElapsed() {
        if (CONNECT_WAIT_ELAPSED.get() != null) {
            CONNECT_WAIT_ELAPSED.remove();
        }
    }

    /**
     * DB接続所要時間の値を取得します。
     * @return
     */
    public static long getElapsed() {
        Long l = CONNECT_WAIT_ELAPSED.get();
        return (l == null) ? 0L : l.longValue();
    }

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource#
     * determineCurrentLookupKey()
     */
    @Override
    protected Object determineCurrentLookupKey() {
        return DbMapperContextHolder.get();
    }

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource#
     * determineTargetDataSource()
     */
    @Override
    protected DataSource determineTargetDataSource() {
        DataSource targetDataSource = dataSourceLookup.getDataSource(CustomDataSourceLookup.DEFAULT_DATA_SOURCE_NAME);

        try {
            if (targetDataSource != null && targetDataSource instanceof HikariDataSource) {
                HikariConfigMXBean configbean = ((HikariDataSource)targetDataSource).getHikariConfigMXBean();
                int max = configbean.getMaximumPoolSize();

                HikariPoolMXBean mxbean = ((HikariDataSource)targetDataSource).getHikariPoolMXBean();
                int waiting = mxbean.getThreadsAwaitingConnection();
                int active = mxbean.getActiveConnections();
                int total = mxbean.getTotalConnections();
                int idle = mxbean.getIdleConnections();
                if (max == active && idle == 0) {
                    // 既に最大数を使い切っていて、idleが0の状態の場合、これからコネクションを取得しようと思うと「待ち」の状態になってしまう。
                    LogUtil.getLogger(this).warn(
                        "Hikari Pool : " +
                            ((HikariDataSource)targetDataSource).getPoolName() +
                            ", max=" +
                            Integer.toString(max) +
                            ", total=" +
                            Integer.toString(total) +
                            ", active=" +
                            Integer.toString(active) +
                            ", idle=" +
                            Integer.toString(idle) +
                            ", waiting=" +
                            // これからコネクションを取得しようとしているので、＋１（すでに待っているコネクション＋これから待ち状態になるコネクション）
                            // このチェックを行ってから実際にgetConnectionを行うまでの数ミリ秒（あるいはミリ秒以下）の間に他の処理が完了して
                            // 結果として「待ち」が発生しない可能性はあるが、getConnectionのところで情報を取得することができないので・・・。
                            Integer.toString(waiting + 1)
                    );
                }
            }
        } catch (Exception ex) {
            LogUtil.getLogger(this).error(ex.getMessage(), ex);
        }
        return targetDataSource;
    }

    /*
     * (non-Javadoc)
     *
     * @see org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource#
     * setDataSourceLookup(org.springframework.jdbc.datasource.lookup.
     * DataSourceLookup)
     */
    @Override
    public void setDataSourceLookup(DataSourceLookup dataSourceLookup) {
        super.setDataSourceLookup(dataSourceLookup);
        Assert.notNull(dataSourceLookup, "dataSourceLookup cannot be null");
        this.dataSourceLookup = dataSourceLookup;
    }
}
