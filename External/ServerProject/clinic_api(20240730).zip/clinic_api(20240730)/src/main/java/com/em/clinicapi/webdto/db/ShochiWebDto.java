package com.em.clinicapi.webdto.db;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2019
/****************************************************************************/
/**
* WebDto : ShochiWebDto クラス
*
* 自動生成クラス <BR>
*
* 作成日 ： 2019/12/05 <BR>
*
* @author DAOGenerator4Smart
*/
//***************************************************************************

import org.springframework.stereotype.Component;
import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
@Component
public class ShochiWebDto extends CustomerWebDtoBase{
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ karteSeq */
	private int  karteSeq = 0;

	/**  プロパティ prescriptionSeq */
	private int  prescriptionSeq = 0;

	/**  プロパティ zenkaiSeq */
	private int  zenkaiSeq = 0;

	/**  プロパティ shinryouKbn */
	private String  shinryouKbn = null;

	/**  プロパティ prescriptionNissuuKaisuu */
	private int  prescriptionNissuuKaisuu = 0;

	/**  プロパティ ingaiTouyakuKbn */
	private String  ingaiTouyakuKbn = null;

	/**  プロパティ touyoHouhouTouyakuKbn */
	private String  touyoHouhouTouyakuKbn = null;

	/**  プロパティ isRinjiTouyoTouyaku */
	private boolean  isRinjiTouyoTouyaku;

	/**  プロパティ isKongouTouyaku */
	private boolean  isKongouTouyaku;

	/**  プロパティ isIppoukaTaishougai */
	private boolean  isIppoukaTaishougai;

	/**  プロパティ isHoukatsuTaishougai */
	private boolean  isHoukatsuTaishougai;

	/**  プロパティ isMarumeTaishougai */
	private boolean  isMarumeTaishougai;

	/**  プロパティ bunkatsuCommentTouyaku */
	private String  bunkatsuCommentTouyaku = null;

	/**  プロパティ setName */
	private String  setName = null;

	/**  プロパティ setChangeKbn */
	private String  setChangeKbn = null;

	/**  プロパティ setShikibetsuKbn */
	private String  setShikibetsuKbn = null;

	/**  プロパティ setJihiCode */
	private String  setJihiCode = null;

	/**  プロパティ zenkaiPrescriptionSeq */
	private int  zenkaiPrescriptionSeq = 0;

	/**  プロパティ setCode */
	private String  setCode = null;

	/**  プロパティ setKbn */
	private String  setKbn = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public ShochiWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：karteSeq を返します。
	* @return karteSeq
	*/
	public int getKarteSeq(){
		return karteSeq;
	}

	/**
	* プロパティー：karteSeq を設定します。
	* @param param  int karteSeq
	*/
	public void setKarteSeq(int karteSeq){
		this.karteSeq = karteSeq;
	}

	/**
	* プロパティー：prescriptionSeq を返します。
	* @return prescriptionSeq
	*/
	public int getPrescriptionSeq(){
		return prescriptionSeq;
	}

	/**
	* プロパティー：prescriptionSeq を設定します。
	* @param param  int prescriptionSeq
	*/
	public void setPrescriptionSeq(int prescriptionSeq){
		this.prescriptionSeq = prescriptionSeq;
	}

	/**
	* プロパティー：zenkaiSeq を返します。
	* @return zenkaiSeq
	*/
	public int getZenkaiSeq(){
		return zenkaiSeq;
	}

	/**
	* プロパティー：zenkaiSeq を設定します。
	* @param param  int zenkaiSeq
	*/
	public void setZenkaiSeq(int zenkaiSeq){
		this.zenkaiSeq = zenkaiSeq;
	}

	/**
	* プロパティー：shinryouKbn を返します。
	* @return shinryouKbn
	*/
	public String getShinryouKbn(){
		return shinryouKbn;
	}

	/**
	* プロパティー：shinryouKbn を設定します。
	* @param param  String shinryouKbn
	*/
	public void setShinryouKbn(String shinryouKbn){
		this.shinryouKbn = shinryouKbn;
	}

	/**
	* プロパティー：prescriptionNissuuKaisuu を返します。
	* @return prescriptionNissuuKaisuu
	*/
	public int getPrescriptionNissuuKaisuu(){
		return prescriptionNissuuKaisuu;
	}

	/**
	* プロパティー：prescriptionNissuuKaisuu を設定します。
	* @param param  int prescriptionNissuuKaisuu
	*/
	public void setPrescriptionNissuuKaisuu(int prescriptionNissuuKaisuu){
		this.prescriptionNissuuKaisuu = prescriptionNissuuKaisuu;
	}

	/**
	* プロパティー：ingaiTouyakuKbn を返します。
	* @return ingaiTouyakuKbn
	*/
	public String getIngaiTouyakuKbn(){
		return ingaiTouyakuKbn;
	}

	/**
	* プロパティー：ingaiTouyakuKbn を設定します。
	* @param param  String ingaiTouyakuKbn
	*/
	public void setIngaiTouyakuKbn(String ingaiTouyakuKbn){
		this.ingaiTouyakuKbn = ingaiTouyakuKbn;
	}

	/**
	* プロパティー：touyoHouhouTouyakuKbn を返します。
	* @return touyoHouhouTouyakuKbn
	*/
	public String getTouyoHouhouTouyakuKbn(){
		return touyoHouhouTouyakuKbn;
	}

	/**
	* プロパティー：touyoHouhouTouyakuKbn を設定します。
	* @param param  String touyoHouhouTouyakuKbn
	*/
	public void setTouyoHouhouTouyakuKbn(String touyoHouhouTouyakuKbn){
		this.touyoHouhouTouyakuKbn = touyoHouhouTouyakuKbn;
	}

	/**
	* プロパティー：isRinjiTouyoTouyaku を返します。
	* @return isRinjiTouyoTouyaku
	*/
	public boolean getIsRinjiTouyoTouyaku(){
		return isRinjiTouyoTouyaku;
	}

	/**
	* プロパティー：isRinjiTouyoTouyaku を設定します。
	* @param param  boolean isRinjiTouyoTouyaku
	*/
	public void setIsRinjiTouyoTouyaku(boolean isRinjiTouyoTouyaku){
		this.isRinjiTouyoTouyaku = isRinjiTouyoTouyaku;
	}

	/**
	* プロパティー：isKongouTouyaku を返します。
	* @return isKongouTouyaku
	*/
	public boolean getIsKongouTouyaku(){
		return isKongouTouyaku;
	}

	/**
	* プロパティー：isKongouTouyaku を設定します。
	* @param param  boolean isKongouTouyaku
	*/
	public void setIsKongouTouyaku(boolean isKongouTouyaku){
		this.isKongouTouyaku = isKongouTouyaku;
	}

	/**
	* プロパティー：isIppoukaTaishougai を返します。
	* @return isIppoukaTaishougai
	*/
	public boolean getIsIppoukaTaishougai(){
		return isIppoukaTaishougai;
	}

	/**
	* プロパティー：isIppoukaTaishougai を設定します。
	* @param param  boolean isIppoukaTaishougai
	*/
	public void setIsIppoukaTaishougai(boolean isIppoukaTaishougai){
		this.isIppoukaTaishougai = isIppoukaTaishougai;
	}

	/**
	* プロパティー：isHoukatsuTaishougai を返します。
	* @return isHoukatsuTaishougai
	*/
	public boolean getIsHoukatsuTaishougai(){
		return isHoukatsuTaishougai;
	}

	/**
	* プロパティー：isHoukatsuTaishougai を設定します。
	* @param param  boolean isHoukatsuTaishougai
	*/
	public void setIsHoukatsuTaishougai(boolean isHoukatsuTaishougai){
		this.isHoukatsuTaishougai = isHoukatsuTaishougai;
	}

	/**
	* プロパティー：isMarumeTaishougai を返します。
	* @return isMarumeTaishougai
	*/
	public boolean getIsMarumeTaishougai(){
		return isMarumeTaishougai;
	}

	/**
	* プロパティー：isMarumeTaishougai を設定します。
	* @param param  boolean isMarumeTaishougai
	*/
	public void setIsMarumeTaishougai(boolean isMarumeTaishougai){
		this.isMarumeTaishougai = isMarumeTaishougai;
	}

	/**
	* プロパティー：bunkatsuCommentTouyaku を返します。
	* @return bunkatsuCommentTouyaku
	*/
	public String getBunkatsuCommentTouyaku(){
		return bunkatsuCommentTouyaku;
	}

	/**
	* プロパティー：bunkatsuCommentTouyaku を設定します。
	* @param param  String bunkatsuCommentTouyaku
	*/
	public void setBunkatsuCommentTouyaku(String bunkatsuCommentTouyaku){
		this.bunkatsuCommentTouyaku = bunkatsuCommentTouyaku;
	}

	/**
	* プロパティー：setName を返します。
	* @return setName
	*/
	public String getSetName(){
		return setName;
	}

	/**
	* プロパティー：setName を設定します。
	* @param param  String setName
	*/
	public void setSetName(String setName){
		this.setName = setName;
	}

	/**
	* プロパティー：setChangeKbn を返します。
	* @return setChangeKbn
	*/
	public String getSetChangeKbn(){
		return setChangeKbn;
	}

	/**
	* プロパティー：setChangeKbn を設定します。
	* @param param  String setChangeKbn
	*/
	public void setSetChangeKbn(String setChangeKbn){
		this.setChangeKbn = setChangeKbn;
	}

	/**
	* プロパティー：setShikibetsuKbn を返します。
	* @return setShikibetsuKbn
	*/
	public String getSetShikibetsuKbn(){
		return setShikibetsuKbn;
	}

	/**
	* プロパティー：setShikibetsuKbn を設定します。
	* @param param  String setShikibetsuKbn
	*/
	public void setSetShikibetsuKbn(String setShikibetsuKbn){
		this.setShikibetsuKbn = setShikibetsuKbn;
	}

	/**
	* プロパティー：setJihiCode を返します。
	* @return setJihiCode
	*/
	public String getSetJihiCode(){
		return setJihiCode;
	}

	/**
	* プロパティー：setJihiCode を設定します。
	* @param param  String setJihiCode
	*/
	public void setSetJihiCode(String setJihiCode){
		this.setJihiCode = setJihiCode;
	}

	/**
	* プロパティー：zenkaiPrescriptionSeq を返します。
	* @return zenkaiPrescriptionSeq
	*/
	public int getZenkaiPrescriptionSeq(){
		return zenkaiPrescriptionSeq;
	}

	/**
	* プロパティー：zenkaiPrescriptionSeq を設定します。
	* @param param  int zenkaiPrescriptionSeq
	*/
	public void setZenkaiPrescriptionSeq(int zenkaiPrescriptionSeq){
		this.zenkaiPrescriptionSeq = zenkaiPrescriptionSeq;
	}

	/**
	* プロパティー：setCode を返します。
	* @return setCode
	*/
	public String getSetCode(){
		return setCode;
	}

	/**
	* プロパティー：setCode を設定します。
	* @param param  String setCode
	*/
	public void setSetCode(String setCode){
		this.setCode = setCode;
	}

	/**
	* プロパティー：setKbn を返します。
	* @return setKbn
	*/
	public String getSetKbn(){
		return setKbn;
	}

	/**
	* プロパティー：setKbn を設定します。
	* @param param  String setKbn
	*/
	public void setSetKbn(String setKbn){
		this.setKbn = setKbn;
	}
}
