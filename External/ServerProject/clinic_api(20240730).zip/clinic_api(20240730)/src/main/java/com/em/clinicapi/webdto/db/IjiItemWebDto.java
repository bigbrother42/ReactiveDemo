package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class IjiItemWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ shinryouDate */
	private java.sql.Date  shinryouDate = null;

	/**  プロパティ raiinKaisuu */
	private int  raiinKaisuu = 0;

	/**  プロパティ prescriptionSeq */
	private int  prescriptionSeq = 0;

	/**  プロパティ subSeq */
	private int  subSeq = 0;

	/**  プロパティ itemSeq */
	private int  itemSeq = 0;

	/**  プロパティ masterKbn */
	private String  masterKbn = null;

	/**  プロパティ masterType */
	private String  masterType = null;

	/**  プロパティ masterCode */
	private String  masterCode = null;

	/**  プロパティ productNameCode */
	private String  productNameCode = null;

	/**  プロパティ ippanNameCode */
	private String  ippanNameCode = null;

	/**  プロパティ codehyouNoAlphabetPart */
	private String  codehyouNoAlphabetPart = null;

	/**  プロパティ codehyouNoKbnNo */
	private String  codehyouNoKbnNo = null;

	/**  プロパティ codehyouNoEdabanNo */
	private String  codehyouNoEdabanNo = null;

	/**  プロパティ codehyouNoKoubanNo */
	private String  codehyouNoKoubanNo = null;

	/**  プロパティ itemName */
	private String  itemName = null;

	/**  プロパティ suuryouInputKbn */
	private String  suuryouInputKbn = null;

	/**  プロパティ suuryouUsedQty */
	private java.math.BigDecimal  suuryouUsedQty = null;

	/**  プロパティ unitCode */
	private String  unitCode = null;

	/**  プロパティ kansanSeq */
	private int  kansanSeq = 0;

	/**  プロパティ kansanInfo */
	private String  kansanInfo = null;

	/**  プロパティ comment */
	private String  comment = null;

	/**  プロパティ commentKbn */
	private String  commentKbn = null;

	/**  プロパティ tooltip */
	private String  tooltip = null;

	/**  プロパティ jidouSanteiKbn */
	private String  jidouSanteiKbn = null;

	/**  プロパティ yakuzaiBunruiNo */
	private String  yakuzaiBunruiNo = null;

	/**  プロパティ isHoukatsuTaishougai */
	private boolean  isHoukatsuTaishougai;

	/**  プロパティ isMarumeTaishougai */
	private boolean  isMarumeTaishougai;

	/**  プロパティ yakuzaiStatusTouyakuKbn */
	private String  yakuzaiStatusTouyakuKbn = null;

	/**  プロパティ zengenKakujitsuConfigTouyakuKbn */
	private String  zengenKakujitsuConfigTouyakuKbn = null;

	/**  プロパティ shinryoukaCode */
	private String  shinryoukaCode = null;

	/**  プロパティ doctorCode */
	private String  doctorCode = null;

	/**  プロパティ futanKbn */
	private String  futanKbn = null;

	/**  プロパティ fukushiFutanKbn */
	private String  fukushiFutanKbn = null;

	/**  プロパティ isShochiTenkiTaishou */
	private boolean  isShochiTenkiTaishou;

	/**  プロパティ jihiBunruiNo */
	private String  jihiBunruiNo = null;

	/**  プロパティ jihiKingaku */
	private java.math.BigDecimal  jihiKingaku = null;

	/**  プロパティ commentTenkiKbn */
	private String  commentTenkiKbn = null;

	/**  プロパティ isKanrenComment */
	private boolean  isKanrenComment;

	/**  プロパティ shochiPrescription */
	private String  shochiPrescription = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public IjiItemWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：shinryouDate を返します。
	* @return shinryouDate
	*/
	public java.sql.Date getShinryouDate(){
		return shinryouDate;
	}

	/**
	* プロパティー：shinryouDate を設定します。
	* @param param  java.sql.Date shinryouDate
	*/
	public void setShinryouDate(java.sql.Date shinryouDate){
		this.shinryouDate = shinryouDate;
	}

	/**
	* プロパティー：raiinKaisuu を返します。
	* @return raiinKaisuu
	*/
	public int getRaiinKaisuu(){
		return raiinKaisuu;
	}

	/**
	* プロパティー：raiinKaisuu を設定します。
	* @param param  int raiinKaisuu
	*/
	public void setRaiinKaisuu(int raiinKaisuu){
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	* プロパティー：prescriptionSeq を返します。
	* @return prescriptionSeq
	*/
	public int getPrescriptionSeq(){
		return prescriptionSeq;
	}

	/**
	* プロパティー：prescriptionSeq を設定します。
	* @param param  int prescriptionSeq
	*/
	public void setPrescriptionSeq(int prescriptionSeq){
		this.prescriptionSeq = prescriptionSeq;
	}

	/**
	* プロパティー：subSeq を返します。
	* @return subSeq
	*/
	public int getSubSeq(){
		return subSeq;
	}

	/**
	* プロパティー：subSeq を設定します。
	* @param param  int subSeq
	*/
	public void setSubSeq(int subSeq){
		this.subSeq = subSeq;
	}

	/**
	* プロパティー：itemSeq を返します。
	* @return itemSeq
	*/
	public int getItemSeq(){
		return itemSeq;
	}

	/**
	* プロパティー：itemSeq を設定します。
	* @param param  int itemSeq
	*/
	public void setItemSeq(int itemSeq){
		this.itemSeq = itemSeq;
	}

	/**
	* プロパティー：masterKbn を返します。
	* @return masterKbn
	*/
	public String getMasterKbn(){
		return masterKbn;
	}

	/**
	* プロパティー：masterKbn を設定します。
	* @param param  String masterKbn
	*/
	public void setMasterKbn(String masterKbn){
		this.masterKbn = masterKbn;
	}

	/**
	* プロパティー：masterType を返します。
	* @return masterType
	*/
	public String getMasterType(){
		return masterType;
	}

	/**
	* プロパティー：masterType を設定します。
	* @param param  String masterType
	*/
	public void setMasterType(String masterType){
		this.masterType = masterType;
	}

	/**
	* プロパティー：masterCode を返します。
	* @return masterCode
	*/
	public String getMasterCode(){
		return masterCode;
	}

	/**
	* プロパティー：masterCode を設定します。
	* @param param  String masterCode
	*/
	public void setMasterCode(String masterCode){
		this.masterCode = masterCode;
	}

	/**
	* プロパティー：productNameCode を返します。
	* @return productNameCode
	*/
	public String getProductNameCode(){
		return productNameCode;
	}

	/**
	* プロパティー：productNameCode を設定します。
	* @param param  String productNameCode
	*/
	public void setProductNameCode(String productNameCode){
		this.productNameCode = productNameCode;
	}

	/**
	* プロパティー：ippanNameCode を返します。
	* @return ippanNameCode
	*/
	public String getIppanNameCode(){
		return ippanNameCode;
	}

	/**
	* プロパティー：ippanNameCode を設定します。
	* @param param  String ippanNameCode
	*/
	public void setIppanNameCode(String ippanNameCode){
		this.ippanNameCode = ippanNameCode;
	}

	/**
	* プロパティー：codehyouNoAlphabetPart を返します。
	* @return codehyouNoAlphabetPart
	*/
	public String getCodehyouNoAlphabetPart(){
		return codehyouNoAlphabetPart;
	}

	/**
	* プロパティー：codehyouNoAlphabetPart を設定します。
	* @param param  String codehyouNoAlphabetPart
	*/
	public void setCodehyouNoAlphabetPart(String codehyouNoAlphabetPart){
		this.codehyouNoAlphabetPart = codehyouNoAlphabetPart;
	}

	/**
	* プロパティー：codehyouNoKbnNo を返します。
	* @return codehyouNoKbnNo
	*/
	public String getCodehyouNoKbnNo(){
		return codehyouNoKbnNo;
	}

	/**
	* プロパティー：codehyouNoKbnNo を設定します。
	* @param param  String codehyouNoKbnNo
	*/
	public void setCodehyouNoKbnNo(String codehyouNoKbnNo){
		this.codehyouNoKbnNo = codehyouNoKbnNo;
	}

	/**
	* プロパティー：codehyouNoEdabanNo を返します。
	* @return codehyouNoEdabanNo
	*/
	public String getCodehyouNoEdabanNo(){
		return codehyouNoEdabanNo;
	}

	/**
	* プロパティー：codehyouNoEdabanNo を設定します。
	* @param param  String codehyouNoEdabanNo
	*/
	public void setCodehyouNoEdabanNo(String codehyouNoEdabanNo){
		this.codehyouNoEdabanNo = codehyouNoEdabanNo;
	}

	/**
	* プロパティー：codehyouNoKoubanNo を返します。
	* @return codehyouNoKoubanNo
	*/
	public String getCodehyouNoKoubanNo(){
		return codehyouNoKoubanNo;
	}

	/**
	* プロパティー：codehyouNoKoubanNo を設定します。
	* @param param  String codehyouNoKoubanNo
	*/
	public void setCodehyouNoKoubanNo(String codehyouNoKoubanNo){
		this.codehyouNoKoubanNo = codehyouNoKoubanNo;
	}

	/**
	* プロパティー：itemName を返します。
	* @return itemName
	*/
	public String getItemName(){
		return itemName;
	}

	/**
	* プロパティー：itemName を設定します。
	* @param param  String itemName
	*/
	public void setItemName(String itemName){
		this.itemName = itemName;
	}

	/**
	* プロパティー：suuryouInputKbn を返します。
	* @return suuryouInputKbn
	*/
	public String getSuuryouInputKbn(){
		return suuryouInputKbn;
	}

	/**
	* プロパティー：suuryouInputKbn を設定します。
	* @param param  String suuryouInputKbn
	*/
	public void setSuuryouInputKbn(String suuryouInputKbn){
		this.suuryouInputKbn = suuryouInputKbn;
	}

	/**
	* プロパティー：suuryouUsedQty を返します。
	* @return suuryouUsedQty
	*/
	public java.math.BigDecimal getSuuryouUsedQty(){
		return suuryouUsedQty;
	}

	/**
	* プロパティー：suuryouUsedQty を設定します。
	* @param param  java.math.BigDecimal suuryouUsedQty
	*/
	public void setSuuryouUsedQty(java.math.BigDecimal suuryouUsedQty){
		this.suuryouUsedQty = suuryouUsedQty;
	}

	/**
	* プロパティー：unitCode を返します。
	* @return unitCode
	*/
	public String getUnitCode(){
		return unitCode;
	}

	/**
	* プロパティー：unitCode を設定します。
	* @param param  String unitCode
	*/
	public void setUnitCode(String unitCode){
		this.unitCode = unitCode;
	}

	/**
	* プロパティー：kansanSeq を返します。
	* @return kansanSeq
	*/
	public int getKansanSeq(){
		return kansanSeq;
	}

	/**
	* プロパティー：kansanSeq を設定します。
	* @param param  int kansanSeq
	*/
	public void setKansanSeq(int kansanSeq){
		this.kansanSeq = kansanSeq;
	}

	/**
	* プロパティー：kansanInfo を返します。
	* @return kansanInfo
	*/
	public String getKansanInfo(){
		return kansanInfo;
	}

	/**
	* プロパティー：kansanInfo を設定します。
	* @param param  String kansanInfo
	*/
	public void setKansanInfo(String kansanInfo){
		this.kansanInfo = kansanInfo;
	}

	/**
	* プロパティー：comment を返します。
	* @return comment
	*/
	public String getComment(){
		return comment;
	}

	/**
	* プロパティー：comment を設定します。
	* @param param  String comment
	*/
	public void setComment(String comment){
		this.comment = comment;
	}

	/**
	* プロパティー：commentKbn を返します。
	* @return commentKbn
	*/
	public String getCommentKbn(){
		return commentKbn;
	}

	/**
	* プロパティー：commentKbn を設定します。
	* @param param  String commentKbn
	*/
	public void setCommentKbn(String commentKbn){
		this.commentKbn = commentKbn;
	}

	/**
	* プロパティー：tooltip を返します。
	* @return tooltip
	*/
	public String getTooltip(){
		return tooltip;
	}

	/**
	* プロパティー：tooltip を設定します。
	* @param param  String tooltip
	*/
	public void setTooltip(String tooltip){
		this.tooltip = tooltip;
	}

	/**
	* プロパティー：jidouSanteiKbn を返します。
	* @return jidouSanteiKbn
	*/
	public String getJidouSanteiKbn(){
		return jidouSanteiKbn;
	}

	/**
	* プロパティー：jidouSanteiKbn を設定します。
	* @param param  String jidouSanteiKbn
	*/
	public void setJidouSanteiKbn(String jidouSanteiKbn){
		this.jidouSanteiKbn = jidouSanteiKbn;
	}

	/**
	* プロパティー：yakuzaiBunruiNo を返します。
	* @return yakuzaiBunruiNo
	*/
	public String getYakuzaiBunruiNo(){
		return yakuzaiBunruiNo;
	}

	/**
	* プロパティー：yakuzaiBunruiNo を設定します。
	* @param param  String yakuzaiBunruiNo
	*/
	public void setYakuzaiBunruiNo(String yakuzaiBunruiNo){
		this.yakuzaiBunruiNo = yakuzaiBunruiNo;
	}

	/**
	* プロパティー：isHoukatsuTaishougai を返します。
	* @return isHoukatsuTaishougai
	*/
	public boolean getIsHoukatsuTaishougai(){
		return isHoukatsuTaishougai;
	}

	/**
	* プロパティー：isHoukatsuTaishougai を設定します。
	* @param param  boolean isHoukatsuTaishougai
	*/
	public void setIsHoukatsuTaishougai(boolean isHoukatsuTaishougai){
		this.isHoukatsuTaishougai = isHoukatsuTaishougai;
	}

	/**
	* プロパティー：isMarumeTaishougai を返します。
	* @return isMarumeTaishougai
	*/
	public boolean getIsMarumeTaishougai(){
		return isMarumeTaishougai;
	}

	/**
	* プロパティー：isMarumeTaishougai を設定します。
	* @param param  boolean isMarumeTaishougai
	*/
	public void setIsMarumeTaishougai(boolean isMarumeTaishougai){
		this.isMarumeTaishougai = isMarumeTaishougai;
	}

	/**
	* プロパティー：yakuzaiStatusTouyakuKbn を返します。
	* @return yakuzaiStatusTouyakuKbn
	*/
	public String getYakuzaiStatusTouyakuKbn(){
		return yakuzaiStatusTouyakuKbn;
	}

	/**
	* プロパティー：yakuzaiStatusTouyakuKbn を設定します。
	* @param param  String yakuzaiStatusTouyakuKbn
	*/
	public void setYakuzaiStatusTouyakuKbn(String yakuzaiStatusTouyakuKbn){
		this.yakuzaiStatusTouyakuKbn = yakuzaiStatusTouyakuKbn;
	}

	/**
	* プロパティー：zengenKakujitsuConfigTouyakuKbn を返します。
	* @return zengenKakujitsuConfigTouyakuKbn
	*/
	public String getZengenKakujitsuConfigTouyakuKbn(){
		return zengenKakujitsuConfigTouyakuKbn;
	}

	/**
	* プロパティー：zengenKakujitsuConfigTouyakuKbn を設定します。
	* @param param  String zengenKakujitsuConfigTouyakuKbn
	*/
	public void setZengenKakujitsuConfigTouyakuKbn(String zengenKakujitsuConfigTouyakuKbn){
		this.zengenKakujitsuConfigTouyakuKbn = zengenKakujitsuConfigTouyakuKbn;
	}

	/**
	* プロパティー：shinryoukaCode を返します。
	* @return shinryoukaCode
	*/
	public String getShinryoukaCode(){
		return shinryoukaCode;
	}

	/**
	* プロパティー：shinryoukaCode を設定します。
	* @param param  String shinryoukaCode
	*/
	public void setShinryoukaCode(String shinryoukaCode){
		this.shinryoukaCode = shinryoukaCode;
	}

	/**
	* プロパティー：doctorCode を返します。
	* @return doctorCode
	*/
	public String getDoctorCode(){
		return doctorCode;
	}

	/**
	* プロパティー：doctorCode を設定します。
	* @param param  String doctorCode
	*/
	public void setDoctorCode(String doctorCode){
		this.doctorCode = doctorCode;
	}

	/**
	* プロパティー：futanKbn を返します。
	* @return futanKbn
	*/
	public String getFutanKbn(){
		return futanKbn;
	}

	/**
	* プロパティー：futanKbn を設定します。
	* @param param  String futanKbn
	*/
	public void setFutanKbn(String futanKbn){
		this.futanKbn = futanKbn;
	}

	/**
	* プロパティー：fukushiFutanKbn を返します。
	* @return fukushiFutanKbn
	*/
	public String getFukushiFutanKbn(){
		return fukushiFutanKbn;
	}

	/**
	* プロパティー：fukushiFutanKbn を設定します。
	* @param param  String fukushiFutanKbn
	*/
	public void setFukushiFutanKbn(String fukushiFutanKbn){
		this.fukushiFutanKbn = fukushiFutanKbn;
	}

	/**
	* プロパティー：isShochiTenkiTaishou を返します。
	* @return isShochiTenkiTaishou
	*/
	public boolean getIsShochiTenkiTaishou(){
		return isShochiTenkiTaishou;
	}

	/**
	* プロパティー：isShochiTenkiTaishou を設定します。
	* @param param  boolean isShochiTenkiTaishou
	*/
	public void setIsShochiTenkiTaishou(boolean isShochiTenkiTaishou){
		this.isShochiTenkiTaishou = isShochiTenkiTaishou;
	}

	/**
	* プロパティー：jihiBunruiNo を返します。
	* @return jihiBunruiNo
	*/
	public String getJihiBunruiNo(){
		return jihiBunruiNo;
	}

	/**
	* プロパティー：jihiBunruiNo を設定します。
	* @param param  String jihiBunruiNo
	*/
	public void setJihiBunruiNo(String jihiBunruiNo){
		this.jihiBunruiNo = jihiBunruiNo;
	}

	/**
	* プロパティー：jihiKingaku を返します。
	* @return jihiKingaku
	*/
	public java.math.BigDecimal getJihiKingaku(){
		return jihiKingaku;
	}

	/**
	* プロパティー：jihiKingaku を設定します。
	* @param param  java.math.BigDecimal jihiKingaku
	*/
	public void setJihiKingaku(java.math.BigDecimal jihiKingaku){
		this.jihiKingaku = jihiKingaku;
	}

	/**
	* プロパティー：commentTenkiKbn を返します。
	* @return commentTenkiKbn
	*/
	public String getCommentTenkiKbn(){
		return commentTenkiKbn;
	}

	/**
	* プロパティー：commentTenkiKbn を設定します。
	* @param param  String commentTenkiKbn
	*/
	public void setCommentTenkiKbn(String commentTenkiKbn){
		this.commentTenkiKbn = commentTenkiKbn;
	}

	/**
	* プロパティー：isKanrenComment を返します。
	* @return isKanrenComment
	*/
	public boolean getIsKanrenComment(){
		return isKanrenComment;
	}

	/**
	* プロパティー：isKanrenComment を設定します。
	* @param param  boolean isKanrenComment
	*/
	public void setIsKanrenComment(boolean isKanrenComment){
		this.isKanrenComment = isKanrenComment;
	}

	/**
	* プロパティー：shochiPrescription を返します。
	* @return shochiPrescription
	*/
	public String getShochiPrescription(){
		return shochiPrescription;
	}

	/**
	* プロパティー：shochiPrescription を設定します。
	* @param param  String shochiPrescription
	*/
	public void setShochiPrescription(String shochiPrescription){
		this.shochiPrescription = shochiPrescription;
	}
}
