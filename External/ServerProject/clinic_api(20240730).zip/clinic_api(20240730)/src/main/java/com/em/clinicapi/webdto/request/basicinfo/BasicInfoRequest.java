package com.em.clinicapi.webdto.request.basicinfo;


import com.em.clinicapi.webdto.base.RequestBase;
import com.em.clinicapi.webdto.request.base.RequestWebDtoBase;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : BasicInfoWebDto クラス <br/>
 * 項目：  <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class BasicInfoRequest extends RequestWebDtoBase {

    /**
     * 項目： グループSEQ <br/>
     * 説明： <br/>
     *       グループSEQ <br/>
     */
    @JsonProperty("Group_ID")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    private String groupId;

    /**
     * 項目： 顧客SEQ <br/>
     * 説明： <br/>
     *       顧客SEQ <br/>
     */
    @JsonProperty("Customer_ID")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    private String customerId;

    /**
     * 項目： レクエスト区分 <br/>
     * 説明： <br/>
     *       ”02"(ドクター)、”03"(職員) <br/>
     */
    @JsonProperty("Request_Number")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    private String requestNumber;

    /**
     * 項目： 日付 <br/>
     * 説明： <br/>
     *       書式：yyyy-MM-dd <br/>
     */
    @JsonProperty("Base_Date")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    private String baseDate;

    /**
     * グループSEQを返事します。
     * @return グループSEQの値
     */
    @JsonProperty("Group_ID")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public String getGroupId() {
        return groupId;
    }

    /**
     * グループSEQを設定します。
     * @param groupId グループSEQ
     */
    @JsonProperty("Group_ID")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    /**
     * 顧客SEQを返事します。
     * @return 顧客SEQの値
     */
    @JsonProperty("Customer_ID")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public String getCustomerId() {
        return customerId;
    }

    /**
     * 顧客SEQを設定します。
     * @param customerId 顧客SEQ
     */
    @JsonProperty("Customer_ID")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    /**
     * レクエスト区分を返事します。
     * @return レクエスト区分の値
     */
    @JsonProperty("Request_Number")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public String getRequestNumber() {
        return requestNumber;
    }

    /**
     * レクエスト区分を設定します。
     * @param requestNumber レクエスト区分
     */
    @JsonProperty("Request_Number")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    /**
     * 日付を返事します。
     * @return 日付の値
     */
    @JsonProperty("Base_Date")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public String getBaseDate() {
        return baseDate;
    }

    /**
     * 日付を設定します。
     * @param baseDate 日付
     */
    @JsonProperty("Base_Date")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    public void setBaseDate(String baseDate) {
        this.baseDate = baseDate;
    }

}