package com.em.clinicapi.common.db.aspect;

import com.em.clinicapi.common.cache.DbMapperContextHolder;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(Ordered.LOWEST_PRECEDENCE - 1)
public class GroupReplicationAdvice {

    /**
     * get class name of executing method(service)
     * @param joinPoint
     */
    @Before("(execution(* com.em.clinicapi.service.*.*(..)) || "
            + "execution(* com.em.clinicapi.*.service.*.*(..)) || "
            + "execution(* com.em.clinicapi.service.*.*.*(..)) || "
            + "execution(* com.em.clinicapi.*.service.*.*.*(..))) &&"
            + "!within(is(FinalType))")
    public void set(JoinPoint joinPoint) {
        DbMapperContextHolder.set(joinPoint.getSignature().getDeclaringTypeName());
    }

    @After("(execution(* com.em.clinicapi.service.*.*(..)) || "
            + "execution(* com.em.clinicapi.*.service.*.*(..)) || "
            + "execution(* com.em.clinicapi.service.*.*.*(..)) || "
            + "execution(* com.em.clinicapi.*.service.*.*.*(..))) &&"
            + "!within(is(FinalType))")
    public void clear() {
        DbMapperContextHolder.clear();
    }

}
