package com.em.clinicapi.mapper;

import com.em.clinicapi.webdto.db.*;
import com.em.clinicapi.webdto.response.patient.HealthInsuranceInformation;
import com.em.clinicapi.webdto.response.patient.HomeAddressInformation;
import com.em.clinicapi.webdto.response.patient.PatientInformation;
import com.em.clinicapi.webdto.response.patient.PrefectureInformation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.util.List;

@Mapper
public interface PatientInfoMapper {

    public List<PatientWebDto> selectPatientWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                       @Param("patientSeq") Integer patientSeq);

    /**
     * 患者Seqによって患者情報を取得
     * @param customerSeq
     * @param patientSeq
     * @return
     */
    public PatientInformation selectPatientInfo(@Param("customerSeq") Integer customerSeq,
                                                @Param("patientSeq") Integer patientSeq);

    /**
     *
     * @param customerSeq
     * @param patientSeq
     * @return
     */
    public List<PrefectureInformation> selectPrefectureInformation(@Param("customerSeq") Integer customerSeq,
                                                                   @Param("patientSeq") Integer patientSeq);

    public KisoMonshinWebDto selectKisoMonshinWebDto(@Param("customerSeq") Integer customerSeq,
                                                     @Param("patientSeq") Integer patientSeq);

    public PatientJitakuWebDto selectPatientJitakuWebDto(@Param("customerSeq") Integer customerSeq,
                                                         @Param("patientSeq") Integer patientSeq);

    public PatientRenrakusakiWebDto selectPatientRenrakusakiWebDto(@Param("customerSeq") Integer customerSeq,
                                                                   @Param("patientSeq") Integer patientSeq);

    public List<UcRecHokenWebDto> selectUcRecHokenWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                             @Param("patientSeq") String patientSeq);

    public List<UcRecDegreeWebDto> selectUcRecDegreeWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                               @Param("patientSeq") String patientSeq);

    public List<ShuhokenWebDto> selectShuhokenWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                         @Param("patientSeq") Integer patientSeq);

    public List<ShuhokenRekiWebDto> selectShuhokenRekiWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                                 @Param("patientSeq") Integer patientSeq);

    public List<FukuhokenWebDto> selectFukuhokenWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                           @Param("patientSeq") Integer patientSeq);

    public List<FukuhokenRekiWebDto> selectFukuhokenRekiWebDtoList(@Param("customerSeq") Integer customerSeq,
                                                                   @Param("patientSeq") Integer patientSeq);

    public List<KouhiMWebDto> selectKouhiMWebDtoList(@Param("houbetsuNo") String houbetsuNo,
                                                     @Param("seidoKbn") String seidoKbn);

    public RousaiHokenWebDto selectRousaiHokenWebDto(@Param("customerSeq") Integer customerSeq,
                                                     @Param("patientSeq") Integer patientSeq,
                                                     @Param("hokenSeq") Integer hokenSeq);

    public JigyoushoMWebDto selectJigyoushoMWebDto(@Param("customerSeq") Integer customerSeq,
                                                   @Param("jigyoushoSeq") Integer jigyoushoSeq);

    public String selectPatientSystemConfigContent(@Param("customerSeq") Integer customerSeq,
                                                   @Param("patientSeq") Integer patientSeq,
                                                   @Param("kinouNo") String kinouNo,
                                                   @Param("itemNo") String itemNo);

    public boolean checkPatientPregnant(@Param("customerSeq") Integer customerSeq,
                                        @Param("patientSeq") Integer patientSeq);

    public List<EmsRousaiAfterCareShoubyouCodeMWebDto> selectEmsRousaiAfterCareShoubyouCodeMDtos(@Param("baseDate") Date baseDate,
                                                                                                 @Param("shoubyouCode") String shoubyouCode);

    public List<String> selectPatientShoubyouNameList(@Param("customerSeq") Integer customerSeq,
                                                      @Param("patientSeq") Integer patientSeq);
}
