package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : PrefectureInformation クラス <br/>
 * 項目： Prefecture_Information <br/>
 * 説明： <br/>
 *       所在地都道府県情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class PrefectureInformation extends ResponseWebDtoBase {

	/**
	 * 項目： P_WholeName <br/>
	 * 説明： <br/>
	 *       都道府県名 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pWholeName;
	/**
	 * 項目： P_Class <br/>
	 * 説明： <br/>
	 *       都道府県コード <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pClass;
	/**
	 * 項目： P_Class_Name <br/>
	 * 説明： <br/>
	 *       都道府県の区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pClassName;
	/**
	 * P_WholeNameを返事します。
	 * @return P_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPWholeName() {
		return pWholeName;
	}

	/**
	 * P_WholeNameを設定します。
	 * @param pWholeName P_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPWholeName(String pWholeName) {
		this.pWholeName = pWholeName;
	}

	/**
	 * P_Classを返事します。
	 * @return P_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPClass() {
		return pClass;
	}

	/**
	 * P_Classを設定します。
	 * @param pClass P_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPClass(String pClass) {
		this.pClass = pClass;
	}

	/**
	 * P_Class_Nameを返事します。
	 * @return P_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPClassName() {
		return pClassName;
	}

	/**
	 * P_Class_Nameを設定します。
	 * @param pClassName P_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("P_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPClassName(String pClassName) {
		this.pClassName = pClassName;
	}

}