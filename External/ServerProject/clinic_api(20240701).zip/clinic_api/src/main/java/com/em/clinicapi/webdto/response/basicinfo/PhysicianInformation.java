package com.em.clinicapi.webdto.response.basicinfo;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public class PhysicianInformation extends ResponseWebDtoBase {
    /**
     * 項目： user_seq <br/>
     * 説明： <br/>
     *       user_seqを設定 <br/>
     */
    @JsonProperty("Code")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String code;

    /**
     * 項目： 漢字氏名 <br/>
     * 説明： <br/>
     *       登録ユーザーの漢字氏名を返却 <br/>
     */
    @JsonProperty("WholeName")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String wholeName;

    /**
     * 項目： カナ氏名 <br/>
     * 説明： <br/>
     *       登録ユーザーのカナ氏名を返却 <br/>
     */
    @JsonProperty("WholeName_inKana")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String wholeNameInKana;

    /**
     * 項目： Physician_Permission_Id <br/>
     */
    @JsonProperty("Physician_Permission_Id")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String physicianPermissionId;

    /**
     * 項目： 麻薬免許 <br/>
     * 説明： <br/>
     *       麻薬免許がある場合はその番号を返却 <br/>
     */
    @JsonProperty("Drug_Permission_Id")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String drugPermissionId;

    /**
     * 項目： Department_Code1 <br/>
     */
    @JsonProperty("Department_Code1")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.ALWAYS)
    private String departmentCode1;

    /**
     * 項目： Department_Code2 <br/>
     */
    @JsonProperty("Department_Code2")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String departmentCode2;

    /**
     * 項目： Department_Code3 <br/>
     */
    @JsonProperty("Department_Code3")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String departmentCode3;

    /**
     * 項目： Department_Code4 <br/>
     */
    @JsonProperty("Department_Code4")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String departmentCode4;

    /**
     * 項目： Department_Code5 <br/>
     */
    @JsonProperty("Department_Code5")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String departmentCode5;

    /**
     * user_seqを返事します。
     * @return user_seqの値
     */
    @JsonProperty("Code")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getCode() {
        return code;
    }

    /**
     * user_seqを設定します。
     * @param code user_seq
     */
    @JsonProperty("Code")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * 漢字氏名を返事します。
     * @return 漢字氏名の値
     */
    @JsonProperty("WholeName")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getWholeName() {
        return wholeName;
    }

    /**
     * 漢字氏名を設定します。
     * @param wholeName 漢字氏名
     */
    @JsonProperty("WholeName")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setWholeName(String wholeName) {
        this.wholeName = wholeName;
    }

    /**
     * カナ氏名を返事します。
     * @return カナ氏名の値
     */
    @JsonProperty("WholeName_inKana")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getWholeNameInKana() {
        return wholeNameInKana;
    }

    /**
     * カナ氏名を設定します。
     * @param wholeNameInKana カナ氏名
     */
    @JsonProperty("WholeName_inKana")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setWholeNameInKana(String wholeNameInKana) {
        this.wholeNameInKana = wholeNameInKana;
    }

    /**
     * Physician_Permission_Idを返事します。
     * @return Physician_Permission_Idの値
     */
    @JsonProperty("Physician_Permission_Id")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getPhysicianPermissionId() {
        return physicianPermissionId;
    }

    /**
     * Physician_Permission_Idを設定します。
     * @param physicianPermissionId Physician_Permission_Id
     */
    @JsonProperty("Physician_Permission_Id")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setPhysicianPermissionId(String physicianPermissionId) {
        this.physicianPermissionId = physicianPermissionId;
    }

    /**
     * 麻薬免許を返事します。
     * @return 麻薬免許の値
     */
    @JsonProperty("Drug_Permission_Id")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getDrugPermissionId() {
        return drugPermissionId;
    }

    /**
     * 麻薬免許を設定します。
     * @param drugPermissionId 麻薬免許
     */
    @JsonProperty("Drug_Permission_Id")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setDrugPermissionId(String drugPermissionId) {
        this.drugPermissionId = drugPermissionId;
    }

    /**
     * Department_Code1を返事します。
     * @return Department_Code1の値
     */
    @JsonProperty("Department_Code1")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.ALWAYS)
    public String getDepartmentCode1() {
        return departmentCode1;
    }

    /**
     * Department_Code1を設定します。
     * @param departmentCode1 Department_Code1
     */
    @JsonProperty("Department_Code1")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.ALWAYS)
    public void setDepartmentCode1(String departmentCode1) {
        this.departmentCode1 = departmentCode1;
    }

    /**
     * Department_Code2を返事します。
     * @return Department_Code2の値
     */
    @JsonProperty("Department_Code2")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getDepartmentCode2() {
        return departmentCode2;
    }

    /**
     * Department_Code2を設定します。
     * @param departmentCode2 Department_Code2
     */
    @JsonProperty("Department_Code2")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setDepartmentCode2(String departmentCode2) {
        this.departmentCode2 = departmentCode2;
    }

    /**
     * Department_Code3を返事します。
     * @return Department_Code3の値
     */
    @JsonProperty("Department_Code3")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getDepartmentCode3() {
        return departmentCode3;
    }

    /**
     * Department_Code3を設定します。
     * @param departmentCode3 Department_Code3
     */
    @JsonProperty("Department_Code3")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setDepartmentCode3(String departmentCode3) {
        this.departmentCode3 = departmentCode3;
    }

    /**
     * Department_Code4を返事します。
     * @return Department_Code4の値
     */
    @JsonProperty("Department_Code4")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getDepartmentCode4() {
        return departmentCode4;
    }

    /**
     * Department_Code4を設定します。
     * @param departmentCode4 Department_Code4
     */
    @JsonProperty("Department_Code4")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setDepartmentCode4(String departmentCode4) {
        this.departmentCode4 = departmentCode4;
    }

    /**
     * Department_Code5を返事します。
     * @return Department_Code5の値
     */
    @JsonProperty("Department_Code5")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public String getDepartmentCode5() {
        return departmentCode5;
    }

    /**
     * Department_Code5を設定します。
     * @param departmentCode5 Department_Code5
     */
    @JsonProperty("Department_Code5")
    @JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setDepartmentCode5(String departmentCode5) {
        this.departmentCode5 = departmentCode5;
    }

}
