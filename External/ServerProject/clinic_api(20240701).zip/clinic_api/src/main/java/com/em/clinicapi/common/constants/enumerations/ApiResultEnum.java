package com.em.clinicapi.common.constants.enumerations;

public enum ApiResultEnum {
    Success("00");


    private final String code;

    ApiResultEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
