package com.em.clinicapi.common.logging;

import com.em.clinicapi.common.db.DbExecutionMonitor;
import com.em.clinicapi.common.util.LogUtil;
import org.apache.logging.log4j.Level;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.apache.logging.log4j.Logger;

import java.util.Objects;
import java.util.Stack;

@Aspect
@Configuration
public class AspectLogging {

    private static final String LOG_MSG_FORMAT_BEFORE_EXEC = "[{}] START";
    private static final String LOG_MSG_FORMAT_AFTER_EXEC_OK = "[{}] END OK Duration=[{}ms]";
    private static final String LOG_MSG_FORMAT_AFTER_EXEC_NG = "[%s] END %s Class=[%s] Message=[%s] Duration=[%dms]";
    private static final String LOG_MSG_FORMAT_AFTER_ACTIVE_CONN = "Active connections=[{}] Currently executing statements=[{}]";

    @Value("${logging.aspect.core.enabled:true}")
    private boolean isCoreEnabled = true;

    @Value("${logging.aspect.dbmonitor.enabled:true}")
    private boolean isDbMonitorEnabled = true;

    private ThreadLocal<Stack<Long>> executionTimerContext = new ThreadLocal<>();

    @Autowired
    private DbExecutionMonitor statementsMonitor;

    /**
     * ロギング機能の対象メソッド実行の定義
     */
    @Pointcut("execution(public * com.em.clinicapi.controller.*.*(..)) || "
            + "execution(public * com.em.clinicapi.service.*.*(..)) || "
            + "execution(public * com.em.clinicapi.logic.*.*(..)) || "
            + "execution(public * com.em.clinicapi.mapper.*.*(..)) || "
            + "execution(public * com.em.clinicapi.controller.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.service.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.logic.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.mapper.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.mapper.*.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.controller.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.service.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.logic.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.mapper.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.controller.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.service.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.logic.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.mapper.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.mapper.*.*.*.*(..))")
    public void defineEntryPoint() {
    }

    /**
     * ロギング機能の対象コントローラー実行の定義
     */
    @Pointcut("execution(public * com.em.clinicapi.controller.*.*(..)) || "
            + "execution(public * com.em.clinicapi.controller.*.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.controller.*.*(..)) || "
            + "execution(public * com.em.clinicapi.*.controller.*.*.*(..))")
    public void defineControllerEntryPoint() {
    }

    /**
     * メソッド実行前のログ出力処理を実行する。
     *
     * @param joinPoint メソッド呼び出しメタデータ
     */
    @Before("defineEntryPoint()")
    public void before(JoinPoint joinPoint) {
        if (isCoreEnabled) {
            startExecutionTimer();
            // ログ出力処理
            LogUtil.getLogger(joinPoint.getSignature().getDeclaringTypeName()).info(LOG_MSG_FORMAT_BEFORE_EXEC, joinPoint);
        }
    }

    /**
     * メソッド実行が正常に完了時のログ出力処理を実行する。
     *
     * @param joinPoint メソッド呼び出しメタデータ
     * @param result    メソッドの戻り値オブジェクト
     */
    @AfterReturning(pointcut = "defineEntryPoint()", returning = "result")
    public void afterReturning(JoinPoint joinPoint, Object result) {
        if (isCoreEnabled) {
            Long spendTime = endExecutionTimer();
            LogUtil.getLogger(joinPoint.getSignature().getDeclaringTypeName()).info(LOG_MSG_FORMAT_AFTER_EXEC_OK,
                    joinPoint, spendTime);
        }
    }

    /**
     * メソッド実行が異常に完了時のログ出力処理を実行する。
     *
     * @param joinPoint メソッド呼び出しメタデータ
     * @param error     スローされた例外オブジェクト
     */
    @AfterThrowing(pointcut = "defineEntryPoint()", throwing = "error")
    public void afterThrowing(JoinPoint joinPoint, Throwable error) {
        if (isCoreEnabled) {
            Long spendTime = endExecutionTimer();
            Level level = LogUtil.getLogLevel(error);
            String message = LogUtil.getLogMessage(error);
            Logger logger = LogUtil.getLogger(joinPoint.getSignature().getDeclaringTypeName());
            String logMessage = String.format(LOG_MSG_FORMAT_AFTER_EXEC_NG, joinPoint, level, error.getClass(), message, spendTime);

            LogUtil.log(logger, level, logMessage, error);
        }
    }

    /**
     * メソッド実行が正常に完了時のログ出力処理を実行する。
     *
     * @param joinPoint メソッド呼び出しメタデータ
     * @param result    メソッドの戻り値オブジェクト
     */
    @AfterReturning(pointcut = "defineControllerEntryPoint()", returning = "result")
    public void afterControllerMethodReturning(JoinPoint joinPoint, Object result) {
        if (isDbMonitorEnabled && Objects.nonNull(statementsMonitor)) {
            LogUtil.getLogger(statementsMonitor).info(LOG_MSG_FORMAT_AFTER_ACTIVE_CONN,
                    statementsMonitor.getActiveConnectionCount(), statementsMonitor.getActiveStatementCount());
        }
    }

    /**
     * メソッド実行が異常に完了時のログ出力処理を実行する。
     *
     * @param joinPoint メソッド呼び出しメタデータ
     * @param error     スローされた例外オブジェクト
     */
    @AfterThrowing(pointcut = "defineControllerEntryPoint()", throwing = "error")
    public void afterControllerMethodThrowing(JoinPoint joinPoint, Throwable error) {
        if (isDbMonitorEnabled && Objects.nonNull(statementsMonitor)) {
            LogUtil.getLogger(statementsMonitor).info(LOG_MSG_FORMAT_AFTER_ACTIVE_CONN,
                    statementsMonitor.getActiveConnectionCount(), statementsMonitor.getActiveStatementCount());
        }
    }

    /**
     * タイマー開始
     */
    private void startExecutionTimer() {
        if (executionTimerContext.get() == null) {
            executionTimerContext.set(new Stack<Long>());
        }
        executionTimerContext.get().push(System.currentTimeMillis());
    }

    /**
     * タイマー終了及び実行時間計算処理
     *
     * @return 実行時間（ミリ秒単位）
     */
    private Long endExecutionTimer() {
        Long spendTime = 0L;
        if (executionTimerContext.get() != null) {
            Long startTimeLong = executionTimerContext.get().pop();
            if (startTimeLong != null) {
                spendTime = System.currentTimeMillis() - startTimeLong;
            }
            if (executionTimerContext.get().size() == 0) {
                executionTimerContext.remove();
            }
        }
        return spendTime;
    }
}
