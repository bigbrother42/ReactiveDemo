package com.em.clinicapi.webdto.request.patient;

import com.em.clinicapi.webdto.request.iryoukikan.IryoukikanInfoRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import javax.validation.Valid;

@JacksonXmlRootElement(localName = "data")
public class PatientInfoRequestWebDto {
    @Valid
    @JsonProperty("PatientInfoRequest")
    private PatientInfoRequest patientInfoRequest;

    @JsonProperty("PatientInfoRequest")
    public PatientInfoRequest getPatientInfoRequest() {
        return patientInfoRequest;
    }

    @JsonProperty("PatientInfoRequest")
    public void setPatientInfoRequest(PatientInfoRequest patientInfoRequest) {
        this.patientInfoRequest = patientInfoRequest;
    }
}
