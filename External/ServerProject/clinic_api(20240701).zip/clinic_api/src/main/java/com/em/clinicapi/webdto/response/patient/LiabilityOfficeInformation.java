package com.em.clinicapi.webdto.response.patient;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : LiabilityOfficeInformation クラス <br/>
 * 項目： Liability_Office_Information <br/>
 * 説明： <br/>
 *       事業所情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class LiabilityOfficeInformation extends ResponseWebDtoBase {

	/**
	 * 項目： L_WholeName <br/>
	 * 説明： <br/>
	 *       労災保険の事業所SEQに紐づく事業所名を返却 <br/>
	 * 備考： <br/>
	 *       ”テスト株式会社” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("L_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String lWholeName;
	/**
	 * 項目： Prefecture_Information <br/>
	 * 説明： <br/>
	 *       所在地都道府県情報 <br/>
	 */
	@Valid
		@JsonProperty("Prefecture_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PrefectureInformation prefectureInformation;
	/**
	 * 項目： City_Information <br/>
	 * 説明： <br/>
	 *       事業所の住所＋番地を返却 <br/>
	 * 備考： <br/>
	 *       "大阪府大阪市　〇〇" <br/>
	 */
	@Valid
		@JsonProperty("City_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private CityInformation cityInformation;
	/**
	 * L_WholeNameを返事します。
	 * @return L_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("L_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLWholeName() {
		return lWholeName;
	}

	/**
	 * L_WholeNameを設定します。
	 * @param lWholeName L_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("L_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLWholeName(String lWholeName) {
		this.lWholeName = lWholeName;
	}

	/**
	 * Prefecture_Informationを返事します。
	 * @return Prefecture_Informationの値
	 */
		@JsonProperty("Prefecture_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public PrefectureInformation getPrefectureInformation() {
		return prefectureInformation;
	}

	/**
	 * Prefecture_Informationを設定します。
	 * @param prefectureInformation Prefecture_Information
	 */
		@JsonProperty("Prefecture_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrefectureInformation(PrefectureInformation prefectureInformation) {
		this.prefectureInformation = prefectureInformation;
	}

	/**
	 * City_Informationを返事します。
	 * @return City_Informationの値
	 */
		@JsonProperty("City_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public CityInformation getCityInformation() {
		return cityInformation;
	}

	/**
	 * City_Informationを設定します。
	 * @param cityInformation City_Information
	 */
		@JsonProperty("City_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCityInformation(CityInformation cityInformation) {
		this.cityInformation = cityInformation;
	}

}