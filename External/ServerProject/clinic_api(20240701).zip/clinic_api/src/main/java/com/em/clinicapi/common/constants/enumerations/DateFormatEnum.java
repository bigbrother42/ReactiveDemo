package com.em.clinicapi.common.constants.enumerations;

public enum DateFormatEnum {

    FormatYYYYMMDD("yyyyMMdd"),
    FormatYYYYMMDDM("yyyy-MM-dd"),
    FormatYYYYMMDDMinus("yyyy-MM-dd"),
    FormatYYYYMMDDSlash("yyyy/MM/dd"),
    FormatYYYYMMDDHHmmss("yyyy/MM/dd HH:mm:ss"),
    FormatHHmmss("HH:mm:ss");

    String value;

    DateFormatEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
