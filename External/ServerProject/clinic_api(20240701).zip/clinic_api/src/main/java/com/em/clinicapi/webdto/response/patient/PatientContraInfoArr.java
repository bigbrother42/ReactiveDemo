package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class PatientContraInfoArr extends ResponseWebDtoBase {
    /**
     * 項目： Patient_Contra_Info <br/>
     * 説明： <br/>
     *       患者禁忌薬剤情報 <br/>
     */
    @JsonProperty("Patient_Contra_Info_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<PatientContraInfo> patientContraInfo;

    /**
     * Patient_Contra_Infoを返事します。
     * @return Patient_Contra_Infoの値
     */
    @JsonProperty("Patient_Contra_Info_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<PatientContraInfo> getPatientContraInfo() {
        return patientContraInfo;
    }

    /**
     * Patient_Contra_Infoを設定します。
     * @param patientContraInfo Patient_Contra_Info
     */
    @JsonProperty("Patient_Contra_Info_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setPatientContraInfo(List<PatientContraInfo> patientContraInfo) {
        this.patientContraInfo = patientContraInfo;
    }
}
