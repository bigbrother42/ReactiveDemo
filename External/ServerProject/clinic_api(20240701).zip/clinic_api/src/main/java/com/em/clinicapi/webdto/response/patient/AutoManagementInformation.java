package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : AutoManagementInformation クラス <br/>
 * 項目： Auto_Management_Information <br/>
 * 説明： <br/>
 *       管理料等自動算定情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class AutoManagementInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Medication_Code <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicationCode;
	/**
	 * 項目： Medication_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicationName;
	/**
	 * 項目： Medication_EndDate <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_EndDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicationEndDate;
	/**
	 * Medication_Codeを返事します。
	 * @return Medication_Codeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicationCode() {
		return medicationCode;
	}

	/**
	 * Medication_Codeを設定します。
	 * @param medicationCode Medication_Code
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicationCode(String medicationCode) {
		this.medicationCode = medicationCode;
	}

	/**
	 * Medication_Nameを返事します。
	 * @return Medication_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicationName() {
		return medicationName;
	}

	/**
	 * Medication_Nameを設定します。
	 * @param medicationName Medication_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicationName(String medicationName) {
		this.medicationName = medicationName;
	}

	/**
	 * Medication_EndDateを返事します。
	 * @return Medication_EndDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_EndDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicationEndDate() {
		return medicationEndDate;
	}

	/**
	 * Medication_EndDateを設定します。
	 * @param medicationEndDate Medication_EndDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medication_EndDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicationEndDate(String medicationEndDate) {
		this.medicationEndDate = medicationEndDate;
	}

}