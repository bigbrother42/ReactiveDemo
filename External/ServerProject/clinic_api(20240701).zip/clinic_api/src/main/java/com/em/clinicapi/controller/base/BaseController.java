package com.em.clinicapi.controller.base;


import com.em.clinicapi.common.constants.enumerations.ApiResultEnum;
import com.em.clinicapi.common.constants.enumerations.ApiResultMessageEnum;
import com.em.clinicapi.common.util.WebDtoUtil;
import com.em.clinicapi.webdto.base.ResponseBase;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.*;


public class BaseController {
    /*protected String getRequestBodyXML() {
        return RequestCacheHolder.get(RequestCacheHolder.REQUEST_BODY_XML);
    }*/

    /*protected <T> T getRequestBody(Class<T> targetClass) throws XmlParseException {
        String xml = getRequestBodyXML();
        T obj = XmlUtil.parseObject(xml, targetClass);
        return obj;
    }*/

    //パラメータチェック
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseBody
    public ResponseBase exception(MethodArgumentNotValidException e, HttpServletRequest request) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        ResponseBase responseBase = new ResponseBase();
        List<String> result = new ArrayList<>();
        BindingResult bindingResult = e.getBindingResult();
        for (ObjectError objectError : bindingResult.getAllErrors()) {
            FieldError fieldError = (FieldError) objectError;
            result.add(fieldError.getField() + ":" + fieldError.getDefaultMessage());
        }
        WebDtoUtil.setResponseBase(responseBase, ApiResultEnum.Success, ApiResultMessageEnum.Success);
        responseBase.setApiResultMessage(objectMapper.writeValueAsString(result));
        return responseBase;
    }
}
