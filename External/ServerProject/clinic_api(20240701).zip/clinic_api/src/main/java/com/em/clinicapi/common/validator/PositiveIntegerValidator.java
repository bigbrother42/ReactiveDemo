package com.em.clinicapi.common.validator;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PositiveIntegerValidator implements ConstraintValidator<PositiveInteger,String> {

    private String message;
    private String fieldName;
    @Override
    public void initialize(PositiveInteger constraintAnnotation) {
        this.message = constraintAnnotation.message();
        this.fieldName = constraintAnnotation.fieldName();
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if(value == null){
            return false;
        }
        if(!value.matches("^[1-9]\\d*$")){
            message =  fieldName + "の入力は1以上の純粋な数字である必要があります。入力値:" + value;
            context.disableDefaultConstraintViolation();
            context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
            return false;
        }else{
            return true;
        }
    }
}
