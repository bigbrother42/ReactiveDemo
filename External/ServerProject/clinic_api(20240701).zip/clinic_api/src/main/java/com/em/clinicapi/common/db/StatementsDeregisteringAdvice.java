package com.em.clinicapi.common.db;

import org.springframework.aop.MethodBeforeAdvice;

import java.lang.reflect.Method;
import java.sql.Connection;

public class StatementsDeregisteringAdvice implements MethodBeforeAdvice {

    private DbExecutionMonitor statementsMonitor;

    /**
     * @return the statementsMonitor
     */
    public DbExecutionMonitor getStatementsMonitor() {
        return statementsMonitor;
    }

    /**
     * @param statementsMonitor the statementsMonitor to set
     */
    public void setStatementsMonitor(DbExecutionMonitor statementsMonitor) {
        this.statementsMonitor = statementsMonitor;
    }

    @Override
    public void before(final Method method, final Object[] args, final Object target) throws Throwable {
        if (method.getName().equals("close")) {
            statementsMonitor.remove(Connection.class.cast(target));
        }
    }
}
