package com.em.clinicapi.webdto.request.patient;


import com.em.clinicapi.webdto.request.base.RequestWebDtoBase;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto :  PatientInfoRequestWebDto クラス <br/>
 * 項目： 患者情報リクエスト <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class PatientInfoRequest extends RequestWebDtoBase {

	/**
	 * 項目： Group_ID <br/>
	 * 説明： <br/>
	 *       グループSEQ <br/>
	 */
	@JsonProperty("Group_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String groupId;

	/**
	 * 項目： Customer_ID <br/>
	 * 説明： <br/>
	 *       顧客SEQ <br/>
	 */
	@JsonProperty("Customer_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String customerId;

	/**
	 * 項目： Patient_ID <br/>
	 * 説明： <br/>
	 *       登録通知の際、patient_seqを渡す想定 <br/>
	 */
	@JsonProperty("Patient_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String patientId;

	/**
	 * Group_IDを返事します。
	 * @return Group_IDの値
	 */
	@JsonProperty("Group_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getGroupId() {
		return groupId;
	}

	/**
	 * Group_IDを設定します。
	 * @param groupId Group_ID
	 */
	@JsonProperty("Group_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	/**
	 * Customer_IDを返事します。
	 * @return Customer_IDの値
	 */
	@JsonProperty("Customer_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Customer_IDを設定します。
	 * @param customerId Customer_ID
	 */
	@JsonProperty("Customer_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Patient_IDを返事します。
	 * @return Patient_IDの値
	 */
	@JsonProperty("Patient_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getPatientId() {
		return patientId;
	}

	/**
	 * Patient_IDを設定します。
	 * @param patientId Patient_ID
	 */
	@JsonProperty("Patient_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

}