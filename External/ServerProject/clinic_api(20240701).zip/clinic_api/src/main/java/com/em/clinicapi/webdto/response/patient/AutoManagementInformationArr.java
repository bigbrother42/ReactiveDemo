package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class AutoManagementInformationArr extends ResponseWebDtoBase {
    /**
     * 項目： Auto_Management_Information <br/>
     * 説明： <br/>
     *       管理料等自動算定情報 <br/>
     */
    @JsonProperty("Auto_Management_Information_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<AutoManagementInformation> autoManagementInformation;

    /**
     * Auto_Management_Informationを返事します。
     * @return Auto_Management_Informationの値
     */
    @JsonProperty("Auto_Management_Information_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<AutoManagementInformation> getAutoManagementInformation() {
        return autoManagementInformation;
    }

    /**
     * Auto_Management_Informationを設定します。
     * @param autoManagementInformation Auto_Management_Information
     */
    @JsonProperty("Auto_Management_Information_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setAutoManagementInformation(List<AutoManagementInformation> autoManagementInformation) {
        this.autoManagementInformation = autoManagementInformation;
    }
}
