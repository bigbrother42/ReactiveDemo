package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class FukuhokenWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ fukuhokenSeq */
	private int  fukuhokenSeq = 0;

	/**  プロパティ fukuhokenType */
	private String  fukuhokenType = null;

	/**  プロパティ futanshaNo */
	private String  futanshaNo = null;

	/**  プロパティ jukyuushaNo */
	private String  jukyuushaNo = null;

	/**  プロパティ kouhiSeidoKbn */
	private String  kouhiSeidoKbn = null;

	/**  プロパティ fukushiNo */
	private String  fukushiNo = null;

	/**  プロパティ fukushiMasterSeq */
	private int  fukushiMasterSeq = 0;

	/**  プロパティ hokenKigou */
	private String  hokenKigou = null;

	/**  プロパティ startDate */
	private java.sql.Date  startDate = null;

	/**  プロパティ endDate */
	private java.sql.Date  endDate = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public FukuhokenWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：fukuhokenSeq を返します。
	* @return fukuhokenSeq
	*/
	public int getFukuhokenSeq(){
		return fukuhokenSeq;
	}

	/**
	* プロパティー：fukuhokenSeq を設定します。
	* @param param  int fukuhokenSeq
	*/
	public void setFukuhokenSeq(int fukuhokenSeq){
		this.fukuhokenSeq = fukuhokenSeq;
	}

	/**
	* プロパティー：fukuhokenType を返します。
	* @return fukuhokenType
	*/
	public String getFukuhokenType(){
		return fukuhokenType;
	}

	/**
	* プロパティー：fukuhokenType を設定します。
	* @param param  String fukuhokenType
	*/
	public void setFukuhokenType(String fukuhokenType){
		this.fukuhokenType = fukuhokenType;
	}

	/**
	* プロパティー：futanshaNo を返します。
	* @return futanshaNo
	*/
	public String getFutanshaNo(){
		return futanshaNo;
	}

	/**
	* プロパティー：futanshaNo を設定します。
	* @param param  String futanshaNo
	*/
	public void setFutanshaNo(String futanshaNo){
		this.futanshaNo = futanshaNo;
	}

	/**
	* プロパティー：jukyuushaNo を返します。
	* @return jukyuushaNo
	*/
	public String getJukyuushaNo(){
		return jukyuushaNo;
	}

	/**
	* プロパティー：jukyuushaNo を設定します。
	* @param param  String jukyuushaNo
	*/
	public void setJukyuushaNo(String jukyuushaNo){
		this.jukyuushaNo = jukyuushaNo;
	}

	/**
	* プロパティー：kouhiSeidoKbn を返します。
	* @return kouhiSeidoKbn
	*/
	public String getKouhiSeidoKbn(){
		return kouhiSeidoKbn;
	}

	/**
	* プロパティー：kouhiSeidoKbn を設定します。
	* @param param  String kouhiSeidoKbn
	*/
	public void setKouhiSeidoKbn(String kouhiSeidoKbn){
		this.kouhiSeidoKbn = kouhiSeidoKbn;
	}

	/**
	* プロパティー：fukushiNo を返します。
	* @return fukushiNo
	*/
	public String getFukushiNo(){
		return fukushiNo;
	}

	/**
	* プロパティー：fukushiNo を設定します。
	* @param param  String fukushiNo
	*/
	public void setFukushiNo(String fukushiNo){
		this.fukushiNo = fukushiNo;
	}

	/**
	* プロパティー：fukushiMasterSeq を返します。
	* @return fukushiMasterSeq
	*/
	public int getFukushiMasterSeq(){
		return fukushiMasterSeq;
	}

	/**
	* プロパティー：fukushiMasterSeq を設定します。
	* @param param  int fukushiMasterSeq
	*/
	public void setFukushiMasterSeq(int fukushiMasterSeq){
		this.fukushiMasterSeq = fukushiMasterSeq;
	}

	/**
	* プロパティー：hokenKigou を返します。
	* @return hokenKigou
	*/
	public String getHokenKigou(){
		return hokenKigou;
	}

	/**
	* プロパティー：hokenKigou を設定します。
	* @param param  String hokenKigou
	*/
	public void setHokenKigou(String hokenKigou){
		this.hokenKigou = hokenKigou;
	}

	/**
	* プロパティー：startDate を返します。
	* @return startDate
	*/
	public java.sql.Date getStartDate(){
		return startDate;
	}

	/**
	* プロパティー：startDate を設定します。
	* @param param  java.sql.Date startDate
	*/
	public void setStartDate(java.sql.Date startDate){
		this.startDate = startDate;
	}

	/**
	* プロパティー：endDate を返します。
	* @return endDate
	*/
	public java.sql.Date getEndDate(){
		return endDate;
	}

	/**
	* プロパティー：endDate を設定します。
	* @param param  java.sql.Date endDate
	*/
	public void setEndDate(java.sql.Date endDate){
		this.endDate = endDate;
	}
}
