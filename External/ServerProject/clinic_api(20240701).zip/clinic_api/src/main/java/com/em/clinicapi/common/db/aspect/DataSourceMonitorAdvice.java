package com.em.clinicapi.common.db.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.aop.Advisor;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.util.List;

@Aspect
@Component
public class DataSourceMonitorAdvice {

    @Autowired
    @Qualifier("connectionQualifier")
    private List<Advisor> advisors;

    /**
     * 1. Firstly, get the Connection object returned by the original javax.sql.DataSource.getConnection() method,
     * and then use the proxy mode to add an advisor to this Connection object.
     * 2. The aspect collection advisors here refer to StatementsRegisteringAdvice and StatementsDeregisteringAdvice defined in DataSourceMonitorConfig
     * 3. These two aspects are injected into the aspect collection advisors through @Qualifier("connectionQualifier")
     * @param pjp
     * @return
     * @throws Throwable
     */
    @Around(value = "anyDataSource()")
    public Object onNewConnection(final ProceedingJoinPoint pjp) throws Throwable {
        Connection retVal = (Connection) pjp.proceed(pjp.getArgs());
        ProxyFactory proxyFactory = new ProxyFactory(retVal);
        for (Advisor adv : this.advisors) {
            proxyFactory.addAdvisor(adv);
        }
        retVal = (Connection) proxyFactory.getProxy();
        return retVal;
    }

    @Pointcut("execution (* javax.sql.DataSource.getConnection())")
    private void anyDataSource() {

    }
}
