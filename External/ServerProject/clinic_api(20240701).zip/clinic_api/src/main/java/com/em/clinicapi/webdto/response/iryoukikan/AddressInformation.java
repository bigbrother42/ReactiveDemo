package com.em.clinicapi.webdto.response.iryoukikan;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : AddressInformation クラス <br/>
 * 項目： Address_Information <br/>
 * 説明： <br/>
 *       連絡先、広告情報 <br/>
 * 備考： <br/>
 *       "" <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class AddressInformation extends ResponseWebDtoBase {

	/**
	 * 項目： WholeAddress <br/>
	 * 説明： <br/>
	 *       所在地 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeAddress;
	/**
	 * 項目： Address_ZipCode <br/>
	 * 説明： <br/>
	 *       郵便番号 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String addressZipCode;
	/**
	 * 項目： PhoneNumber <br/>
	 * 説明： <br/>
	 *       電話番号 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String phoneNumber;
	/**
	 * 項目： FaxNumber <br/>
	 * 説明： <br/>
	 *       FAX番号 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FaxNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String faxNumber;
	/**
	 * 項目： E_mail_Address <br/>
	 * 説明： <br/>
	 *       Eメールアドレス <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("E_mail_Address")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String eMailAddress;
	/**
	 * 項目： Homepage_Address <br/>
	 * 説明： <br/>
	 *       ホームページアドレス <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Homepage_Address")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String homepageAddress;
	/**
	 * WholeAddressを返事します。
	 * @return WholeAddressの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeAddress() {
		return wholeAddress;
	}

	/**
	 * WholeAddressを設定します。
	 * @param wholeAddress WholeAddress
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeAddress(String wholeAddress) {
		this.wholeAddress = wholeAddress;
	}

	/**
	 * Address_ZipCodeを返事します。
	 * @return Address_ZipCodeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAddressZipCode() {
		return addressZipCode;
	}

	/**
	 * Address_ZipCodeを設定します。
	 * @param addressZipCode Address_ZipCode
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}

	/**
	 * PhoneNumberを返事します。
	 * @return PhoneNumberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * PhoneNumberを設定します。
	 * @param phoneNumber PhoneNumber
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	/**
	 * FaxNumberを返事します。
	 * @return FaxNumberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FaxNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getFaxNumber() {
		return faxNumber;
	}

	/**
	 * FaxNumberを設定します。
	 * @param faxNumber FaxNumber
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FaxNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	/**
	 * E_mail_Addressを返事します。
	 * @return E_mail_Addressの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("E_mail_Address")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getEMailAddress() {
		return eMailAddress;
	}

	/**
	 * E_mail_Addressを設定します。
	 * @param eMailAddress E_mail_Address
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("E_mail_Address")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setEMailAddress(String eMailAddress) {
		this.eMailAddress = eMailAddress;
	}

	/**
	 * Homepage_Addressを返事します。
	 * @return Homepage_Addressの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Homepage_Address")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHomepageAddress() {
		return homepageAddress;
	}

	/**
	 * Homepage_Addressを設定します。
	 * @param homepageAddress Homepage_Address
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Homepage_Address")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHomepageAddress(String homepageAddress) {
		this.homepageAddress = homepageAddress;
	}

}