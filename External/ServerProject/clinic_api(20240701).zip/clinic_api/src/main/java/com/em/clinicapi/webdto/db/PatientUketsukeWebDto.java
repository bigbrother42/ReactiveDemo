package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/

/**
 * WebDto : PatientUketsukeWebDto クラス<br>
 *
 * 自動生成クラス<br>
 *
 * 作成日 ： 2024/04/22<br>
 *
 * @author DAOGenerator4Smart
 */
//***************************************************************************
@Component
public class PatientUketsukeWebDto extends CustomerWebDtoBase {

	/** プロパティ uketsukeDate */
	private java.sql.Date uketsukeDate = null;

	/** プロパティ uketsukeSeq */
	private int uketsukeSeq = 0;

	/** プロパティ raiinKaisuu */
	private int raiinKaisuu = 0;

	/** プロパティ raiinOrder */
	private int raiinOrder = 0;

	/** プロパティ isOrderChange */
	private boolean isOrderChange;

	/** プロパティ patientSeq */
	private int patientSeq = 0;

	/** プロパティ hokenSeq */
	private int hokenSeq = 0;

	/** プロパティ uketsukeDateTime */
	private java.sql.Timestamp uketsukeDateTime = null;

	/** プロパティ yoyakuDateTime */
	private java.sql.Timestamp yoyakuDateTime = null;

	/** プロパティ yoyakuType */
	private String yoyakuType = null;

	/** プロパティ yoyakuComment */
	private String yoyakuComment = null;

	/** プロパティ shinsatsuStartDateTime */
	private java.sql.Timestamp shinsatsuStartDateTime = null;

	/** プロパティ kaikeiEndDateTime */
	private java.sql.Timestamp kaikeiEndDateTime = null;

	/** プロパティ kaikeiWaitDateTime */
	private java.sql.Timestamp kaikeiWaitDateTime = null;

	/** プロパティ kaikeiWaitReasonKbn */
	private String kaikeiWaitReasonKbn = null;

	/** プロパティ shinryoukaCode */
	private String shinryoukaCode = null;

	/** プロパティ doctorCode */
	private String doctorCode = null;

	/** プロパティ joukyouKbn */
	private String joukyouKbn = null;

	/** プロパティ roomCode */
	private String roomCode = null;

	/** プロパティ patientMemo */
	private String patientMemo = null;

	/** プロパティ uketsukeComment */
	private String uketsukeComment = null;

	/** プロパティ uketsukeComment2 */
	private String uketsukeComment2 = null;

	/** プロパティ timeKbn */
	private String timeKbn = null;

	/** プロパティ isTimeKbnChange */
	private boolean isTimeKbnChange;

	/** プロパティ shosaishinKbn */
	private String shosaishinKbn = null;

	/** プロパティ isShosaishinChange */
	private boolean isShosaishinChange;

	/** プロパティ finalRaiinDate */
	private java.sql.Date finalRaiinDate = null;

	/** プロパティ patientUniqueMark */
	private int patientUniqueMark = 0;

	/** プロパティ yakuhinMark */
	private int yakuhinMark = 0;

	/** プロパティ chuushaMark */
	private int chuushaMark = 0;

	/** プロパティ shochiMark */
	private int shochiMark = 0;

	/** プロパティ kensaMark */
	private int kensaMark = 0;

	/** プロパティ imageShindanMark */
	private int imageShindanMark = 0;

	/** プロパティ rehabilitationMark */
	private int rehabilitationMark = 0;

	/** プロパティ shujutsuMark */
	private int shujutsuMark = 0;

	/** プロパティ masuiMark */
	private int masuiMark = 0;

	/** プロパティ groupTypeMark */
	private int groupTypeMark = 0;

	/** プロパティ uketsukeGroupCode */
	private String uketsukeGroupCode = null;

	/** プロパティ sainyouKbn */
	private String sainyouKbn = null;

	/** プロパティ saiketsuKbn */
	private String saiketsuKbn = null;

	/** プロパティ bikou */
	private String bikou = null;

	/** プロパティ freeColumn */
	private String freeColumn = null;

	/** プロパティ isDeleted */
	private boolean isDeleted;

	/** プロパティ uketsukeWakuNo */
	private String uketsukeWakuNo = null;

	/** プロパティ answerStatusKbn */
	private String answerStatusKbn = null;

	/** プロパティ monshinKidouUrl */
	private String monshinKidouUrl = null;

	/** プロパティ answerDateTime */
	private java.sql.Timestamp answerDateTime = null;

	/** プロパティ answerCode */
	private String answerCode = null;

	/** プロパティ uketsukeTempName */
	private String uketsukeTempName = null;

	/** プロパティ uketsukeSakiKbn */
	private String uketsukeSakiKbn = null;

	/** プロパティ kaigoMark */
	private int kaigoMark = 0;

	/** プロパティ kaikeiKbn */
	private String kaikeiKbn = null;

	/** プロパティ urikakeTourokuJoukyouKbn */
	private String urikakeTourokuJoukyouKbn = null;

	/** プロパティ urikakeKanriComment */
	private String urikakeKanriComment = null;

	/** プロパティ webYoyakuUketsukeNo */
	private String webYoyakuUketsukeNo = null;

	/** プロパティ shikakuKakuninResultKbn */
	private String shikakuKakuninResultKbn = null;

	/** プロパティ sanshouAgreementKbn */
	private String sanshouAgreementKbn = null;

	/**
	 * デフォルトのコンストラクタ
	 */
	public PatientUketsukeWebDto() {
		super();
	}

	/**
	 * プロパティー：uketsukeDate を返します。
	 *
	 * @return uketsukeDate
	 */
	public java.sql.Date getUketsukeDate() {
		return uketsukeDate;
	}

	/**
	 * プロパティー：uketsukeDate を設定します。
	 *
	 * @param uketsukeDate uketsukeDateを設定。
	 */
	public void setUketsukeDate(java.sql.Date uketsukeDate) {
		this.uketsukeDate = uketsukeDate;
	}

	/**
	 * プロパティー：uketsukeSeq を返します。
	 *
	 * @return uketsukeSeq
	 */
	public int getUketsukeSeq() {
		return uketsukeSeq;
	}

	/**
	 * プロパティー：uketsukeSeq を設定します。
	 *
	 * @param uketsukeSeq uketsukeSeqを設定。
	 */
	public void setUketsukeSeq(int uketsukeSeq) {
		this.uketsukeSeq = uketsukeSeq;
	}

	/**
	 * プロパティー：raiinKaisuu を返します。
	 *
	 * @return raiinKaisuu
	 */
	public int getRaiinKaisuu() {
		return raiinKaisuu;
	}

	/**
	 * プロパティー：raiinKaisuu を設定します。
	 *
	 * @param raiinKaisuu raiinKaisuuを設定。
	 */
	public void setRaiinKaisuu(int raiinKaisuu) {
		this.raiinKaisuu = raiinKaisuu;
	}

	/**
	 * プロパティー：raiinOrder を返します。
	 *
	 * @return raiinOrder
	 */
	public int getRaiinOrder() {
		return raiinOrder;
	}

	/**
	 * プロパティー：raiinOrder を設定します。
	 *
	 * @param raiinOrder raiinOrderを設定。
	 */
	public void setRaiinOrder(int raiinOrder) {
		this.raiinOrder = raiinOrder;
	}

	/**
	 * プロパティー：isOrderChange を返します。
	 *
	 * @return isOrderChange
	 */
	public boolean getIsOrderChange() {
		return isOrderChange;
	}

	/**
	 * プロパティー：isOrderChange を設定します。
	 *
	 * @param isOrderChange isOrderChangeを設定。
	 */
	public void setIsOrderChange(boolean isOrderChange) {
		this.isOrderChange = isOrderChange;
	}

	/**
	 * プロパティー：patientSeq を返します。
	 *
	 * @return patientSeq
	 */
	public int getPatientSeq() {
		return patientSeq;
	}

	/**
	 * プロパティー：patientSeq を設定します。
	 *
	 * @param patientSeq patientSeqを設定。
	 */
	public void setPatientSeq(int patientSeq) {
		this.patientSeq = patientSeq;
	}

	/**
	 * プロパティー：hokenSeq を返します。
	 *
	 * @return hokenSeq
	 */
	public int getHokenSeq() {
		return hokenSeq;
	}

	/**
	 * プロパティー：hokenSeq を設定します。
	 *
	 * @param hokenSeq hokenSeqを設定。
	 */
	public void setHokenSeq(int hokenSeq) {
		this.hokenSeq = hokenSeq;
	}

	/**
	 * プロパティー：uketsukeDateTime を返します。
	 *
	 * @return uketsukeDateTime
	 */
	public java.sql.Timestamp getUketsukeDateTime() {
		return uketsukeDateTime;
	}

	/**
	 * プロパティー：uketsukeDateTime を設定します。
	 *
	 * @param uketsukeDateTime uketsukeDateTimeを設定。
	 */
	public void setUketsukeDateTime(java.sql.Timestamp uketsukeDateTime) {
		this.uketsukeDateTime = uketsukeDateTime;
	}

	/**
	 * プロパティー：yoyakuDateTime を返します。
	 *
	 * @return yoyakuDateTime
	 */
	public java.sql.Timestamp getYoyakuDateTime() {
		return yoyakuDateTime;
	}

	/**
	 * プロパティー：yoyakuDateTime を設定します。
	 *
	 * @param yoyakuDateTime yoyakuDateTimeを設定。
	 */
	public void setYoyakuDateTime(java.sql.Timestamp yoyakuDateTime) {
		this.yoyakuDateTime = yoyakuDateTime;
	}

	/**
	 * プロパティー：yoyakuType を返します。
	 *
	 * @return yoyakuType
	 */
	public String getYoyakuType() {
		return yoyakuType;
	}

	/**
	 * プロパティー：yoyakuType を設定します。
	 *
	 * @param yoyakuType yoyakuTypeを設定。
	 */
	public void setYoyakuType(String yoyakuType) {
		this.yoyakuType = yoyakuType;
	}

	/**
	 * プロパティー：yoyakuComment を返します。
	 *
	 * @return yoyakuComment
	 */
	public String getYoyakuComment() {
		return yoyakuComment;
	}

	/**
	 * プロパティー：yoyakuComment を設定します。
	 *
	 * @param yoyakuComment yoyakuCommentを設定。
	 */
	public void setYoyakuComment(String yoyakuComment) {
		this.yoyakuComment = yoyakuComment;
	}

	/**
	 * プロパティー：shinsatsuStartDateTime を返します。
	 *
	 * @return shinsatsuStartDateTime
	 */
	public java.sql.Timestamp getShinsatsuStartDateTime() {
		return shinsatsuStartDateTime;
	}

	/**
	 * プロパティー：shinsatsuStartDateTime を設定します。
	 *
	 * @param shinsatsuStartDateTime shinsatsuStartDateTimeを設定。
	 */
	public void setShinsatsuStartDateTime(java.sql.Timestamp shinsatsuStartDateTime) {
		this.shinsatsuStartDateTime = shinsatsuStartDateTime;
	}

	/**
	 * プロパティー：kaikeiEndDateTime を返します。
	 *
	 * @return kaikeiEndDateTime
	 */
	public java.sql.Timestamp getKaikeiEndDateTime() {
		return kaikeiEndDateTime;
	}

	/**
	 * プロパティー：kaikeiEndDateTime を設定します。
	 *
	 * @param kaikeiEndDateTime kaikeiEndDateTimeを設定。
	 */
	public void setKaikeiEndDateTime(java.sql.Timestamp kaikeiEndDateTime) {
		this.kaikeiEndDateTime = kaikeiEndDateTime;
	}

	/**
	 * プロパティー：kaikeiWaitDateTime を返します。
	 *
	 * @return kaikeiWaitDateTime
	 */
	public java.sql.Timestamp getKaikeiWaitDateTime() {
		return kaikeiWaitDateTime;
	}

	/**
	 * プロパティー：kaikeiWaitDateTime を設定します。
	 *
	 * @param kaikeiWaitDateTime kaikeiWaitDateTimeを設定。
	 */
	public void setKaikeiWaitDateTime(java.sql.Timestamp kaikeiWaitDateTime) {
		this.kaikeiWaitDateTime = kaikeiWaitDateTime;
	}

	/**
	 * プロパティー：kaikeiWaitReasonKbn を返します。
	 *
	 * @return kaikeiWaitReasonKbn
	 */
	public String getKaikeiWaitReasonKbn() {
		return kaikeiWaitReasonKbn;
	}

	/**
	 * プロパティー：kaikeiWaitReasonKbn を設定します。
	 *
	 * @param kaikeiWaitReasonKbn kaikeiWaitReasonKbnを設定。
	 */
	public void setKaikeiWaitReasonKbn(String kaikeiWaitReasonKbn) {
		this.kaikeiWaitReasonKbn = kaikeiWaitReasonKbn;
	}

	/**
	 * プロパティー：shinryoukaCode を返します。
	 *
	 * @return shinryoukaCode
	 */
	public String getShinryoukaCode() {
		return shinryoukaCode;
	}

	/**
	 * プロパティー：shinryoukaCode を設定します。
	 *
	 * @param shinryoukaCode shinryoukaCodeを設定。
	 */
	public void setShinryoukaCode(String shinryoukaCode) {
		this.shinryoukaCode = shinryoukaCode;
	}

	/**
	 * プロパティー：doctorCode を返します。
	 *
	 * @return doctorCode
	 */
	public String getDoctorCode() {
		return doctorCode;
	}

	/**
	 * プロパティー：doctorCode を設定します。
	 *
	 * @param doctorCode doctorCodeを設定。
	 */
	public void setDoctorCode(String doctorCode) {
		this.doctorCode = doctorCode;
	}

	/**
	 * プロパティー：joukyouKbn を返します。
	 *
	 * @return joukyouKbn
	 */
	public String getJoukyouKbn() {
		return joukyouKbn;
	}

	/**
	 * プロパティー：joukyouKbn を設定します。
	 *
	 * @param joukyouKbn joukyouKbnを設定。
	 */
	public void setJoukyouKbn(String joukyouKbn) {
		this.joukyouKbn = joukyouKbn;
	}

	/**
	 * プロパティー：roomCode を返します。
	 *
	 * @return roomCode
	 */
	public String getRoomCode() {
		return roomCode;
	}

	/**
	 * プロパティー：roomCode を設定します。
	 *
	 * @param roomCode roomCodeを設定。
	 */
	public void setRoomCode(String roomCode) {
		this.roomCode = roomCode;
	}

	/**
	 * プロパティー：patientMemo を返します。
	 *
	 * @return patientMemo
	 */
	public String getPatientMemo() {
		return patientMemo;
	}

	/**
	 * プロパティー：patientMemo を設定します。
	 *
	 * @param patientMemo patientMemoを設定。
	 */
	public void setPatientMemo(String patientMemo) {
		this.patientMemo = patientMemo;
	}

	/**
	 * プロパティー：uketsukeComment を返します。
	 *
	 * @return uketsukeComment
	 */
	public String getUketsukeComment() {
		return uketsukeComment;
	}

	/**
	 * プロパティー：uketsukeComment を設定します。
	 *
	 * @param uketsukeComment uketsukeCommentを設定。
	 */
	public void setUketsukeComment(String uketsukeComment) {
		this.uketsukeComment = uketsukeComment;
	}

	/**
	 * プロパティー：uketsukeComment2 を返します。
	 *
	 * @return uketsukeComment2
	 */
	public String getUketsukeComment2() {
		return uketsukeComment2;
	}

	/**
	 * プロパティー：uketsukeComment2 を設定します。
	 *
	 * @param uketsukeComment2 uketsukeComment2を設定。
	 */
	public void setUketsukeComment2(String uketsukeComment2) {
		this.uketsukeComment2 = uketsukeComment2;
	}

	/**
	 * プロパティー：timeKbn を返します。
	 *
	 * @return timeKbn
	 */
	public String getTimeKbn() {
		return timeKbn;
	}

	/**
	 * プロパティー：timeKbn を設定します。
	 *
	 * @param timeKbn timeKbnを設定。
	 */
	public void setTimeKbn(String timeKbn) {
		this.timeKbn = timeKbn;
	}

	/**
	 * プロパティー：isTimeKbnChange を返します。
	 *
	 * @return isTimeKbnChange
	 */
	public boolean getIsTimeKbnChange() {
		return isTimeKbnChange;
	}

	/**
	 * プロパティー：isTimeKbnChange を設定します。
	 *
	 * @param isTimeKbnChange isTimeKbnChangeを設定。
	 */
	public void setIsTimeKbnChange(boolean isTimeKbnChange) {
		this.isTimeKbnChange = isTimeKbnChange;
	}

	/**
	 * プロパティー：shosaishinKbn を返します。
	 *
	 * @return shosaishinKbn
	 */
	public String getShosaishinKbn() {
		return shosaishinKbn;
	}

	/**
	 * プロパティー：shosaishinKbn を設定します。
	 *
	 * @param shosaishinKbn shosaishinKbnを設定。
	 */
	public void setShosaishinKbn(String shosaishinKbn) {
		this.shosaishinKbn = shosaishinKbn;
	}

	/**
	 * プロパティー：isShosaishinChange を返します。
	 *
	 * @return isShosaishinChange
	 */
	public boolean getIsShosaishinChange() {
		return isShosaishinChange;
	}

	/**
	 * プロパティー：isShosaishinChange を設定します。
	 *
	 * @param isShosaishinChange isShosaishinChangeを設定。
	 */
	public void setIsShosaishinChange(boolean isShosaishinChange) {
		this.isShosaishinChange = isShosaishinChange;
	}

	/**
	 * プロパティー：finalRaiinDate を返します。
	 *
	 * @return finalRaiinDate
	 */
	public java.sql.Date getFinalRaiinDate() {
		return finalRaiinDate;
	}

	/**
	 * プロパティー：finalRaiinDate を設定します。
	 *
	 * @param finalRaiinDate finalRaiinDateを設定。
	 */
	public void setFinalRaiinDate(java.sql.Date finalRaiinDate) {
		this.finalRaiinDate = finalRaiinDate;
	}

	/**
	 * プロパティー：patientUniqueMark を返します。
	 *
	 * @return patientUniqueMark
	 */
	public int getPatientUniqueMark() {
		return patientUniqueMark;
	}

	/**
	 * プロパティー：patientUniqueMark を設定します。
	 *
	 * @param patientUniqueMark patientUniqueMarkを設定。
	 */
	public void setPatientUniqueMark(int patientUniqueMark) {
		this.patientUniqueMark = patientUniqueMark;
	}

	/**
	 * プロパティー：yakuhinMark を返します。
	 *
	 * @return yakuhinMark
	 */
	public int getYakuhinMark() {
		return yakuhinMark;
	}

	/**
	 * プロパティー：yakuhinMark を設定します。
	 *
	 * @param yakuhinMark yakuhinMarkを設定。
	 */
	public void setYakuhinMark(int yakuhinMark) {
		this.yakuhinMark = yakuhinMark;
	}

	/**
	 * プロパティー：chuushaMark を返します。
	 *
	 * @return chuushaMark
	 */
	public int getChuushaMark() {
		return chuushaMark;
	}

	/**
	 * プロパティー：chuushaMark を設定します。
	 *
	 * @param chuushaMark chuushaMarkを設定。
	 */
	public void setChuushaMark(int chuushaMark) {
		this.chuushaMark = chuushaMark;
	}

	/**
	 * プロパティー：shochiMark を返します。
	 *
	 * @return shochiMark
	 */
	public int getShochiMark() {
		return shochiMark;
	}

	/**
	 * プロパティー：shochiMark を設定します。
	 *
	 * @param shochiMark shochiMarkを設定。
	 */
	public void setShochiMark(int shochiMark) {
		this.shochiMark = shochiMark;
	}

	/**
	 * プロパティー：kensaMark を返します。
	 *
	 * @return kensaMark
	 */
	public int getKensaMark() {
		return kensaMark;
	}

	/**
	 * プロパティー：kensaMark を設定します。
	 *
	 * @param kensaMark kensaMarkを設定。
	 */
	public void setKensaMark(int kensaMark) {
		this.kensaMark = kensaMark;
	}

	/**
	 * プロパティー：imageShindanMark を返します。
	 *
	 * @return imageShindanMark
	 */
	public int getImageShindanMark() {
		return imageShindanMark;
	}

	/**
	 * プロパティー：imageShindanMark を設定します。
	 *
	 * @param imageShindanMark imageShindanMarkを設定。
	 */
	public void setImageShindanMark(int imageShindanMark) {
		this.imageShindanMark = imageShindanMark;
	}

	/**
	 * プロパティー：rehabilitationMark を返します。
	 *
	 * @return rehabilitationMark
	 */
	public int getRehabilitationMark() {
		return rehabilitationMark;
	}

	/**
	 * プロパティー：rehabilitationMark を設定します。
	 *
	 * @param rehabilitationMark rehabilitationMarkを設定。
	 */
	public void setRehabilitationMark(int rehabilitationMark) {
		this.rehabilitationMark = rehabilitationMark;
	}

	/**
	 * プロパティー：shujutsuMark を返します。
	 *
	 * @return shujutsuMark
	 */
	public int getShujutsuMark() {
		return shujutsuMark;
	}

	/**
	 * プロパティー：shujutsuMark を設定します。
	 *
	 * @param shujutsuMark shujutsuMarkを設定。
	 */
	public void setShujutsuMark(int shujutsuMark) {
		this.shujutsuMark = shujutsuMark;
	}

	/**
	 * プロパティー：masuiMark を返します。
	 *
	 * @return masuiMark
	 */
	public int getMasuiMark() {
		return masuiMark;
	}

	/**
	 * プロパティー：masuiMark を設定します。
	 *
	 * @param masuiMark masuiMarkを設定。
	 */
	public void setMasuiMark(int masuiMark) {
		this.masuiMark = masuiMark;
	}

	/**
	 * プロパティー：groupTypeMark を返します。
	 *
	 * @return groupTypeMark
	 */
	public int getGroupTypeMark() {
		return groupTypeMark;
	}

	/**
	 * プロパティー：groupTypeMark を設定します。
	 *
	 * @param groupTypeMark groupTypeMarkを設定。
	 */
	public void setGroupTypeMark(int groupTypeMark) {
		this.groupTypeMark = groupTypeMark;
	}

	/**
	 * プロパティー：uketsukeGroupCode を返します。
	 *
	 * @return uketsukeGroupCode
	 */
	public String getUketsukeGroupCode() {
		return uketsukeGroupCode;
	}

	/**
	 * プロパティー：uketsukeGroupCode を設定します。
	 *
	 * @param uketsukeGroupCode uketsukeGroupCodeを設定。
	 */
	public void setUketsukeGroupCode(String uketsukeGroupCode) {
		this.uketsukeGroupCode = uketsukeGroupCode;
	}

	/**
	 * プロパティー：sainyouKbn を返します。
	 *
	 * @return sainyouKbn
	 */
	public String getSainyouKbn() {
		return sainyouKbn;
	}

	/**
	 * プロパティー：sainyouKbn を設定します。
	 *
	 * @param sainyouKbn sainyouKbnを設定。
	 */
	public void setSainyouKbn(String sainyouKbn) {
		this.sainyouKbn = sainyouKbn;
	}

	/**
	 * プロパティー：saiketsuKbn を返します。
	 *
	 * @return saiketsuKbn
	 */
	public String getSaiketsuKbn() {
		return saiketsuKbn;
	}

	/**
	 * プロパティー：saiketsuKbn を設定します。
	 *
	 * @param saiketsuKbn saiketsuKbnを設定。
	 */
	public void setSaiketsuKbn(String saiketsuKbn) {
		this.saiketsuKbn = saiketsuKbn;
	}

	/**
	 * プロパティー：bikou を返します。
	 *
	 * @return bikou
	 */
	public String getBikou() {
		return bikou;
	}

	/**
	 * プロパティー：bikou を設定します。
	 *
	 * @param bikou bikouを設定。
	 */
	public void setBikou(String bikou) {
		this.bikou = bikou;
	}

	/**
	 * プロパティー：freeColumn を返します。
	 *
	 * @return freeColumn
	 */
	public String getFreeColumn() {
		return freeColumn;
	}

	/**
	 * プロパティー：freeColumn を設定します。
	 *
	 * @param freeColumn freeColumnを設定。
	 */
	public void setFreeColumn(String freeColumn) {
		this.freeColumn = freeColumn;
	}

	/**
	 * プロパティー：isDeleted を返します。
	 *
	 * @return isDeleted
	 */
	public boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * プロパティー：isDeleted を設定します。
	 *
	 * @param isDeleted isDeletedを設定。
	 */
	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * プロパティー：uketsukeWakuNo を返します。
	 *
	 * @return uketsukeWakuNo
	 */
	public String getUketsukeWakuNo() {
		return uketsukeWakuNo;
	}

	/**
	 * プロパティー：uketsukeWakuNo を設定します。
	 *
	 * @param uketsukeWakuNo uketsukeWakuNoを設定。
	 */
	public void setUketsukeWakuNo(String uketsukeWakuNo) {
		this.uketsukeWakuNo = uketsukeWakuNo;
	}

	/**
	 * プロパティー：answerStatusKbn を返します。
	 *
	 * @return answerStatusKbn
	 */
	public String getAnswerStatusKbn() {
		return answerStatusKbn;
	}

	/**
	 * プロパティー：answerStatusKbn を設定します。
	 *
	 * @param answerStatusKbn answerStatusKbnを設定。
	 */
	public void setAnswerStatusKbn(String answerStatusKbn) {
		this.answerStatusKbn = answerStatusKbn;
	}

	/**
	 * プロパティー：monshinKidouUrl を返します。
	 *
	 * @return monshinKidouUrl
	 */
	public String getMonshinKidouUrl() {
		return monshinKidouUrl;
	}

	/**
	 * プロパティー：monshinKidouUrl を設定します。
	 *
	 * @param monshinKidouUrl monshinKidouUrlを設定。
	 */
	public void setMonshinKidouUrl(String monshinKidouUrl) {
		this.monshinKidouUrl = monshinKidouUrl;
	}

	/**
	 * プロパティー：answerDateTime を返します。
	 *
	 * @return answerDateTime
	 */
	public java.sql.Timestamp getAnswerDateTime() {
		return answerDateTime;
	}

	/**
	 * プロパティー：answerDateTime を設定します。
	 *
	 * @param answerDateTime answerDateTimeを設定。
	 */
	public void setAnswerDateTime(java.sql.Timestamp answerDateTime) {
		this.answerDateTime = answerDateTime;
	}

	/**
	 * プロパティー：answerCode を返します。
	 *
	 * @return answerCode
	 */
	public String getAnswerCode() {
		return answerCode;
	}

	/**
	 * プロパティー：answerCode を設定します。
	 *
	 * @param answerCode answerCodeを設定。
	 */
	public void setAnswerCode(String answerCode) {
		this.answerCode = answerCode;
	}

	/**
	 * プロパティー：uketsukeTempName を返します。
	 *
	 * @return uketsukeTempName
	 */
	public String getUketsukeTempName() {
		return uketsukeTempName;
	}

	/**
	 * プロパティー：uketsukeTempName を設定します。
	 *
	 * @param uketsukeTempName uketsukeTempNameを設定。
	 */
	public void setUketsukeTempName(String uketsukeTempName) {
		this.uketsukeTempName = uketsukeTempName;
	}

	/**
	 * プロパティー：uketsukeSakiKbn を返します。
	 *
	 * @return uketsukeSakiKbn
	 */
	public String getUketsukeSakiKbn() {
		return uketsukeSakiKbn;
	}

	/**
	 * プロパティー：uketsukeSakiKbn を設定します。
	 *
	 * @param uketsukeSakiKbn uketsukeSakiKbnを設定。
	 */
	public void setUketsukeSakiKbn(String uketsukeSakiKbn) {
		this.uketsukeSakiKbn = uketsukeSakiKbn;
	}

	/**
	 * プロパティー：kaigoMark を返します。
	 *
	 * @return kaigoMark
	 */
	public int getKaigoMark() {
		return kaigoMark;
	}

	/**
	 * プロパティー：kaigoMark を設定します。
	 *
	 * @param kaigoMark kaigoMarkを設定。
	 */
	public void setKaigoMark(int kaigoMark) {
		this.kaigoMark = kaigoMark;
	}

	/**
	 * プロパティー：kaikeiKbn を返します。
	 *
	 * @return kaikeiKbn
	 */
	public String getKaikeiKbn() {
		return kaikeiKbn;
	}

	/**
	 * プロパティー：kaikeiKbn を設定します。
	 *
	 * @param kaikeiKbn kaikeiKbnを設定。
	 */
	public void setKaikeiKbn(String kaikeiKbn) {
		this.kaikeiKbn = kaikeiKbn;
	}

	/**
	 * プロパティー：urikakeTourokuJoukyouKbn を返します。
	 *
	 * @return urikakeTourokuJoukyouKbn
	 */
	public String getUrikakeTourokuJoukyouKbn() {
		return urikakeTourokuJoukyouKbn;
	}

	/**
	 * プロパティー：urikakeTourokuJoukyouKbn を設定します。
	 *
	 * @param urikakeTourokuJoukyouKbn urikakeTourokuJoukyouKbnを設定。
	 */
	public void setUrikakeTourokuJoukyouKbn(String urikakeTourokuJoukyouKbn) {
		this.urikakeTourokuJoukyouKbn = urikakeTourokuJoukyouKbn;
	}

	/**
	 * プロパティー：urikakeKanriComment を返します。
	 *
	 * @return urikakeKanriComment
	 */
	public String getUrikakeKanriComment() {
		return urikakeKanriComment;
	}

	/**
	 * プロパティー：urikakeKanriComment を設定します。
	 *
	 * @param urikakeKanriComment urikakeKanriCommentを設定。
	 */
	public void setUrikakeKanriComment(String urikakeKanriComment) {
		this.urikakeKanriComment = urikakeKanriComment;
	}

	/**
	 * プロパティー：webYoyakuUketsukeNo を返します。
	 *
	 * @return webYoyakuUketsukeNo
	 */
	public String getWebYoyakuUketsukeNo() {
		return webYoyakuUketsukeNo;
	}

	/**
	 * プロパティー：webYoyakuUketsukeNo を設定します。
	 *
	 * @param webYoyakuUketsukeNo webYoyakuUketsukeNoを設定。
	 */
	public void setWebYoyakuUketsukeNo(String webYoyakuUketsukeNo) {
		this.webYoyakuUketsukeNo = webYoyakuUketsukeNo;
	}

	/**
	 * プロパティー：shikakuKakuninResultKbn を返します。
	 *
	 * @return shikakuKakuninResultKbn
	 */
	public String getShikakuKakuninResultKbn() {
		return shikakuKakuninResultKbn;
	}

	/**
	 * プロパティー：shikakuKakuninResultKbn を設定します。
	 *
	 * @param shikakuKakuninResultKbn shikakuKakuninResultKbnを設定。
	 */
	public void setShikakuKakuninResultKbn(String shikakuKakuninResultKbn) {
		this.shikakuKakuninResultKbn = shikakuKakuninResultKbn;
	}

	/**
	 * プロパティー：sanshouAgreementKbn を返します。
	 *
	 * @return sanshouAgreementKbn
	 */
	public String getSanshouAgreementKbn() {
		return sanshouAgreementKbn;
	}

	/**
	 * プロパティー：sanshouAgreementKbn を設定します。
	 *
	 * @param sanshouAgreementKbn sanshouAgreementKbnを設定。
	 */
	public void setSanshouAgreementKbn(String sanshouAgreementKbn) {
		this.sanshouAgreementKbn = sanshouAgreementKbn;
	}
}
