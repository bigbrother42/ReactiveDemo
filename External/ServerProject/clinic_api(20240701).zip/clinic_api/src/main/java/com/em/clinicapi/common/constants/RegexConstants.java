package com.em.clinicapi.common.constants;

public class RegexConstants {
    public static final String WRAP_AND_ENTER = "(\r\n|\n|\n\r)";
}
