package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class JigyoushoMWebDto extends CustomerWebDtoBase {
	/**  プロパティ jigyoushoSeq */
	private int  jigyoushoSeq = 0;

	/**  プロパティ hokenKbn */
	private String  hokenKbn = null;

	/**  プロパティ jigyoushoName */
	private String  jigyoushoName = null;

	/**  プロパティ jigyoushoAddress */
	private String  jigyoushoAddress = null;

	/**  プロパティ jigyoushoBanchi */
	private String  jigyoushoBanchi = null;

	/**  プロパティ jigyoushoPhoneNo */
	private String  jigyoushoPhoneNo = null;

	/**  プロパティ jigyoushoPostalNo */
	private String  jigyoushoPostalNo = null;

	/**  プロパティ isNotDisplay */
	private boolean  isNotDisplay;


	/**
	*  デフォルトのコンストラクタ
	*/
	public JigyoushoMWebDto()	{
		super();
	}


	/**
	* プロパティー：jigyoushoSeq を返します。
	* @return jigyoushoSeq
	*/
	public int getJigyoushoSeq(){
		return jigyoushoSeq;
	}

	/**
	* プロパティー：jigyoushoSeq を設定します。
	* @param param  int jigyoushoSeq
	*/
	public void setJigyoushoSeq(int jigyoushoSeq){
		this.jigyoushoSeq = jigyoushoSeq;
	}

	/**
	* プロパティー：hokenKbn を返します。
	* @return hokenKbn
	*/
	public String getHokenKbn(){
		return hokenKbn;
	}

	/**
	* プロパティー：hokenKbn を設定します。
	* @param param  String hokenKbn
	*/
	public void setHokenKbn(String hokenKbn){
		this.hokenKbn = hokenKbn;
	}

	/**
	* プロパティー：jigyoushoName を返します。
	* @return jigyoushoName
	*/
	public String getJigyoushoName(){
		return jigyoushoName;
	}

	/**
	* プロパティー：jigyoushoName を設定します。
	* @param param  String jigyoushoName
	*/
	public void setJigyoushoName(String jigyoushoName){
		this.jigyoushoName = jigyoushoName;
	}

	/**
	* プロパティー：jigyoushoAddress を返します。
	* @return jigyoushoAddress
	*/
	public String getJigyoushoAddress(){
		return jigyoushoAddress;
	}

	/**
	* プロパティー：jigyoushoAddress を設定します。
	* @param param  String jigyoushoAddress
	*/
	public void setJigyoushoAddress(String jigyoushoAddress){
		this.jigyoushoAddress = jigyoushoAddress;
	}

	/**
	* プロパティー：jigyoushoBanchi を返します。
	* @return jigyoushoBanchi
	*/
	public String getJigyoushoBanchi(){
		return jigyoushoBanchi;
	}

	/**
	* プロパティー：jigyoushoBanchi を設定します。
	* @param param  String jigyoushoBanchi
	*/
	public void setJigyoushoBanchi(String jigyoushoBanchi){
		this.jigyoushoBanchi = jigyoushoBanchi;
	}

	/**
	* プロパティー：jigyoushoPhoneNo を返します。
	* @return jigyoushoPhoneNo
	*/
	public String getJigyoushoPhoneNo(){
		return jigyoushoPhoneNo;
	}

	/**
	* プロパティー：jigyoushoPhoneNo を設定します。
	* @param param  String jigyoushoPhoneNo
	*/
	public void setJigyoushoPhoneNo(String jigyoushoPhoneNo){
		this.jigyoushoPhoneNo = jigyoushoPhoneNo;
	}

	/**
	* プロパティー：jigyoushoPostalNo を返します。
	* @return jigyoushoPostalNo
	*/
	public String getJigyoushoPostalNo(){
		return jigyoushoPostalNo;
	}

	/**
	* プロパティー：jigyoushoPostalNo を設定します。
	* @param param  String jigyoushoPostalNo
	*/
	public void setJigyoushoPostalNo(String jigyoushoPostalNo){
		this.jigyoushoPostalNo = jigyoushoPostalNo;
	}

	/**
	* プロパティー：isNotDisplay を返します。
	* @return isNotDisplay
	*/
	public boolean getIsNotDisplay(){
		return isNotDisplay;
	}

	/**
	* プロパティー：isNotDisplay を設定します。
	* @param param  boolean isNotDisplay
	*/
	public void setIsNotDisplay(boolean isNotDisplay){
		this.isNotDisplay = isNotDisplay;
	}
}
