package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : DamageClass クラス <br/>
 * 項目： Damage_Class <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class DamageClass extends ResponseWebDtoBase {

	/**
	 * 項目： D_Code <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("D_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dCode;
	/**
	 * 項目： D_WholeName <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("D_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dWholeName;
	/**
	 * D_Codeを返事します。
	 * @return D_Codeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("D_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDCode() {
		return dCode;
	}

	/**
	 * D_Codeを設定します。
	 * @param dCode D_Code
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("D_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDCode(String dCode) {
		this.dCode = dCode;
	}

	/**
	 * D_WholeNameを返事します。
	 * @return D_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("D_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDWholeName() {
		return dWholeName;
	}

	/**
	 * D_WholeNameを設定します。
	 * @param dWholeName D_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("D_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDWholeName(String dWholeName) {
		this.dWholeName = dWholeName;
	}

}