package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : WorkPlaceInformation クラス <br/>
 * 項目： WorkPlace_Information <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class WorkPlaceInformation extends ResponseWebDtoBase {

	/**
	 * 項目： WholeName <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeName;
	/**
	 * 項目： Address_ZipCode <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String addressZipCode;
	/**
	 * 項目： WholeAddress1 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeAddress1;
	/**
	 * 項目： WholeAddress2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeAddress2;
	/**
	 * 項目： PhoneNumber <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String phoneNumber;
	/**
	 * WholeNameを返事します。
	 * @return WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeName() {
		return wholeName;
	}

	/**
	 * WholeNameを設定します。
	 * @param wholeName WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeName(String wholeName) {
		this.wholeName = wholeName;
	}

	/**
	 * Address_ZipCodeを返事します。
	 * @return Address_ZipCodeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAddressZipCode() {
		return addressZipCode;
	}

	/**
	 * Address_ZipCodeを設定します。
	 * @param addressZipCode Address_ZipCode
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}

	/**
	 * WholeAddress1を返事します。
	 * @return WholeAddress1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeAddress1() {
		return wholeAddress1;
	}

	/**
	 * WholeAddress1を設定します。
	 * @param wholeAddress1 WholeAddress1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeAddress1(String wholeAddress1) {
		this.wholeAddress1 = wholeAddress1;
	}

	/**
	 * WholeAddress2を返事します。
	 * @return WholeAddress2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeAddress2() {
		return wholeAddress2;
	}

	/**
	 * WholeAddress2を設定します。
	 * @param wholeAddress2 WholeAddress2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeAddress2(String wholeAddress2) {
		this.wholeAddress2 = wholeAddress2;
	}

	/**
	 * PhoneNumberを返事します。
	 * @return PhoneNumberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * PhoneNumberを設定します。
	 * @param phoneNumber PhoneNumber
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

}