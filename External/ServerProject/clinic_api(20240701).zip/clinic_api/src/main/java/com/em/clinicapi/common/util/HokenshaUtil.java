package com.em.clinicapi.common.util;

import com.em.clinicapi.common.constants.enumerations.EmEnum;

public class HokenshaUtil {

    public static boolean isIryoHoken(String hokenKbn) {
        if (!StringUtil.isNullOrEmpty(hokenKbn)) {
            return hokenKbn.equals(EmEnum.HokenKbn.KOKUHO.getValue()) ||
                    hokenKbn.equals(EmEnum.HokenKbn.SHAHO.getValue()) ||
                    hokenKbn.equals(EmEnum.HokenKbn.KOUHI.getValue());
        }

        return false;
    }

    public static boolean isJihi(String hokenKbn) {
        if (!StringUtil.isNullOrEmpty(hokenKbn)) {
            return hokenKbn.equals(EmEnum.HokenKbn.JIHI.getValue());
        }

        return false;
    }

}
