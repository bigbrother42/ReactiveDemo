package com.em.clinicapi.webdto.response.patient;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : PatientInformation クラス <br/>
 * 項目： Patient_Information <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class PatientInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Patient_ID <br/>
	 * 説明： <br/>
	 *       患者の患者SEQを返却 <br/>
	 * 備考： <br/>
	 *       123.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Patient_ID")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String patientId;
	/**
	 * 項目： Patient_NO <br/>
	 * 説明： <br/>
	 *       患者の患者番号を返却 <br/>
	 * 備考： <br/>
	 *       123.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Patient_NO")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String patientNo;
	/**
	 * 項目： Karte_NO <br/>
	 * 説明： <br/>
	 *       患者のカルテ番号を返却 <br/>
	 * 備考： <br/>
	 *       123.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Karte_NO")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String karteNo;
	/**
	 * 項目： WholeName <br/>
	 * 説明： <br/>
	 *       患者の漢字氏名を返却 <br/>
	 * 備考： <br/>
	 *       ”患者　太郎” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeName;
	/**
	 * 項目： WholeName_inKana <br/>
	 * 説明： <br/>
	 *       患者のカナ氏名を返却 <br/>
	 * 備考： <br/>
	 *       ”ｶﾝｼﾞｬ ﾀﾛｳ" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName_inKana")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeNameInKana;
	/**
	 * 項目： BirthDate <br/>
	 * 説明： <br/>
	 *       患者の生年月日を返却 <br/>
	 * 備考： <br/>
	 *       "2000-01-01" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("BirthDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String birthDate;
	/**
	 * 項目： Sex <br/>
	 * 説明： <br/>
	 *       患者の性別を返却　(男:1、女:2) <br/>
	 * 備考： <br/>
	 *       ”1” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Sex")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String sex;
	/**
	 * 項目： HouseHolder_WholeName <br/>
	 * 説明： <br/>
	 *       設定するものがないので空値 <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HouseHolder_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String houseHolderWholeName;
	/**
	 * 項目： Relationship <br/>
	 * 説明： <br/>
	 *       〃 <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Relationship")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String relationship;
	/**
	 * 項目： Home_Address_Information <br/>
	 */
	@Valid
		@JsonProperty("Home_Address_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private HomeAddressInformation homeAddressInformation;
	/**
	 * 項目： WorkPlace_Information <br/>
	 */
	@Valid
		@JsonProperty("WorkPlace_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private WorkPlaceInformation workPlaceInformation;
	/**
	 * 項目： Contact_Information <br/>
	 */
	@Valid
		@JsonProperty("Contact_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ContactInformation contactInformation;
	/**
	 * 項目： Home2_Information <br/>
	 */
	@Valid
		@JsonProperty("Home2_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Home2Information home2Information;
	/**
	 * 項目： Contraindication1 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Contraindication1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String contraindication1;
	/**
	 * 項目： Contraindication2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Contraindication2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String contraindication2;
	/**
	 * 項目： Allergy1 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Allergy1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String allergy1;
	/**
	 * 項目： Allergy2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Allergy2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String allergy2;
	/**
	 * 項目： Infection1 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Infection1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String infection1;
	/**
	 * 項目： Infection2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Infection2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String infection2;
	/**
	 * 項目： Comment1 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Comment1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String comment1;
	/**
	 * 項目： Comment2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Comment2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String comment2;
	/**
	 * 項目： TestPatient_Flag <br/>
	 * 説明： <br/>
	 *       テスト患者であれば”1” <br/>
	 *       そうでない場合は”0” <br/>
	 * 備考： <br/>
	 *       ”0” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("TestPatient_Flag")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String testPatientFlag;
	/**
	 * 項目： Death_Flag <br/>
	 * 説明： <br/>
	 *       死亡時は”1” <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Death_Flag")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String deathFlag;
	/**
	 * 項目： Occupation <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Occupation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String occupation;
	/**
	 * 項目： NickName <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("NickName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String nickName;
	/**
	 * 項目： CellularNumber <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("CellularNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String cellularNumber;
	/**
	 * 項目： FaxNumber <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FaxNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String faxNumber;
	/**
	 * 項目： EmailAddress <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("EmailAddress")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String emailAddress;
	/**
	 * 項目： Reduction_Reason <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Reason")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String reductionReason;
	/**
	 * 項目： Reduction_Reason_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Reason_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String reductionReasonName;
	/**
	 * 項目： Discount <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discount")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String discount;
	/**
	 * 項目： Discount_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discount_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String discountName;
	/**
	 * 項目： Condition1 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String condition1;
	/**
	 * 項目： Condition1_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition1_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String condition1Name;
	/**
	 * 項目： Condition2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String condition2;
	/**
	 * 項目： Condition2_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition2_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String condition2Name;
	/**
	 * 項目： Condition3 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition3")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String condition3;
	/**
	 * 項目： Condition3_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition3_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String condition3Name;
	/**
	 * 項目： Ic_Code <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ic_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String icCode;
	/**
	 * 項目： Ic_Code_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ic_Code_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String icCodeName;
	/**
	 * 項目： Community_Cid <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Cid")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String communityCid;
	/**
	 * 項目： Community_Cid_Agree <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Cid_Agree")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String communityCidAgree;
	/**
	 * 項目： FirstVisit_Date <br/>
	 * 説明： <br/>
	 *       初回初診を算定した日付を返却 <br/>
	 * 備考： <br/>
	 *       "2024-02-03" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FirstVisit_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String firstVisitDate;
	/**
	 * 項目： LastVisit_Date <br/>
	 * 説明： <br/>
	 *       最終来院日を返却 <br/>
	 * 備考： <br/>
	 *       "2024-03-05" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("LastVisit_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String lastVisitDate;
	/**
	 * 項目： Outpatient_Class <br/>
	 * 説明： <br/>
	 *       入院中 <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outpatient_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String outpatientClass;
	/**
	 * 項目： Admission_Date <br/>
	 * 説明： <br/>
	 *       入院日 <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Admission_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String admissionDate;
	/**
	 * 項目： Discharge_Date <br/>
	 * 説明： <br/>
	 *       退院日 <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discharge_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dischargeDate;
	/**
	 * 項目： Facility_Seq <br/>
	 * 説明： <br/>
	 *       入居施設より該当患者の施設SEQを返却 <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Facility_Seq")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String facilitySeq;
	/**
	 * 項目： HealthInsurance_Information <br/>
	 * 説明： <br/>
	 *       保険組み合わせ情報 <br/>
	 */
		@JsonProperty("HealthInsurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private HealthInsuranceInformationArr healthInsuranceInformationArr;

	/**
	 * 項目： Care_Information <br/>
	 * 説明： <br/>
	 *       介護情報 <br/>
	 */
	@Valid
		@JsonProperty("Care_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private CareInformation careInformation;
	/**
	 * 項目： Personally_Information <br/>
	 * 説明： <br/>
	 *       患者個別情報 <br/>
	 */
	@Valid
		@JsonProperty("Personally_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PersonallyInformation personallyInformation;
	/**
	 * 項目： Individual_Number <br/>
	 * 説明： <br/>
	 *       個人番号情報 <br/>
	 */
		@JsonProperty("Individual_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private IndividualNumberArr individualNumberArr;
	/**
	 * 項目： Auto_Management_Information <br/>
	 * 説明： <br/>
	 *       管理料等自動算定情報 <br/>
	 */
		@JsonProperty("Auto_Management_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AutoManagementInformationArr autoManagementInformationArr;
	/**
	 * 項目： Patient_Contra_Information <br/>
	 * 説明： <br/>
	 *       患者禁忌薬剤情報 <br/>
	 */
	@Valid
		@JsonProperty("Patient_Contra_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PatientContraInformation patientContraInformation;
	/**
	 * Patient_IDを返事します。
	 * @return Patient_IDの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Patient_ID")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPatientId() {
		return patientId;
	}

	/**
	 * Patient_IDを設定します。
	 * @param patientId Patient_ID
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Patient_ID")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	/**
	 * Patient_NOを返事します。
	 * @return Patient_NOの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Patient_NO")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPatientNo() {
		return patientNo;
	}

	/**
	 * Patient_NOを設定します。
	 * @param patientNo Patient_NO
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Patient_NO")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPatientNo(String patientNo) {
		this.patientNo = patientNo;
	}

	/**
	 * Karte_NOを返事します。
	 * @return Karte_NOの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Karte_NO")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getKarteNo() {
		return karteNo;
	}

	/**
	 * Karte_NOを設定します。
	 * @param karteNo Karte_NO
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Karte_NO")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setKarteNo(String karteNo) {
		this.karteNo = karteNo;
	}

	/**
	 * WholeNameを返事します。
	 * @return WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeName() {
		return wholeName;
	}

	/**
	 * WholeNameを設定します。
	 * @param wholeName WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeName(String wholeName) {
		this.wholeName = wholeName;
	}

	/**
	 * WholeName_inKanaを返事します。
	 * @return WholeName_inKanaの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName_inKana")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeNameInKana() {
		return wholeNameInKana;
	}

	/**
	 * WholeName_inKanaを設定します。
	 * @param wholeNameInKana WholeName_inKana
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName_inKana")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeNameInKana(String wholeNameInKana) {
		this.wholeNameInKana = wholeNameInKana;
	}

	/**
	 * BirthDateを返事します。
	 * @return BirthDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("BirthDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getBirthDate() {
		return birthDate;
	}

	/**
	 * BirthDateを設定します。
	 * @param birthDate BirthDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("BirthDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	/**
	 * Sexを返事します。
	 * @return Sexの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Sex")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getSex() {
		return sex;
	}

	/**
	 * Sexを設定します。
	 * @param sex Sex
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Sex")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setSex(String sex) {
		this.sex = sex;
	}

	/**
	 * HouseHolder_WholeNameを返事します。
	 * @return HouseHolder_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HouseHolder_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHouseHolderWholeName() {
		return houseHolderWholeName;
	}

	/**
	 * HouseHolder_WholeNameを設定します。
	 * @param houseHolderWholeName HouseHolder_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HouseHolder_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHouseHolderWholeName(String houseHolderWholeName) {
		this.houseHolderWholeName = houseHolderWholeName;
	}

	/**
	 * Relationshipを返事します。
	 * @return Relationshipの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Relationship")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRelationship() {
		return relationship;
	}

	/**
	 * Relationshipを設定します。
	 * @param relationship Relationship
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Relationship")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 * Home_Address_Informationを返事します。
	 * @return Home_Address_Informationの値
	 */
		@JsonProperty("Home_Address_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public HomeAddressInformation getHomeAddressInformation() {
		return homeAddressInformation;
	}

	/**
	 * Home_Address_Informationを設定します。
	 * @param homeAddressInformation Home_Address_Information
	 */
		@JsonProperty("Home_Address_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHomeAddressInformation(HomeAddressInformation homeAddressInformation) {
		this.homeAddressInformation = homeAddressInformation;
	}

	/**
	 * WorkPlace_Informationを返事します。
	 * @return WorkPlace_Informationの値
	 */
		@JsonProperty("WorkPlace_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public WorkPlaceInformation getWorkPlaceInformation() {
		return workPlaceInformation;
	}

	/**
	 * WorkPlace_Informationを設定します。
	 * @param workPlaceInformation WorkPlace_Information
	 */
		@JsonProperty("WorkPlace_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWorkPlaceInformation(WorkPlaceInformation workPlaceInformation) {
		this.workPlaceInformation = workPlaceInformation;
	}

	/**
	 * Contact_Informationを返事します。
	 * @return Contact_Informationの値
	 */
		@JsonProperty("Contact_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public ContactInformation getContactInformation() {
		return contactInformation;
	}

	/**
	 * Contact_Informationを設定します。
	 * @param contactInformation Contact_Information
	 */
		@JsonProperty("Contact_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setContactInformation(ContactInformation contactInformation) {
		this.contactInformation = contactInformation;
	}

	/**
	 * Home2_Informationを返事します。
	 * @return Home2_Informationの値
	 */
		@JsonProperty("Home2_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public Home2Information getHome2Information() {
		return home2Information;
	}

	/**
	 * Home2_Informationを設定します。
	 * @param home2Information Home2_Information
	 */
		@JsonProperty("Home2_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHome2Information(Home2Information home2Information) {
		this.home2Information = home2Information;
	}

	/**
	 * Contraindication1を返事します。
	 * @return Contraindication1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Contraindication1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getContraindication1() {
		return contraindication1;
	}

	/**
	 * Contraindication1を設定します。
	 * @param contraindication1 Contraindication1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Contraindication1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setContraindication1(String contraindication1) {
		this.contraindication1 = contraindication1;
	}

	/**
	 * Contraindication2を返事します。
	 * @return Contraindication2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Contraindication2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getContraindication2() {
		return contraindication2;
	}

	/**
	 * Contraindication2を設定します。
	 * @param contraindication2 Contraindication2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Contraindication2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setContraindication2(String contraindication2) {
		this.contraindication2 = contraindication2;
	}

	/**
	 * Allergy1を返事します。
	 * @return Allergy1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Allergy1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAllergy1() {
		return allergy1;
	}

	/**
	 * Allergy1を設定します。
	 * @param allergy1 Allergy1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Allergy1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAllergy1(String allergy1) {
		this.allergy1 = allergy1;
	}

	/**
	 * Allergy2を返事します。
	 * @return Allergy2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Allergy2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAllergy2() {
		return allergy2;
	}

	/**
	 * Allergy2を設定します。
	 * @param allergy2 Allergy2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Allergy2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAllergy2(String allergy2) {
		this.allergy2 = allergy2;
	}

	/**
	 * Infection1を返事します。
	 * @return Infection1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Infection1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInfection1() {
		return infection1;
	}

	/**
	 * Infection1を設定します。
	 * @param infection1 Infection1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Infection1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInfection1(String infection1) {
		this.infection1 = infection1;
	}

	/**
	 * Infection2を返事します。
	 * @return Infection2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Infection2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInfection2() {
		return infection2;
	}

	/**
	 * Infection2を設定します。
	 * @param infection2 Infection2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Infection2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInfection2(String infection2) {
		this.infection2 = infection2;
	}

	/**
	 * Comment1を返事します。
	 * @return Comment1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Comment1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getComment1() {
		return comment1;
	}

	/**
	 * Comment1を設定します。
	 * @param comment1 Comment1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Comment1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setComment1(String comment1) {
		this.comment1 = comment1;
	}

	/**
	 * Comment2を返事します。
	 * @return Comment2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Comment2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getComment2() {
		return comment2;
	}

	/**
	 * Comment2を設定します。
	 * @param comment2 Comment2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Comment2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setComment2(String comment2) {
		this.comment2 = comment2;
	}

	/**
	 * TestPatient_Flagを返事します。
	 * @return TestPatient_Flagの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("TestPatient_Flag")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getTestPatientFlag() {
		return testPatientFlag;
	}

	/**
	 * TestPatient_Flagを設定します。
	 * @param testPatientFlag TestPatient_Flag
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("TestPatient_Flag")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setTestPatientFlag(String testPatientFlag) {
		this.testPatientFlag = testPatientFlag;
	}

	/**
	 * Death_Flagを返事します。
	 * @return Death_Flagの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Death_Flag")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDeathFlag() {
		return deathFlag;
	}

	/**
	 * Death_Flagを設定します。
	 * @param deathFlag Death_Flag
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Death_Flag")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDeathFlag(String deathFlag) {
		this.deathFlag = deathFlag;
	}

	/**
	 * Occupationを返事します。
	 * @return Occupationの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Occupation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOccupation() {
		return occupation;
	}

	/**
	 * Occupationを設定します。
	 * @param occupation Occupation
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Occupation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	/**
	 * NickNameを返事します。
	 * @return NickNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("NickName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getNickName() {
		return nickName;
	}

	/**
	 * NickNameを設定します。
	 * @param nickName NickName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("NickName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}

	/**
	 * CellularNumberを返事します。
	 * @return CellularNumberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("CellularNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCellularNumber() {
		return cellularNumber;
	}

	/**
	 * CellularNumberを設定します。
	 * @param cellularNumber CellularNumber
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("CellularNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCellularNumber(String cellularNumber) {
		this.cellularNumber = cellularNumber;
	}

	/**
	 * FaxNumberを返事します。
	 * @return FaxNumberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FaxNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getFaxNumber() {
		return faxNumber;
	}

	/**
	 * FaxNumberを設定します。
	 * @param faxNumber FaxNumber
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FaxNumber")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	/**
	 * EmailAddressを返事します。
	 * @return EmailAddressの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("EmailAddress")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * EmailAddressを設定します。
	 * @param emailAddress EmailAddress
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("EmailAddress")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/**
	 * Reduction_Reasonを返事します。
	 * @return Reduction_Reasonの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Reason")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getReductionReason() {
		return reductionReason;
	}

	/**
	 * Reduction_Reasonを設定します。
	 * @param reductionReason Reduction_Reason
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Reason")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setReductionReason(String reductionReason) {
		this.reductionReason = reductionReason;
	}

	/**
	 * Reduction_Reason_Nameを返事します。
	 * @return Reduction_Reason_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Reason_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getReductionReasonName() {
		return reductionReasonName;
	}

	/**
	 * Reduction_Reason_Nameを設定します。
	 * @param reductionReasonName Reduction_Reason_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Reason_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setReductionReasonName(String reductionReasonName) {
		this.reductionReasonName = reductionReasonName;
	}

	/**
	 * Discountを返事します。
	 * @return Discountの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discount")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDiscount() {
		return discount;
	}

	/**
	 * Discountを設定します。
	 * @param discount Discount
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discount")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDiscount(String discount) {
		this.discount = discount;
	}

	/**
	 * Discount_Nameを返事します。
	 * @return Discount_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discount_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDiscountName() {
		return discountName;
	}

	/**
	 * Discount_Nameを設定します。
	 * @param discountName Discount_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discount_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	/**
	 * Condition1を返事します。
	 * @return Condition1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCondition1() {
		return condition1;
	}

	/**
	 * Condition1を設定します。
	 * @param condition1 Condition1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCondition1(String condition1) {
		this.condition1 = condition1;
	}

	/**
	 * Condition1_Nameを返事します。
	 * @return Condition1_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition1_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCondition1Name() {
		return condition1Name;
	}

	/**
	 * Condition1_Nameを設定します。
	 * @param condition1Name Condition1_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition1_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCondition1Name(String condition1Name) {
		this.condition1Name = condition1Name;
	}

	/**
	 * Condition2を返事します。
	 * @return Condition2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCondition2() {
		return condition2;
	}

	/**
	 * Condition2を設定します。
	 * @param condition2 Condition2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCondition2(String condition2) {
		this.condition2 = condition2;
	}

	/**
	 * Condition2_Nameを返事します。
	 * @return Condition2_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition2_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCondition2Name() {
		return condition2Name;
	}

	/**
	 * Condition2_Nameを設定します。
	 * @param condition2Name Condition2_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition2_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCondition2Name(String condition2Name) {
		this.condition2Name = condition2Name;
	}

	/**
	 * Condition3を返事します。
	 * @return Condition3の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition3")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCondition3() {
		return condition3;
	}

	/**
	 * Condition3を設定します。
	 * @param condition3 Condition3
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition3")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCondition3(String condition3) {
		this.condition3 = condition3;
	}

	/**
	 * Condition3_Nameを返事します。
	 * @return Condition3_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition3_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCondition3Name() {
		return condition3Name;
	}

	/**
	 * Condition3_Nameを設定します。
	 * @param condition3Name Condition3_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Condition3_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCondition3Name(String condition3Name) {
		this.condition3Name = condition3Name;
	}

	/**
	 * Ic_Codeを返事します。
	 * @return Ic_Codeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ic_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getIcCode() {
		return icCode;
	}

	/**
	 * Ic_Codeを設定します。
	 * @param icCode Ic_Code
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ic_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setIcCode(String icCode) {
		this.icCode = icCode;
	}

	/**
	 * Ic_Code_Nameを返事します。
	 * @return Ic_Code_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ic_Code_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getIcCodeName() {
		return icCodeName;
	}

	/**
	 * Ic_Code_Nameを設定します。
	 * @param icCodeName Ic_Code_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ic_Code_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setIcCodeName(String icCodeName) {
		this.icCodeName = icCodeName;
	}

	/**
	 * Community_Cidを返事します。
	 * @return Community_Cidの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Cid")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCommunityCid() {
		return communityCid;
	}

	/**
	 * Community_Cidを設定します。
	 * @param communityCid Community_Cid
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Cid")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCommunityCid(String communityCid) {
		this.communityCid = communityCid;
	}

	/**
	 * Community_Cid_Agreeを返事します。
	 * @return Community_Cid_Agreeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Cid_Agree")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCommunityCidAgree() {
		return communityCidAgree;
	}

	/**
	 * Community_Cid_Agreeを設定します。
	 * @param communityCidAgree Community_Cid_Agree
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Cid_Agree")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCommunityCidAgree(String communityCidAgree) {
		this.communityCidAgree = communityCidAgree;
	}

	/**
	 * FirstVisit_Dateを返事します。
	 * @return FirstVisit_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FirstVisit_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getFirstVisitDate() {
		return firstVisitDate;
	}

	/**
	 * FirstVisit_Dateを設定します。
	 * @param firstVisitDate FirstVisit_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("FirstVisit_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setFirstVisitDate(String firstVisitDate) {
		this.firstVisitDate = firstVisitDate;
	}

	/**
	 * LastVisit_Dateを返事します。
	 * @return LastVisit_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("LastVisit_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLastVisitDate() {
		return lastVisitDate;
	}

	/**
	 * LastVisit_Dateを設定します。
	 * @param lastVisitDate LastVisit_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("LastVisit_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLastVisitDate(String lastVisitDate) {
		this.lastVisitDate = lastVisitDate;
	}

	/**
	 * Outpatient_Classを返事します。
	 * @return Outpatient_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outpatient_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOutpatientClass() {
		return outpatientClass;
	}

	/**
	 * Outpatient_Classを設定します。
	 * @param outpatientClass Outpatient_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outpatient_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOutpatientClass(String outpatientClass) {
		this.outpatientClass = outpatientClass;
	}

	/**
	 * Admission_Dateを返事します。
	 * @return Admission_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Admission_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAdmissionDate() {
		return admissionDate;
	}

	/**
	 * Admission_Dateを設定します。
	 * @param admissionDate Admission_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Admission_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	/**
	 * Discharge_Dateを返事します。
	 * @return Discharge_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discharge_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDischargeDate() {
		return dischargeDate;
	}

	/**
	 * Discharge_Dateを設定します。
	 * @param dischargeDate Discharge_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Discharge_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDischargeDate(String dischargeDate) {
		this.dischargeDate = dischargeDate;
	}

	/**
	 * Facility_Seqを返事します。
	 * @return Facility_Seqの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Facility_Seq")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getFacilitySeq() {
		return facilitySeq;
	}

	/**
	 * Facility_Seqを設定します。
	 * @param facilitySeq Facility_Seq
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Facility_Seq")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setFacilitySeq(String facilitySeq) {
		this.facilitySeq = facilitySeq;
	}

	/**
	 * HealthInsurance_Informationを返事します。
	 * @return HealthInsurance_Informationの値
	 */
		@JsonProperty("HealthInsurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public HealthInsuranceInformationArr getHealthInsuranceInformationArr() {
		return healthInsuranceInformationArr;
	}

	/**
	 * HealthInsurance_Informationを設定します。
	 * @param healthInsuranceInformationArr HealthInsurance_Information
	 */
		@JsonProperty("HealthInsurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuranceInformationArr(HealthInsuranceInformationArr healthInsuranceInformationArr) {
		this.healthInsuranceInformationArr = healthInsuranceInformationArr;
	}

	/**
	 * Care_Informationを返事します。
	 * @return Care_Informationの値
	 */
		@JsonProperty("Care_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public CareInformation getCareInformation() {
		return careInformation;
	}

	/**
	 * Care_Informationを設定します。
	 * @param careInformation Care_Information
	 */
		@JsonProperty("Care_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCareInformation(CareInformation careInformation) {
		this.careInformation = careInformation;
	}

	/**
	 * Personally_Informationを返事します。
	 * @return Personally_Informationの値
	 */
		@JsonProperty("Personally_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public PersonallyInformation getPersonallyInformation() {
		return personallyInformation;
	}

	/**
	 * Personally_Informationを設定します。
	 * @param personallyInformation Personally_Information
	 */
		@JsonProperty("Personally_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPersonallyInformation(PersonallyInformation personallyInformation) {
		this.personallyInformation = personallyInformation;
	}

	/**
	 * Individual_Numberを返事します。
	 * @return Individual_Numberの値
	 */
	@JsonProperty("Individual_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public IndividualNumberArr getIndividualNumberArr() {
		return individualNumberArr;
	}

	/**
	 * Individual_Numberを設定します。
	 * @param individualNumberArr Individual_Number
	 */
	@JsonProperty("Individual_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setIndividualNumberArr(IndividualNumberArr individualNumberArr) {
		this.individualNumberArr = individualNumberArr;
	}

	/**
	 * Auto_Management_Informationを返事します。
	 * @return Auto_Management_Informationの値
	 */
	@JsonProperty("Auto_Management_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public AutoManagementInformationArr getAutoManagementInformationArr() {
		return autoManagementInformationArr;
	}

	/**
	 * Auto_Management_Informationを設定します。
	 * @param autoManagementInformationArr Auto_Management_Information
	 */
	@JsonProperty("Auto_Management_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAutoManagementInformationArr(AutoManagementInformationArr autoManagementInformationArr) {
		this.autoManagementInformationArr = autoManagementInformationArr;
	}

	/**
	 * Patient_Contra_Informationを返事します。
	 * @return Patient_Contra_Informationの値
	 */
		@JsonProperty("Patient_Contra_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public PatientContraInformation getPatientContraInformation() {
		return patientContraInformation;
	}

	/**
	 * Patient_Contra_Informationを設定します。
	 * @param patientContraInformation Patient_Contra_Information
	 */
		@JsonProperty("Patient_Contra_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPatientContraInformation(PatientContraInformation patientContraInformation) {
		this.patientContraInformation = patientContraInformation;
	}

}