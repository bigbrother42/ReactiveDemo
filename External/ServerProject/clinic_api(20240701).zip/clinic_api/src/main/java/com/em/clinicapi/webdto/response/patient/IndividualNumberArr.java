package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class IndividualNumberArr extends ResponseWebDtoBase {
    /**
     * 項目： Individual_Number <br/>
     * 説明： <br/>
     *       個人番号情報 <br/>
     */
    @JsonProperty("Individual_Number_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<IndividualNumber> individualNumber;

    /**
     * Individual_Numberを返事します。
     * @return Individual_Numberの値
     */
    @JsonProperty("Individual_Number_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<IndividualNumber> getIndividualNumber() {
        return individualNumber;
    }

    /**
     * Individual_Numberを設定します。
     * @param individualNumber Individual_Number
     */
    @JsonProperty("Individual_Number_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setIndividualNumber(List<IndividualNumber> individualNumber) {
        this.individualNumber = individualNumber;
    }
}
