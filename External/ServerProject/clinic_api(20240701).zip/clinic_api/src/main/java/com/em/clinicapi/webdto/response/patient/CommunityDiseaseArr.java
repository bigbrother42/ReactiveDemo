package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class CommunityDiseaseArr extends ResponseWebDtoBase {
    /**
     * 項目： Community_Disease <br/>
     */
    @JsonProperty("Community_Disease_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<CommunityDisease> communityDisease;

    /**
     * Community_Diseaseを返事します。
     * @return Community_Diseaseの値
     */
    @JsonProperty("Community_Disease_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<CommunityDisease> getCommunityDisease() {
        return communityDisease;
    }

    /**
     * Community_Diseaseを設定します。
     * @param communityDisease Community_Disease
     */
    @JsonProperty("Community_Disease_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setCommunityDisease(List<CommunityDisease> communityDisease) {
        this.communityDisease = communityDisease;
    }
}
