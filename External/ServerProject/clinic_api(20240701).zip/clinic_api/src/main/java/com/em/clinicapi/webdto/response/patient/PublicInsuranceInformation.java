package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : PublicInsuranceInformation クラス <br/>
 * 項目： PublicInsurance_Information <br/>
 * 説明： <br/>
 *       公費情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class PublicInsuranceInformation extends ResponseWebDtoBase {

	/**
	 * 項目： PublicInsurance_Class <br/>
	 * 説明： <br/>
	 *       公費Mの法別番号を返却 <br/>
	 * 備考： <br/>
	 *       "19" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String publicInsuranceClass;
	/**
	 * 項目： PublicInsurance_Name <br/>
	 * 説明： <br/>
	 *       公費Mの公費名称を返却 <br/>
	 * 備考： <br/>
	 *       "原爆援護法（一般疾病医療）" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurance_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String publicInsuranceName;
	/**
	 * 項目： PublicInsurer_Number <br/>
	 * 説明： <br/>
	 *       副保険の負担者番号を返却 <br/>
	 * 備考： <br/>
	 *       "88138011" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurer_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String publicInsurerNumber;
	/**
	 * 項目： PublicInsuredPerson_Number <br/>
	 * 説明： <br/>
	 *       副保険の受給者番号を返却 <br/>
	 * 備考： <br/>
	 *       "1111111" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String publicInsuredPersonNumber;
	/**
	 * 項目： Rate_Admission <br/>
	 * 説明： <br/>
	 *       入院負担率 <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rate_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String rateAdmission;
	/**
	 * 項目： Money_Admission <br/>
	 * 説明： <br/>
	 *       入院固定額 <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Money_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String moneyAdmission;
	/**
	 * 項目： Rate_Outpatient <br/>
	 * 説明： <br/>
	 *       副保険歴の患者負担割合を返却 <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rate_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String rateOutpatient;
	/**
	 * 項目： Money_Outpatient <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Money_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String moneyOutpatient;
	/**
	 * 項目： Certificate_IssuedDate <br/>
	 * 説明： <br/>
	 *       副保険の開始日を返却　※未指定の場合は1900-01-01 <br/>
	 * 備考： <br/>
	 *       "2023-03-01" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_IssuedDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateIssuedDate;
	/**
	 * 項目： Certificate_ExpiredDate <br/>
	 * 説明： <br/>
	 *       副保険の終了日を返却　※未指定の場合は1900-01-01 <br/>
	 * 備考： <br/>
	 *       "2023-06-30" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateExpiredDate;
	/**
	 * 項目： Certificate_CheckDate <br/>
	 * 備考： <br/>
	 *       "9999-12-31" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_CheckDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateCheckDate;
	/**
	 * PublicInsurance_Classを返事します。
	 * @return PublicInsurance_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPublicInsuranceClass() {
		return publicInsuranceClass;
	}

	/**
	 * PublicInsurance_Classを設定します。
	 * @param publicInsuranceClass PublicInsurance_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPublicInsuranceClass(String publicInsuranceClass) {
		this.publicInsuranceClass = publicInsuranceClass;
	}

	/**
	 * PublicInsurance_Nameを返事します。
	 * @return PublicInsurance_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurance_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPublicInsuranceName() {
		return publicInsuranceName;
	}

	/**
	 * PublicInsurance_Nameを設定します。
	 * @param publicInsuranceName PublicInsurance_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurance_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPublicInsuranceName(String publicInsuranceName) {
		this.publicInsuranceName = publicInsuranceName;
	}

	/**
	 * PublicInsurer_Numberを返事します。
	 * @return PublicInsurer_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurer_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPublicInsurerNumber() {
		return publicInsurerNumber;
	}

	/**
	 * PublicInsurer_Numberを設定します。
	 * @param publicInsurerNumber PublicInsurer_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsurer_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPublicInsurerNumber(String publicInsurerNumber) {
		this.publicInsurerNumber = publicInsurerNumber;
	}

	/**
	 * PublicInsuredPerson_Numberを返事します。
	 * @return PublicInsuredPerson_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPublicInsuredPersonNumber() {
		return publicInsuredPersonNumber;
	}

	/**
	 * PublicInsuredPerson_Numberを設定します。
	 * @param publicInsuredPersonNumber PublicInsuredPerson_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PublicInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPublicInsuredPersonNumber(String publicInsuredPersonNumber) {
		this.publicInsuredPersonNumber = publicInsuredPersonNumber;
	}

	/**
	 * Rate_Admissionを返事します。
	 * @return Rate_Admissionの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rate_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRateAdmission() {
		return rateAdmission;
	}

	/**
	 * Rate_Admissionを設定します。
	 * @param rateAdmission Rate_Admission
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rate_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRateAdmission(String rateAdmission) {
		this.rateAdmission = rateAdmission;
	}

	/**
	 * Money_Admissionを返事します。
	 * @return Money_Admissionの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Money_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMoneyAdmission() {
		return moneyAdmission;
	}

	/**
	 * Money_Admissionを設定します。
	 * @param moneyAdmission Money_Admission
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Money_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMoneyAdmission(String moneyAdmission) {
		this.moneyAdmission = moneyAdmission;
	}

	/**
	 * Rate_Outpatientを返事します。
	 * @return Rate_Outpatientの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rate_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRateOutpatient() {
		return rateOutpatient;
	}

	/**
	 * Rate_Outpatientを設定します。
	 * @param rateOutpatient Rate_Outpatient
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rate_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRateOutpatient(String rateOutpatient) {
		this.rateOutpatient = rateOutpatient;
	}

	/**
	 * Money_Outpatientを返事します。
	 * @return Money_Outpatientの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Money_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMoneyOutpatient() {
		return moneyOutpatient;
	}

	/**
	 * Money_Outpatientを設定します。
	 * @param moneyOutpatient Money_Outpatient
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Money_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMoneyOutpatient(String moneyOutpatient) {
		this.moneyOutpatient = moneyOutpatient;
	}

	/**
	 * Certificate_IssuedDateを返事します。
	 * @return Certificate_IssuedDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_IssuedDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateIssuedDate() {
		return certificateIssuedDate;
	}

	/**
	 * Certificate_IssuedDateを設定します。
	 * @param certificateIssuedDate Certificate_IssuedDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_IssuedDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateIssuedDate(String certificateIssuedDate) {
		this.certificateIssuedDate = certificateIssuedDate;
	}

	/**
	 * Certificate_ExpiredDateを返事します。
	 * @return Certificate_ExpiredDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateExpiredDate() {
		return certificateExpiredDate;
	}

	/**
	 * Certificate_ExpiredDateを設定します。
	 * @param certificateExpiredDate Certificate_ExpiredDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateExpiredDate(String certificateExpiredDate) {
		this.certificateExpiredDate = certificateExpiredDate;
	}

	/**
	 * Certificate_CheckDateを返事します。
	 * @return Certificate_CheckDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_CheckDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateCheckDate() {
		return certificateCheckDate;
	}

	/**
	 * Certificate_CheckDateを設定します。
	 * @param certificateCheckDate Certificate_CheckDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_CheckDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateCheckDate(String certificateCheckDate) {
		this.certificateCheckDate = certificateCheckDate;
	}

}