package com.em.clinicapi.common.db;

import com.em.clinicapi.common.cache.ServerReplicationManager;
import com.em.clinicapi.common.util.LogUtil;
import com.em.clinicapi.webdto.ReplicationMWebDto;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.datasource.lookup.DataSourceLookup;
import org.springframework.jdbc.datasource.lookup.DataSourceLookupFailureException;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.sql.DataSource;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class EmDataSourceLookup implements DataSourceLookup {

    public static final String DEFAULT_DATA_SOURCE_NAME = "DEFAULT";
    public static final String DEFAULT_DATA_SOURCE_SCHEMA = "public";

    @Value("${spring.datasource.driver-class-name}")
    private String datasourceDriver;

    @Value("${spring.datasource.url}")
    private String datasourceUrl;

    @Value("${spring.datasource.username}")
    private String datasourceUsername;

    @Value("${spring.datasource.password}")
    private String datasourcePassword;

    @Value("${api.datasource.driver-class-name:}")
    private String emDatasourceDriver;

    @Value("${api.datasource.domain-name:}")
    private String emDatasourceDomainName;

    @Value("${api.datasource.port-number:}")
    private String emDatasourcePortNumber;

    @Value("${api.datasource.username:}")
    private String emDatasourceUsername;

    @Value("${api.datasource.password:}")
    private String emDatasourcePassword;

    @Value("${api.datasource.useCache:true}")
    private boolean useCache;

    /**
     * コネクションプールの最小確保接続数
     * 指定なしの場合：5
     */
    @Value("${api.datasource.hikari.minimumIdle:5}")
    private int hikariMinimumIdle;
    /**
     * コネクションプール最大数
     * （接続先単位でコネクションプールが作成されるため、想定される接続先のDB数と、warファイルの数を考慮する必要があります）
     * 指定なしの場合：25
     */
    @Value("${api.datasource.hikari.maximumPoolSize:25}")
    private int hikariMaximumPoolSize;
    /**
     * コネクションプールから接続を取得する際のタイムアウト時間（ミリ秒）
     * 指定なしの場合：10秒（10000ミリ秒）
     */
    @Value("${api.datasource.hikari.connectionTimeout:10000}")
    private long hikariConnectionTimeout;
    /**
     * アイドル状態のコネクションがプールから削除されるまでの時間（ミリ秒）
     * 指定なしの場合：10分（600000ミリ秒）
     */
    @Value("${api.datasource.hikari.idleTimeout:600000}")
    private long hikariIdleTimeout;
    /**
     * あるコネクションが作成されてから破棄されるまでの時間（ミリ秒）
     * 使用中だった場合は、close()が呼び出された後に破棄される。
     * この値が短すぎると、使用済みのコネクション（プールから除去されたコネクション）がメモリ上に残り続けることとなる（そのうちGCで回収されるが、いつ回収されるかは不定）。
     * 指定なしの場合：30分（1800000ミリ秒）
     */
    @Value("${api.datasource.hikari.maxLifetime:1800000}")
    private long hikariMaxLifetime;

    /**
     * 接続初期化に実行するSQL
     */
    @Value("${api.datasource.hikari.connectionInitSql:select 1}")
    private String hikariConnectionInitSql;

    private ConcurrentHashMap<String, DataSource> dataSourcePool = new ConcurrentHashMap<>();

    /*
     * (non-Javadoc)
     *
     * @see
     * org.springframework.jdbc.datasource.lookup.DataSourceLookup#getDataSource(
     * java.lang.String)
     */
    @Override
    public DataSource getDataSource(String dataSourceName) throws DataSourceLookupFailureException {
        DataSource dataSource = null;
        if (dataSourceName.equals(DEFAULT_DATA_SOURCE_NAME)) {
            dataSource = getDefaultDataSource();
            LogUtil.getLogger(this).debug("Default DataSource has been loaded successfully.");
        } else {
            dataSource = resolveDataSource(dataSourceName);
        }
        return dataSource;
    }

    /**
     *
     * @param dataSourceName
     * @return
     */
    public DataSource resolveDataSource(String dataSourceName) {
        DataSource dataSource = getDefaultDataSource();
        try {
            ReplicationMWebDto groupReplication = ServerReplicationManager.getCurrentGroupReplication();
            ReplicationMWebDto customerReplication = ServerReplicationManager.getCurrentCustomerReplication();
            if (dataSourceName.equalsIgnoreCase("CUSTOMER")
                    || dataSourceName.equalsIgnoreCase("COMMON")) {
                if (customerReplication != null) {
                    dataSource = getDataSourceOfReplication(customerReplication);
                } else if (groupReplication != null) {
                    dataSource = getDataSourceOfReplication(groupReplication);
                }
            } else if (dataSourceName.equalsIgnoreCase("GROUP")) {
                if (groupReplication != null) {
                    dataSource = getDataSourceOfReplication(groupReplication);
                }
            }
        } catch (Exception ex) {
            LogUtil.getLogger(this).error(ex.getMessage(), ex);
            dataSource = getDefaultDataSource();
        }
        return dataSource;
    }

    /**
     * ディフォルトのデータソースを取得する
     *
     * @return ディフォルトのデータソースオブジェクト
     */
    public DataSource getDefaultDataSource() {
        DataSource dataSource = createDataSource(this.datasourceDriver, this.datasourceUrl, this.datasourceUsername,
                this.datasourcePassword);
//		DataSource persistedDataSource = dataSourcePool.putIfAbsent(DEFAULT_DATA_SOURCE_NAME, dataSource);
//		return useCache && persistedDataSource != null ? persistedDataSource : dataSource;
        // useCache プロパティの考慮はどこまで必要か？
        return dataSource;
    }

    /**
     * データソースを作成する
     *
     * @param driverClassName データベースドライバー
     * @param url             DBインスタンスの接続先URL
     * @param username        接続するの時に使用ユーザーのログインID
     * @param password        接続するの時に使用ユーザーのパスワード
     * @return データソースオブジェクト
     */
    public DataSource createDataSource(String driverClassName, String url, String username, String password) {
        return createDataSource(driverClassName, url, username, password, DEFAULT_DATA_SOURCE_SCHEMA);
    }

    /**
     * データソースを作成する
     *
     * @param driverClassName データベースドライバー
     * @param url             DBインスタンスの接続先URL
     * @param username        接続するの時に使用ユーザーのログインID
     * @param password        接続するの時に使用ユーザーのパスワード
     * @param schema          スキーマ名
     * @return データソースオブジェクト
     */
    public DataSource createDataSource(String driverClassName, String url, String username, String password,
                                       String schema) {

        // Effective Java 第３版　項目81 の記載を参考に実装
        // atomicに処理するため、putIfAbsentを使う必要がある。
        // ただ、毎回 createDataSource を実行するのも避けたいところではあることへの対応

        // HikariDataSourceにおいては new したタイミングで必要なコネクションが生成される。
        // したがって、DataSource作成⇒キャッシュチェック の順番ではなく、
        // キャッシュチェック ⇒ DataSource作成 の順番でないと、DB接続数をすぐに超過してしまう。

        DataSource result = this.dataSourcePool.get(url);
        if (result == null) {

            HikariConfig hikariConfig = new HikariConfig();
            hikariConfig.setDriverClassName(driverClassName);
            hikariConfig.setJdbcUrl(url);
            hikariConfig.setUsername(username);
            hikariConfig.setPassword(password);

            // 以下、コネクションプールの設定
            hikariConfig.setMinimumIdle(this.hikariMinimumIdle); // デフォルト：-1
            hikariConfig.setMaximumPoolSize(this.hikariMaximumPoolSize); // デフォルト：-1（無制限）
            hikariConfig.setConnectionTimeout(this.hikariConnectionTimeout); // コネクションを取得できなかったらSQLException（デフォルト：30秒）
            // setValidationTimeout : 指定しない（デフォルト：5秒）　コネクション作成時、有効になるまで最長５秒待つ？
            hikariConfig.setIdleTimeout(this.hikariIdleTimeout); // デフォルト：10分
            hikariConfig.setMaxLifetime(this.hikariMaxLifetime); // デフォルト：30分
            // setLeakDetectionThreshold : 指定しない（リーク検出の支援にはなるが、クラスヒストグラムで監視することで代用する）
            hikariConfig.setConnectionInitSql(this.hikariConnectionInitSql); // 接続初期化時にSQLを実行して接続できることを確認しておく。
            //hikariConfig.setConnectionTestQuery("select 1"); // 接続が有効かどうかをチェックする。JDBC4なら、Connection#isValid() でチェック可能で、そちらの方が推奨されるとのこと。PostgreSQL ドライバーの 42.0.0 以降はすべてJDBC4
            hikariConfig.setPoolName(url);

            //  org.postgresql.jdbc.PgConnection.getNetworkTimeout() メソッドはまだ実装されていません。
            // 上記のメッセージが出力されてしまうが回避できない（HikariDataSourceそのものを書き換えるしかない）
            final HikariDataSource dataSource = new HikariDataSource(hikariConfig);

            // コネクションプール作成時、接続を試みているスキーマ名をログ出力する
            // 接続先URLなどの情報は、HikariCPが出力するため、ここではスキーマ名のみを出力する。
            LogUtil.getLogger(this).info("Create Connection Pool (" + schema + ")");

            result = this.dataSourcePool.putIfAbsent(url, // 接続先URLごとにデータソース（＝コネクションプール）をキャッシュする
                    dataSource);
            if (result == null) {
                result = dataSource;
            }
        }
        return result;
//		final DriverManagerDataSource dataSource = new DriverManagerDataSource();
//		dataSource.setDriverClassName(driverClassName);
//		dataSource.setUrl(url);
//		dataSource.setUsername(username);
//		dataSource.setPassword(password);
//		dataSource.setSchema(schema);
//		return dataSource;
    }

    /**
     * レプリケーション情報よりDB接続先URLを作成する
     *
     * @param replication レプリケーション情報オブジェクト
     * @return DB接続先URL
     */
    public String getJDBCConnectionURL(ReplicationMWebDto replication) {
        String dbConnectionUrl = replication.getDbConnectionUrl();
        String dbName = replication.getDbServerInstanceId();
//		String schema = replication.getDbSchemaName();
        // currentSchemaの設定は、getConnection() の時に setSchema を呼び出すことで対応。
//		String url = dbConnectionUrl + "/" + dbName + "?currentSchema=" + schema;
        String url = dbConnectionUrl + "/" + dbName;
        LogUtil.getLogger(this)
                .debug("Replication:[" + replication.getReplicationId() + "] DB Connection:[" + url + "]");
        return url;
    }

    /**
     * レプリケーションのデータベースを作成する
     *
     * @param replication レプリケーション情報オブジェクト
     * @return データソースオブジェクト
     */
    public DataSource getDataSourceOfReplication(ReplicationMWebDto replication) {
        Assert.hasText(emDatasourceDriver, "Configuration [maps.datasource.driver-class-name] is not defined.");
        Assert.hasText(emDatasourceUsername, "Configuration [maps.datasource.username] is not defined.");
        Assert.hasText(emDatasourcePassword, "Configuration [maps.datasource.password] is not defined.");
        String driver = emDatasourceDriver;
        String url = getJDBCConnectionURL(replication);
        String username = emDatasourceUsername;
        String password = emDatasourcePassword;
        String schema = replication.getDbSchemaName();

        try {
            DataSource replicationDataSource = createDataSource(driver, url, username, password, schema);
            //		DataSource persistedDataSource = dataSourcePool.putIfAbsent(replication.getReplicationId(),
            //				replicationDataSource);
            //		return useCache && persistedDataSource != null ? persistedDataSource : replicationDataSource;
            return replicationDataSource;
        } catch (Exception e) {
            // データベース接続に失敗した場合、replication_id などの情報をログに出力する。
            LogUtil.getLogger(this)
                    .error("Connect to Database : Fail!" + replication.getReplicationId() + "," + replication.getReplicationName());
            throw e;
        }
    }

    public DataSource getDataSourceOfReplication() {
        Assert.hasText(emDatasourceDriver, "Configuration [maps.datasource.driver-class-name] is not defined.");
        Assert.hasText(emDatasourceUsername, "Configuration [maps.datasource.username] is not defined.");
        Assert.hasText(emDatasourcePassword, "Configuration [maps.datasource.password] is not defined.");
        String driver = emDatasourceDriver;
        String url = datasourceUrl;
        String username = emDatasourceUsername;
        String password = emDatasourcePassword;
        String schema = "";

        try {
            DataSource replicationDataSource = createDataSource(driver, url, username, password, schema);
            //		DataSource persistedDataSource = dataSourcePool.putIfAbsent(replication.getReplicationId(),
            //				replicationDataSource);
            //		return useCache && persistedDataSource != null ? persistedDataSource : replicationDataSource;
            return replicationDataSource;
        } catch (Exception e) {
            // データベース接続に失敗した場合、replication_id などの情報をログに出力する。
            LogUtil.getLogger(this).error("Connect to Database : Fail!");
            throw e;
        }
    }
}
