package com.em.clinicapi.webdto.response.iryoukikan;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : MedicalInformation クラス <br/>
 * 項目： Medical_Information <br/>
 * 説明： <br/>
 *       医療機関情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class MedicalInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Prefectures_Number <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Prefectures_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String prefecturesNumber;
	/**
	 * 項目： Point_list <br/>
	 * 説明： <br/>
	 *       点数表　(1:医科) <br/>
	 * 備考： <br/>
	 *       "1" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Point_list")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pointList;
	/**
	 * 項目： Institution_Code <br/>
	 * 説明： <br/>
	 *       医療機関(医科)の医療機関コードを返却 <br/>
	 * 備考： <br/>
	 *       "1234567" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String institutionCode;
	/**
	 * 項目： Institution_Speciation <br/>
	 * 説明： <br/>
	 *       医療機関種別　(1:病院、2:診療所) <br/>
	 * 備考： <br/>
	 *       "2" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Speciation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String institutionSpeciation;
	/**
	 * 項目： Institution_Id <br/>
	 * 説明： <br/>
	 *       医療機関ID <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Id")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String institutionId;
	/**
	 * 項目： Institution_WholeName <br/>
	 * 説明： <br/>
	 *       医療機関(医科)の医療機関名称を返却 <br/>
	 * 備考： <br/>
	 *       "テストクリニック" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String institutionWholeName;
	/**
	 * 項目： Short_Institution_WholeName <br/>
	 * 説明： <br/>
	 *       短縮医療機関名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Short_Institution_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String shortInstitutionWholeName;
	/**
	 * 項目： Establisher_WholeName <br/>
	 * 説明： <br/>
	 *       医療機関(医科)の開設者漢字名称を返却 <br/>
	 * 備考： <br/>
	 *       "テスト　管理者" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Establisher_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String establisherWholeName;
	/**
	 * 項目： Administrator_WholeName <br/>
	 * 説明： <br/>
	 *       管理者名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Administrator_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String administratorWholeName;
	/**
	 * 項目： Hospital_bed_Capacity <br/>
	 * 説明： <br/>
	 *       病床数(許可) <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Hospital_bed_Capacity")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String hospitalBedCapacity;
	/**
	 * 項目： Hospital_bed_Capacity_General <br/>
	 * 説明： <br/>
	 *       病床数(一般) <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Hospital_bed_Capacity_General")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String hospitalBedCapacityGeneral;
	/**
	 * 項目： Om_Payment_Class <br/>
	 * 説明： <br/>
	 *       老人支払区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Om_Payment_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String omPaymentClass;
	/**
	 * 項目： Om_Payment_Class_Name <br/>
	 * 説明： <br/>
	 *       老人支払区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Om_Payment_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String omPaymentClassName;
	/**
	 * 項目： Old_General_Hospital_Class <br/>
	 * 説明： <br/>
	 *       旧総合病院フラグ <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Old_General_Hospital_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String oldGeneralHospitalClass;
	/**
	 * 項目： Old_General_Hospital_Class_Name <br/>
	 * 説明： <br/>
	 *       旧総合病院フラグ名称 <br/>
	 * 備考： <br/>
	 *       "旧総合病院ではない" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Old_General_Hospital_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String oldGeneralHospitalClassName;
	/**
	 * 項目： Outside_Class <br/>
	 * 説明： <br/>
	 *       院外処方区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outside_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String outsideClass;
	/**
	 * 項目： Outside_Class_Name <br/>
	 * 説明： <br/>
	 *       院外処方区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outside_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String outsideClassName;
	/**
	 * 項目： Institution_Code_Kanji <br/>
	 * 説明： <br/>
	 *       医療機関コード（漢字） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Code_Kanji")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String institutionCodeKanji;
	/**
	 * 項目： Delivery_Organization_Control_Number <br/>
	 * 説明： <br/>
	 *       分娩機関管理番号 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Delivery_Organization_Control_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String deliveryOrganizationControlNumber;
	/**
	 * 項目： Print_Invoice_Receipt_Class <br/>
	 * 説明： <br/>
	 *       請求書発行フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Invoice_Receipt_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printInvoiceReceiptClass;
	/**
	 * 項目： Print_Invoice_Receipt_Class_Name <br/>
	 * 説明： <br/>
	 *       請求書発行フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Invoice_Receipt_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printInvoiceReceiptClassName;
	/**
	 * 項目： Print_Prescription_Class <br/>
	 * 説明： <br/>
	 *       院外処方箋発行フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Prescription_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printPrescriptionClass;
	/**
	 * 項目： Print_Prescription_Class_Name <br/>
	 * 説明： <br/>
	 *       院外処方箋発行フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Prescription_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printPrescriptionClassName;
	/**
	 * 項目： Last_Prescription_Display_Class <br/>
	 * 説明： <br/>
	 *       前回処方表示フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Last_Prescription_Display_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String lastPrescriptionDisplayClass;
	/**
	 * 項目： Last_Prescription_Display_Class_Name <br/>
	 * 説明： <br/>
	 *       前回処方表示フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Last_Prescription_Display_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String lastPrescriptionDisplayClassName;
	/**
	 * 項目： Print_Medicine_Information_Class <br/>
	 * 説明： <br/>
	 *       薬剤情報表示フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medicine_Information_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printMedicineInformationClass;
	/**
	 * 項目： Print_Medicine_Information_Class_Name <br/>
	 * 説明： <br/>
	 *       薬剤情報表示フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medicine_Information_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printMedicineInformationClassName;
	/**
	 * 項目： Print_Statement_Class <br/>
	 * 説明： <br/>
	 *       診療明細書発行フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Statement_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printStatementClass;
	/**
	 * 項目： Print_Statement_Class_Name <br/>
	 * 説明： <br/>
	 *       診療明細書発行フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Statement_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printStatementClassName;
	/**
	 * 項目： Print_Medication_Note_Class <br/>
	 * 説明： <br/>
	 *       お薬手帳発行フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medication_Note_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printMedicationNoteClass;
	/**
	 * 項目： Print_Medication_Note_Class_Name <br/>
	 * 説明： <br/>
	 *       お薬手帳発行フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medication_Note_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printMedicationNoteClassName;
	/**
	 * 項目： Print_Appointment_Form_Class <br/>
	 * 説明： <br/>
	 *       予約票発行フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Appointment_Form_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printAppointmentFormClass;
	/**
	 * 項目： Print_Appointment_Form_Class_Name <br/>
	 * 説明： <br/>
	 *       予約票発行フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Appointment_Form_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String printAppointmentFormClassName;
	/**
	 * 項目： Data_Collection_Creation_Class <br/>
	 * 説明： <br/>
	 *       データ収集フラグ <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Creation_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dataCollectionCreationClass;
	/**
	 * 項目： Data_Collection_Creation_Class_Name <br/>
	 * 説明： <br/>
	 *       データ収集フラグ名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Creation_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dataCollectionCreationClassName;
	/**
	 * 項目： Data_Collection_Submission_Method_Class <br/>
	 * 説明： <br/>
	 *       データ収集提出方法区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Submission_Method_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dataCollectionSubmissionMethodClass;
	/**
	 * 項目： Data_Collection_Submission_Method_Class_Name <br/>
	 * 説明： <br/>
	 *       データ収集提出方法区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Submission_Method_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dataCollectionSubmissionMethodClassName;
	/**
	 * 項目： Orca_Surveillance_Class <br/>
	 * 説明： <br/>
	 *       ORCAサーベイランス区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Orca_Surveillance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String orcaSurveillanceClass;
	/**
	 * 項目： Orca_Surveillance_Class_Name <br/>
	 * 説明： <br/>
	 *       ORCAサーベイランス区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Orca_Surveillance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String orcaSurveillanceClassName;
	/**
	 * 項目： Reduction_Calculation_Object_Class <br/>
	 * 説明： <br/>
	 *       減免計算対象区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Calculation_Object_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String reductionCalculationObjectClass;
	/**
	 * 項目： Reduction_Calculation_Object_Class_Name <br/>
	 * 説明： <br/>
	 *       減免計算対象区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Calculation_Object_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String reductionCalculationObjectClassName;
	/**
	 * 項目： Ac_Money_Rounding_Reduction_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分（減免有） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ac_Money_Rounding_Reduction_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String acMoneyRoundingReductionClass;
	/**
	 * 項目： Ac_Money_Rounding_Reduction_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分（減免有）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ac_Money_Rounding_Reduction_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String acMoneyRoundingReductionClassName;
	/**
	 * 項目： Ac_Money_Rounding_No_Reduction_Information <br/>
	 * 説明： <br/>
	 *       請求額端数区分（減免無）情報 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
	@Valid
		@JsonProperty("Ac_Money_Rounding_No_Reduction_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AcMoneyRoundingNoReductionInformation acMoneyRoundingNoReductionInformation;
	/**
	 * 項目： Tax_Rounding_Class <br/>
	 * 説明： <br/>
	 *       消費税端数区分 <br/>
	 * 備考： <br/>
	 *       ？ <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Tax_Rounding_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String taxRoundingClass;
	/**
	 * 項目： Tax_Rounding_Class_Name <br/>
	 * 説明： <br/>
	 *       消費税端数区分名称 <br/>
	 * 備考： <br/>
	 *       ？ <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Tax_Rounding_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String taxRoundingClassName;
	/**
	 * 項目： Self_Insurance_Total_Class <br/>
	 * 説明： <br/>
	 *       自費保険集計先区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Self_Insurance_Total_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String selfInsuranceTotalClass;
	/**
	 * 項目： Self_Insurance_Total_Class_Name <br/>
	 * 説明： <br/>
	 *       自費保険集計先区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Self_Insurance_Total_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String selfInsuranceTotalClassName;
	/**
	 * 項目： Local_Public_Expenses_Insurance_Number_Tab_Class <br/>
	 * 説明： <br/>
	 *       地方公費保険番号タブ区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Local_Public_Expenses_Insurance_Number_Tab_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String localPublicExpensesInsuranceNumberTabClass;
	/**
	 * 項目： Local_Public_Expenses_Insurance_Number_Tab_Class_Name <br/>
	 * 説明： <br/>
	 *       地方公費保険番号タブ区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Local_Public_Expenses_Insurance_Number_Tab_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String localPublicExpensesInsuranceNumberTabClassName;
	/**
	 * 項目： Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class <br/>
	 * 説明： <br/>
	 *       更正・育成限度額日割計算区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String rehabilitationNurtureCreditLimitCalculateDailyRateClass;
	/**
	 * 項目： Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Name <br/>
	 * 説明： <br/>
	 *       更正・育成限度額日割計算区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String rehabilitationNurtureCreditLimitCalculateDailyRateClassName;
	/**
	 * 項目： Oe_Rounding_Class <br/>
	 * 説明： <br/>
	 *       自費コード数量計算端数区分 <br/>
	 * 備考： <br/>
	 *       ？ <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Oe_Rounding_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String oeRoundingClass;
	/**
	 * 項目： Oe_Rounding_Class_Name <br/>
	 * 説明： <br/>
	 *       自費コード数量計算端数区分名称 <br/>
	 * 備考： <br/>
	 *       ？ <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Oe_Rounding_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String oeRoundingClassName;
	/**
	 * 項目： Address_Information <br/>
	 * 説明： <br/>
	 *       連絡先、広告情報 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
	@Valid
		@JsonProperty("Address_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AddressInformation addressInformation;
	/**
	 * Prefectures_Numberを返事します。
	 * @return Prefectures_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Prefectures_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrefecturesNumber() {
		return prefecturesNumber;
	}

	/**
	 * Prefectures_Numberを設定します。
	 * @param prefecturesNumber Prefectures_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Prefectures_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrefecturesNumber(String prefecturesNumber) {
		this.prefecturesNumber = prefecturesNumber;
	}

	/**
	 * Point_listを返事します。
	 * @return Point_listの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Point_list")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPointList() {
		return pointList;
	}

	/**
	 * Point_listを設定します。
	 * @param pointList Point_list
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Point_list")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPointList(String pointList) {
		this.pointList = pointList;
	}

	/**
	 * Institution_Codeを返事します。
	 * @return Institution_Codeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInstitutionCode() {
		return institutionCode;
	}

	/**
	 * Institution_Codeを設定します。
	 * @param institutionCode Institution_Code
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInstitutionCode(String institutionCode) {
		this.institutionCode = institutionCode;
	}

	/**
	 * Institution_Speciationを返事します。
	 * @return Institution_Speciationの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Speciation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInstitutionSpeciation() {
		return institutionSpeciation;
	}

	/**
	 * Institution_Speciationを設定します。
	 * @param institutionSpeciation Institution_Speciation
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Speciation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInstitutionSpeciation(String institutionSpeciation) {
		this.institutionSpeciation = institutionSpeciation;
	}

	/**
	 * Institution_Idを返事します。
	 * @return Institution_Idの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Id")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInstitutionId() {
		return institutionId;
	}

	/**
	 * Institution_Idを設定します。
	 * @param institutionId Institution_Id
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Id")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInstitutionId(String institutionId) {
		this.institutionId = institutionId;
	}

	/**
	 * Institution_WholeNameを返事します。
	 * @return Institution_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInstitutionWholeName() {
		return institutionWholeName;
	}

	/**
	 * Institution_WholeNameを設定します。
	 * @param institutionWholeName Institution_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInstitutionWholeName(String institutionWholeName) {
		this.institutionWholeName = institutionWholeName;
	}

	/**
	 * Short_Institution_WholeNameを返事します。
	 * @return Short_Institution_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Short_Institution_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getShortInstitutionWholeName() {
		return shortInstitutionWholeName;
	}

	/**
	 * Short_Institution_WholeNameを設定します。
	 * @param shortInstitutionWholeName Short_Institution_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Short_Institution_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setShortInstitutionWholeName(String shortInstitutionWholeName) {
		this.shortInstitutionWholeName = shortInstitutionWholeName;
	}

	/**
	 * Establisher_WholeNameを返事します。
	 * @return Establisher_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Establisher_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getEstablisherWholeName() {
		return establisherWholeName;
	}

	/**
	 * Establisher_WholeNameを設定します。
	 * @param establisherWholeName Establisher_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Establisher_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setEstablisherWholeName(String establisherWholeName) {
		this.establisherWholeName = establisherWholeName;
	}

	/**
	 * Administrator_WholeNameを返事します。
	 * @return Administrator_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Administrator_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAdministratorWholeName() {
		return administratorWholeName;
	}

	/**
	 * Administrator_WholeNameを設定します。
	 * @param administratorWholeName Administrator_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Administrator_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAdministratorWholeName(String administratorWholeName) {
		this.administratorWholeName = administratorWholeName;
	}

	/**
	 * Hospital_bed_Capacityを返事します。
	 * @return Hospital_bed_Capacityの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Hospital_bed_Capacity")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHospitalBedCapacity() {
		return hospitalBedCapacity;
	}

	/**
	 * Hospital_bed_Capacityを設定します。
	 * @param hospitalBedCapacity Hospital_bed_Capacity
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Hospital_bed_Capacity")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHospitalBedCapacity(String hospitalBedCapacity) {
		this.hospitalBedCapacity = hospitalBedCapacity;
	}

	/**
	 * Hospital_bed_Capacity_Generalを返事します。
	 * @return Hospital_bed_Capacity_Generalの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Hospital_bed_Capacity_General")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHospitalBedCapacityGeneral() {
		return hospitalBedCapacityGeneral;
	}

	/**
	 * Hospital_bed_Capacity_Generalを設定します。
	 * @param hospitalBedCapacityGeneral Hospital_bed_Capacity_General
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Hospital_bed_Capacity_General")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHospitalBedCapacityGeneral(String hospitalBedCapacityGeneral) {
		this.hospitalBedCapacityGeneral = hospitalBedCapacityGeneral;
	}

	/**
	 * Om_Payment_Classを返事します。
	 * @return Om_Payment_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Om_Payment_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOmPaymentClass() {
		return omPaymentClass;
	}

	/**
	 * Om_Payment_Classを設定します。
	 * @param omPaymentClass Om_Payment_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Om_Payment_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOmPaymentClass(String omPaymentClass) {
		this.omPaymentClass = omPaymentClass;
	}

	/**
	 * Om_Payment_Class_Nameを返事します。
	 * @return Om_Payment_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Om_Payment_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOmPaymentClassName() {
		return omPaymentClassName;
	}

	/**
	 * Om_Payment_Class_Nameを設定します。
	 * @param omPaymentClassName Om_Payment_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Om_Payment_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOmPaymentClassName(String omPaymentClassName) {
		this.omPaymentClassName = omPaymentClassName;
	}

	/**
	 * Old_General_Hospital_Classを返事します。
	 * @return Old_General_Hospital_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Old_General_Hospital_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOldGeneralHospitalClass() {
		return oldGeneralHospitalClass;
	}

	/**
	 * Old_General_Hospital_Classを設定します。
	 * @param oldGeneralHospitalClass Old_General_Hospital_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Old_General_Hospital_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOldGeneralHospitalClass(String oldGeneralHospitalClass) {
		this.oldGeneralHospitalClass = oldGeneralHospitalClass;
	}

	/**
	 * Old_General_Hospital_Class_Nameを返事します。
	 * @return Old_General_Hospital_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Old_General_Hospital_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOldGeneralHospitalClassName() {
		return oldGeneralHospitalClassName;
	}

	/**
	 * Old_General_Hospital_Class_Nameを設定します。
	 * @param oldGeneralHospitalClassName Old_General_Hospital_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Old_General_Hospital_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOldGeneralHospitalClassName(String oldGeneralHospitalClassName) {
		this.oldGeneralHospitalClassName = oldGeneralHospitalClassName;
	}

	/**
	 * Outside_Classを返事します。
	 * @return Outside_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outside_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOutsideClass() {
		return outsideClass;
	}

	/**
	 * Outside_Classを設定します。
	 * @param outsideClass Outside_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outside_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOutsideClass(String outsideClass) {
		this.outsideClass = outsideClass;
	}

	/**
	 * Outside_Class_Nameを返事します。
	 * @return Outside_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outside_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOutsideClassName() {
		return outsideClassName;
	}

	/**
	 * Outside_Class_Nameを設定します。
	 * @param outsideClassName Outside_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Outside_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOutsideClassName(String outsideClassName) {
		this.outsideClassName = outsideClassName;
	}

	/**
	 * Institution_Code_Kanjiを返事します。
	 * @return Institution_Code_Kanjiの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Code_Kanji")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInstitutionCodeKanji() {
		return institutionCodeKanji;
	}

	/**
	 * Institution_Code_Kanjiを設定します。
	 * @param institutionCodeKanji Institution_Code_Kanji
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Institution_Code_Kanji")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInstitutionCodeKanji(String institutionCodeKanji) {
		this.institutionCodeKanji = institutionCodeKanji;
	}

	/**
	 * Delivery_Organization_Control_Numberを返事します。
	 * @return Delivery_Organization_Control_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Delivery_Organization_Control_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDeliveryOrganizationControlNumber() {
		return deliveryOrganizationControlNumber;
	}

	/**
	 * Delivery_Organization_Control_Numberを設定します。
	 * @param deliveryOrganizationControlNumber Delivery_Organization_Control_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Delivery_Organization_Control_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDeliveryOrganizationControlNumber(String deliveryOrganizationControlNumber) {
		this.deliveryOrganizationControlNumber = deliveryOrganizationControlNumber;
	}

	/**
	 * Print_Invoice_Receipt_Classを返事します。
	 * @return Print_Invoice_Receipt_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Invoice_Receipt_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintInvoiceReceiptClass() {
		return printInvoiceReceiptClass;
	}

	/**
	 * Print_Invoice_Receipt_Classを設定します。
	 * @param printInvoiceReceiptClass Print_Invoice_Receipt_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Invoice_Receipt_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintInvoiceReceiptClass(String printInvoiceReceiptClass) {
		this.printInvoiceReceiptClass = printInvoiceReceiptClass;
	}

	/**
	 * Print_Invoice_Receipt_Class_Nameを返事します。
	 * @return Print_Invoice_Receipt_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Invoice_Receipt_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintInvoiceReceiptClassName() {
		return printInvoiceReceiptClassName;
	}

	/**
	 * Print_Invoice_Receipt_Class_Nameを設定します。
	 * @param printInvoiceReceiptClassName Print_Invoice_Receipt_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Invoice_Receipt_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintInvoiceReceiptClassName(String printInvoiceReceiptClassName) {
		this.printInvoiceReceiptClassName = printInvoiceReceiptClassName;
	}

	/**
	 * Print_Prescription_Classを返事します。
	 * @return Print_Prescription_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Prescription_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintPrescriptionClass() {
		return printPrescriptionClass;
	}

	/**
	 * Print_Prescription_Classを設定します。
	 * @param printPrescriptionClass Print_Prescription_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Prescription_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintPrescriptionClass(String printPrescriptionClass) {
		this.printPrescriptionClass = printPrescriptionClass;
	}

	/**
	 * Print_Prescription_Class_Nameを返事します。
	 * @return Print_Prescription_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Prescription_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintPrescriptionClassName() {
		return printPrescriptionClassName;
	}

	/**
	 * Print_Prescription_Class_Nameを設定します。
	 * @param printPrescriptionClassName Print_Prescription_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Prescription_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintPrescriptionClassName(String printPrescriptionClassName) {
		this.printPrescriptionClassName = printPrescriptionClassName;
	}

	/**
	 * Last_Prescription_Display_Classを返事します。
	 * @return Last_Prescription_Display_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Last_Prescription_Display_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLastPrescriptionDisplayClass() {
		return lastPrescriptionDisplayClass;
	}

	/**
	 * Last_Prescription_Display_Classを設定します。
	 * @param lastPrescriptionDisplayClass Last_Prescription_Display_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Last_Prescription_Display_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLastPrescriptionDisplayClass(String lastPrescriptionDisplayClass) {
		this.lastPrescriptionDisplayClass = lastPrescriptionDisplayClass;
	}

	/**
	 * Last_Prescription_Display_Class_Nameを返事します。
	 * @return Last_Prescription_Display_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Last_Prescription_Display_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLastPrescriptionDisplayClassName() {
		return lastPrescriptionDisplayClassName;
	}

	/**
	 * Last_Prescription_Display_Class_Nameを設定します。
	 * @param lastPrescriptionDisplayClassName Last_Prescription_Display_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Last_Prescription_Display_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLastPrescriptionDisplayClassName(String lastPrescriptionDisplayClassName) {
		this.lastPrescriptionDisplayClassName = lastPrescriptionDisplayClassName;
	}

	/**
	 * Print_Medicine_Information_Classを返事します。
	 * @return Print_Medicine_Information_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medicine_Information_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintMedicineInformationClass() {
		return printMedicineInformationClass;
	}

	/**
	 * Print_Medicine_Information_Classを設定します。
	 * @param printMedicineInformationClass Print_Medicine_Information_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medicine_Information_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintMedicineInformationClass(String printMedicineInformationClass) {
		this.printMedicineInformationClass = printMedicineInformationClass;
	}

	/**
	 * Print_Medicine_Information_Class_Nameを返事します。
	 * @return Print_Medicine_Information_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medicine_Information_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintMedicineInformationClassName() {
		return printMedicineInformationClassName;
	}

	/**
	 * Print_Medicine_Information_Class_Nameを設定します。
	 * @param printMedicineInformationClassName Print_Medicine_Information_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medicine_Information_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintMedicineInformationClassName(String printMedicineInformationClassName) {
		this.printMedicineInformationClassName = printMedicineInformationClassName;
	}

	/**
	 * Print_Statement_Classを返事します。
	 * @return Print_Statement_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Statement_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintStatementClass() {
		return printStatementClass;
	}

	/**
	 * Print_Statement_Classを設定します。
	 * @param printStatementClass Print_Statement_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Statement_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintStatementClass(String printStatementClass) {
		this.printStatementClass = printStatementClass;
	}

	/**
	 * Print_Statement_Class_Nameを返事します。
	 * @return Print_Statement_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Statement_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintStatementClassName() {
		return printStatementClassName;
	}

	/**
	 * Print_Statement_Class_Nameを設定します。
	 * @param printStatementClassName Print_Statement_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Statement_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintStatementClassName(String printStatementClassName) {
		this.printStatementClassName = printStatementClassName;
	}

	/**
	 * Print_Medication_Note_Classを返事します。
	 * @return Print_Medication_Note_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medication_Note_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintMedicationNoteClass() {
		return printMedicationNoteClass;
	}

	/**
	 * Print_Medication_Note_Classを設定します。
	 * @param printMedicationNoteClass Print_Medication_Note_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medication_Note_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintMedicationNoteClass(String printMedicationNoteClass) {
		this.printMedicationNoteClass = printMedicationNoteClass;
	}

	/**
	 * Print_Medication_Note_Class_Nameを返事します。
	 * @return Print_Medication_Note_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medication_Note_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintMedicationNoteClassName() {
		return printMedicationNoteClassName;
	}

	/**
	 * Print_Medication_Note_Class_Nameを設定します。
	 * @param printMedicationNoteClassName Print_Medication_Note_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Medication_Note_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintMedicationNoteClassName(String printMedicationNoteClassName) {
		this.printMedicationNoteClassName = printMedicationNoteClassName;
	}

	/**
	 * Print_Appointment_Form_Classを返事します。
	 * @return Print_Appointment_Form_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Appointment_Form_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintAppointmentFormClass() {
		return printAppointmentFormClass;
	}

	/**
	 * Print_Appointment_Form_Classを設定します。
	 * @param printAppointmentFormClass Print_Appointment_Form_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Appointment_Form_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintAppointmentFormClass(String printAppointmentFormClass) {
		this.printAppointmentFormClass = printAppointmentFormClass;
	}

	/**
	 * Print_Appointment_Form_Class_Nameを返事します。
	 * @return Print_Appointment_Form_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Appointment_Form_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPrintAppointmentFormClassName() {
		return printAppointmentFormClassName;
	}

	/**
	 * Print_Appointment_Form_Class_Nameを設定します。
	 * @param printAppointmentFormClassName Print_Appointment_Form_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Print_Appointment_Form_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPrintAppointmentFormClassName(String printAppointmentFormClassName) {
		this.printAppointmentFormClassName = printAppointmentFormClassName;
	}

	/**
	 * Data_Collection_Creation_Classを返事します。
	 * @return Data_Collection_Creation_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Creation_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDataCollectionCreationClass() {
		return dataCollectionCreationClass;
	}

	/**
	 * Data_Collection_Creation_Classを設定します。
	 * @param dataCollectionCreationClass Data_Collection_Creation_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Creation_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDataCollectionCreationClass(String dataCollectionCreationClass) {
		this.dataCollectionCreationClass = dataCollectionCreationClass;
	}

	/**
	 * Data_Collection_Creation_Class_Nameを返事します。
	 * @return Data_Collection_Creation_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Creation_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDataCollectionCreationClassName() {
		return dataCollectionCreationClassName;
	}

	/**
	 * Data_Collection_Creation_Class_Nameを設定します。
	 * @param dataCollectionCreationClassName Data_Collection_Creation_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Creation_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDataCollectionCreationClassName(String dataCollectionCreationClassName) {
		this.dataCollectionCreationClassName = dataCollectionCreationClassName;
	}

	/**
	 * Data_Collection_Submission_Method_Classを返事します。
	 * @return Data_Collection_Submission_Method_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Submission_Method_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDataCollectionSubmissionMethodClass() {
		return dataCollectionSubmissionMethodClass;
	}

	/**
	 * Data_Collection_Submission_Method_Classを設定します。
	 * @param dataCollectionSubmissionMethodClass Data_Collection_Submission_Method_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Submission_Method_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDataCollectionSubmissionMethodClass(String dataCollectionSubmissionMethodClass) {
		this.dataCollectionSubmissionMethodClass = dataCollectionSubmissionMethodClass;
	}

	/**
	 * Data_Collection_Submission_Method_Class_Nameを返事します。
	 * @return Data_Collection_Submission_Method_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Submission_Method_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDataCollectionSubmissionMethodClassName() {
		return dataCollectionSubmissionMethodClassName;
	}

	/**
	 * Data_Collection_Submission_Method_Class_Nameを設定します。
	 * @param dataCollectionSubmissionMethodClassName Data_Collection_Submission_Method_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Data_Collection_Submission_Method_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDataCollectionSubmissionMethodClassName(String dataCollectionSubmissionMethodClassName) {
		this.dataCollectionSubmissionMethodClassName = dataCollectionSubmissionMethodClassName;
	}

	/**
	 * Orca_Surveillance_Classを返事します。
	 * @return Orca_Surveillance_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Orca_Surveillance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOrcaSurveillanceClass() {
		return orcaSurveillanceClass;
	}

	/**
	 * Orca_Surveillance_Classを設定します。
	 * @param orcaSurveillanceClass Orca_Surveillance_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Orca_Surveillance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOrcaSurveillanceClass(String orcaSurveillanceClass) {
		this.orcaSurveillanceClass = orcaSurveillanceClass;
	}

	/**
	 * Orca_Surveillance_Class_Nameを返事します。
	 * @return Orca_Surveillance_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Orca_Surveillance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOrcaSurveillanceClassName() {
		return orcaSurveillanceClassName;
	}

	/**
	 * Orca_Surveillance_Class_Nameを設定します。
	 * @param orcaSurveillanceClassName Orca_Surveillance_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Orca_Surveillance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOrcaSurveillanceClassName(String orcaSurveillanceClassName) {
		this.orcaSurveillanceClassName = orcaSurveillanceClassName;
	}

	/**
	 * Reduction_Calculation_Object_Classを返事します。
	 * @return Reduction_Calculation_Object_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Calculation_Object_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getReductionCalculationObjectClass() {
		return reductionCalculationObjectClass;
	}

	/**
	 * Reduction_Calculation_Object_Classを設定します。
	 * @param reductionCalculationObjectClass Reduction_Calculation_Object_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Calculation_Object_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setReductionCalculationObjectClass(String reductionCalculationObjectClass) {
		this.reductionCalculationObjectClass = reductionCalculationObjectClass;
	}

	/**
	 * Reduction_Calculation_Object_Class_Nameを返事します。
	 * @return Reduction_Calculation_Object_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Calculation_Object_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getReductionCalculationObjectClassName() {
		return reductionCalculationObjectClassName;
	}

	/**
	 * Reduction_Calculation_Object_Class_Nameを設定します。
	 * @param reductionCalculationObjectClassName Reduction_Calculation_Object_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reduction_Calculation_Object_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setReductionCalculationObjectClassName(String reductionCalculationObjectClassName) {
		this.reductionCalculationObjectClassName = reductionCalculationObjectClassName;
	}

	/**
	 * Ac_Money_Rounding_Reduction_Classを返事します。
	 * @return Ac_Money_Rounding_Reduction_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ac_Money_Rounding_Reduction_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAcMoneyRoundingReductionClass() {
		return acMoneyRoundingReductionClass;
	}

	/**
	 * Ac_Money_Rounding_Reduction_Classを設定します。
	 * @param acMoneyRoundingReductionClass Ac_Money_Rounding_Reduction_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ac_Money_Rounding_Reduction_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAcMoneyRoundingReductionClass(String acMoneyRoundingReductionClass) {
		this.acMoneyRoundingReductionClass = acMoneyRoundingReductionClass;
	}

	/**
	 * Ac_Money_Rounding_Reduction_Class_Nameを返事します。
	 * @return Ac_Money_Rounding_Reduction_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ac_Money_Rounding_Reduction_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAcMoneyRoundingReductionClassName() {
		return acMoneyRoundingReductionClassName;
	}

	/**
	 * Ac_Money_Rounding_Reduction_Class_Nameを設定します。
	 * @param acMoneyRoundingReductionClassName Ac_Money_Rounding_Reduction_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Ac_Money_Rounding_Reduction_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAcMoneyRoundingReductionClassName(String acMoneyRoundingReductionClassName) {
		this.acMoneyRoundingReductionClassName = acMoneyRoundingReductionClassName;
	}

	/**
	 * Ac_Money_Rounding_No_Reduction_Informationを返事します。
	 * @return Ac_Money_Rounding_No_Reduction_Informationの値
	 */
		@JsonProperty("Ac_Money_Rounding_No_Reduction_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public AcMoneyRoundingNoReductionInformation getAcMoneyRoundingNoReductionInformation() {
		return acMoneyRoundingNoReductionInformation;
	}

	/**
	 * Ac_Money_Rounding_No_Reduction_Informationを設定します。
	 * @param acMoneyRoundingNoReductionInformation Ac_Money_Rounding_No_Reduction_Information
	 */
		@JsonProperty("Ac_Money_Rounding_No_Reduction_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAcMoneyRoundingNoReductionInformation(AcMoneyRoundingNoReductionInformation acMoneyRoundingNoReductionInformation) {
		this.acMoneyRoundingNoReductionInformation = acMoneyRoundingNoReductionInformation;
	}

	/**
	 * Tax_Rounding_Classを返事します。
	 * @return Tax_Rounding_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Tax_Rounding_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getTaxRoundingClass() {
		return taxRoundingClass;
	}

	/**
	 * Tax_Rounding_Classを設定します。
	 * @param taxRoundingClass Tax_Rounding_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Tax_Rounding_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setTaxRoundingClass(String taxRoundingClass) {
		this.taxRoundingClass = taxRoundingClass;
	}

	/**
	 * Tax_Rounding_Class_Nameを返事します。
	 * @return Tax_Rounding_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Tax_Rounding_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getTaxRoundingClassName() {
		return taxRoundingClassName;
	}

	/**
	 * Tax_Rounding_Class_Nameを設定します。
	 * @param taxRoundingClassName Tax_Rounding_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Tax_Rounding_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setTaxRoundingClassName(String taxRoundingClassName) {
		this.taxRoundingClassName = taxRoundingClassName;
	}

	/**
	 * Self_Insurance_Total_Classを返事します。
	 * @return Self_Insurance_Total_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Self_Insurance_Total_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getSelfInsuranceTotalClass() {
		return selfInsuranceTotalClass;
	}

	/**
	 * Self_Insurance_Total_Classを設定します。
	 * @param selfInsuranceTotalClass Self_Insurance_Total_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Self_Insurance_Total_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setSelfInsuranceTotalClass(String selfInsuranceTotalClass) {
		this.selfInsuranceTotalClass = selfInsuranceTotalClass;
	}

	/**
	 * Self_Insurance_Total_Class_Nameを返事します。
	 * @return Self_Insurance_Total_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Self_Insurance_Total_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getSelfInsuranceTotalClassName() {
		return selfInsuranceTotalClassName;
	}

	/**
	 * Self_Insurance_Total_Class_Nameを設定します。
	 * @param selfInsuranceTotalClassName Self_Insurance_Total_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Self_Insurance_Total_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setSelfInsuranceTotalClassName(String selfInsuranceTotalClassName) {
		this.selfInsuranceTotalClassName = selfInsuranceTotalClassName;
	}

	/**
	 * Local_Public_Expenses_Insurance_Number_Tab_Classを返事します。
	 * @return Local_Public_Expenses_Insurance_Number_Tab_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Local_Public_Expenses_Insurance_Number_Tab_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLocalPublicExpensesInsuranceNumberTabClass() {
		return localPublicExpensesInsuranceNumberTabClass;
	}

	/**
	 * Local_Public_Expenses_Insurance_Number_Tab_Classを設定します。
	 * @param localPublicExpensesInsuranceNumberTabClass Local_Public_Expenses_Insurance_Number_Tab_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Local_Public_Expenses_Insurance_Number_Tab_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLocalPublicExpensesInsuranceNumberTabClass(String localPublicExpensesInsuranceNumberTabClass) {
		this.localPublicExpensesInsuranceNumberTabClass = localPublicExpensesInsuranceNumberTabClass;
	}

	/**
	 * Local_Public_Expenses_Insurance_Number_Tab_Class_Nameを返事します。
	 * @return Local_Public_Expenses_Insurance_Number_Tab_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Local_Public_Expenses_Insurance_Number_Tab_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLocalPublicExpensesInsuranceNumberTabClassName() {
		return localPublicExpensesInsuranceNumberTabClassName;
	}

	/**
	 * Local_Public_Expenses_Insurance_Number_Tab_Class_Nameを設定します。
	 * @param localPublicExpensesInsuranceNumberTabClassName Local_Public_Expenses_Insurance_Number_Tab_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Local_Public_Expenses_Insurance_Number_Tab_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLocalPublicExpensesInsuranceNumberTabClassName(String localPublicExpensesInsuranceNumberTabClassName) {
		this.localPublicExpensesInsuranceNumberTabClassName = localPublicExpensesInsuranceNumberTabClassName;
	}

	/**
	 * Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Classを返事します。
	 * @return Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRehabilitationNurtureCreditLimitCalculateDailyRateClass() {
		return rehabilitationNurtureCreditLimitCalculateDailyRateClass;
	}

	/**
	 * Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Classを設定します。
	 * @param rehabilitationNurtureCreditLimitCalculateDailyRateClass Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRehabilitationNurtureCreditLimitCalculateDailyRateClass(String rehabilitationNurtureCreditLimitCalculateDailyRateClass) {
		this.rehabilitationNurtureCreditLimitCalculateDailyRateClass = rehabilitationNurtureCreditLimitCalculateDailyRateClass;
	}

	/**
	 * Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Nameを返事します。
	 * @return Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRehabilitationNurtureCreditLimitCalculateDailyRateClassName() {
		return rehabilitationNurtureCreditLimitCalculateDailyRateClassName;
	}

	/**
	 * Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Nameを設定します。
	 * @param rehabilitationNurtureCreditLimitCalculateDailyRateClassName Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Rehabilitation_Nurture_Credit_Limit_Calculate_Daily_Rate_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRehabilitationNurtureCreditLimitCalculateDailyRateClassName(String rehabilitationNurtureCreditLimitCalculateDailyRateClassName) {
		this.rehabilitationNurtureCreditLimitCalculateDailyRateClassName = rehabilitationNurtureCreditLimitCalculateDailyRateClassName;
	}

	/**
	 * Oe_Rounding_Classを返事します。
	 * @return Oe_Rounding_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Oe_Rounding_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOeRoundingClass() {
		return oeRoundingClass;
	}

	/**
	 * Oe_Rounding_Classを設定します。
	 * @param oeRoundingClass Oe_Rounding_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Oe_Rounding_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOeRoundingClass(String oeRoundingClass) {
		this.oeRoundingClass = oeRoundingClass;
	}

	/**
	 * Oe_Rounding_Class_Nameを返事します。
	 * @return Oe_Rounding_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Oe_Rounding_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getOeRoundingClassName() {
		return oeRoundingClassName;
	}

	/**
	 * Oe_Rounding_Class_Nameを設定します。
	 * @param oeRoundingClassName Oe_Rounding_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Oe_Rounding_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setOeRoundingClassName(String oeRoundingClassName) {
		this.oeRoundingClassName = oeRoundingClassName;
	}

	/**
	 * Address_Informationを返事します。
	 * @return Address_Informationの値
	 */
		@JsonProperty("Address_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public AddressInformation getAddressInformation() {
		return addressInformation;
	}

	/**
	 * Address_Informationを設定します。
	 * @param addressInformation Address_Information
	 */
		@JsonProperty("Address_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAddressInformation(AddressInformation addressInformation) {
		this.addressInformation = addressInformation;
	}

}