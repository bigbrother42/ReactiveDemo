package com.em.clinicapi.service;

import com.em.clinicapi.logic.BasicInfoLogic;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequestWebDto;
import com.em.clinicapi.webdto.request.iryoukikan.IryoukikanInfoRequestWebDto;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequest;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponseWebDto;
import com.em.clinicapi.webdto.response.iryoukikan.IryoukikanInfoResponseWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class BasicInfoService {

    @Autowired
    private BasicInfoLogic basicInfoLogic;

    /**
     * アカウント情報取得(医師)
     * @param dto
     * @return
     */
    public UserBasicInfoResponseWebDto getDoctorBasicInfo(BasicInfoRequestWebDto dto) {
        return basicInfoLogic.getDoctorBasicInfo2(dto);
    }

    /**
     * 医療機関情報を取得
     * @param dto
     * @return
     */
    public IryoukikanInfoResponseWebDto getIryoukikanInfo(IryoukikanInfoRequestWebDto dto) {
        return basicInfoLogic.getIryoukikanInfo(dto);
    }
}
