package com.em.clinicapi.logic;

import com.em.clinicapi.common.constants.*;
import com.em.clinicapi.common.constants.enumerations.*;
import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.common.exception.SystemException;
import com.em.clinicapi.mapper.BasicInfoMapper;
import com.em.clinicapi.webdto.db.JihiHasuuMWebDto;
import com.em.clinicapi.webdto.db.ShouhizeiritsuMWebDto;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequest;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequestWebDto;
import com.em.clinicapi.webdto.request.iryoukikan.IryoukikanInfoRequestWebDto;
import com.em.clinicapi.webdto.response.basicinfo.PhysicianInformation;
import com.em.clinicapi.webdto.response.basicinfo.PhysicianInformationArr;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponse;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponseWebDto;
import com.em.clinicapi.webdto.response.iryoukikan.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;


@Component
public class BasicInfoLogic {

    public static final String Reskey = "PatientInfo";

    // yyyy-MM-dd
    private SimpleDateFormat sdfDate = new SimpleDateFormat(DateFormatEnum.FormatYYYYMMDDM.getValue());
    // HH:mm:ss
    private SimpleDateFormat sdfTime = new SimpleDateFormat(DateFormatEnum.FormatHHmmss.getValue());
    private String customerSeq;

    @Autowired
    BasicInfoMapper basicInfoMapper;

    /**
     * アカウント情報取得(医師)
     * @param doctorInfoRequestWebDto
     * @return
     */
    public UserBasicInfoResponseWebDto getDoctorBasicInfo2(BasicInfoRequestWebDto doctorInfoRequestWebDto)
    {
        try {
            customerSeq = doctorInfoRequestWebDto.getBasicInfoRequest().getCustomerId();
        } catch(Exception e) {
            throw new InvalidRequestException("リクエストのパラメータ「Customer_ID」は不正でした。");
        }

        Date responseDate = new Date();

        UserBasicInfoResponseWebDto doctorBasicInfoResponseWebDto = new UserBasicInfoResponseWebDto();
        UserBasicInfoResponse doctorBasicInfoResponse = new UserBasicInfoResponse();
        // レスポンスを返す時点の日付
        doctorBasicInfoResponse.setInformationDate(sdfDate.format(responseDate));
        // レスポンスを返す時点の時刻
        doctorBasicInfoResponse.setInformationTime(sdfTime.format(responseDate));
        // 成功時は"00"を返す
        doctorBasicInfoResponse.setApiResult(ApiResultEnum.Success.getCode());
        doctorBasicInfoResponse.setApiResultMessage(ApiResultMessageEnum.Success.getMessage());
        doctorBasicInfoResponse.setReskey(ReskeyEnum.PatientInfo.getKey());
        doctorBasicInfoResponse.setBaseDate(doctorInfoRequestWebDto.getBasicInfoRequest().getBaseDate());

        List<PhysicianInformation> physicianInformations = basicInfoMapper.selectDoctorBasicInfo();
        PhysicianInformationArr physicianInformationArr = new PhysicianInformationArr();
        physicianInformationArr.setType(ClassTypeEnum.array);
        physicianInformationArr.setPhysicianInformation(physicianInformations);

        doctorBasicInfoResponse.setPhysicianInformationArr(physicianInformationArr);
        doctorBasicInfoResponseWebDto.setUserBasicInfoResponse(doctorBasicInfoResponse);

        return doctorBasicInfoResponseWebDto;
    }

    /**
     * 医療機関情報を取得
     * @param iryoukikanInfoRequestWebDto
     * @return
     */
    public IryoukikanInfoResponseWebDto getIryoukikanInfo(IryoukikanInfoRequestWebDto iryoukikanInfoRequestWebDto) {
        IryoukikanInfoResponseWebDto iryoukikanInfoResponseWebDto = new IryoukikanInfoResponseWebDto();
        IryoukikanInfoResponse iryoukikanInfoResponse = new IryoukikanInfoResponse();

        SimpleDateFormat sdfDate = new SimpleDateFormat(DateFormatEnum.FormatYYYYMMDDM.getValue());
        SimpleDateFormat sdfTime = new SimpleDateFormat(DateFormatEnum.FormatHHmmss.getValue());
        String customerSeqStr = iryoukikanInfoRequestWebDto.getIryoukikanInfoRequest().getCustomerId();
        Integer customerSeq = Integer.valueOf(customerSeqStr);
        String baseDateStr = iryoukikanInfoRequestWebDto.getIryoukikanInfoRequest().getBaseDate();
        Date baseDate;
        try{
            baseDate = sdfDate.parse(baseDateStr);
        } catch(ParseException parseException) {
            throw new InvalidRequestException("リクエストのパラメータ「Base_Date」は不正でした。");
        }

        Date responseDate = new Date();
        // レスポンスを返す時点の日付
        iryoukikanInfoResponse.setInformationDate(sdfDate.format(responseDate));
        // レスポンスを返す時点の時刻
        iryoukikanInfoResponse.setInformationTime(sdfTime.format(responseDate));
        // 成功時は"00"を返す
        iryoukikanInfoResponse.setApiResult(ApiResultEnum.Success.getCode());
        iryoukikanInfoResponse.setApiResultMessage(ApiResultMessageEnum.Success.getMessage());
        iryoukikanInfoResponse.setReskey(Reskey);
        // リクエスト側のBase_Dateを返却
        iryoukikanInfoResponse.setBaseDate(iryoukikanInfoRequestWebDto.getIryoukikanInfoRequest().getBaseDate());
        /*医療機関情報*/
        MedicalInformation medicalInformation = generateMedicalInformation(customerSeq, baseDate);
        iryoukikanInfoResponse.setMedicalInformation(medicalInformation);

        iryoukikanInfoResponseWebDto.setIryoukikanInfoResponse(iryoukikanInfoResponse);
        return iryoukikanInfoResponseWebDto;
    }

    private MedicalInformation generateMedicalInformation(Integer customerSeq, Date baseDate) {

        /*医療機関情報*/
        MedicalInformation medicalInformation = basicInfoMapper.selectIryoukikanInfo(
                customerSeq, new java.sql.Date(baseDate.getTime()));
        if (medicalInformation == null) {
            throw new SystemException("有効な医療機関情報がありません。");
        }

        medicalInformation.setPrefecturesNumber(medicalInformation.getPrefecturesNumber());
        // 点数表　(1:医科)
        medicalInformation.setPointList(StringConstants.NUMBER_1);
        // 医療機関(医科)の医療機関コードを返却
        medicalInformation.setInstitutionCode(medicalInformation.getInstitutionCode());
        // 医療機関種別　(1:病院、2:診療所)
        medicalInformation.setInstitutionSpeciation(StringConstants.NUMBER_2);
        // 医療機関ID
        medicalInformation.setInstitutionId(StringConstants.EMPTY_STRING);
        // 医療機関(医科)の医療機関名称を返却
        medicalInformation.setInstitutionWholeName(medicalInformation.getInstitutionWholeName());
        // 短縮医療機関名称
        medicalInformation.setShortInstitutionWholeName(StringConstants.EMPTY_STRING);
        // 医療機関(医科)の開設者漢字名称を返却
        medicalInformation.setEstablisherWholeName(medicalInformation.getEstablisherWholeName());
        // 管理者名称
        medicalInformation.setAdministratorWholeName(StringConstants.EMPTY_STRING);
        // 病床数(許可)
        medicalInformation.setHospitalBedCapacity(StringConstants.NUMBER_0);
        // 病床数(一般)
        medicalInformation.setHospitalBedCapacityGeneral(StringConstants.NUMBER_0);
        // 老人支払区分
        medicalInformation.setOmPaymentClass(StringConstants.EMPTY_STRING);
        // 老人支払区分名称
        medicalInformation.setOmPaymentClassName(StringConstants.EMPTY_STRING);
        // 旧総合病院フラグ
        medicalInformation.setOldGeneralHospitalClass(StringConstants.NUMBER_0);
        // 旧総合病院フラグ名称
        medicalInformation.setOldGeneralHospitalClassName("旧総合病院ではない");
        // 院外処方区分
        medicalInformation.setOutsideClass(StringConstants.EMPTY_STRING);
        // 院外処方区分名称
        medicalInformation.setOutsideClassName(StringConstants.EMPTY_STRING);
        // 医療機関コード（漢字）
        medicalInformation.setInstitutionCodeKanji(StringConstants.EMPTY_STRING);
        // 分娩機関管理番号
        medicalInformation.setDeliveryOrganizationControlNumber(StringConstants.EMPTY_STRING);
        // 請求書発行フラグ
        medicalInformation.setPrintInvoiceReceiptClass(StringConstants.EMPTY_STRING);
        // 請求書発行フラグ名称
        medicalInformation.setPrintInvoiceReceiptClassName(StringConstants.EMPTY_STRING);
        // 院外処方箋発行フラグ
        medicalInformation.setPrintPrescriptionClass(StringConstants.EMPTY_STRING);
        // 院外処方箋発行フラグ名称
        medicalInformation.setPrintPrescriptionClassName(StringConstants.EMPTY_STRING);
        // 前回処方表示フラグ
        medicalInformation.setLastPrescriptionDisplayClass(StringConstants.EMPTY_STRING);
        // 前回処方表示フラグ名称
        medicalInformation.setLastPrescriptionDisplayClassName(StringConstants.EMPTY_STRING);
        // 薬剤情報表示フラグ
        medicalInformation.setPrintMedicineInformationClass(StringConstants.EMPTY_STRING);
        // 薬剤情報表示フラグ名称
        medicalInformation.setPrintMedicineInformationClassName(StringConstants.EMPTY_STRING);
        // 診療明細書発行フラグ
        medicalInformation.setPrintStatementClass(StringConstants.EMPTY_STRING);
        // 診療明細書発行フラグ名称
        medicalInformation.setPrintStatementClassName(StringConstants.EMPTY_STRING);
        // お薬手帳発行フラグ
        medicalInformation.setPrintMedicationNoteClass(StringConstants.EMPTY_STRING);
        // お薬手帳発行フラグ名称
        medicalInformation.setPrintMedicationNoteClassName(StringConstants.EMPTY_STRING);
        // 予約票発行フラグ
        medicalInformation.setPrintAppointmentFormClass(StringConstants.EMPTY_STRING);
        // 予約票発行フラグ名称
        medicalInformation.setPrintAppointmentFormClassName(StringConstants.EMPTY_STRING);
        // データ収集フラグ
        medicalInformation.setDataCollectionCreationClass(StringConstants.EMPTY_STRING);
        // データ収集フラグ名称
        medicalInformation.setDataCollectionCreationClassName(StringConstants.EMPTY_STRING);
        // データ収集提出方法区分
        medicalInformation.setDataCollectionSubmissionMethodClass(StringConstants.EMPTY_STRING);
        // データ収集提出方法区分名称
        medicalInformation.setDataCollectionSubmissionMethodClassName(StringConstants.EMPTY_STRING);
        // ORCAサーベイランス区分
        medicalInformation.setOrcaSurveillanceClass(StringConstants.EMPTY_STRING);
        // ORCAサーベイランス区分名称
        medicalInformation.setOrcaSurveillanceClassName(StringConstants.EMPTY_STRING);
        // 減免計算対象区分
        medicalInformation.setReductionCalculationObjectClass(StringConstants.EMPTY_STRING);
        // 減免計算対象区分名称
        medicalInformation.setReductionCalculationObjectClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分（減免有）
        medicalInformation.setAcMoneyRoundingReductionClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分（減免有）名称
        medicalInformation.setAcMoneyRoundingReductionClassName(StringConstants.EMPTY_STRING);

        /*請求額端数区分（減免無）情報*/
        AcMoneyRoundingNoReductionInformation acMoneyRoundingNoReductionInformation = generateAcMoneyRoundingNoReductionInformation();
        medicalInformation.setAcMoneyRoundingNoReductionInformation(acMoneyRoundingNoReductionInformation);

        // 消費税端数区分
        medicalInformation.setTaxRoundingClass(StringConstants.EMPTY_STRING);
        // 消費税端数区分名称
        medicalInformation.setTaxRoundingClassName(StringConstants.EMPTY_STRING);
        List<ShouhizeiritsuMWebDto> shouhizeiritsuMWebDtoList = basicInfoMapper.selectShouhizeiritsuMDtos(new java.sql.Date(baseDate.getTime()));
        if (!shouhizeiritsuMWebDtoList.isEmpty()) {
            ShouhizeiritsuMWebDto shouhizeiritsuMWebDto = shouhizeiritsuMWebDtoList
                    .stream()
                    .filter(o -> ShouhizeiritsuEnum.NormalTaxRate.getType().equals(o.getShouhizeiType()))
                    .findFirst()
                    .orElse(null);
            if (shouhizeiritsuMWebDto != null) {
                medicalInformation.setTaxRoundingClass(ShouhizeiritsuEnum.NormalTaxRate.getType());
                medicalInformation.setTaxRoundingClassName(String.valueOf(shouhizeiritsuMWebDto.getShouhizeiRate()));
            }
        }
        // 自費保険集計先区分
        medicalInformation.setSelfInsuranceTotalClass(StringConstants.EMPTY_STRING);
        // 自費保険集計先区分名称
        medicalInformation.setSelfInsuranceTotalClassName(StringConstants.EMPTY_STRING);
        // 地方公費保険番号タブ区分
        medicalInformation.setLocalPublicExpensesInsuranceNumberTabClass(StringConstants.EMPTY_STRING);
        // 地方公費保険番号タブ区分名称
        medicalInformation.setLocalPublicExpensesInsuranceNumberTabClassName(StringConstants.EMPTY_STRING);
        // 更正・育成限度額日割計算区分
        medicalInformation.setRehabilitationNurtureCreditLimitCalculateDailyRateClass(StringConstants.EMPTY_STRING);
        // 更正・育成限度額日割計算区分名称
        medicalInformation.setRehabilitationNurtureCreditLimitCalculateDailyRateClassName(StringConstants.EMPTY_STRING);
        // 自費コード数量計算端数区分
        medicalInformation.setOeRoundingClass(StringConstants.EMPTY_STRING);
        // 自費コード数量計算端数区分名称
        medicalInformation.setOeRoundingClassName(StringConstants.EMPTY_STRING);
        List<JihiHasuuMWebDto> jihiHasuuMWebDtoList = basicInfoMapper.selectJihiHasuuMDtos(new java.sql.Date(baseDate.getTime()));
        if (!jihiHasuuMWebDtoList.isEmpty()) {
            JihiHasuuMWebDto jihiHasuuMWebDto = jihiHasuuMWebDtoList.get(0);
            String jishiItemHasuu = String.valueOf(jihiHasuuMWebDto.getJihiItemHasuuKeisan());
            if (HasuuKeisanEnum.OneRoundDown.getCode().equals(jishiItemHasuu)) {
                medicalInformation.setOeRoundingClass(HasuuKeisanEnum.OneRoundDown.getCode());
                medicalInformation.setOeRoundingClassName(HasuuKeisanEnum.OneRoundDown.getDescription());
            } else if (HasuuKeisanEnum.OneRounding.getCode().equals(jishiItemHasuu)) {
                medicalInformation.setOeRoundingClass(HasuuKeisanEnum.OneRounding.getCode());
                medicalInformation.setOeRoundingClassName(HasuuKeisanEnum.OneRounding.getDescription());
            } else if (HasuuKeisanEnum.OneRoundUp.getCode().equals(jishiItemHasuu)) {
                medicalInformation.setOeRoundingClass(HasuuKeisanEnum.OneRoundUp.getCode());
                medicalInformation.setOeRoundingClassName(HasuuKeisanEnum.OneRoundUp.getDescription());
            } else if (HasuuKeisanEnum.TenRoundDown.getCode().equals(jishiItemHasuu)) {
                medicalInformation.setOeRoundingClass(HasuuKeisanEnum.TenRoundDown.getCode());
                medicalInformation.setOeRoundingClassName(HasuuKeisanEnum.TenRoundDown.getDescription());
            } else if (HasuuKeisanEnum.TenRounding.getCode().equals(jishiItemHasuu)) {
                medicalInformation.setOeRoundingClass(HasuuKeisanEnum.TenRounding.getCode());
                medicalInformation.setOeRoundingClassName(HasuuKeisanEnum.TenRounding.getDescription());
            } else if (HasuuKeisanEnum.TenRoundUp.getCode().equals(jishiItemHasuu)) {
                medicalInformation.setOeRoundingClass(HasuuKeisanEnum.TenRoundUp.getCode());
                medicalInformation.setOeRoundingClassName(HasuuKeisanEnum.TenRoundUp.getDescription());
            }
        }

        /*連絡先、広告情報*/
        AddressInformation addressInformation = generateAddressInformation();
        medicalInformation.setAddressInformation(addressInformation);

        return medicalInformation;
    }

    private AcMoneyRoundingNoReductionInformation generateAcMoneyRoundingNoReductionInformation() {

        /*請求額端数区分（減免無）情報*/
        AcMoneyRoundingNoReductionInformation acMoneyRoundingNoReductionInformation = new AcMoneyRoundingNoReductionInformation();
        // 請求額端数区分医保（減免無・保険分）
        acMoneyRoundingNoReductionInformation.setMedicalInsuranceClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分医保（減免無・保険分）名称
        acMoneyRoundingNoReductionInformation.setMedicalInsuranceClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分医保（減免無・自費分）
        acMoneyRoundingNoReductionInformation.setMedicalInsuranceOeClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分医保（減免無・自費分）名称
        acMoneyRoundingNoReductionInformation.setMedicalInsuranceOeClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分労災（減免無・保険分）
        acMoneyRoundingNoReductionInformation.setAccidentInsuranceClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分労災（減免無・保険分）名称
        acMoneyRoundingNoReductionInformation.setAccidentInsuranceClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分労災（減免無・自費分）
        acMoneyRoundingNoReductionInformation.setAccidentInsuranceOeClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分労災（減免無・自費分）名称
        acMoneyRoundingNoReductionInformation.setAccidentInsuranceOeClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分自賠責（減免無・保険分）
        acMoneyRoundingNoReductionInformation.setLiabilityInsuranceClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分自賠責（減免無・保険分）名称
        acMoneyRoundingNoReductionInformation.setLiabilityInsuranceClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分自賠責（減免無・自費分）
        acMoneyRoundingNoReductionInformation.setLiabilityInsuranceOeClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分自賠責（減免無・自費分）名称
        acMoneyRoundingNoReductionInformation.setLiabilityInsuranceOeClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分公害（減免無・自費分）
        acMoneyRoundingNoReductionInformation.setPollutionOeClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分公害（減免無・自費分）名称
        acMoneyRoundingNoReductionInformation.setPollutionOeClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分第三者行為（減免無・保険分）
        acMoneyRoundingNoReductionInformation.setThirdPartyClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分第三者行為（減免無・保険分）名称
        acMoneyRoundingNoReductionInformation.setThirdPartyClassName(StringConstants.EMPTY_STRING);
        // 請求額端数区分第三者行為（減免無・自費分）
        acMoneyRoundingNoReductionInformation.setThirdPartyOeClass(StringConstants.EMPTY_STRING);
        // 請求額端数区分第三者行為（減免無・自費分）名称
        acMoneyRoundingNoReductionInformation.setThirdPartyOeClassName(StringConstants.EMPTY_STRING);
        // 第三者行為（医療費）負担金額計算区分
        acMoneyRoundingNoReductionInformation.setThirdPartyMoneyCalculationClass(StringConstants.EMPTY_STRING);
        // 第三者行為（医療費）負担金額計算区分名称
        acMoneyRoundingNoReductionInformation.setThirdPartyMoneyCalculationClassName(StringConstants.EMPTY_STRING);

        return acMoneyRoundingNoReductionInformation;
    }

    private AddressInformation generateAddressInformation(){

        /*連絡先、広告情報*/
        AddressInformation addressInformation = new AddressInformation();
        // 所在地
        addressInformation.setWholeAddress(StringConstants.EMPTY_STRING);
        // 郵便番号
        addressInformation.setAddressZipCode(StringConstants.EMPTY_STRING);
        // 電話番号
        addressInformation.setPhoneNumber(StringConstants.EMPTY_STRING);
        // FAX番号
        addressInformation.setFaxNumber(StringConstants.EMPTY_STRING);
        // Eメールアドレス
        addressInformation.setEMailAddress(StringConstants.EMPTY_STRING);
        // ホームページアドレス
        addressInformation.setHomepageAddress(StringConstants.EMPTY_STRING);

        return addressInformation;
    }
}
