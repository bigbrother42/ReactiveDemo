package com.em.clinicapi.common.constants.enumerations;

public enum ShouhizeiritsuEnum {

    NormalTaxRate("0", "通常"),
    ReducedTaxRate("1", "食料品軽減税率");

    private final String type;
    private final String description;

    ShouhizeiritsuEnum(String type, String description) {
        this.type = type;
        this.description = description;
    }

    public String getType() {
        return this.type;
    }

    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        return this.type + " " + name();
    }
}
