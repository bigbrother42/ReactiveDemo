package com.em.clinicapi.common.constants.enumerations.errorcode;

// orca api を参照
public enum ShoubyouError implements ApiError {
    PATIENTSEQ_NOT_SET("01", "患者番号の設定がありません"),
    PATIENT_NOT_EXIST("10", "患者番号に該当する患者が存在しません"),
    DATE_NOT_EXIST("11", "基準日が暦日ではありません"),
    INFORMATION_OVERFLOW("20", "対象病名が２００件以上存在します"),
    INFORMATION_NOT_EXIST("21", "対象病名がありません"),
    //  職員情報が取得できません
    // 医療機関情報が取得できません
    // システム日付が取得できません
    // 患者番号構成情報が取得できません
    // グループ医療機関が不整合です。処理を終了して下さい
    // システム項目が設定できません
    Other("89", ""),
    IN_USE_BY_OTHER_TERMINAL("90", "他端末使用中"),
    SHORI_KBN_NOT_SET("91", "処理区分未設定"),
    CONTENT_ERROR("97", "送信内容に誤りがあります"),
    CANT_READ_CONTENT("98", "送信内容の読込ができませんでした"),
    USER_NOT_LOGIN_IN("99", "ユーザID未登録");

    String code;
    String message;

    ShoubyouError(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
