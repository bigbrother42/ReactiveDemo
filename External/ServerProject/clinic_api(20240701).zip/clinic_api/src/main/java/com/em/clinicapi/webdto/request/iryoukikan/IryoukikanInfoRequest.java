package com.em.clinicapi.webdto.request.iryoukikan;


import com.em.clinicapi.webdto.request.base.RequestWebDtoBase;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : IryoukikanInfoRequestWebDto クラス <br/>
 * 項目： 医療機関情報リクエスト <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class IryoukikanInfoRequest extends RequestWebDtoBase {

	/**
	 * 項目： Reskey <br/>
	 */
	@JsonProperty("Reskey")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String reskey;

	/**
	 * 項目： Group_ID <br/>
	 * 説明： <br/>
	 *       グループSEQ <br/>
	 */
	@JsonProperty("Group_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String groupId;

	/**
	 * 項目： Customer_ID <br/>
	 * 説明： <br/>
	 *       顧客SEQ <br/>
	 */
	@JsonProperty("Customer_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String customerId;

	/**
	 * 項目： Request_Number <br/>
	 * 説明： <br/>
	 *       ”04"(医療機関基本情報) <br/>
	 */
	@JsonProperty("Request_Number")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String requestNumber;

	/**
	 * 項目： Base_Date <br/>
	 */
	@JsonProperty("Base_Date")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	private String baseDate;

	/**
	 * Reskeyを返事します。
	 * @return Reskeyの値
	 */
	@JsonProperty("Reskey")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getReskey() {
		return reskey;
	}

	/**
	 * Reskeyを設定します。
	 * @param reskey Reskey
	 */
	@JsonProperty("Reskey")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setReskey(String reskey) {
		this.reskey = reskey;
	}

	/**
	 * Group_IDを返事します。
	 * @return Group_IDの値
	 */
	@JsonProperty("Group_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getGroupId() {
		return groupId;
	}

	/**
	 * Group_IDを設定します。
	 * @param groupId Group_ID
	 */
	@JsonProperty("Group_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	/**
	 * Customer_IDを返事します。
	 * @return Customer_IDの値
	 */
	@JsonProperty("Customer_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getCustomerId() {
		return customerId;
	}

	/**
	 * Customer_IDを設定します。
	 * @param customerId Customer_ID
	 */
	@JsonProperty("Customer_ID")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	/**
	 * Request_Numberを返事します。
	 * @return Request_Numberの値
	 */
	@JsonProperty("Request_Number")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getRequestNumber() {
		return requestNumber;
	}

	/**
	 * Request_Numberを設定します。
	 * @param requestNumber Request_Number
	 */
	@JsonProperty("Request_Number")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setRequestNumber(String requestNumber) {
		this.requestNumber = requestNumber;
	}

	/**
	 * Base_Dateを返事します。
	 * @return Base_Dateの値
	 */
	@JsonProperty("Base_Date")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public String getBaseDate() {
		return baseDate;
	}

	/**
	 * Base_Dateを設定します。
	 * @param baseDate Base_Date
	 */
	@JsonProperty("Base_Date")
	@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
	public void setBaseDate(String baseDate) {
		this.baseDate = baseDate;
	}

}