package com.em.clinicapi.common.exception;

public class JsonParseException extends Exception {

    public JsonParseException(String message) {
        super(message);
    }
}
