package com.em.clinicapi.webdto.base;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.xml.bind.annotation.XmlRootElement;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestBase {

    /**
     * 項目： グループSEQ <br/>
     * 説明： <br/>
     *       グループSEQ <br/>
     */
    @JsonProperty("Group_ID")
    private Integer groupId;

    /**
     * 項目： 顧客SEQ <br/>
     * 説明： <br/>
     *       顧客SEQ <br/>
     */
    @JsonProperty("Customer_ID")
    private Integer customerId;

    /**
     * グループSEQを返事します。
     * @return グループSEQの値
     */
    @JsonProperty("Group_ID")
    public Integer getGroupId() {
        return groupId;
    }

    /**
     * グループSEQを設定します。
     * @param groupId グループSEQ
     */
    @JsonProperty("Group_ID")
    public void setGroupId(Integer groupId) {
        this.groupId = groupId;
    }

    /**
     * 顧客SEQを返事します。
     * @return 顧客SEQの値
     */
    @JsonProperty("Customer_ID")
    public Integer getCustomerId() {
        return customerId;
    }

    /**
     * 顧客SEQを設定します。
     * @param customerId 顧客SEQ
     */
    @JsonProperty("Customer_ID")
    public void setCustomerId(Integer customerId) {
        this.customerId = customerId;
    }

}
