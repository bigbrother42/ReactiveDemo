package com.em.clinicapi.common.constants.enumerations;

public enum HasuuKeisanEnum {
    OneRoundDown("0", "1円未満切り捨て"),
    OneRounding("1", "1円未満四捨五入"),
    OneRoundUp("2", "1円未満切り上げ"),
    TenRoundDown("3", "10円未満切り捨て"),
    TenRounding("4", "10円未満四捨五入"),
    TenRoundUp("5", "10円未満切り上げ");

    private final String code;
    private final String description;

    HasuuKeisanEnum(String code, String description) {
        this.code = code;
        this.description = description;
    }

    public String getCode() {
        return this.code;
    }

    public String getDescription() {
        return this.description;
    }

    @Override
    public String toString() {
        return this.code + " " + name();
    }
}
