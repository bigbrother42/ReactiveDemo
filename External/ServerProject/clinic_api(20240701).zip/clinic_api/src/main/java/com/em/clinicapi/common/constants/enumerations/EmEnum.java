package com.em.clinicapi.common.constants.enumerations;

import java.util.Arrays;

public class EmEnum {
    // マスタータイプ
    public enum MasterType {
        // 診療行為
        Shinryou("S"),
        // 一般名
        Ippanmei("I"),
        // 医薬品
        Iyakuhin("Y"),
        // 特定機材
        Tokuteikizai("T"),
        // コメント
        Comment("C"),
        // 用法
        Youhou("U"),
        // 修飾語
        Shuushokugo("Z"),
        //mks画像合成マスター
        MksMaster("M"),
        // 自費
        Jihi("J"),
        // 傷病名
        Shoubyoumei("B"),
        // 検査
        Kensa("K"),
        // 介護マスター　
        // 20220929 63959 qishiyun add
        KaigoMaster("KGM"),
        // 未使用
        None("None");

        String value;

        MasterType(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum TenkiKbn {
        // なし
        None("0"),
        // 治ゆ
        Cure("2"),
        // 転医
        Transfer("5"),
        // 中止
        Stop("4"),
        // 死亡
        Dead("3");

        String value;

        TenkiKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    public enum OrcaTenkiKbn {
        // なし
        None(""),
        // 死亡
        Dead("D"),
        // 転医
        Transfer("S"),
        // 中止
        Stop("C"),
        // 治ゆ
        Cure("F");


        String value;

        OrcaTenkiKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }
    }

    /**
     * 保険種類
     */
    public enum HokenKbn {

        /**
         * 社保
         */
        SHAHO("1"),

        /**
         * 　国保
         */
        KOKUHO("2"),

        /**
         * 公費
         */
        KOUHI("3"),


        /**
         * 介護
         */
        KAIGO("4"),

        /**
         * 労災
         */
        ROUSAI("5"),

        /**
         * 自賠責
         */
        JIBAISEKI("6"),

        /**
         * 公害
         */
        KOUGAI("7"),

        /**
         * 自費
         */
        JIHI("100"),
        // 20210225 #42719 add start
        /**
         * 治験
         */
        CHIKEN("101"),
        // 20210225 #42719 add end
        /**
         * 保険証忘れ
         */
        NONE("102");

        String value;

        HokenKbn(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public static HokenKbn GeteEnumByValue(String value) {
            return Arrays.stream(HokenKbn.values()).filter(data -> data.getValue().equals(value)).findFirst().orElse(null);
        }
    }

}
