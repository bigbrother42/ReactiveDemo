package com.em.clinicapi.controller;

import com.em.clinicapi.common.constants.RequestConstants;
import com.em.clinicapi.common.constants.enumerations.RequestNumberEnum;
import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.controller.base.BaseController;
import com.em.clinicapi.service.BasicInfoService;
import com.em.clinicapi.webdto.request.iryoukikan.IryoukikanInfoRequestWebDto;
import com.em.clinicapi.webdto.response.iryoukikan.IryoukikanInfoResponseWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/clinic/api/karte")
public class KarteInfoController extends BaseController {

    @Autowired
    private BasicInfoService basicInfoService;

    /**
     * 医療機関情報を取得
     * @param iryoukikanInfoRequestWebDto
     * @return
     */
    @PostMapping(value = "/getiryoukikan", consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
    public IryoukikanInfoResponseWebDto getIryoukikanInfo(@RequestBody IryoukikanInfoRequestWebDto iryoukikanInfoRequestWebDto){
        if (!RequestNumberEnum.InstitutionInfo.getCode().equals(iryoukikanInfoRequestWebDto.getIryoukikanInfoRequest().getRequestNumber())) {
            throw new InvalidRequestException(RequestConstants.REQUEST_NUMBER);
        }

        return basicInfoService.getIryoukikanInfo(iryoukikanInfoRequestWebDto);
    }
}
