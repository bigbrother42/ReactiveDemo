package com.em.clinicapi.mapper;

import com.em.clinicapi.webdto.db.KarteWebDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Date;


@Mapper
public interface KarteInfoMapper {

}
