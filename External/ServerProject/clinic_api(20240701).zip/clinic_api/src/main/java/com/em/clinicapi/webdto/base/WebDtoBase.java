package com.em.clinicapi.webdto.base;

import java.io.Serializable;
import java.sql.Timestamp;

public class WebDtoBase implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /** プロパティ createdBy */
    private int createdBy = 0;

    /** プロパティ createdAt */
    private Timestamp createdAt = null;

    /** プロパティ updatedBy */
    private int updatedBy = 0;

    /** プロパティ updatedAt */
    private Timestamp updatedAt = null;

    /**
     * プロパティー：createdBy を返します。
     *
     * @return createdBy
     */
    public int getCreatedBy() {
        return this.createdBy;
    }

    /**
     * プロパティー：createdBy を設定します。
     *
     * @param createdBy
     */
    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    /**
     * プロパティー：createdAt を返します。
     *
     * @return createdAt
     */
    public java.sql.Timestamp getCreatedAt() {
        return this.createdAt;
    }

    /**
     * プロパティー：createdAt を設定します。
     *
     * @param createdAt
     */
    public void setCreatedAt(java.sql.Timestamp createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * プロパティー：updatedBy を返します。
     *
     * @return updatedBy
     */
    public int getUpdatedBy() {
        return this.updatedBy;
    }

    /**
     * プロパティー：updatedBy を設定します。
     *
     * @param updatedBy
     */
    public void setUpdatedBy(int updatedBy) {
        this.updatedBy = updatedBy;
    }

    /**
     * プロパティー：updatedAt を返します。
     *
     * @return updatedAt
     */
    public java.sql.Timestamp getUpdatedAt() {
        return this.updatedAt;
    }

    /**
     * プロパティー：updatedAt を設定します。
     *
     * @param updatedAt
     */
    public void setUpdatedAt(java.sql.Timestamp updatedAt) {
        this.updatedAt = updatedAt;
    }

}
