package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

public class KisoMonshinWebDto extends CustomerWebDtoBase {
    /**  プロパティ patientSeq */
    private int  patientSeq = 0;

    /**  プロパティ kisoMonshinContent */
    private String  kisoMonshinContent = null;


    /**
     *  デフォルトのコンストラクタ
     */
    public KisoMonshinWebDto()	{
        super();
    }


    /**
     * プロパティー：patientSeq を返します。
     * @return patientSeq
     */
    public int getPatientSeq(){
        return patientSeq;
    }

    /**
     * プロパティー：patientSeq を設定します。
     * @param param  int patientSeq
     */
    public void setPatientSeq(int patientSeq){
        this.patientSeq = patientSeq;
    }

    /**
     * プロパティー：kisoMonshinContent を返します。
     * @return kisoMonshinContent
     */
    public String getKisoMonshinContent(){
        return kisoMonshinContent;
    }

    /**
     * プロパティー：kisoMonshinContent を設定します。
     * @param param  String kisoMonshinContent
     */
    public void setKisoMonshinContent(String kisoMonshinContent){
        this.kisoMonshinContent = kisoMonshinContent;
    }
}
