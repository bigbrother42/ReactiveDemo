package com.em.clinicapi.webdto.response.basicinfo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import javax.validation.Valid;

@JacksonXmlRootElement(localName = "xmlio2")
public class UserBasicInfoResponseWebDto {
    @Valid
    @JsonProperty("physicianres")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private UserBasicInfoResponse userBasicInfoResponse;

    @JsonProperty("physicianres")
    public UserBasicInfoResponse getUserBasicInfoResponse() {
        return userBasicInfoResponse;
    }

    @JsonProperty("physicianres")
    public void setUserBasicInfoResponse(UserBasicInfoResponse userBasicInfoResponse) {
        this.userBasicInfoResponse = userBasicInfoResponse;
    }
}
