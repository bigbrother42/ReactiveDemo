package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : Certification クラス <br/>
 * 項目： Certification <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class Certification extends ResponseWebDtoBase {

	/**
	 * 項目： Need_Care_State_Code <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Need_Care_State_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String needCareStateCode;
	/**
	 * 項目： Need_Care_State <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Need_Care_State")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String needCareState;
	/**
	 * 項目： Certification_Date <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certification_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificationDate;
	/**
	 * 項目： Certificate_StartDate <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateStartDate;
	/**
	 * 項目： Certificate_ExpiredDate <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateExpiredDate;
	/**
	 * Need_Care_State_Codeを返事します。
	 * @return Need_Care_State_Codeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Need_Care_State_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getNeedCareStateCode() {
		return needCareStateCode;
	}

	/**
	 * Need_Care_State_Codeを設定します。
	 * @param needCareStateCode Need_Care_State_Code
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Need_Care_State_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setNeedCareStateCode(String needCareStateCode) {
		this.needCareStateCode = needCareStateCode;
	}

	/**
	 * Need_Care_Stateを返事します。
	 * @return Need_Care_Stateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Need_Care_State")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getNeedCareState() {
		return needCareState;
	}

	/**
	 * Need_Care_Stateを設定します。
	 * @param needCareState Need_Care_State
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Need_Care_State")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setNeedCareState(String needCareState) {
		this.needCareState = needCareState;
	}

	/**
	 * Certification_Dateを返事します。
	 * @return Certification_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certification_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificationDate() {
		return certificationDate;
	}

	/**
	 * Certification_Dateを設定します。
	 * @param certificationDate Certification_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certification_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificationDate(String certificationDate) {
		this.certificationDate = certificationDate;
	}

	/**
	 * Certificate_StartDateを返事します。
	 * @return Certificate_StartDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateStartDate() {
		return certificateStartDate;
	}

	/**
	 * Certificate_StartDateを設定します。
	 * @param certificateStartDate Certificate_StartDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateStartDate(String certificateStartDate) {
		this.certificateStartDate = certificateStartDate;
	}

	/**
	 * Certificate_ExpiredDateを返事します。
	 * @return Certificate_ExpiredDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateExpiredDate() {
		return certificateExpiredDate;
	}

	/**
	 * Certificate_ExpiredDateを設定します。
	 * @param certificateExpiredDate Certificate_ExpiredDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateExpiredDate(String certificateExpiredDate) {
		this.certificateExpiredDate = certificateExpiredDate;
	}

}