package com.em.clinicapi.logic;

import org.springframework.stereotype.Component;

@Component
public class KarteInfoLogic {

}