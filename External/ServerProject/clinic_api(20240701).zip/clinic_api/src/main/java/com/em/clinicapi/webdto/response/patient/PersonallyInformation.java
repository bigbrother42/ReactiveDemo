package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : PersonallyInformation クラス <br/>
 * 項目： Personally_Information <br/>
 * 説明： <br/>
 *       患者個別情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class PersonallyInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Pregnant_Class <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pregnant_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pregnantClass;
	/**
	 * 項目： Community_Disease2 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Disease2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String communityDisease2;
	/**
	 * 項目： Community_Disease3 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Disease3")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String communityDisease3;
	/**
	 * Pregnant_Classを返事します。
	 * @return Pregnant_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pregnant_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPregnantClass() {
		return pregnantClass;
	}

	/**
	 * Pregnant_Classを設定します。
	 * @param pregnantClass Pregnant_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pregnant_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPregnantClass(String pregnantClass) {
		this.pregnantClass = pregnantClass;
	}

	/**
	 * Community_Disease2を返事します。
	 * @return Community_Disease2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Disease2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCommunityDisease2() {
		return communityDisease2;
	}

	/**
	 * Community_Disease2を設定します。
	 * @param communityDisease2 Community_Disease2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Disease2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCommunityDisease2(String communityDisease2) {
		this.communityDisease2 = communityDisease2;
	}

	/**
	 * Community_Disease3を返事します。
	 * @return Community_Disease3の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Disease3")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCommunityDisease3() {
		return communityDisease3;
	}

	/**
	 * Community_Disease3を設定します。
	 * @param communityDisease3 Community_Disease3
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Community_Disease3")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCommunityDisease3(String communityDisease3) {
		this.communityDisease3 = communityDisease3;
	}

}