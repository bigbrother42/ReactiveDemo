package com.em.clinicapi.webdto.response.patient;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : AccidentInsuranceInformation クラス <br/>
 * 項目： Accident_Insurance_Information <br/>
 * 説明： <br/>
 *       労災、自賠責情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class AccidentInsuranceInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Accident_Insurance_WholeName <br/>
	 * 説明： <br/>
	 *       労災保険の保険区分名を返却 <br/>
	 * 備考： <br/>
	 *       "短期業務" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentInsuranceWholeName;
	/**
	 * 項目： Disease_Location <br/>
	 * 説明： <br/>
	 *       傷病部位 <br/>
	 * 備考： <br/>
	 *       ”” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Disease_Location")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String diseaseLocation;
	/**
	 * 項目： Disease_Date <br/>
	 * 説明： <br/>
	 *       労災保険の療養開始日を返却　※未指定の場合は1900-01-01 <br/>
	 * 備考： <br/>
	 *       "2022-05-11" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Disease_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String diseaseDate;
	/**
	 * 項目： Accident_Insurance_Number <br/>
	 * 説明： <br/>
	 *       労災保険の労働保険番号を返却 <br/>
	 * 備考： <br/>
	 *       "11111111111111" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentInsuranceNumber;
	/**
	 * 項目： PensionCertificate_Number <br/>
	 * 説明： <br/>
	 *       労災保険の年金証書番号を返却　※未指定の場合は空値 <br/>
	 * 備考： <br/>
	 *       "12345" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PensionCertificate_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pensionCertificateNumber;
	/**
	 * 項目： Accident_Class <br/>
	 * 説明： <br/>
	 *       災害区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentClass;
	/**
	 * 項目： Labor_Station_Code <br/>
	 * 説明： <br/>
	 *       労働基準監督署コード <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Labor_Station_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String laborStationCode;
	/**
	 * 項目： Labor_Station_Code_Name <br/>
	 * 説明： <br/>
	 *       労働基準監督署名 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Labor_Station_Code_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String laborStationCodeName;
	/**
	 * 項目： Liability_Office_Information <br/>
	 * 説明： <br/>
	 *       事業所情報 <br/>
	 */
	@Valid
		@JsonProperty("Liability_Office_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private LiabilityOfficeInformation liabilityOfficeInformation;
	/**
	 * 項目： Liability_Insurance_Office_Name <br/>
	 * 説明： <br/>
	 *       主保険の事業所SEQに紐づく事業所名 <br/>
	 *       ※保険区分が”6”(自賠責) <br/>
	 * 備考： <br/>
	 *       "テスト損害保険株式会社" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Office_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String liabilityInsuranceOfficeName;
	/**
	 * 項目： PersonalHealthRecord_Number <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PersonalHealthRecord_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String personalHealthRecordNumber;
	/**
	 * 項目： Damage_Class <br/>
	 */
	@Valid
		@JsonProperty("Damage_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private DamageClass damageClass;
	/**
	 * Accident_Insurance_WholeNameを返事します。
	 * @return Accident_Insurance_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentInsuranceWholeName() {
		return accidentInsuranceWholeName;
	}

	/**
	 * Accident_Insurance_WholeNameを設定します。
	 * @param accidentInsuranceWholeName Accident_Insurance_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceWholeName(String accidentInsuranceWholeName) {
		this.accidentInsuranceWholeName = accidentInsuranceWholeName;
	}

	/**
	 * Disease_Locationを返事します。
	 * @return Disease_Locationの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Disease_Location")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDiseaseLocation() {
		return diseaseLocation;
	}

	/**
	 * Disease_Locationを設定します。
	 * @param diseaseLocation Disease_Location
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Disease_Location")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDiseaseLocation(String diseaseLocation) {
		this.diseaseLocation = diseaseLocation;
	}

	/**
	 * Disease_Dateを返事します。
	 * @return Disease_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Disease_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getDiseaseDate() {
		return diseaseDate;
	}

	/**
	 * Disease_Dateを設定します。
	 * @param diseaseDate Disease_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Disease_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDiseaseDate(String diseaseDate) {
		this.diseaseDate = diseaseDate;
	}

	/**
	 * Accident_Insurance_Numberを返事します。
	 * @return Accident_Insurance_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentInsuranceNumber() {
		return accidentInsuranceNumber;
	}

	/**
	 * Accident_Insurance_Numberを設定します。
	 * @param accidentInsuranceNumber Accident_Insurance_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceNumber(String accidentInsuranceNumber) {
		this.accidentInsuranceNumber = accidentInsuranceNumber;
	}

	/**
	 * PensionCertificate_Numberを返事します。
	 * @return PensionCertificate_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PensionCertificate_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPensionCertificateNumber() {
		return pensionCertificateNumber;
	}

	/**
	 * PensionCertificate_Numberを設定します。
	 * @param pensionCertificateNumber PensionCertificate_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PensionCertificate_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPensionCertificateNumber(String pensionCertificateNumber) {
		this.pensionCertificateNumber = pensionCertificateNumber;
	}

	/**
	 * Accident_Classを返事します。
	 * @return Accident_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentClass() {
		return accidentClass;
	}

	/**
	 * Accident_Classを設定します。
	 * @param accidentClass Accident_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentClass(String accidentClass) {
		this.accidentClass = accidentClass;
	}

	/**
	 * Labor_Station_Codeを返事します。
	 * @return Labor_Station_Codeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Labor_Station_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLaborStationCode() {
		return laborStationCode;
	}

	/**
	 * Labor_Station_Codeを設定します。
	 * @param laborStationCode Labor_Station_Code
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Labor_Station_Code")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLaborStationCode(String laborStationCode) {
		this.laborStationCode = laborStationCode;
	}

	/**
	 * Labor_Station_Code_Nameを返事します。
	 * @return Labor_Station_Code_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Labor_Station_Code_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLaborStationCodeName() {
		return laborStationCodeName;
	}

	/**
	 * Labor_Station_Code_Nameを設定します。
	 * @param laborStationCodeName Labor_Station_Code_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Labor_Station_Code_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLaborStationCodeName(String laborStationCodeName) {
		this.laborStationCodeName = laborStationCodeName;
	}

	/**
	 * Liability_Office_Informationを返事します。
	 * @return Liability_Office_Informationの値
	 */
		@JsonProperty("Liability_Office_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public LiabilityOfficeInformation getLiabilityOfficeInformation() {
		return liabilityOfficeInformation;
	}

	/**
	 * Liability_Office_Informationを設定します。
	 * @param liabilityOfficeInformation Liability_Office_Information
	 */
		@JsonProperty("Liability_Office_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLiabilityOfficeInformation(LiabilityOfficeInformation liabilityOfficeInformation) {
		this.liabilityOfficeInformation = liabilityOfficeInformation;
	}

	/**
	 * Liability_Insurance_Office_Nameを返事します。
	 * @return Liability_Insurance_Office_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Office_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLiabilityInsuranceOfficeName() {
		return liabilityInsuranceOfficeName;
	}

	/**
	 * Liability_Insurance_Office_Nameを設定します。
	 * @param liabilityInsuranceOfficeName Liability_Insurance_Office_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Office_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLiabilityInsuranceOfficeName(String liabilityInsuranceOfficeName) {
		this.liabilityInsuranceOfficeName = liabilityInsuranceOfficeName;
	}

	/**
	 * PersonalHealthRecord_Numberを返事します。
	 * @return PersonalHealthRecord_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PersonalHealthRecord_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPersonalHealthRecordNumber() {
		return personalHealthRecordNumber;
	}

	/**
	 * PersonalHealthRecord_Numberを設定します。
	 * @param personalHealthRecordNumber PersonalHealthRecord_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PersonalHealthRecord_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPersonalHealthRecordNumber(String personalHealthRecordNumber) {
		this.personalHealthRecordNumber = personalHealthRecordNumber;
	}

	/**
	 * Damage_Classを返事します。
	 * @return Damage_Classの値
	 */
		@JsonProperty("Damage_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public DamageClass getDamageClass() {
		return damageClass;
	}

	/**
	 * Damage_Classを設定します。
	 * @param damageClass Damage_Class
	 */
		@JsonProperty("Damage_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setDamageClass(DamageClass damageClass) {
		this.damageClass = damageClass;
	}

}