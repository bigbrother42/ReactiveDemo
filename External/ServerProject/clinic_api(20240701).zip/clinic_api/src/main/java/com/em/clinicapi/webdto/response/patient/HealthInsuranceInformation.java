package com.em.clinicapi.webdto.response.patient;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : HealthInsuranceInformation クラス <br/>
 * 項目： HealthInsurance_Information <br/>
 * 説明： <br/>
 *       保険組み合わせ情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************

public class HealthInsuranceInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Insurance_Combination_Number <br/>
	 * 説明： <br/>
	 *       主保険の主保険SEQを返却 <br/>
	 * 備考： <br/>
	 *       1.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_Combination_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceCombinationNumber;
	/**
	 * 項目： InsuranceCombination_Rate_Admission <br/>
	 * 説明： <br/>
	 *       入院負担割合 <br/>
	 * 備考： <br/>
	 *       0.0 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceCombination_Rate_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceCombinationRateAdmission;
	/**
	 * 項目： InsuranceCombination_Rate_Outpatient <br/>
	 * 説明： <br/>
	 *       主保険歴の患者負担割合を返却 <br/>
	 * 備考： <br/>
	 *       0.3 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceCombination_Rate_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceCombinationRateOutpatient;
	/**
	 * 項目： Insurance_Nondisplay <br/>
	 * 説明： <br/>
	 *       保険組み合わせ非表示区分 <br/>
	 *       (”O":外来非表示、”I”：入院非表示、”N"：非表示なし) <br/>
	 * 備考： <br/>
	 *       "N" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_Nondisplay")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceNondisplay;
	/**
	 * 項目： InsuranceProvider_Class <br/>
	 * 説明： <br/>
	 *       主保険の保険区分を返却 <br/>
	 *       "1":社保、"2":国保、"3":公費、"4":介護 <br/>
	 *       "5":労災、"6"自賠責、"7":公害、"100":自費 <br/>
	 *       "101"：治験、"102":保険証忘れ <br/>
	 * 備考： <br/>
	 *       ”2” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceProviderClass;
	/**
	 * 項目： InsuranceProvider_Number <br/>
	 * 説明： <br/>
	 *       主保険の保険者番号を返却 <br/>
	 * 備考： <br/>
	 *       "1234567" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceProviderNumber;
	/**
	 * 項目： InsuranceProvider_WholeName <br/>
	 * 説明： <br/>
	 *       保険者区分の名称を返却 <br/>
	 * 備考： <br/>
	 *       "国保” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceProviderWholeName;
	/**
	 * 項目： HealthInsuredPerson_Symbol <br/>
	 * 説明： <br/>
	 *       主保険の記号を返却 <br/>
	 * 備考： <br/>
	 *       "０１" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Symbol")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonSymbol;
	/**
	 * 項目： HealthInsuredPerson_Number <br/>
	 * 説明： <br/>
	 *       主保険の番号を返却 <br/>
	 * 備考： <br/>
	 *       "１２３４５" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonNumber;
	/**
	 * 項目： HealthInsuredPerson_Branch_Number <br/>
	 * 説明： <br/>
	 *       主保険の枝番を返却 <br/>
	 * 備考： <br/>
	 *       "01" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Branch_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonBranchNumber;
	/**
	 * 項目： HealthInsuredPerson_Continuation <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Continuation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonContinuation;
	/**
	 * 項目： HealthInsuredPerson_Assistance <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Assistance")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonAssistance;
	/**
	 * 項目： HealthInsuredPerson_Assistance_Name <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Assistance_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonAssistanceName;
	/**
	 * 項目： RelationToInsuredPerson <br/>
	 * 説明： <br/>
	 *       本人家族区分　(1:本人、2:家族) <br/>
	 * 備考： <br/>
	 *       "1" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("RelationToInsuredPerson")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String relationToInsuredPerson;
	/**
	 * 項目： HealthInsuredPerson_WholeName <br/>
	 * 説明： <br/>
	 *       主保険の被保険者氏名を返却 <br/>
	 * 備考： <br/>
	 *       "患者　太郎" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonWholeName;
	/**
	 * 項目： Certificate_StartDate <br/>
	 * 説明： <br/>
	 *       主保険の開始日を返却　※未指定の場合は1900-01-01 <br/>
	 * 備考： <br/>
	 *       "2023-01-01" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateStartDate;
	/**
	 * 項目： Certificate_ExpiredDate <br/>
	 * 説明： <br/>
	 *       主保険の終了日を返却　※未指定の場合は9999-12-31 <br/>
	 * 備考： <br/>
	 *       "2025-12-31" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateExpiredDate;
	/**
	 * 項目： Certificate_GetDate <br/>
	 * 説明： <br/>
	 *       主保険の資格取得日を返却　※未指定の場合は1900-01-01 <br/>
	 * 備考： <br/>
	 *       "2023-01-01" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_GetDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateGetDate;
	/**
	 * 項目： Insurance_CheckDate <br/>
	 * 説明： <br/>
	 *       当該保険の最終確認日を返却　※ない場合は1900-01-01 <br/>
	 * 備考： <br/>
	 *       "2024-02-24" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_CheckDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceCheckDate;
	/**
	 * 項目： PublicInsurance_Information <br/>
	 * 説明： <br/>
	 *       公費情報 <br/>
	 */
		@JsonProperty("PublicInsurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PublicInsuranceInformationArr publicInsuranceInformationArr;
	/**
	 * 項目： Accident_Insurance_Information <br/>
	 * 説明： <br/>
	 *       労災、自賠責情報 <br/>
	 */
	@Valid
		@JsonProperty("Accident_Insurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AccidentInsuranceInformation accidentInsuranceInformation;
	/**
	 * Insurance_Combination_Numberを返事します。
	 * @return Insurance_Combination_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_Combination_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceCombinationNumber() {
		return insuranceCombinationNumber;
	}

	/**
	 * Insurance_Combination_Numberを設定します。
	 * @param insuranceCombinationNumber Insurance_Combination_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_Combination_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceCombinationNumber(String insuranceCombinationNumber) {
		this.insuranceCombinationNumber = insuranceCombinationNumber;
	}

	/**
	 * InsuranceCombination_Rate_Admissionを返事します。
	 * @return InsuranceCombination_Rate_Admissionの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceCombination_Rate_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceCombinationRateAdmission() {
		return insuranceCombinationRateAdmission;
	}

	/**
	 * InsuranceCombination_Rate_Admissionを設定します。
	 * @param insuranceCombinationRateAdmission InsuranceCombination_Rate_Admission
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceCombination_Rate_Admission")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceCombinationRateAdmission(String insuranceCombinationRateAdmission) {
		this.insuranceCombinationRateAdmission = insuranceCombinationRateAdmission;
	}

	/**
	 * InsuranceCombination_Rate_Outpatientを返事します。
	 * @return InsuranceCombination_Rate_Outpatientの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceCombination_Rate_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceCombinationRateOutpatient() {
		return insuranceCombinationRateOutpatient;
	}

	/**
	 * InsuranceCombination_Rate_Outpatientを設定します。
	 * @param insuranceCombinationRateOutpatient InsuranceCombination_Rate_Outpatient
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceCombination_Rate_Outpatient")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceCombinationRateOutpatient(String insuranceCombinationRateOutpatient) {
		this.insuranceCombinationRateOutpatient = insuranceCombinationRateOutpatient;
	}

	/**
	 * Insurance_Nondisplayを返事します。
	 * @return Insurance_Nondisplayの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_Nondisplay")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceNondisplay() {
		return insuranceNondisplay;
	}

	/**
	 * Insurance_Nondisplayを設定します。
	 * @param insuranceNondisplay Insurance_Nondisplay
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_Nondisplay")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceNondisplay(String insuranceNondisplay) {
		this.insuranceNondisplay = insuranceNondisplay;
	}

	/**
	 * InsuranceProvider_Classを返事します。
	 * @return InsuranceProvider_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceProviderClass() {
		return insuranceProviderClass;
	}

	/**
	 * InsuranceProvider_Classを設定します。
	 * @param insuranceProviderClass InsuranceProvider_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceProviderClass(String insuranceProviderClass) {
		this.insuranceProviderClass = insuranceProviderClass;
	}

	/**
	 * InsuranceProvider_Numberを返事します。
	 * @return InsuranceProvider_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceProviderNumber() {
		return insuranceProviderNumber;
	}

	/**
	 * InsuranceProvider_Numberを設定します。
	 * @param insuranceProviderNumber InsuranceProvider_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceProviderNumber(String insuranceProviderNumber) {
		this.insuranceProviderNumber = insuranceProviderNumber;
	}

	/**
	 * InsuranceProvider_WholeNameを返事します。
	 * @return InsuranceProvider_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceProviderWholeName() {
		return insuranceProviderWholeName;
	}

	/**
	 * InsuranceProvider_WholeNameを設定します。
	 * @param insuranceProviderWholeName InsuranceProvider_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceProviderWholeName(String insuranceProviderWholeName) {
		this.insuranceProviderWholeName = insuranceProviderWholeName;
	}

	/**
	 * HealthInsuredPerson_Symbolを返事します。
	 * @return HealthInsuredPerson_Symbolの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Symbol")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonSymbol() {
		return healthInsuredPersonSymbol;
	}

	/**
	 * HealthInsuredPerson_Symbolを設定します。
	 * @param healthInsuredPersonSymbol HealthInsuredPerson_Symbol
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Symbol")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonSymbol(String healthInsuredPersonSymbol) {
		this.healthInsuredPersonSymbol = healthInsuredPersonSymbol;
	}

	/**
	 * HealthInsuredPerson_Numberを返事します。
	 * @return HealthInsuredPerson_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonNumber() {
		return healthInsuredPersonNumber;
	}

	/**
	 * HealthInsuredPerson_Numberを設定します。
	 * @param healthInsuredPersonNumber HealthInsuredPerson_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonNumber(String healthInsuredPersonNumber) {
		this.healthInsuredPersonNumber = healthInsuredPersonNumber;
	}

	/**
	 * HealthInsuredPerson_Branch_Numberを返事します。
	 * @return HealthInsuredPerson_Branch_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Branch_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonBranchNumber() {
		return healthInsuredPersonBranchNumber;
	}

	/**
	 * HealthInsuredPerson_Branch_Numberを設定します。
	 * @param healthInsuredPersonBranchNumber HealthInsuredPerson_Branch_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Branch_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonBranchNumber(String healthInsuredPersonBranchNumber) {
		this.healthInsuredPersonBranchNumber = healthInsuredPersonBranchNumber;
	}

	/**
	 * HealthInsuredPerson_Continuationを返事します。
	 * @return HealthInsuredPerson_Continuationの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Continuation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonContinuation() {
		return healthInsuredPersonContinuation;
	}

	/**
	 * HealthInsuredPerson_Continuationを設定します。
	 * @param healthInsuredPersonContinuation HealthInsuredPerson_Continuation
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Continuation")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonContinuation(String healthInsuredPersonContinuation) {
		this.healthInsuredPersonContinuation = healthInsuredPersonContinuation;
	}

	/**
	 * HealthInsuredPerson_Assistanceを返事します。
	 * @return HealthInsuredPerson_Assistanceの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Assistance")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonAssistance() {
		return healthInsuredPersonAssistance;
	}

	/**
	 * HealthInsuredPerson_Assistanceを設定します。
	 * @param healthInsuredPersonAssistance HealthInsuredPerson_Assistance
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Assistance")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonAssistance(String healthInsuredPersonAssistance) {
		this.healthInsuredPersonAssistance = healthInsuredPersonAssistance;
	}

	/**
	 * HealthInsuredPerson_Assistance_Nameを返事します。
	 * @return HealthInsuredPerson_Assistance_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Assistance_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonAssistanceName() {
		return healthInsuredPersonAssistanceName;
	}

	/**
	 * HealthInsuredPerson_Assistance_Nameを設定します。
	 * @param healthInsuredPersonAssistanceName HealthInsuredPerson_Assistance_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Assistance_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonAssistanceName(String healthInsuredPersonAssistanceName) {
		this.healthInsuredPersonAssistanceName = healthInsuredPersonAssistanceName;
	}

	/**
	 * RelationToInsuredPersonを返事します。
	 * @return RelationToInsuredPersonの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("RelationToInsuredPerson")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRelationToInsuredPerson() {
		return relationToInsuredPerson;
	}

	/**
	 * RelationToInsuredPersonを設定します。
	 * @param relationToInsuredPerson RelationToInsuredPerson
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("RelationToInsuredPerson")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRelationToInsuredPerson(String relationToInsuredPerson) {
		this.relationToInsuredPerson = relationToInsuredPerson;
	}

	/**
	 * HealthInsuredPerson_WholeNameを返事します。
	 * @return HealthInsuredPerson_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonWholeName() {
		return healthInsuredPersonWholeName;
	}

	/**
	 * HealthInsuredPerson_WholeNameを設定します。
	 * @param healthInsuredPersonWholeName HealthInsuredPerson_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonWholeName(String healthInsuredPersonWholeName) {
		this.healthInsuredPersonWholeName = healthInsuredPersonWholeName;
	}

	/**
	 * Certificate_StartDateを返事します。
	 * @return Certificate_StartDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateStartDate() {
		return certificateStartDate;
	}

	/**
	 * Certificate_StartDateを設定します。
	 * @param certificateStartDate Certificate_StartDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateStartDate(String certificateStartDate) {
		this.certificateStartDate = certificateStartDate;
	}

	/**
	 * Certificate_ExpiredDateを返事します。
	 * @return Certificate_ExpiredDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateExpiredDate() {
		return certificateExpiredDate;
	}

	/**
	 * Certificate_ExpiredDateを設定します。
	 * @param certificateExpiredDate Certificate_ExpiredDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateExpiredDate(String certificateExpiredDate) {
		this.certificateExpiredDate = certificateExpiredDate;
	}

	/**
	 * Certificate_GetDateを返事します。
	 * @return Certificate_GetDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_GetDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateGetDate() {
		return certificateGetDate;
	}

	/**
	 * Certificate_GetDateを設定します。
	 * @param certificateGetDate Certificate_GetDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_GetDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateGetDate(String certificateGetDate) {
		this.certificateGetDate = certificateGetDate;
	}

	/**
	 * Insurance_CheckDateを返事します。
	 * @return Insurance_CheckDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_CheckDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceCheckDate() {
		return insuranceCheckDate;
	}

	/**
	 * Insurance_CheckDateを設定します。
	 * @param insuranceCheckDate Insurance_CheckDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Insurance_CheckDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceCheckDate(String insuranceCheckDate) {
		this.insuranceCheckDate = insuranceCheckDate;
	}

	/**
	 * PublicInsurance_Informationを返事します。
	 * @return PublicInsurance_Informationの値
	 */
	@JsonProperty("PublicInsurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public PublicInsuranceInformationArr getPublicInsuranceInformationArr() {
		return publicInsuranceInformationArr;
	}

	/**
	 * PublicInsurance_Informationを設定します。
	 * @param publicInsuranceInformationArr PublicInsurance_Information
	 */
	@JsonProperty("PublicInsurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPublicInsuranceInformationArr(PublicInsuranceInformationArr publicInsuranceInformationArr) {
		this.publicInsuranceInformationArr = publicInsuranceInformationArr;
	}

	/**
	 * Accident_Insurance_Informationを返事します。
	 * @return Accident_Insurance_Informationの値
	 */
		@JsonProperty("Accident_Insurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public AccidentInsuranceInformation getAccidentInsuranceInformation() {
		return accidentInsuranceInformation;
	}

	/**
	 * Accident_Insurance_Informationを設定します。
	 * @param accidentInsuranceInformation Accident_Insurance_Information
	 */
		@JsonProperty("Accident_Insurance_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceInformation(AccidentInsuranceInformation accidentInsuranceInformation) {
		this.accidentInsuranceInformation = accidentInsuranceInformation;
	}

}