package com.em.clinicapi.mapper;

import com.em.clinicapi.webdto.ReplicationMCustomWebDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface EmReplicationMapper {

    public ReplicationMCustomWebDto selectGroupCustomerReplication(@Param("groupSeq") Integer groupSeq, @Param("customerSeq") Integer customerSeq);
}
