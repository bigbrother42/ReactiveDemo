package com.em.clinicapi.webdto.response.base;

import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.util.StringUtil;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;

import java.io.IOException;

public class XmlTypeStringAttributeSerialize extends JsonSerializer<String> {

    private final String ATTRIBUTE_NAME = "type";
    private final String ATTRIBUTE_VAL = "string";

    @Override
    public void serialize(String value, JsonGenerator gen, SerializerProvider serializers) throws IOException, JsonProcessingException {
        if (gen instanceof ToXmlGenerator) {
            ToXmlGenerator xmlGen = (ToXmlGenerator) gen;

            xmlGen.writeStartObject();
            xmlGen.setNextIsAttribute(true);
            xmlGen.writeStringField(ATTRIBUTE_NAME, ATTRIBUTE_VAL);
            xmlGen.setNextIsAttribute(false);

            if (!StringUtil.isNullOrEmpty(value)) {
                xmlGen.setNextIsUnwrapped(true);
                xmlGen.writeStringField(StringConstants.EMPTY_STRING, value);
            }

            xmlGen.writeEndObject();
        } else {
            gen.writeString(value);
        }
    }
}
