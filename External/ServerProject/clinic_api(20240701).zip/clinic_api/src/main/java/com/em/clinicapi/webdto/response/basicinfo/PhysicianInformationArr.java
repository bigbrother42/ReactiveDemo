package com.em.clinicapi.webdto.response.basicinfo;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class PhysicianInformationArr extends ResponseWebDtoBase {
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonProperty("Physician_Information_child")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<PhysicianInformation> physicianInformation;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonProperty("Physician_Information_child")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<PhysicianInformation> getPhysicianInformation() {
        return physicianInformation;
    }

    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonProperty("Physician_Information_child")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setPhysicianInformation(List<PhysicianInformation> physicianInformation) {
        this.physicianInformation = physicianInformation;
    }
}
