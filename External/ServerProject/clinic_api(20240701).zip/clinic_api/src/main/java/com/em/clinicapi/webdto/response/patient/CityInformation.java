package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : CityInformation クラス <br/>
 * 項目： City_Information <br/>
 * 説明： <br/>
 *       事業所の住所＋番地を返却 <br/>
 * 備考： <br/>
 *       "大阪府大阪市　〇〇" <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class CityInformation extends ResponseWebDtoBase {

	/**
	 * 項目： C_WholeName <br/>
	 * 説明： <br/>
	 *       都市区名 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String cWholeName;
	/**
	 * 項目： C_Class <br/>
	 * 説明： <br/>
	 *       都市区コード <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String cClass;
	/**
	 * 項目： C_Class_Name <br/>
	 * 説明： <br/>
	 *       都市の区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String cClassName;
	/**
	 * C_WholeNameを返事します。
	 * @return C_WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCWholeName() {
		return cWholeName;
	}

	/**
	 * C_WholeNameを設定します。
	 * @param cWholeName C_WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCWholeName(String cWholeName) {
		this.cWholeName = cWholeName;
	}

	/**
	 * C_Classを返事します。
	 * @return C_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCClass() {
		return cClass;
	}

	/**
	 * C_Classを設定します。
	 * @param cClass C_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCClass(String cClass) {
		this.cClass = cClass;
	}

	/**
	 * C_Class_Nameを返事します。
	 * @return C_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCClassName() {
		return cClassName;
	}

	/**
	 * C_Class_Nameを設定します。
	 * @param cClassName C_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("C_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCClassName(String cClassName) {
		this.cClassName = cClassName;
	}

}