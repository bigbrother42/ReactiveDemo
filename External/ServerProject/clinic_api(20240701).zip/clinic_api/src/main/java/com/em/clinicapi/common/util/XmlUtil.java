package com.em.clinicapi.common.util;

import com.em.clinicapi.common.constants.RegexConstants;
import com.em.clinicapi.common.constants.StringConstants;
import com.em.clinicapi.common.exception.XmlParseException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class XmlUtil {

    public static <T> T parseObject(String text, Class<T> targetClass) throws XmlParseException {
        try{
            if (!text.isEmpty()) {
                text = text.replaceAll(RegexConstants.WRAP_AND_ENTER, StringConstants.EMPTY_STRING);

                XmlMapper xmlMapper = new XmlMapper();

                return xmlMapper.readValue(text, targetClass);
            }
            else {
                // TODO exception message
                throw new XmlParseException("xml is empty!");
            }
        } catch(Exception e) {
            // TODO exception message
            throw new XmlParseException("", e);
        }
    }

    public static String findNode(String xmlContent, String nodeName) {
        StringBuilder stringBuilder = new StringBuilder();
        String regex = stringBuilder
                .append("<")
                .append(nodeName)
                .append("[^>]*>([^<]*)</")
                .append(nodeName)
                .append(">")
                .toString();
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(xmlContent);

        String content = StringConstants.EMPTY_STRING;
        if (matcher.find()) {
            content = matcher.group(1);
        }

        return content;
    }
}
