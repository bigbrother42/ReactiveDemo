package com.em.clinicapi.common.constants;

public class StringConstants {

    public static final String EMPTY_STRING = "";
    public static final String NULL_STRING = "null";

    public static final String NUMBER_0 = "0";
    public static final String NUMBER_1 = "1";
    public static final String NUMBER_2 = "2";

    public static final String CLASS_TYPE_RECORD = "record";
    public static final String CLASS_TYPE_ARRAY = "array";
}
