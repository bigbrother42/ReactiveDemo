package com.em.clinicapi.mapper;

import com.em.clinicapi.webdto.db.JihiHasuuMWebDto;
import com.em.clinicapi.webdto.db.ShouhizeiritsuMWebDto;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequest;
import com.em.clinicapi.webdto.response.basicinfo.PhysicianInformation;
import com.em.clinicapi.webdto.response.iryoukikan.MedicalInformation;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.util.List;

@Mapper
public interface BasicInfoMapper {

    public List<PhysicianInformation> selectDoctorBasicInfo();

    MedicalInformation selectIryoukikanInfo(@Param("customerSeq") Integer customerSeq, @Param("baseDate") Date baseDate);

    public List<ShouhizeiritsuMWebDto> selectShouhizeiritsuMDtos(@Param("baseDate") Date baseDate);

    public List<JihiHasuuMWebDto> selectJihiHasuuMDtos(@Param("baseDate") Date baseDate);
}
