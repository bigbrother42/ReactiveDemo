package com.em.clinicapi.config;

import com.em.clinicapi.common.constants.enumerations.ErrorEnum;
import com.em.clinicapi.common.exception.ErrorResponse;
import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.common.exception.JsonParseException;
import com.em.clinicapi.common.exception.XmlParseException;
import com.em.clinicapi.common.util.LogUtil;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerConfig {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleException(Exception ex) {
        LogUtil.getLogger(ExceptionHandlerConfig.class).error(ex.getMessage(), ex);

        ErrorResponse errorResponse = new ErrorResponse(
                ErrorEnum.InternalServerError.value(), ErrorEnum.InternalServerError.getDescription(), ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(JsonParseException.class)
    public ResponseEntity<ErrorResponse> handleJsonParseException(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse(
                ErrorEnum.JsonParseError.value(), ErrorEnum.JsonParseError.getDescription(), ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.METHOD_FAILURE);
    }

    @ExceptionHandler(XmlParseException.class)
    public ResponseEntity<ErrorResponse> handleXmlParseException(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse(
                ErrorEnum.XmlParseError.value(), ErrorEnum.XmlParseError.getDescription(), ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.METHOD_FAILURE);
    }

    @ExceptionHandler(InvalidRequestException.class)
    public ResponseEntity<ErrorResponse> handleInvalidRequestException(Exception ex) {
        ErrorResponse errorResponse = new ErrorResponse(
                ErrorEnum.InvalidRequest.value(), ErrorEnum.InvalidRequest.getDescription(), ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.METHOD_FAILURE);
    }
}
