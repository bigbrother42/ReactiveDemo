package com.em.clinicapi.webdto.response.patient;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : CareInformation クラス <br/>
 * 項目： Care_Information <br/>
 * 説明： <br/>
 *       介護情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class CareInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Insurance <br/>
	 * 説明： <br/>
	 *       介護保険情報 <br/>
	 */
		@JsonProperty("Insurance")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private InsuranceArr insuranceArr;
	/**
	 * 項目： Certification <br/>
	 */
		@JsonProperty("Certification")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private CertificationArr certificationArr;
	/**
	 * 項目： Community_Disease <br/>
	 */
		@JsonProperty("Community_Disease")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private CommunityDiseaseArr communityDiseaseArr;
	/**
	 * Insuranceを返事します。
	 * @return Insuranceの値
	 */
	@JsonProperty("Insurance")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public InsuranceArr getInsuranceArr() {
		return insuranceArr;
	}

	/**
	 * Insuranceを設定します。
	 * @param insuranceArr Insurance
	 */
	@JsonProperty("Insurance")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceArr(InsuranceArr insuranceArr) {
		this.insuranceArr = insuranceArr;
	}

	/**
	 * Certificationを返事します。
	 * @return Certificationの値
	 */
	@JsonProperty("Certification")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public CertificationArr getCertificationArr() {
		return certificationArr;
	}

	/**
	 * Certificationを設定します。
	 * @param certificationArr Certification
	 */
	@JsonProperty("Certification")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificationArr(CertificationArr certificationArr) {
		this.certificationArr = certificationArr;
	}

	/**
	 * Community_Diseaseを返事します。
	 * @return Community_Diseaseの値
	 */
	@JsonProperty("Community_Disease")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public CommunityDiseaseArr getCommunityDiseaseArr() {
		return communityDiseaseArr;
	}

	/**
	 * Community_Diseaseを設定します。
	 * @param communityDiseaseArr Community_Disease
	 */
	@JsonProperty("Community_Disease")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCommunityDiseaseArr(CommunityDiseaseArr communityDiseaseArr) {
		this.communityDiseaseArr = communityDiseaseArr;
	}

}