package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class UcRecDegreeWebDto extends CustomerWebDtoBase {
	/**  プロパティ degreeId */
	private String  degreeId = null;

	/**  プロパティ hokenId */
	private String  hokenId = null;

	/**  プロパティ riyoushaId */
	private String  riyoushaId = null;

	/**  プロパティ approvalDate */
	private java.sql.Date  approvalDate = null;

	/**  プロパティ degreeKbn */
	private String  degreeKbn = null;

	/**  プロパティ gendogaku */
	private java.math.BigDecimal  gendogaku = null;

	/**  プロパティ ninteiStartDate */
	private java.sql.Date  ninteiStartDate = null;

	/**  プロパティ ninteiEndDate */
	private java.sql.Date  ninteiEndDate = null;

	/**  プロパティ gendogakuStartDate */
	private java.sql.Date  gendogakuStartDate = null;

	/**  プロパティ gendogakuEndDate */
	private java.sql.Date  gendogakuEndDate = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public UcRecDegreeWebDto()	{
		super();
	}


	/**
	* プロパティー：degreeId を返します。
	* @return degreeId
	*/
	public String getDegreeId(){
		return degreeId;
	}

	/**
	* プロパティー：degreeId を設定します。
	* @param param  String degreeId
	*/
	public void setDegreeId(String degreeId){
		this.degreeId = degreeId;
	}

	/**
	* プロパティー：hokenId を返します。
	* @return hokenId
	*/
	public String getHokenId(){
		return hokenId;
	}

	/**
	* プロパティー：hokenId を設定します。
	* @param param  String hokenId
	*/
	public void setHokenId(String hokenId){
		this.hokenId = hokenId;
	}

	/**
	* プロパティー：riyoushaId を返します。
	* @return riyoushaId
	*/
	public String getRiyoushaId(){
		return riyoushaId;
	}

	/**
	* プロパティー：riyoushaId を設定します。
	* @param param  String riyoushaId
	*/
	public void setRiyoushaId(String riyoushaId){
		this.riyoushaId = riyoushaId;
	}

	/**
	* プロパティー：approvalDate を返します。
	* @return approvalDate
	*/
	public java.sql.Date getApprovalDate(){
		return approvalDate;
	}

	/**
	* プロパティー：approvalDate を設定します。
	* @param param  java.sql.Date approvalDate
	*/
	public void setApprovalDate(java.sql.Date approvalDate){
		this.approvalDate = approvalDate;
	}

	/**
	* プロパティー：degreeKbn を返します。
	* @return degreeKbn
	*/
	public String getDegreeKbn(){
		return degreeKbn;
	}

	/**
	* プロパティー：degreeKbn を設定します。
	* @param param  String degreeKbn
	*/
	public void setDegreeKbn(String degreeKbn){
		this.degreeKbn = degreeKbn;
	}

	/**
	* プロパティー：gendogaku を返します。
	* @return gendogaku
	*/
	public java.math.BigDecimal getGendogaku(){
		return gendogaku;
	}

	/**
	* プロパティー：gendogaku を設定します。
	* @param param  java.math.BigDecimal gendogaku
	*/
	public void setGendogaku(java.math.BigDecimal gendogaku){
		this.gendogaku = gendogaku;
	}

	/**
	* プロパティー：ninteiStartDate を返します。
	* @return ninteiStartDate
	*/
	public java.sql.Date getNinteiStartDate(){
		return ninteiStartDate;
	}

	/**
	* プロパティー：ninteiStartDate を設定します。
	* @param param  java.sql.Date ninteiStartDate
	*/
	public void setNinteiStartDate(java.sql.Date ninteiStartDate){
		this.ninteiStartDate = ninteiStartDate;
	}

	/**
	* プロパティー：ninteiEndDate を返します。
	* @return ninteiEndDate
	*/
	public java.sql.Date getNinteiEndDate(){
		return ninteiEndDate;
	}

	/**
	* プロパティー：ninteiEndDate を設定します。
	* @param param  java.sql.Date ninteiEndDate
	*/
	public void setNinteiEndDate(java.sql.Date ninteiEndDate){
		this.ninteiEndDate = ninteiEndDate;
	}

	/**
	* プロパティー：gendogakuStartDate を返します。
	* @return gendogakuStartDate
	*/
	public java.sql.Date getGendogakuStartDate(){
		return gendogakuStartDate;
	}

	/**
	* プロパティー：gendogakuStartDate を設定します。
	* @param param  java.sql.Date gendogakuStartDate
	*/
	public void setGendogakuStartDate(java.sql.Date gendogakuStartDate){
		this.gendogakuStartDate = gendogakuStartDate;
	}

	/**
	* プロパティー：gendogakuEndDate を返します。
	* @return gendogakuEndDate
	*/
	public java.sql.Date getGendogakuEndDate(){
		return gendogakuEndDate;
	}

	/**
	* プロパティー：gendogakuEndDate を設定します。
	* @param param  java.sql.Date gendogakuEndDate
	*/
	public void setGendogakuEndDate(java.sql.Date gendogakuEndDate){
		this.gendogakuEndDate = gendogakuEndDate;
	}
}
