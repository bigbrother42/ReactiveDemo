package com.em.clinicapi.common.constants.enumerations;

public enum DbConnectionTypeEnum {
    KIBAN,
    GROUP,
    CUSTOMER,
    COMMON
}
