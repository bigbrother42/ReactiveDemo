package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class InsuranceArr extends ResponseWebDtoBase {
    /**
     * 項目： Insurance <br/>
     * 説明： <br/>
     *       介護保険情報 <br/>
     */
    @JsonProperty("Insurance_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<Insurance> insurance;

    /**
     * Insuranceを返事します。
     * @return Insuranceの値
     */
    @JsonProperty("Insurance_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<Insurance> getInsurance() {
        return insurance;
    }

    /**
     * Insuranceを設定します。
     * @param insurance Insurance
     */
    @JsonProperty("Insurance_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setInsurance(List<Insurance> insurance) {
        this.insurance = insurance;
    }
}
