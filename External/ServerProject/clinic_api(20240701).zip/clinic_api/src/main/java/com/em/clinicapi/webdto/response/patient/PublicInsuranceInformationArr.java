package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class PublicInsuranceInformationArr extends ResponseWebDtoBase {
    /**
     * 項目： PublicInsurance_Information <br/>
     * 説明： <br/>
     *       公費情報 <br/>
     */
    @JsonProperty("PublicInsurance_Information_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<PublicInsuranceInformation> publicInsuranceInformation;

    /**
     * PublicInsurance_Informationを返事します。
     * @return PublicInsurance_Informationの値
     */
    @JsonProperty("PublicInsurance_Information_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<PublicInsuranceInformation> getPublicInsuranceInformation() {
        return publicInsuranceInformation;
    }

    /**
     * PublicInsurance_Informationを設定します。
     * @param publicInsuranceInformation PublicInsurance_Information
     */
    @JsonProperty("PublicInsurance_Information_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setPublicInsuranceInformation(List<PublicInsuranceInformation> publicInsuranceInformation) {
        this.publicInsuranceInformation = publicInsuranceInformation;
    }
}
