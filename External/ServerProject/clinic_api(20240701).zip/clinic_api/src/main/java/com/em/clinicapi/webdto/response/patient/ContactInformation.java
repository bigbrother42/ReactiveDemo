package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : ContactInformation クラス <br/>
 * 項目： Contact_Information <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class ContactInformation extends ResponseWebDtoBase {

	/**
	 * 項目： WholeName <br/>
	 * 説明： <br/>
	 *       患者連絡先の連絡先名称を返却 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeName;
	/**
	 * 項目： Relationship <br/>
	 * 説明： <br/>
	 *       ”本人”固定 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Relationship")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String relationship;
	/**
	 * 項目： Address_ZipCode <br/>
	 * 説明： <br/>
	 *       患者連絡先の郵便番号を返却 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String addressZipCode;
	/**
	 * 項目： WholeAddress1 <br/>
	 * 説明： <br/>
	 *       患者連絡先の住所を返却 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeAddress1;
	/**
	 * 項目： WholeAddress2 <br/>
	 * 説明： <br/>
	 *       患者連絡先の番地を返却 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String wholeAddress2;
	/**
	 * 項目： PhoneNumber1 <br/>
	 * 説明： <br/>
	 *       患者連絡先の電話番号を返却 <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String phoneNumber1;
	/**
	 * 項目： PhoneNumber2 <br/>
	 * 説明： <br/>
	 *       設定するものがないので空値 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String phoneNumber2;
	/**
	 * WholeNameを返事します。
	 * @return WholeNameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeName() {
		return wholeName;
	}

	/**
	 * WholeNameを設定します。
	 * @param wholeName WholeName
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeName")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeName(String wholeName) {
		this.wholeName = wholeName;
	}

	/**
	 * Relationshipを返事します。
	 * @return Relationshipの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Relationship")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getRelationship() {
		return relationship;
	}

	/**
	 * Relationshipを設定します。
	 * @param relationship Relationship
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Relationship")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 * Address_ZipCodeを返事します。
	 * @return Address_ZipCodeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAddressZipCode() {
		return addressZipCode;
	}

	/**
	 * Address_ZipCodeを設定します。
	 * @param addressZipCode Address_ZipCode
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Address_ZipCode")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAddressZipCode(String addressZipCode) {
		this.addressZipCode = addressZipCode;
	}

	/**
	 * WholeAddress1を返事します。
	 * @return WholeAddress1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeAddress1() {
		return wholeAddress1;
	}

	/**
	 * WholeAddress1を設定します。
	 * @param wholeAddress1 WholeAddress1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeAddress1(String wholeAddress1) {
		this.wholeAddress1 = wholeAddress1;
	}

	/**
	 * WholeAddress2を返事します。
	 * @return WholeAddress2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getWholeAddress2() {
		return wholeAddress2;
	}

	/**
	 * WholeAddress2を設定します。
	 * @param wholeAddress2 WholeAddress2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("WholeAddress2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setWholeAddress2(String wholeAddress2) {
		this.wholeAddress2 = wholeAddress2;
	}

	/**
	 * PhoneNumber1を返事します。
	 * @return PhoneNumber1の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPhoneNumber1() {
		return phoneNumber1;
	}

	/**
	 * PhoneNumber1を設定します。
	 * @param phoneNumber1 PhoneNumber1
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber1")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPhoneNumber1(String phoneNumber1) {
		this.phoneNumber1 = phoneNumber1;
	}

	/**
	 * PhoneNumber2を返事します。
	 * @return PhoneNumber2の値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPhoneNumber2() {
		return phoneNumber2;
	}

	/**
	 * PhoneNumber2を設定します。
	 * @param phoneNumber2 PhoneNumber2
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("PhoneNumber2")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPhoneNumber2(String phoneNumber2) {
		this.phoneNumber2 = phoneNumber2;
	}

}