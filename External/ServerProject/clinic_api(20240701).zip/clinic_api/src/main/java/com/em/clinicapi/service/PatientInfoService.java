package com.em.clinicapi.service;

import com.em.clinicapi.logic.PatientInfoLogic;
import com.em.clinicapi.webdto.request.patient.PatientInfoRequest;
import com.em.clinicapi.webdto.request.patient.PatientInfoRequestWebDto;
import com.em.clinicapi.webdto.response.patient.PatientInfoResponseWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PatientInfoService {

    @Autowired
    private PatientInfoLogic patientInfoLogic;

    /**
     *
     * @param patientInfoRequestWebDto
     * @return
     */
    public PatientInfoResponseWebDto getPatientInfo(PatientInfoRequestWebDto patientInfoRequestWebDto) {
        return patientInfoLogic.getPatientInfo(patientInfoRequestWebDto);
    }
}
