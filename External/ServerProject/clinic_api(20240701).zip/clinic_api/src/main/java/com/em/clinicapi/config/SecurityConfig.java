package com.em.clinicapi.config;

import com.em.clinicapi.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

    private final static String URI_CLINIC_API = "/clinic/api/**";

    @Autowired
    private PasswordEncoder oauthClientPasswordEncoder;

    @Bean
    public ClientRegistrationRepository clientRegistrationRepository(@Qualifier("oauthClientPasswordEncoder") PasswordEncoder passwordEncoder) {
        return new CustomClientRegistrationRepository(passwordEncoder);
    }

    @Bean
    public UserDetailsService userDetailsService() {
        return new CustomUserDetailsService();
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
                .antMatchers(URI_CLINIC_API).permitAll() // Allow publicly accessible API endpoints
                .anyRequest().authenticated() // Other API endpoints require authentication
                .and()
            .formLogin()
                .and()
            .httpBasic()
                .and()
            .csrf()
                .disable()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            //.oauth2Login() // Enable OAuth2 login support
        ;

        /*http
            .authorizeRequests()
                .antMatchers(URI_CLINIC_API).permitAll() // Allow publicly accessible API endpoints
                .anyRequest().authenticated() // Other API endpoints require authentication
                .and()
            .csrf().disable().httpBasic()
                .and()
            .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
            .oauth2Login()
            .clientRegistrationRepository(clientRegistrationRepository(oauthClientPasswordEncoder))
                .and()
            .userDetailsService(userDetailsService())
        ;*/
    }
}
