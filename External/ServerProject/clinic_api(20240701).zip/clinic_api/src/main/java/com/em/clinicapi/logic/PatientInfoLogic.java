package com.em.clinicapi.logic;

import com.em.clinicapi.common.constants.*;
import com.em.clinicapi.common.constants.enumerations.ApiResultEnum;
import com.em.clinicapi.common.constants.enumerations.ApiResultMessageEnum;
import com.em.clinicapi.common.constants.enumerations.ClassTypeEnum;
import com.em.clinicapi.common.constants.enumerations.DateFormatEnum;
import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.common.util.ListUtil;
import com.em.clinicapi.common.util.StringUtil;
import com.em.clinicapi.mapper.PatientInfoMapper;
import com.em.clinicapi.webdto.db.*;
import com.em.clinicapi.webdto.request.patient.PatientInfoRequest;
import com.em.clinicapi.webdto.request.patient.PatientInfoRequestWebDto;
import com.em.clinicapi.webdto.response.patient.*;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.*;

@Component
public class PatientInfoLogic {

    public static final String Reskey = "PatientInfo";

    public static final List<String> DiseaseList = Arrays.asList("高血圧症", "糖尿病", "脂質異常症", "認知症");

    // yyyy-MM-dd
    private SimpleDateFormat sdfDate = new SimpleDateFormat(DateFormatEnum.FormatYYYYMMDDM.getValue());
    // HH:mm:ss
    private SimpleDateFormat sdfTime = new SimpleDateFormat(DateFormatEnum.FormatHHmmss.getValue());

    private PatientInformation patientInformation;
    private KisoMonshinWebDto kisoMonshinWebDto;
    private Integer customerSeq;
    private Integer patientSeq;

    @Autowired
    private PatientInfoMapper patientInfoMapper;

    /**
     *
     * @return
     */
    public PatientInfoResponseWebDto getPatientInfo(PatientInfoRequestWebDto patientInfoRequestWebDto) {

        try {
            String customerSeqStr = patientInfoRequestWebDto.getPatientInfoRequest().getCustomerId();
            customerSeq = Integer.valueOf(customerSeqStr);
        } catch(Exception e) {
            throw new InvalidRequestException("リクエストのパラメータ「Customer_ID」は不正でした。");
        }

        try {
            String patientId = patientInfoRequestWebDto.getPatientInfoRequest().getPatientId();
            patientSeq = Integer.valueOf(patientId);
        } catch(Exception e) {
            throw new InvalidRequestException("リクエストのパラメータ「Patient_ID」は不正でした。");
        }

        Date responseDate = new Date();

        PatientInfoResponseWebDto patientInfoResponseWebDto = new PatientInfoResponseWebDto();
        PatientInfoResponse patientInfoResponse = new PatientInfoResponse();
        // レスポンスを返す時点の日付
        patientInfoResponse.setInformationDate(sdfDate.format(responseDate));
        // レスポンスを返す時点の時刻
        patientInfoResponse.setInformationTime(sdfTime.format(responseDate));
        // 成功時は"00"を返す
        patientInfoResponse.setApiResult(ApiResultEnum.Success.getCode());
        patientInfoResponse.setApiResultMessage(ApiResultMessageEnum.Success.getMessage());
        patientInfoResponse.setReskey(Reskey);

        // 患者情報を取得
        patientInformation = patientInfoMapper.selectPatientInfo(customerSeq, patientSeq);

        // 基礎問診を取得
        kisoMonshinWebDto = patientInfoMapper.selectKisoMonshinWebDto(customerSeq, patientSeq);

        // 患者基本情報
        PatientInformation patientInformation = generatePatientInformation();
        patientInfoResponse.setPatientInformation(patientInformation);

        patientInfoResponseWebDto.setPatientInfoResponse(patientInfoResponse);

        return patientInfoResponseWebDto;
    }

    private PatientInformation generatePatientInformation() {
        // 患者の患者SEQ
        patientInformation.setPatientId(patientInformation.getPatientId());
        // 患者の患者番号
        patientInformation.setPatientNo(patientInformation.getPatientNo());
        // 患者のカルテ番号
        patientInformation.setKarteNo(patientInformation.getKarteNo());
        // 患者の漢字氏名
        patientInformation.setWholeName(patientInformation.getWholeName());
        // 患者のカナ氏名
        patientInformation.setWholeNameInKana(patientInformation.getWholeNameInKana());
        // 患者の生年月日
        patientInformation.setBirthDate(patientInformation.getBirthDate());
        // 患者の性別　(男:1、女:2)
        patientInformation.setSex(patientInformation.getSex());
        patientInformation.setHouseHolderWholeName(StringConstants.EMPTY_STRING);
        patientInformation.setRelationship(StringConstants.EMPTY_STRING);

        // 患者自宅情報
        HomeAddressInformation homeAddressInformation = generateHomeAddressInformation();
        patientInformation.setHomeAddressInformation(homeAddressInformation);

        // 患者連絡先情報
        ContactInformation contactInformation = generateContactInformation();
        patientInformation.setContactInformation(contactInformation);

        // テスト患者であれば”1”
        // そうでない場合は”0”
        patientInformation.setTestPatientFlag(patientInformation.getTestPatientFlag());
        // 死亡時は”1”, 設定できない
        patientInformation.setDeathFlag(patientInformation.getDeathFlag());
        // 初回初診を算定した日付
        patientInformation.setFirstVisitDate(patientInformation.getFirstVisitDate());
        // 最終来院日
        patientInformation.setLastVisitDate(patientInformation.getLastVisitDate());
        patientInformation.setOutpatientClass(StringConstants.EMPTY_STRING);
        patientInformation.setAdmissionDate(StringConstants.EMPTY_STRING);
        patientInformation.setDischargeDate(StringConstants.EMPTY_STRING);
        // 入居施設より該当患者の施設SEQを返却
        patientInformation.setFacilitySeq(patientInformation.getFacilitySeq());

        // 保険組み合わせ情報
        List<HealthInsuranceInformation> healthInsuranceInformations = generateHealthInsuranceInformationList();
        HealthInsuranceInformationArr healthInsuranceInformationArr = new HealthInsuranceInformationArr();
        healthInsuranceInformationArr.setType(ClassTypeEnum.array);
        healthInsuranceInformationArr.setHealthInsuranceInformation(healthInsuranceInformations);
        patientInformation.setHealthInsuranceInformationArr(healthInsuranceInformationArr);

        // 介護情報
        CareInformation careInformation = new CareInformation();
        // 介護保険情報
        List<Insurance> insuranceList = generateInsuranceList();
        InsuranceArr insuranceArr = new InsuranceArr();
        insuranceArr.setType(ClassTypeEnum.array);
        insuranceArr.setInsurance(insuranceList);
        careInformation.setInsuranceArr(insuranceArr);
        // 介護認定情報
        List<Certification> certificationList = generateCertificationList();
        CertificationArr certificationArr = new CertificationArr();
        certificationArr.setType(ClassTypeEnum.array);
        certificationArr.setCertification(certificationList);
        careInformation.setCertificationArr(certificationArr);
        // 地域包括診療対象疾病
        List<CommunityDisease> communityDiseaseList = generateCommunityDiseaseList();
        CommunityDiseaseArr communityDiseaseArr = new CommunityDiseaseArr();
        communityDiseaseArr.setType(ClassTypeEnum.array);
        communityDiseaseArr.setCommunityDisease(communityDiseaseList);
        careInformation.setCommunityDiseaseArr(communityDiseaseArr);
        patientInformation.setCareInformation(careInformation);

        // 患者個別情報
        PersonallyInformation personallyInformation = generatePersonallyInformation();
        patientInformation.setPersonallyInformation(personallyInformation);

        // 個人番号情報
        List<IndividualNumber> individualNumberList = generateIndividualNumberList();
        if (!individualNumberList.isEmpty()) {
            IndividualNumberArr individualNumberArr = new IndividualNumberArr();
            individualNumberArr.setType(ClassTypeEnum.array);
            individualNumberArr.setIndividualNumber(individualNumberList);
            patientInformation.setIndividualNumberArr(individualNumberArr);
        }

        // TODO 管理料等自動算定情報
        List<AutoManagementInformation> autoManagementInformationList = generateAutoManagementInformationList();
        if (!autoManagementInformationList.isEmpty()) {
            AutoManagementInformationArr autoManagementInformationArr = new AutoManagementInformationArr();
            autoManagementInformationArr.setType(ClassTypeEnum.array);
            autoManagementInformationArr.setAutoManagementInformation(autoManagementInformationList);
            patientInformation.setAutoManagementInformationArr(autoManagementInformationArr);
        }

        // 患者禁忌薬剤情報
        PatientContraInformation patientContraInformation = new PatientContraInformation();
        List<PatientContraInfo> patientContraInfoList = generatePatientContraInfoList();
        PatientContraInfoArr patientContraInfoArr = new PatientContraInfoArr();
        patientContraInfoArr.setType(ClassTypeEnum.array);
        patientContraInfoArr.setPatientContraInfo(patientContraInfoList);
        patientContraInformation.setPatientContraInfoArr(patientContraInfoArr);
        patientInformation.setPatientContraInformation(patientContraInformation);

        return patientInformation;
    }

    private List<AutoManagementInformation> generateAutoManagementInformationList() {
        List<AutoManagementInformation> autoManagementInformationList = new ArrayList<>();

        /*for (int i = 0; i < 2; i++) {
            AutoManagementInformation autoManagementInformation = new AutoManagementInformation();
            autoManagementInformation.setMedicationCode(StringConstants.EMPTY_STRING);
            autoManagementInformation.setMedicationName(StringConstants.EMPTY_STRING);
            autoManagementInformation.setMedicationEndDate(StringConstants.EMPTY_STRING);

            autoManagementInformationList.add(autoManagementInformation);
        }*/

        return autoManagementInformationList;
    }

    private boolean isEmptyString(String text) {
        return StringConstants.EMPTY_STRING.equals(text) || StringConstants.NULL_STRING.equals(text.toLowerCase());
    }

    private List<PatientContraInfo> generatePatientContraInfoList() {
        if (kisoMonshinWebDto == null) return null;

        List<PatientContraInfo> patientContraInfoList = new ArrayList<>();

        String kisoMonnshinContentStr = kisoMonshinWebDto.getKisoMonshinContent();
        try {
            JSONObject kisoMonnshinContentJson = JSONObject.fromObject(kisoMonnshinContentStr);
            if (kisoMonnshinContentJson != null) {
                JSONArray jsonArray = kisoMonnshinContentJson.getJSONArray("gridcontrollist");
                if (jsonArray != null &&jsonArray.size() > 0) {
                    JSONObject jsonObject = jsonArray.getJSONObject(0);
                    if (jsonObject != null) {
                        JSONObject dataJsonObject = jsonObject.getJSONObject("Data");
                        if (dataJsonObject != null) {
                            JSONArray contraindicationJsonArray = dataJsonObject.getJSONArray("DrugContraindicationList");
                            if (contraindicationJsonArray != null && contraindicationJsonArray.size() > 0) {
                                for(int i = 0; i < contraindicationJsonArray.size(); i++) {
                                    JSONObject contraindicationJsonObj = contraindicationJsonArray.getJSONObject(i);
                                    if (contraindicationJsonObj != null) {
                                        String medicationCode = contraindicationJsonObj.optString("ItemCode", StringConstants.EMPTY_STRING);
                                        if (!isEmptyString(medicationCode)) {
                                            PatientContraInfo patientContraInfo = new PatientContraInfo();
                                            // 薬剤コード
                                            patientContraInfo.setMedicationCode(contraindicationJsonObj.optString("ItemCode", StringConstants.EMPTY_STRING));
                                            // 薬剤名称
                                            patientContraInfo.setMedicationName(contraindicationJsonObj.optString("ItemName", StringConstants.EMPTY_STRING));
                                            // 有効終了日
                                            patientContraInfo.setMedicationEndDate(contraindicationJsonObj.optString("", StringConstants.EMPTY_STRING));
                                            // 禁忌開始日
                                            String itemDateStr = contraindicationJsonObj.optString("ItemDate", StringConstants.EMPTY_STRING);
                                            if (!isEmptyString(itemDateStr.toLowerCase())) {
                                                patientContraInfo.setContraStartDate(itemDateStr);
                                            }

                                            patientContraInfoList.add(patientContraInfo);
                                        }
                                    }

                                }
                            }


                        }
                    }
                }
            }
        } catch(Exception ex) {
            // do nothing
        }

        return patientContraInfoList;
    }

    private List<IndividualNumber> generateIndividualNumberList() {
        List<IndividualNumber> individualNumberList = new ArrayList<>();

        /*for (int i = 0; i < 2; i++) {
            IndividualNumber individualNumber = new IndividualNumber();
            individualNumber.setInId(StringConstants.EMPTY_STRING);
            individualNumber.setInNumber(StringConstants.EMPTY_STRING);
            individualNumber.setInDescription(StringConstants.EMPTY_STRING);

            individualNumberList.add(individualNumber);
        }*/

        return individualNumberList;
    }

    private PersonallyInformation generatePersonallyInformation() {
        PersonallyInformation personallyInformation = new PersonallyInformation();

        // 妊婦区分
        boolean isPregnant = patientInfoMapper.checkPatientPregnant(customerSeq, patientSeq);
        personallyInformation.setPregnantClass(isPregnant ? "1" : "0");
        // 認知症地域包括診療加算算定
        // （True：該当である）
        String patientSystemConfigContent = patientInfoMapper.selectPatientSystemConfigContent(customerSeq, patientSeq, "UK020001", "ShinryouKanren");
        String communityDisease2 = "False";
        String communityDisease3 = "False";
        if (!StringUtil.isNullOrEmpty(patientSystemConfigContent)) {
            try {
                JSONObject contentOBj = JSONObject.fromObject(patientSystemConfigContent);
                communityDisease2 = contentOBj.optString("IsNinchishouKasan", "False");
                communityDisease3 = contentOBj.optString("IsShouniKasan", "False");
            } catch(Exception ex) {
                // do nothing
            }
        }
        personallyInformation.setCommunityDisease2(communityDisease2);
        // 小児かかりつけ診療料算定
        // （True：該当である）
        personallyInformation.setCommunityDisease3(communityDisease3);

        return personallyInformation;
    }

    private List<CommunityDisease> generateCommunityDiseaseList() {
        List<String> shoubyouNameList = patientInfoMapper.selectPatientShoubyouNameList(customerSeq, patientSeq);

        List<CommunityDisease> communityDiseaseList = new ArrayList<>();
        boolean isExist = shoubyouNameList
                .stream()
                .anyMatch(o -> DiseaseList
                        .stream()
                        .anyMatch(x -> o.contains(x)));
        if (isExist) {
            for (int i = 0; i < 4; i++) {
                CommunityDisease communityDisease = new CommunityDisease();
                String targetDisease = "False";
                int finalI = i;
                if (shoubyouNameList.stream().anyMatch(o -> o.contains(DiseaseList.get(finalI)))) {
                    targetDisease = "True";
                }

                communityDisease.setTargetDisease(targetDisease);

                communityDiseaseList.add(communityDisease);
            }
        }

        return communityDiseaseList;
    }

    private List<Certification> generateCertificationList() {
        List<Certification> certificationList = new ArrayList<>();
        List<UcRecDegreeWebDto> ucRecDegreeWebDtoList = patientInfoMapper.selectUcRecDegreeWebDtoList(customerSeq, String.valueOf(patientSeq));

        if (!ListUtil.isEmpty(ucRecDegreeWebDtoList)) {
            for (UcRecDegreeWebDto ucRecDegreeWebDto : ucRecDegreeWebDtoList) {
                Certification certification = new Certification();
                // 要介護状態コード
                certification.setNeedCareStateCode(ucRecDegreeWebDto.getDegreeKbn());
                // 要介護状態
                String stateContent = StringConstants.EMPTY_STRING;
                switch (ucRecDegreeWebDto.getDegreeKbn()){
                    case "11":
                        stateContent = "要支援（経過摘要介護）";
                        break;
                    case "12":
                        stateContent = "要支援１";
                        break;
                    case "13":
                        stateContent = "要支援２";
                        break;
                    case "21":
                        stateContent = "要介護１";
                        break;
                    case "22":
                        stateContent = "要介護２";
                        break;
                    case "23":
                        stateContent = "要介護３";
                        break;
                    case "24":
                        stateContent = "要介護４";
                        break;
                    case "25":
                        stateContent = "要介護５";
                        break;
                    case "0":
                        stateContent = "その他（非該当）";
                        break;
                    default:
                        break;
                }
                certification.setNeedCareState(stateContent);
                // 認定日
                certification.setCertificationDate(sdfDate.format(ucRecDegreeWebDto.getApprovalDate()));
                // 開始
                certification.setCertificateStartDate(sdfDate.format(ucRecDegreeWebDto.getNinteiStartDate()));
                // 終了
                certification.setCertificateExpiredDate(sdfDate.format(ucRecDegreeWebDto.getNinteiEndDate()));

                certificationList.add(certification);
            }
        }

        return certificationList;
    }

    private List<Insurance> generateInsuranceList() {
        List<Insurance> insuranceList = new ArrayList<>();
        List<UcRecHokenWebDto> ucRecHokenWebDtoList = patientInfoMapper.selectUcRecHokenWebDtoList(customerSeq, String.valueOf(patientSeq));

        if (!ListUtil.isEmpty(ucRecHokenWebDtoList)) {
            for (UcRecHokenWebDto ucRecHokenWebDto : ucRecHokenWebDtoList) {
                Insurance insurance = new Insurance();
                // 保険者番号
                insurance.setInsuranceProviderNumber(ucRecHokenWebDto.getHokenshaNo());
                // 被保険者番号
                insurance.setHealthInsuredPersonNumber(ucRecHokenWebDto.getHihokenshaNo());
                // 開始
                insurance.setCertificateStartDate(sdfDate.format(ucRecHokenWebDto.getStartDate()));
                // 終了
                insurance.setCertificateExpiredDate(sdfDate.format(ucRecHokenWebDto.getEndDate()));

                insuranceList.add(insurance);
            }
        }

        return insuranceList;
    }

    private ContactInformation generateContactInformation() {
        PatientRenrakusakiWebDto patientRenrakusakiWebDto = patientInfoMapper.selectPatientRenrakusakiWebDto(customerSeq, patientSeq);

        ContactInformation contactInformation = null;
        if (patientRenrakusakiWebDto != null) {
            contactInformation = new ContactInformation();
            // 患者連絡先の連絡先名称
            contactInformation.setWholeName(patientRenrakusakiWebDto.getContactInfoName());
            // ”本人”固定
            contactInformation.setRelationship("本人");
            // 患者連絡先の郵便番号
            contactInformation.setAddressZipCode(patientRenrakusakiWebDto.getPostalNo());
            // 患者連絡先の住所
            contactInformation.setWholeAddress1(patientRenrakusakiWebDto.getAddress());
            // 患者連絡先の番地
            contactInformation.setWholeAddress2(patientRenrakusakiWebDto.getBanchi());
            // 患者連絡先の電話番号
            contactInformation.setPhoneNumber1(patientRenrakusakiWebDto.getPhoneNo());
            // 設定するものがないので空値
            contactInformation.setPhoneNumber2(StringConstants.EMPTY_STRING);
        }

        return contactInformation;
    }

    private HomeAddressInformation generateHomeAddressInformation() {
        PatientJitakuWebDto patientJitakuWebDto = patientInfoMapper.selectPatientJitakuWebDto(customerSeq, patientSeq);

        HomeAddressInformation homeAddressInformation = null;
        if (patientJitakuWebDto != null) {
            homeAddressInformation = new HomeAddressInformation();
            // 患者自宅の郵便番号
            homeAddressInformation.setAddressZipCode(patientJitakuWebDto.getPostalNo());
            // 患者自宅の住所
            homeAddressInformation.setWholeAddress1(patientJitakuWebDto.getAddress());
            // 患者自宅の番地
            homeAddressInformation.setWholeAddress2(patientJitakuWebDto.getBanchi());
            // 患者自宅の電話番号
            homeAddressInformation.setPhoneNumber1(patientJitakuWebDto.getPhoneNo());
        }

        return homeAddressInformation;
    }

    private List<HealthInsuranceInformation> generateHealthInsuranceInformationList() {
        List<HealthInsuranceInformation> healthInsuranceInformationList = new ArrayList<>();

        List<ShuhokenWebDto> shuhokenWebDtoList = patientInfoMapper.selectShuhokenWebDtoList(customerSeq, patientSeq);
        if (!ListUtil.isEmpty(shuhokenWebDtoList)) {
            List<ShuhokenRekiWebDto> shuhokenRekiWebDtoList = patientInfoMapper.selectShuhokenRekiWebDtoList(customerSeq, patientSeq);
            List<FukuhokenWebDto> fukuhokenWebDtoList = patientInfoMapper.selectFukuhokenWebDtoList(customerSeq, patientSeq);
            List<FukuhokenRekiWebDto> fukuhokenRekiWebDtoList = patientInfoMapper.selectFukuhokenRekiWebDtoList(customerSeq, patientSeq);

            for (ShuhokenWebDto shuhokenWebDto : shuhokenWebDtoList) {
                HealthInsuranceInformation healthInsuranceInformation = new HealthInsuranceInformation();
                // 保険組合せ番号
                healthInsuranceInformation.setInsuranceCombinationNumber(String.valueOf(shuhokenWebDto.getHokenSeq()));
                // 入院負担割合
                healthInsuranceInformation.setInsuranceCombinationRateAdmission(StringConstants.NUMBER_0);
                // 外来負担割合
                shuhokenRekiWebDtoList
                    .stream()
                    .filter(o -> shuhokenWebDto.getHokenSeq() == o.getHokenSeq() && shuhokenWebDto.getPatientSeq() == o.getPatientSeq())
                    .sorted(Comparator.comparing(ShuhokenRekiWebDto::getStartDate).reversed())
                    .findFirst()
                    .ifPresent(o ->
                        healthInsuranceInformation.setInsuranceCombinationRateOutpatient(String.valueOf(o.getPatientFutanRate()))
                );
                // 保険組合せ非表示区分
                // O:外来非表示、I:入院非表示、N:非表示無し
                healthInsuranceInformation.setInsuranceNondisplay("N");
                // 保険の種類(060:国保)
                healthInsuranceInformation.setInsuranceProviderClass(shuhokenWebDto.getHokenKbn());
                // 保険者番号
                healthInsuranceInformation.setInsuranceProviderNumber(shuhokenWebDto.getHokenshaNo());
                // 保険の制度名称
                String insuranceName = StringConstants.EMPTY_STRING;
                switch(shuhokenWebDto.getHokenKbn()) {
                    case "1":
                        insuranceName = "社保";
                        break;
                    case "2":
                        insuranceName = "国保";
                        break;
                    case "3":
                        insuranceName = "公費";
                        break;
                    case "4":
                        insuranceName = "介護";
                        break;
                    case "5":
                        insuranceName = "労災";
                        break;
                    case "6":
                        insuranceName = "自賠責";
                        break;
                    case "7":
                        insuranceName = "公害";
                        break;
                    case "100":
                        insuranceName = "自費";
                        break;
                    case "101":
                        insuranceName = "治験";
                        break;
                    case "102":
                        insuranceName = "保険証忘れ";
                        break;
                    default:
                        break;
                }
                healthInsuranceInformation.setInsuranceProviderWholeName(insuranceName);
                // 記号
                healthInsuranceInformation.setHealthInsuredPersonSymbol(shuhokenWebDto.getHokenKigou());
                // 番号
                healthInsuranceInformation.setHealthInsuredPersonNumber(shuhokenWebDto.getHokenNo());
                // 枝番
                healthInsuranceInformation.setHealthInsuredPersonBranchNumber(shuhokenWebDto.getEdaNo());
                // 本人家族区分
                // 1:本人、 2:家族
                healthInsuranceInformation.setRelationToInsuredPerson(shuhokenWebDto.getHonninFamilyKbn());
                // 被保険者名
                healthInsuranceInformation.setHealthInsuredPersonWholeName(shuhokenWebDto.getHihokenshaName());
                // 適用開始日
                healthInsuranceInformation.setCertificateStartDate(sdfDate.format(shuhokenWebDto.getStartDate()));
                // 適用終了日
                healthInsuranceInformation.setCertificateExpiredDate(sdfDate.format(shuhokenWebDto.getEndDate()));
                // 資格取得日
                healthInsuranceInformation.setCertificateGetDate(sdfDate.format(shuhokenWebDto.getShikakuShutokuDate()));
                // 最終確認日
                healthInsuranceInformation.setInsuranceCheckDate(sdfDate.format(shuhokenWebDto.getKakuteiDateTime()));

                // 公費情報（副保険について）
                List<FukuhokenWebDto> fukuhokenWebDtoListTmp = new ArrayList<>();
                if (shuhokenWebDto.getFukuhoken1Seq() != 0) {
                    fukuhokenWebDtoList
                        .stream()
                        .filter(o -> o.getPatientSeq() == shuhokenWebDto.getPatientSeq() && o.getFukuhokenSeq() == shuhokenWebDto.getFukuhoken1Seq())
                        .findFirst()
                        .ifPresent(o -> fukuhokenWebDtoListTmp.add(o));
                }

                if (shuhokenWebDto.getFukuhoken2Seq() != 0) {
                    fukuhokenWebDtoList
                        .stream()
                        .filter(o -> o.getPatientSeq() == shuhokenWebDto.getPatientSeq() && o.getFukuhokenSeq() == shuhokenWebDto.getFukuhoken1Seq())
                        .findFirst()
                        .ifPresent(o -> fukuhokenWebDtoListTmp.add(o));
                }

                if (shuhokenWebDto.getFukuhoken3Seq() != 0) {
                    fukuhokenWebDtoList
                        .stream()
                        .filter(o -> o.getPatientSeq() == shuhokenWebDto.getPatientSeq() && o.getFukuhokenSeq() == shuhokenWebDto.getFukuhoken1Seq())
                        .findFirst()
                        .ifPresent(o -> fukuhokenWebDtoListTmp.add(o));
                }

                if (shuhokenWebDto.getFukuhoken4Seq() != 0) {
                    fukuhokenWebDtoList
                        .stream()
                        .filter(o -> o.getPatientSeq() == shuhokenWebDto.getPatientSeq() && o.getFukuhokenSeq() == shuhokenWebDto.getFukuhoken1Seq())
                        .findFirst()
                        .ifPresent(o -> fukuhokenWebDtoListTmp.add(o));
                }

                if (!ListUtil.isEmpty(fukuhokenWebDtoListTmp)) {
                    List<PublicInsuranceInformation> publicInsuranceInformationList = new ArrayList<>();
                    for (FukuhokenWebDto fukuhokenWebDto : fukuhokenWebDtoListTmp) {
                        // 福祉は対象外
                        if ("2".equals(fukuhokenWebDto.getFukuhokenType())) continue;

                        PublicInsuranceInformation publicInsuranceInformation = new PublicInsuranceInformation();
                        String futanshoNo = fukuhokenWebDto.getFutanshaNo();
                        // 公費Mの法別番号を返却
                        publicInsuranceInformation.setPublicInsuranceClass(futanshoNo.substring(0, 2));
                        // 公費Mの公費名称を返却
                        patientInfoMapper.selectKouhiMWebDtoList(futanshoNo.substring(0, 2), fukuhokenWebDto.getKouhiSeidoKbn())
                                .stream()
                                .findFirst()
                                .ifPresent(o -> publicInsuranceInformation.setPublicInsuranceName(o.getKouhiName()));
                        // 副保険の負担者番号を返却
                        publicInsuranceInformation.setPublicInsurerNumber(futanshoNo);
                        // 副保険の受給者番号を返却
                        publicInsuranceInformation.setPublicInsuredPersonNumber(fukuhokenWebDto.getJukyuushaNo());
                        // 入院負担率, 未サポートのため0固定
                        publicInsuranceInformation.setRateAdmission(StringConstants.NUMBER_0);
                        // 入院固定額
                        publicInsuranceInformation.setMoneyAdmission(StringConstants.NUMBER_0);
                        // 副保険歴の患者負担割合を返却
                        fukuhokenRekiWebDtoList
                                .stream()
                                .filter(o -> o.getPatientSeq() == fukuhokenWebDto.getPatientSeq() && o.getFukuhokenSeq() == fukuhokenWebDto.getFukuhokenSeq())
                                .sorted(Comparator.comparing(FukuhokenRekiWebDto::getStartDate).reversed())
                                .findFirst()
                                .ifPresent(o -> publicInsuranceInformation.setRateOutpatient(String.valueOf(o.getPatientFutanRate())));
                        publicInsuranceInformation.setMoneyOutpatient(StringConstants.NUMBER_0);
                        // 副保険の開始日
                        publicInsuranceInformation.setCertificateIssuedDate(sdfDate.format(fukuhokenWebDto.getStartDate()));
                        // 副保険の終了日
                        publicInsuranceInformation.setCertificateExpiredDate(sdfDate.format(fukuhokenWebDto.getEndDate()));
                        publicInsuranceInformation.setCertificateCheckDate("9999-12-31");

                        publicInsuranceInformationList.add(publicInsuranceInformation);
                    }

                    PublicInsuranceInformationArr publicInsuranceInformationArr = new PublicInsuranceInformationArr();
                    publicInsuranceInformationArr.setType(ClassTypeEnum.array);
                    publicInsuranceInformationArr.setPublicInsuranceInformation(publicInsuranceInformationList);
                    healthInsuranceInformation.setPublicInsuranceInformationArr(publicInsuranceInformationArr);
                }

                // 労災、自賠責情報
                if ("5".equals(shuhokenWebDto.getHokenKbn()) || "6".equals(shuhokenWebDto.getHokenKbn())) {
                    // 労災、自賠責の場合
                    AccidentInsuranceInformation accidentInsuranceInformation = generateAccidentInsuranceInformation(shuhokenWebDto.getHokenSeq());
                    healthInsuranceInformation.setAccidentInsuranceInformation(accidentInsuranceInformation);
                }

                healthInsuranceInformationList.add(healthInsuranceInformation);
            }
        }

        return healthInsuranceInformationList;
    }

    private List<PublicInsuranceInformation> generatePublicInsuranceInformationList() {
        List<PublicInsuranceInformation> publicInsuranceInformationList = new ArrayList<>();

        for (int i = 0; i < 2; i++) {
            PublicInsuranceInformation publicInsuranceInformation = new PublicInsuranceInformation();
            // 公費Mの法別番号を返却
            publicInsuranceInformation.setPublicInsuranceClass(StringConstants.EMPTY_STRING);
            // 公費Mの公費名称を返却
            publicInsuranceInformation.setPublicInsuranceName(StringConstants.EMPTY_STRING);
            // 副保険の負担者番号を返却
            publicInsuranceInformation.setPublicInsurerNumber(StringConstants.EMPTY_STRING);
            // 副保険の受給者番号を返却
            publicInsuranceInformation.setPublicInsuredPersonNumber(StringConstants.EMPTY_STRING);
            // 入院負担率, 未サポートのため0固定
            publicInsuranceInformation.setRateAdmission(StringConstants.EMPTY_STRING);
            // 入院固定額
            publicInsuranceInformation.setMoneyAdmission(StringConstants.EMPTY_STRING);
            // 副保険歴の患者負担割合を返却
            publicInsuranceInformation.setRateOutpatient(StringConstants.EMPTY_STRING);
            publicInsuranceInformation.setMoneyOutpatient(StringConstants.EMPTY_STRING);
            // 副保険の開始日
            publicInsuranceInformation.setCertificateIssuedDate(StringConstants.EMPTY_STRING);
            // 副保険の終了日
            publicInsuranceInformation.setCertificateExpiredDate(StringConstants.EMPTY_STRING);
            publicInsuranceInformation.setCertificateCheckDate(StringConstants.EMPTY_STRING);

            publicInsuranceInformationList.add(publicInsuranceInformation);
        }

        return publicInsuranceInformationList;
    }

    private AccidentInsuranceInformation generateAccidentInsuranceInformation(int hokenSeq) {
        RousaiHokenWebDto rousaiHokenWebDto = patientInfoMapper.selectRousaiHokenWebDto(customerSeq, patientSeq, hokenSeq);

        if (rousaiHokenWebDto == null) return null;

        AccidentInsuranceInformation accidentInsuranceInformation = new AccidentInsuranceInformation();
        // 労災保険の保険区分名を返却
        String rousaiKbn = StringConstants.EMPTY_STRING;
        switch (rousaiHokenWebDto.getRousaiKbn()){
            case "1":
                rousaiKbn = "短期業務";
                break;
            case "2":
                rousaiKbn = "短期通勤";
                break;
            case "3":
                rousaiKbn = "傷病業務";
                break;
            case "4":
                rousaiKbn = "傷病通勤";
                break;
            case "5":
                rousaiKbn = "アフターケア";
                break;
            default:
                break;
        }
        accidentInsuranceInformation.setAccidentInsuranceWholeName(rousaiKbn);
        // 傷病部位
        accidentInsuranceInformation.setDiseaseLocation(StringConstants.EMPTY_STRING);
        // 労災保険の療養開始日を返却 ※未指定の場合は1900-01-01
        accidentInsuranceInformation.setDiseaseDate(sdfDate.format(rousaiHokenWebDto.getRyouyouStartDate()));
        // 労災保険の労働保険番号を返却
        accidentInsuranceInformation.setAccidentInsuranceNumber(rousaiHokenWebDto.getRoudouHokenNo());
        // 労災保険の年金証書番号を返却　※未指定の場合は空値
        accidentInsuranceInformation.setPensionCertificateNumber(rousaiHokenWebDto.getNenkinShoushoNo());
        // 災害区分
        accidentInsuranceInformation.setAccidentClass(StringConstants.EMPTY_STRING);
        // 労働基準監督署コード
        accidentInsuranceInformation.setLaborStationCode(StringConstants.EMPTY_STRING);
        // 労働基準監督署名
        accidentInsuranceInformation.setLaborStationCodeName(StringConstants.EMPTY_STRING);

        // 事業所情報
        LiabilityOfficeInformation liabilityOfficeInformation = generateLiabilityOfficeInformation(rousaiHokenWebDto.getJigyoushoSeq());
        accidentInsuranceInformation.setLiabilityOfficeInformation(liabilityOfficeInformation);
        // 主保険の事業所SEQに紐づく事業所名
        // ※保険区分が”6”(自賠責)
        String liabilityInsuranceOfficeName = liabilityOfficeInformation == null ? StringConstants.EMPTY_STRING : liabilityOfficeInformation.getLWholeName();
        accidentInsuranceInformation.setLiabilityInsuranceOfficeName(liabilityInsuranceOfficeName);
        // アフターケア　健康管理手帳番号
        accidentInsuranceInformation.setPersonalHealthRecordNumber(rousaiHokenWebDto.getHealthKanriHandbookNo());
        // アフターケア　損傷区分情報
        DamageClass damageClass = new DamageClass();
        // 損傷区分コード
        damageClass.setDCode(rousaiHokenWebDto.getShoubyouCode());
        damageClass.setDWholeName(StringConstants.EMPTY_STRING);
        List<EmsRousaiAfterCareShoubyouCodeMWebDto> emsRousaiAfterCareShoubyouCodeMWebDtoList
                = patientInfoMapper.selectEmsRousaiAfterCareShoubyouCodeMDtos(
                        new java.sql.Date(new Date().getTime()), rousaiHokenWebDto.getShoubyouCode());
        if (!emsRousaiAfterCareShoubyouCodeMWebDtoList.isEmpty()) {
            damageClass.setDWholeName(emsRousaiAfterCareShoubyouCodeMWebDtoList.get(0).getShoubyouName());
        }
        accidentInsuranceInformation.setDamageClass(damageClass);

        return accidentInsuranceInformation;
    }

    private DamageClass generateDamageClass() {
        DamageClass damageClass = new DamageClass();

        damageClass.setDCode(StringConstants.EMPTY_STRING);
        damageClass.setDWholeName(StringConstants.EMPTY_STRING);

        return damageClass;
    }

    private LiabilityOfficeInformation generateLiabilityOfficeInformation(int jigyoushoSeq) {
        JigyoushoMWebDto jigyoushoMWebDto = patientInfoMapper.selectJigyoushoMWebDto(customerSeq, jigyoushoSeq);

        if (jigyoushoMWebDto == null) return null;

        LiabilityOfficeInformation liabilityOfficeInformation = new LiabilityOfficeInformation();
        // 労災保険の事業所SEQに紐づく事業所名を返却
        liabilityOfficeInformation.setLWholeName(jigyoushoMWebDto.getJigyoushoName());

        // 所在地都道府県情報
        PrefectureInformation prefectureInformation = new PrefectureInformation();
        // 都道府県名
        prefectureInformation.setPWholeName(StringConstants.EMPTY_STRING);
        // 都道府県コード
        prefectureInformation.setPClass(StringConstants.EMPTY_STRING);
        // 都道府県の区分
        prefectureInformation.setPClassName(StringConstants.EMPTY_STRING);
        liabilityOfficeInformation.setPrefectureInformation(prefectureInformation);

        // 事業所の住所＋番地を返却
        CityInformation cityInformation = new CityInformation();
        // 都市区名
        cityInformation.setCWholeName(StringConstants.EMPTY_STRING);
        // 都市区コード
        cityInformation.setCClass(StringConstants.EMPTY_STRING);
        // 都市の区分
        cityInformation.setCClassName(StringConstants.EMPTY_STRING);
        liabilityOfficeInformation.setCityInformation(cityInformation);

        return liabilityOfficeInformation;
    }
}