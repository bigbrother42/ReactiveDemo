package com.em.clinicapi.common.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.time.LocalDate;

public class EMDateValidator implements ConstraintValidator<EMDate,String> {

    private String message;
    @Override
    public void initialize(EMDate constraintAnnotation) {
        this.message = constraintAnnotation.message();
        ConstraintValidator.super.initialize(constraintAnnotation);
    }

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
       if(value == null){
           return false;
       }
       try{
           LocalDate tmpDate = LocalDate.parse(value);
           LocalDate minDate = LocalDate.of(1900,1,1);
           LocalDate maxDate = LocalDate.of(2999,12,31);
           if((tmpDate.equals(minDate) || tmpDate.isAfter(minDate))
                   && (tmpDate.equals(maxDate) || tmpDate.isBefore(maxDate))){
               return  true;
           }
           else{
               message = "日付の入力は不正です。[1900-01-01]~[2999-12-31]の範囲内を入力してください。入力値:" + value;
               context.disableDefaultConstraintViolation();
               context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
               return false;
           }

       }catch (Exception e){
           message = "日付の入力は不正です。入力値:" + value + " " + e.getMessage();
           context.disableDefaultConstraintViolation();
           context.buildConstraintViolationWithTemplate(message).addConstraintViolation();
           return false;
       }
    }
}
