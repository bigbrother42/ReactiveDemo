package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class ShuhokenWebDto extends CustomerWebDtoBase {
	/**  プロパティ patientSeq */
	private int  patientSeq = 0;

	/**  プロパティ hokenSeq */
	private int  hokenSeq = 0;

	/**  プロパティ jigyoushoSeq */
	private int  jigyoushoSeq = 0;

	/**  プロパティ startDate */
	private java.sql.Date  startDate = null;

	/**  プロパティ endDate */
	private java.sql.Date  endDate = null;

	/**  プロパティ hokenKbn */
	private String  hokenKbn = null;

	/**  プロパティ jihiKbn */
	private String  jihiKbn = null;

	/**  プロパティ hokenshaNo */
	private String  hokenshaNo = null;

	/**  プロパティ hokenKigou */
	private String  hokenKigou = null;

	/**  プロパティ hokenNo */
	private String  hokenNo = null;

	/**  プロパティ edaNo */
	private String  edaNo = null;

	/**  プロパティ honninFamilyKbn */
	private String  honninFamilyKbn = null;

	/**  プロパティ shokumujouReasonKbn */
	private String  shokumujouReasonKbn = null;

	/**  プロパティ hihokenshaName */
	private String  hihokenshaName = null;

	/**  プロパティ shikakuShutokuDate */
	private java.sql.Date  shikakuShutokuDate = null;

	/**  プロパティ houteigaiKyuufuKbn */
	private String  houteigaiKyuufuKbn = null;

	/**  プロパティ specialRyouyouhiKbn */
	private String  specialRyouyouhiKbn = null;

	/**  プロパティ shoumeishoNo */
	private String  shoumeishoNo = null;

	/**  プロパティ gyoumuTsuukinSaigaiMune */
	private String  gyoumuTsuukinSaigaiMune = null;

	/**  プロパティ hokenshouKakuninDate */
	private java.sql.Date  hokenshouKakuninDate = null;

	/**  プロパティ finalRaiinDate */
	private java.sql.Date  finalRaiinDate = null;

	/**  プロパティ kakuteiKbn */
	private String  kakuteiKbn = null;

	/**  プロパティ kakuteisha */
	private String  kakuteisha = null;

	/**  プロパティ kakuteiDateTime */
	private java.sql.Timestamp  kakuteiDateTime = null;

	/**  プロパティ thirdPartyNinshouKbn */
	private String  thirdPartyNinshouKbn = null;

	/**  プロパティ fukuhoken1Seq */
	private int  fukuhoken1Seq = 0;

	/**  プロパティ fukuhoken2Seq */
	private int  fukuhoken2Seq = 0;

	/**  プロパティ fukuhoken3Seq */
	private int  fukuhoken3Seq = 0;

	/**  プロパティ fukuhoken4Seq */
	private int  fukuhoken4Seq = 0;

	/**  プロパティ hokenMemo */
	private String  hokenMemo = null;

	/**  プロパティ kyuufuWariaiKakuninKbn */
	private String  kyuufuWariaiKakuninKbn = null;


	/**
	*  デフォルトのコンストラクタ
	*/
	public ShuhokenWebDto()	{
		super();
	}


	/**
	* プロパティー：patientSeq を返します。
	* @return patientSeq
	*/
	public int getPatientSeq(){
		return patientSeq;
	}

	/**
	* プロパティー：patientSeq を設定します。
	* @param param  int patientSeq
	*/
	public void setPatientSeq(int patientSeq){
		this.patientSeq = patientSeq;
	}

	/**
	* プロパティー：hokenSeq を返します。
	* @return hokenSeq
	*/
	public int getHokenSeq(){
		return hokenSeq;
	}

	/**
	* プロパティー：hokenSeq を設定します。
	* @param param  int hokenSeq
	*/
	public void setHokenSeq(int hokenSeq){
		this.hokenSeq = hokenSeq;
	}

	/**
	* プロパティー：jigyoushoSeq を返します。
	* @return jigyoushoSeq
	*/
	public int getJigyoushoSeq(){
		return jigyoushoSeq;
	}

	/**
	* プロパティー：jigyoushoSeq を設定します。
	* @param param  int jigyoushoSeq
	*/
	public void setJigyoushoSeq(int jigyoushoSeq){
		this.jigyoushoSeq = jigyoushoSeq;
	}

	/**
	* プロパティー：startDate を返します。
	* @return startDate
	*/
	public java.sql.Date getStartDate(){
		return startDate;
	}

	/**
	* プロパティー：startDate を設定します。
	* @param param  java.sql.Date startDate
	*/
	public void setStartDate(java.sql.Date startDate){
		this.startDate = startDate;
	}

	/**
	* プロパティー：endDate を返します。
	* @return endDate
	*/
	public java.sql.Date getEndDate(){
		return endDate;
	}

	/**
	* プロパティー：endDate を設定します。
	* @param param  java.sql.Date endDate
	*/
	public void setEndDate(java.sql.Date endDate){
		this.endDate = endDate;
	}

	/**
	* プロパティー：hokenKbn を返します。
	* @return hokenKbn
	*/
	public String getHokenKbn(){
		return hokenKbn;
	}

	/**
	* プロパティー：hokenKbn を設定します。
	* @param param  String hokenKbn
	*/
	public void setHokenKbn(String hokenKbn){
		this.hokenKbn = hokenKbn;
	}

	/**
	* プロパティー：jihiKbn を返します。
	* @return jihiKbn
	*/
	public String getJihiKbn(){
		return jihiKbn;
	}

	/**
	* プロパティー：jihiKbn を設定します。
	* @param param  String jihiKbn
	*/
	public void setJihiKbn(String jihiKbn){
		this.jihiKbn = jihiKbn;
	}

	/**
	* プロパティー：hokenshaNo を返します。
	* @return hokenshaNo
	*/
	public String getHokenshaNo(){
		return hokenshaNo;
	}

	/**
	* プロパティー：hokenshaNo を設定します。
	* @param param  String hokenshaNo
	*/
	public void setHokenshaNo(String hokenshaNo){
		this.hokenshaNo = hokenshaNo;
	}

	/**
	* プロパティー：hokenKigou を返します。
	* @return hokenKigou
	*/
	public String getHokenKigou(){
		return hokenKigou;
	}

	/**
	* プロパティー：hokenKigou を設定します。
	* @param param  String hokenKigou
	*/
	public void setHokenKigou(String hokenKigou){
		this.hokenKigou = hokenKigou;
	}

	/**
	* プロパティー：hokenNo を返します。
	* @return hokenNo
	*/
	public String getHokenNo(){
		return hokenNo;
	}

	/**
	* プロパティー：hokenNo を設定します。
	* @param param  String hokenNo
	*/
	public void setHokenNo(String hokenNo){
		this.hokenNo = hokenNo;
	}

	/**
	* プロパティー：edaNo を返します。
	* @return edaNo
	*/
	public String getEdaNo(){
		return edaNo;
	}

	/**
	* プロパティー：edaNo を設定します。
	* @param param  String edaNo
	*/
	public void setEdaNo(String edaNo){
		this.edaNo = edaNo;
	}

	/**
	* プロパティー：honninFamilyKbn を返します。
	* @return honninFamilyKbn
	*/
	public String getHonninFamilyKbn(){
		return honninFamilyKbn;
	}

	/**
	* プロパティー：honninFamilyKbn を設定します。
	* @param param  String honninFamilyKbn
	*/
	public void setHonninFamilyKbn(String honninFamilyKbn){
		this.honninFamilyKbn = honninFamilyKbn;
	}

	/**
	* プロパティー：shokumujouReasonKbn を返します。
	* @return shokumujouReasonKbn
	*/
	public String getShokumujouReasonKbn(){
		return shokumujouReasonKbn;
	}

	/**
	* プロパティー：shokumujouReasonKbn を設定します。
	* @param param  String shokumujouReasonKbn
	*/
	public void setShokumujouReasonKbn(String shokumujouReasonKbn){
		this.shokumujouReasonKbn = shokumujouReasonKbn;
	}

	/**
	* プロパティー：hihokenshaName を返します。
	* @return hihokenshaName
	*/
	public String getHihokenshaName(){
		return hihokenshaName;
	}

	/**
	* プロパティー：hihokenshaName を設定します。
	* @param param  String hihokenshaName
	*/
	public void setHihokenshaName(String hihokenshaName){
		this.hihokenshaName = hihokenshaName;
	}

	/**
	* プロパティー：shikakuShutokuDate を返します。
	* @return shikakuShutokuDate
	*/
	public java.sql.Date getShikakuShutokuDate(){
		return shikakuShutokuDate;
	}

	/**
	* プロパティー：shikakuShutokuDate を設定します。
	* @param param  java.sql.Date shikakuShutokuDate
	*/
	public void setShikakuShutokuDate(java.sql.Date shikakuShutokuDate){
		this.shikakuShutokuDate = shikakuShutokuDate;
	}

	/**
	* プロパティー：houteigaiKyuufuKbn を返します。
	* @return houteigaiKyuufuKbn
	*/
	public String getHouteigaiKyuufuKbn(){
		return houteigaiKyuufuKbn;
	}

	/**
	* プロパティー：houteigaiKyuufuKbn を設定します。
	* @param param  String houteigaiKyuufuKbn
	*/
	public void setHouteigaiKyuufuKbn(String houteigaiKyuufuKbn){
		this.houteigaiKyuufuKbn = houteigaiKyuufuKbn;
	}

	/**
	* プロパティー：specialRyouyouhiKbn を返します。
	* @return specialRyouyouhiKbn
	*/
	public String getSpecialRyouyouhiKbn(){
		return specialRyouyouhiKbn;
	}

	/**
	* プロパティー：specialRyouyouhiKbn を設定します。
	* @param param  String specialRyouyouhiKbn
	*/
	public void setSpecialRyouyouhiKbn(String specialRyouyouhiKbn){
		this.specialRyouyouhiKbn = specialRyouyouhiKbn;
	}

	/**
	* プロパティー：shoumeishoNo を返します。
	* @return shoumeishoNo
	*/
	public String getShoumeishoNo(){
		return shoumeishoNo;
	}

	/**
	* プロパティー：shoumeishoNo を設定します。
	* @param param  String shoumeishoNo
	*/
	public void setShoumeishoNo(String shoumeishoNo){
		this.shoumeishoNo = shoumeishoNo;
	}

	/**
	* プロパティー：gyoumuTsuukinSaigaiMune を返します。
	* @return gyoumuTsuukinSaigaiMune
	*/
	public String getGyoumuTsuukinSaigaiMune(){
		return gyoumuTsuukinSaigaiMune;
	}

	/**
	* プロパティー：gyoumuTsuukinSaigaiMune を設定します。
	* @param param  String gyoumuTsuukinSaigaiMune
	*/
	public void setGyoumuTsuukinSaigaiMune(String gyoumuTsuukinSaigaiMune){
		this.gyoumuTsuukinSaigaiMune = gyoumuTsuukinSaigaiMune;
	}

	/**
	* プロパティー：hokenshouKakuninDate を返します。
	* @return hokenshouKakuninDate
	*/
	public java.sql.Date getHokenshouKakuninDate(){
		return hokenshouKakuninDate;
	}

	/**
	* プロパティー：hokenshouKakuninDate を設定します。
	* @param param  java.sql.Date hokenshouKakuninDate
	*/
	public void setHokenshouKakuninDate(java.sql.Date hokenshouKakuninDate){
		this.hokenshouKakuninDate = hokenshouKakuninDate;
	}

	/**
	* プロパティー：finalRaiinDate を返します。
	* @return finalRaiinDate
	*/
	public java.sql.Date getFinalRaiinDate(){
		return finalRaiinDate;
	}

	/**
	* プロパティー：finalRaiinDate を設定します。
	* @param param  java.sql.Date finalRaiinDate
	*/
	public void setFinalRaiinDate(java.sql.Date finalRaiinDate){
		this.finalRaiinDate = finalRaiinDate;
	}

	/**
	* プロパティー：kakuteiKbn を返します。
	* @return kakuteiKbn
	*/
	public String getKakuteiKbn(){
		return kakuteiKbn;
	}

	/**
	* プロパティー：kakuteiKbn を設定します。
	* @param param  String kakuteiKbn
	*/
	public void setKakuteiKbn(String kakuteiKbn){
		this.kakuteiKbn = kakuteiKbn;
	}

	/**
	* プロパティー：kakuteisha を返します。
	* @return kakuteisha
	*/
	public String getKakuteisha(){
		return kakuteisha;
	}

	/**
	* プロパティー：kakuteisha を設定します。
	* @param param  String kakuteisha
	*/
	public void setKakuteisha(String kakuteisha){
		this.kakuteisha = kakuteisha;
	}

	/**
	* プロパティー：kakuteiDateTime を返します。
	* @return kakuteiDateTime
	*/
	public java.sql.Timestamp getKakuteiDateTime(){
		return kakuteiDateTime;
	}

	/**
	* プロパティー：kakuteiDateTime を設定します。
	* @param param  java.sql.Timestamp kakuteiDateTime
	*/
	public void setKakuteiDateTime(java.sql.Timestamp kakuteiDateTime){
		this.kakuteiDateTime = kakuteiDateTime;
	}

	/**
	* プロパティー：thirdPartyNinshouKbn を返します。
	* @return thirdPartyNinshouKbn
	*/
	public String getThirdPartyNinshouKbn(){
		return thirdPartyNinshouKbn;
	}

	/**
	* プロパティー：thirdPartyNinshouKbn を設定します。
	* @param param  String thirdPartyNinshouKbn
	*/
	public void setThirdPartyNinshouKbn(String thirdPartyNinshouKbn){
		this.thirdPartyNinshouKbn = thirdPartyNinshouKbn;
	}

	/**
	* プロパティー：fukuhoken1Seq を返します。
	* @return fukuhoken1Seq
	*/
	public int getFukuhoken1Seq(){
		return fukuhoken1Seq;
	}

	/**
	* プロパティー：fukuhoken1Seq を設定します。
	* @param param  int fukuhoken1Seq
	*/
	public void setFukuhoken1Seq(int fukuhoken1Seq){
		this.fukuhoken1Seq = fukuhoken1Seq;
	}

	/**
	* プロパティー：fukuhoken2Seq を返します。
	* @return fukuhoken2Seq
	*/
	public int getFukuhoken2Seq(){
		return fukuhoken2Seq;
	}

	/**
	* プロパティー：fukuhoken2Seq を設定します。
	* @param param  int fukuhoken2Seq
	*/
	public void setFukuhoken2Seq(int fukuhoken2Seq){
		this.fukuhoken2Seq = fukuhoken2Seq;
	}

	/**
	* プロパティー：fukuhoken3Seq を返します。
	* @return fukuhoken3Seq
	*/
	public int getFukuhoken3Seq(){
		return fukuhoken3Seq;
	}

	/**
	* プロパティー：fukuhoken3Seq を設定します。
	* @param param  int fukuhoken3Seq
	*/
	public void setFukuhoken3Seq(int fukuhoken3Seq){
		this.fukuhoken3Seq = fukuhoken3Seq;
	}

	/**
	* プロパティー：fukuhoken4Seq を返します。
	* @return fukuhoken4Seq
	*/
	public int getFukuhoken4Seq(){
		return fukuhoken4Seq;
	}

	/**
	* プロパティー：fukuhoken4Seq を設定します。
	* @param param  int fukuhoken4Seq
	*/
	public void setFukuhoken4Seq(int fukuhoken4Seq){
		this.fukuhoken4Seq = fukuhoken4Seq;
	}

	/**
	* プロパティー：hokenMemo を返します。
	* @return hokenMemo
	*/
	public String getHokenMemo(){
		return hokenMemo;
	}

	/**
	* プロパティー：hokenMemo を設定します。
	* @param param  String hokenMemo
	*/
	public void setHokenMemo(String hokenMemo){
		this.hokenMemo = hokenMemo;
	}

	/**
	* プロパティー：kyuufuWariaiKakuninKbn を返します。
	* @return kyuufuWariaiKakuninKbn
	*/
	public String getKyuufuWariaiKakuninKbn(){
		return kyuufuWariaiKakuninKbn;
	}

	/**
	* プロパティー：kyuufuWariaiKakuninKbn を設定します。
	* @param param  String kyuufuWariaiKakuninKbn
	*/
	public void setKyuufuWariaiKakuninKbn(String kyuufuWariaiKakuninKbn){
		this.kyuufuWariaiKakuninKbn = kyuufuWariaiKakuninKbn;
	}
}
