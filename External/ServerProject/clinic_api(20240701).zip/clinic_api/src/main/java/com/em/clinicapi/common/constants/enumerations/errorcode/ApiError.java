package com.em.clinicapi.common.constants.enumerations.errorcode;

public interface ApiError {

    String getCode();

    String getMessage();
}
