package com.em.clinicapi.webdto.request.iryoukikan;

import com.em.clinicapi.webdto.request.iryoukikan.IryoukikanInfoRequest;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

import javax.validation.Valid;

@JacksonXmlRootElement(localName = "data")
public class IryoukikanInfoRequestWebDto {
    @Valid
    @JsonProperty("system01_managereq")
    private IryoukikanInfoRequest iryoukikanInfoRequest;

    @JsonProperty("system01_managereq")
    public IryoukikanInfoRequest getIryoukikanInfoRequest() {
        return iryoukikanInfoRequest;
    }

    @JsonProperty("system01_managereq")
    public void setIryoukikanInfoRequest(IryoukikanInfoRequest iryoukikanInfoRequest) {
        this.iryoukikanInfoRequest = iryoukikanInfoRequest;
    }
}
