package com.em.clinicapi.common.constants.enumerations;

public enum ClassTypeEnum {
    record("record"),
    array("array");

    private final String code;

    ClassTypeEnum(String code) {
        this.code = code;
    }

    public String getCode() {
        return code;
    }
}
