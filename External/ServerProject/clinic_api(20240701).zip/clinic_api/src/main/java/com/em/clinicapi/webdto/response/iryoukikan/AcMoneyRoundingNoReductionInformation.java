package com.em.clinicapi.webdto.response.iryoukikan;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : AcMoneyRoundingNoReductionInformation クラス <br/>
 * 項目： Ac_Money_Rounding_No_Reduction_Information <br/>
 * 説明： <br/>
 *       請求額端数区分（減免無）情報 <br/>
 * 備考： <br/>
 *       "" <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class AcMoneyRoundingNoReductionInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Medical_Insurance_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分医保（減免無・保険分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicalInsuranceClass;
	/**
	 * 項目： Medical_Insurance_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分医保（減免無・保険分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicalInsuranceClassName;
	/**
	 * 項目： Medical_Insurance_Oe_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分医保（減免無・自費分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicalInsuranceOeClass;
	/**
	 * 項目： Medical_Insurance_Oe_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分医保（減免無・自費分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String medicalInsuranceOeClassName;
	/**
	 * 項目： Accident_Insurance_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分労災（減免無・保険分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentInsuranceClass;
	/**
	 * 項目： Accident_Insurance_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分労災（減免無・保険分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentInsuranceClassName;
	/**
	 * 項目： Accident_Insurance_Oe_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分労災（減免無・自費分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentInsuranceOeClass;
	/**
	 * 項目： Accident_Insurance_Oe_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分労災（減免無・自費分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accidentInsuranceOeClassName;
	/**
	 * 項目： Liability_Insurance_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分自賠責（減免無・保険分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String liabilityInsuranceClass;
	/**
	 * 項目： Liability_Insurance_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分自賠責（減免無・保険分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String liabilityInsuranceClassName;
	/**
	 * 項目： Liability_Insurance_Oe_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分自賠責（減免無・自費分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String liabilityInsuranceOeClass;
	/**
	 * 項目： Liability_Insurance_Oe_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分自賠責（減免無・自費分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String liabilityInsuranceOeClassName;
	/**
	 * 項目： Pollution_Oe_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分公害（減免無・自費分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pollution_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pollutionOeClass;
	/**
	 * 項目： Pollution_Oe_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分公害（減免無・自費分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pollution_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String pollutionOeClassName;
	/**
	 * 項目： Third_Party_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分第三者行為（減免無・保険分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String thirdPartyClass;
	/**
	 * 項目： Third_Party_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分第三者行為（減免無・保険分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String thirdPartyClassName;
	/**
	 * 項目： Third_Party_Oe_Class <br/>
	 * 説明： <br/>
	 *       請求額端数区分第三者行為（減免無・自費分） <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String thirdPartyOeClass;
	/**
	 * 項目： Third_Party_Oe_Class_Name <br/>
	 * 説明： <br/>
	 *       請求額端数区分第三者行為（減免無・自費分）名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String thirdPartyOeClassName;
	/**
	 * 項目： Third_Party_Money_Calculation_Class <br/>
	 * 説明： <br/>
	 *       第三者行為（医療費）負担金額計算区分 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Money_Calculation_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String thirdPartyMoneyCalculationClass;
	/**
	 * 項目： Third_Party_Money_Calculation_Class_Name <br/>
	 * 説明： <br/>
	 *       第三者行為（医療費）負担金額計算区分名称 <br/>
	 * 備考： <br/>
	 *       "" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Money_Calculation_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String thirdPartyMoneyCalculationClassName;
	/**
	 * Medical_Insurance_Classを返事します。
	 * @return Medical_Insurance_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicalInsuranceClass() {
		return medicalInsuranceClass;
	}

	/**
	 * Medical_Insurance_Classを設定します。
	 * @param medicalInsuranceClass Medical_Insurance_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicalInsuranceClass(String medicalInsuranceClass) {
		this.medicalInsuranceClass = medicalInsuranceClass;
	}

	/**
	 * Medical_Insurance_Class_Nameを返事します。
	 * @return Medical_Insurance_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicalInsuranceClassName() {
		return medicalInsuranceClassName;
	}

	/**
	 * Medical_Insurance_Class_Nameを設定します。
	 * @param medicalInsuranceClassName Medical_Insurance_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicalInsuranceClassName(String medicalInsuranceClassName) {
		this.medicalInsuranceClassName = medicalInsuranceClassName;
	}

	/**
	 * Medical_Insurance_Oe_Classを返事します。
	 * @return Medical_Insurance_Oe_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicalInsuranceOeClass() {
		return medicalInsuranceOeClass;
	}

	/**
	 * Medical_Insurance_Oe_Classを設定します。
	 * @param medicalInsuranceOeClass Medical_Insurance_Oe_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicalInsuranceOeClass(String medicalInsuranceOeClass) {
		this.medicalInsuranceOeClass = medicalInsuranceOeClass;
	}

	/**
	 * Medical_Insurance_Oe_Class_Nameを返事します。
	 * @return Medical_Insurance_Oe_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getMedicalInsuranceOeClassName() {
		return medicalInsuranceOeClassName;
	}

	/**
	 * Medical_Insurance_Oe_Class_Nameを設定します。
	 * @param medicalInsuranceOeClassName Medical_Insurance_Oe_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Medical_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicalInsuranceOeClassName(String medicalInsuranceOeClassName) {
		this.medicalInsuranceOeClassName = medicalInsuranceOeClassName;
	}

	/**
	 * Accident_Insurance_Classを返事します。
	 * @return Accident_Insurance_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentInsuranceClass() {
		return accidentInsuranceClass;
	}

	/**
	 * Accident_Insurance_Classを設定します。
	 * @param accidentInsuranceClass Accident_Insurance_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceClass(String accidentInsuranceClass) {
		this.accidentInsuranceClass = accidentInsuranceClass;
	}

	/**
	 * Accident_Insurance_Class_Nameを返事します。
	 * @return Accident_Insurance_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentInsuranceClassName() {
		return accidentInsuranceClassName;
	}

	/**
	 * Accident_Insurance_Class_Nameを設定します。
	 * @param accidentInsuranceClassName Accident_Insurance_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceClassName(String accidentInsuranceClassName) {
		this.accidentInsuranceClassName = accidentInsuranceClassName;
	}

	/**
	 * Accident_Insurance_Oe_Classを返事します。
	 * @return Accident_Insurance_Oe_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentInsuranceOeClass() {
		return accidentInsuranceOeClass;
	}

	/**
	 * Accident_Insurance_Oe_Classを設定します。
	 * @param accidentInsuranceOeClass Accident_Insurance_Oe_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceOeClass(String accidentInsuranceOeClass) {
		this.accidentInsuranceOeClass = accidentInsuranceOeClass;
	}

	/**
	 * Accident_Insurance_Oe_Class_Nameを返事します。
	 * @return Accident_Insurance_Oe_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getAccidentInsuranceOeClassName() {
		return accidentInsuranceOeClassName;
	}

	/**
	 * Accident_Insurance_Oe_Class_Nameを設定します。
	 * @param accidentInsuranceOeClassName Accident_Insurance_Oe_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Accident_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setAccidentInsuranceOeClassName(String accidentInsuranceOeClassName) {
		this.accidentInsuranceOeClassName = accidentInsuranceOeClassName;
	}

	/**
	 * Liability_Insurance_Classを返事します。
	 * @return Liability_Insurance_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLiabilityInsuranceClass() {
		return liabilityInsuranceClass;
	}

	/**
	 * Liability_Insurance_Classを設定します。
	 * @param liabilityInsuranceClass Liability_Insurance_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLiabilityInsuranceClass(String liabilityInsuranceClass) {
		this.liabilityInsuranceClass = liabilityInsuranceClass;
	}

	/**
	 * Liability_Insurance_Class_Nameを返事します。
	 * @return Liability_Insurance_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLiabilityInsuranceClassName() {
		return liabilityInsuranceClassName;
	}

	/**
	 * Liability_Insurance_Class_Nameを設定します。
	 * @param liabilityInsuranceClassName Liability_Insurance_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLiabilityInsuranceClassName(String liabilityInsuranceClassName) {
		this.liabilityInsuranceClassName = liabilityInsuranceClassName;
	}

	/**
	 * Liability_Insurance_Oe_Classを返事します。
	 * @return Liability_Insurance_Oe_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLiabilityInsuranceOeClass() {
		return liabilityInsuranceOeClass;
	}

	/**
	 * Liability_Insurance_Oe_Classを設定します。
	 * @param liabilityInsuranceOeClass Liability_Insurance_Oe_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLiabilityInsuranceOeClass(String liabilityInsuranceOeClass) {
		this.liabilityInsuranceOeClass = liabilityInsuranceOeClass;
	}

	/**
	 * Liability_Insurance_Oe_Class_Nameを返事します。
	 * @return Liability_Insurance_Oe_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getLiabilityInsuranceOeClassName() {
		return liabilityInsuranceOeClassName;
	}

	/**
	 * Liability_Insurance_Oe_Class_Nameを設定します。
	 * @param liabilityInsuranceOeClassName Liability_Insurance_Oe_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Liability_Insurance_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setLiabilityInsuranceOeClassName(String liabilityInsuranceOeClassName) {
		this.liabilityInsuranceOeClassName = liabilityInsuranceOeClassName;
	}

	/**
	 * Pollution_Oe_Classを返事します。
	 * @return Pollution_Oe_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pollution_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPollutionOeClass() {
		return pollutionOeClass;
	}

	/**
	 * Pollution_Oe_Classを設定します。
	 * @param pollutionOeClass Pollution_Oe_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pollution_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPollutionOeClass(String pollutionOeClass) {
		this.pollutionOeClass = pollutionOeClass;
	}

	/**
	 * Pollution_Oe_Class_Nameを返事します。
	 * @return Pollution_Oe_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pollution_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getPollutionOeClassName() {
		return pollutionOeClassName;
	}

	/**
	 * Pollution_Oe_Class_Nameを設定します。
	 * @param pollutionOeClassName Pollution_Oe_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Pollution_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPollutionOeClassName(String pollutionOeClassName) {
		this.pollutionOeClassName = pollutionOeClassName;
	}

	/**
	 * Third_Party_Classを返事します。
	 * @return Third_Party_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getThirdPartyClass() {
		return thirdPartyClass;
	}

	/**
	 * Third_Party_Classを設定します。
	 * @param thirdPartyClass Third_Party_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setThirdPartyClass(String thirdPartyClass) {
		this.thirdPartyClass = thirdPartyClass;
	}

	/**
	 * Third_Party_Class_Nameを返事します。
	 * @return Third_Party_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getThirdPartyClassName() {
		return thirdPartyClassName;
	}

	/**
	 * Third_Party_Class_Nameを設定します。
	 * @param thirdPartyClassName Third_Party_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setThirdPartyClassName(String thirdPartyClassName) {
		this.thirdPartyClassName = thirdPartyClassName;
	}

	/**
	 * Third_Party_Oe_Classを返事します。
	 * @return Third_Party_Oe_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getThirdPartyOeClass() {
		return thirdPartyOeClass;
	}

	/**
	 * Third_Party_Oe_Classを設定します。
	 * @param thirdPartyOeClass Third_Party_Oe_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Oe_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setThirdPartyOeClass(String thirdPartyOeClass) {
		this.thirdPartyOeClass = thirdPartyOeClass;
	}

	/**
	 * Third_Party_Oe_Class_Nameを返事します。
	 * @return Third_Party_Oe_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getThirdPartyOeClassName() {
		return thirdPartyOeClassName;
	}

	/**
	 * Third_Party_Oe_Class_Nameを設定します。
	 * @param thirdPartyOeClassName Third_Party_Oe_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Oe_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setThirdPartyOeClassName(String thirdPartyOeClassName) {
		this.thirdPartyOeClassName = thirdPartyOeClassName;
	}

	/**
	 * Third_Party_Money_Calculation_Classを返事します。
	 * @return Third_Party_Money_Calculation_Classの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Money_Calculation_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getThirdPartyMoneyCalculationClass() {
		return thirdPartyMoneyCalculationClass;
	}

	/**
	 * Third_Party_Money_Calculation_Classを設定します。
	 * @param thirdPartyMoneyCalculationClass Third_Party_Money_Calculation_Class
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Money_Calculation_Class")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setThirdPartyMoneyCalculationClass(String thirdPartyMoneyCalculationClass) {
		this.thirdPartyMoneyCalculationClass = thirdPartyMoneyCalculationClass;
	}

	/**
	 * Third_Party_Money_Calculation_Class_Nameを返事します。
	 * @return Third_Party_Money_Calculation_Class_Nameの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Money_Calculation_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getThirdPartyMoneyCalculationClassName() {
		return thirdPartyMoneyCalculationClassName;
	}

	/**
	 * Third_Party_Money_Calculation_Class_Nameを設定します。
	 * @param thirdPartyMoneyCalculationClassName Third_Party_Money_Calculation_Class_Name
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Third_Party_Money_Calculation_Class_Name")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setThirdPartyMoneyCalculationClassName(String thirdPartyMoneyCalculationClassName) {
		this.thirdPartyMoneyCalculationClassName = thirdPartyMoneyCalculationClassName;
	}

}