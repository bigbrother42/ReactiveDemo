package com.em.clinicapi.controller;

import com.em.clinicapi.common.constants.RequestConstants;
import com.em.clinicapi.common.constants.enumerations.RequestNumberEnum;
import com.em.clinicapi.common.exception.InvalidRequestException;
import com.em.clinicapi.controller.base.BaseController;
import com.em.clinicapi.service.BasicInfoService;
import com.em.clinicapi.webdto.request.basicinfo.BasicInfoRequestWebDto;
import com.em.clinicapi.webdto.response.basicinfo.UserBasicInfoResponseWebDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/clinic/api/system")
public class BasicInfoController extends BaseController {

    @Autowired
    private BasicInfoService basicInfoService;

    // @JsonProperty is a general purpose annotation of fasterxml and can be used as xml conversion as well
    // spring boot support fasterxml by default, and will convert xml string to Java object if MediaType is set to xml

    /**
     * アカウント情報取得(医師)
     *
     * @param basicInfoRequestWebDto
     * @return
     */
    @PostMapping(value = "/getdoctor", consumes = MediaType.APPLICATION_XML_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
    public UserBasicInfoResponseWebDto getDoctor(@RequestBody BasicInfoRequestWebDto basicInfoRequestWebDto) {
        if (!RequestNumberEnum.Doctor.getCode().equals(basicInfoRequestWebDto.getBasicInfoRequest().getRequestNumber()))
            throw new InvalidRequestException(RequestConstants.REQUEST_NUMBER);

        return basicInfoService.getDoctorBasicInfo(basicInfoRequestWebDto);
    }
}
