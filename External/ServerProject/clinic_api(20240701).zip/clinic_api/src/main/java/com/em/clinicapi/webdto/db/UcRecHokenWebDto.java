package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2022
/****************************************************************************/

/**
 * WebDto : UcRecHokenWebDto クラス<br>
 *
 * 自動生成クラス<br>
 *
 * 作成日 ： 2022/10/11<br>
 *
 * @author DAOGenerator4Smart
 */
//***************************************************************************
@Component
public class UcRecHokenWebDto extends CustomerWebDtoBase {

	/** プロパティ hokenId */
	private String hokenId = null;

	/** プロパティ riyoushaId */
	private String riyoushaId = null;

	/** プロパティ hokenshaNo */
	private String hokenshaNo = null;

	/** プロパティ hihokenshaNo */
	private String hihokenshaNo = null;

	/** プロパティ startDate */
	private java.sql.Date startDate = null;

	/** プロパティ endDate */
	private java.sql.Date endDate = null;

	/** プロパティ isDeleted */
	private boolean isDeleted;

	/** プロパティ isKyotakuRyouyou */
	private boolean isKyotakuRyouyou;

	/** プロパティ isHoumonKango */
	private boolean isHoumonKango;

	/** プロパティ isHoumonRiha */
	private boolean isHoumonRiha;

	/** プロパティ isTsuushoRiha */
	private boolean isTsuushoRiha;

	/**
	 * デフォルトのコンストラクタ
	 */
	public UcRecHokenWebDto() {
		super();
	}

	/**
	 * プロパティー：hokenId を返します。
	 *
	 * @return hokenId
	 */
	public String getHokenId() {
		return hokenId;
	}

	/**
	 * プロパティー：hokenId を設定します。
	 *
	 * @param hokenId hokenIdを設定。
	 */
	public void setHokenId(String hokenId) {
		this.hokenId = hokenId;
	}

	/**
	 * プロパティー：riyoushaId を返します。
	 *
	 * @return riyoushaId
	 */
	public String getRiyoushaId() {
		return riyoushaId;
	}

	/**
	 * プロパティー：riyoushaId を設定します。
	 *
	 * @param riyoushaId riyoushaIdを設定。
	 */
	public void setRiyoushaId(String riyoushaId) {
		this.riyoushaId = riyoushaId;
	}

	/**
	 * プロパティー：hokenshaNo を返します。
	 *
	 * @return hokenshaNo
	 */
	public String getHokenshaNo() {
		return hokenshaNo;
	}

	/**
	 * プロパティー：hokenshaNo を設定します。
	 *
	 * @param hokenshaNo hokenshaNoを設定。
	 */
	public void setHokenshaNo(String hokenshaNo) {
		this.hokenshaNo = hokenshaNo;
	}

	/**
	 * プロパティー：hihokenshaNo を返します。
	 *
	 * @return hihokenshaNo
	 */
	public String getHihokenshaNo() {
		return hihokenshaNo;
	}

	/**
	 * プロパティー：hihokenshaNo を設定します。
	 *
	 * @param hihokenshaNo hihokenshaNoを設定。
	 */
	public void setHihokenshaNo(String hihokenshaNo) {
		this.hihokenshaNo = hihokenshaNo;
	}

	/**
	 * プロパティー：startDate を返します。
	 *
	 * @return startDate
	 */
	public java.sql.Date getStartDate() {
		return startDate;
	}

	/**
	 * プロパティー：startDate を設定します。
	 *
	 * @param startDate startDateを設定。
	 */
	public void setStartDate(java.sql.Date startDate) {
		this.startDate = startDate;
	}

	/**
	 * プロパティー：endDate を返します。
	 *
	 * @return endDate
	 */
	public java.sql.Date getEndDate() {
		return endDate;
	}

	/**
	 * プロパティー：endDate を設定します。
	 *
	 * @param endDate endDateを設定。
	 */
	public void setEndDate(java.sql.Date endDate) {
		this.endDate = endDate;
	}

	/**
	 * プロパティー：isDeleted を返します。
	 *
	 * @return isDeleted
	 */
	public boolean getIsDeleted() {
		return isDeleted;
	}

	/**
	 * プロパティー：isDeleted を設定します。
	 *
	 * @param isDeleted isDeletedを設定。
	 */
	public void setIsDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	/**
	 * プロパティー：isKyotakuRyouyou を返します。
	 *
	 * @return isKyotakuRyouyou
	 */
	public boolean getIsKyotakuRyouyou() {
		return isKyotakuRyouyou;
	}

	/**
	 * プロパティー：isKyotakuRyouyou を設定します。
	 *
	 * @param isKyotakuRyouyou isKyotakuRyouyouを設定。
	 */
	public void setIsKyotakuRyouyou(boolean isKyotakuRyouyou) {
		this.isKyotakuRyouyou = isKyotakuRyouyou;
	}

	/**
	 * プロパティー：isHoumonKango を返します。
	 *
	 * @return isHoumonKango
	 */
	public boolean getIsHoumonKango() {
		return isHoumonKango;
	}

	/**
	 * プロパティー：isHoumonKango を設定します。
	 *
	 * @param isHoumonKango isHoumonKangoを設定。
	 */
	public void setIsHoumonKango(boolean isHoumonKango) {
		this.isHoumonKango = isHoumonKango;
	}

	/**
	 * プロパティー：isHoumonRiha を返します。
	 *
	 * @return isHoumonRiha
	 */
	public boolean getIsHoumonRiha() {
		return isHoumonRiha;
	}

	/**
	 * プロパティー：isHoumonRiha を設定します。
	 *
	 * @param isHoumonRiha isHoumonRihaを設定。
	 */
	public void setIsHoumonRiha(boolean isHoumonRiha) {
		this.isHoumonRiha = isHoumonRiha;
	}

	/**
	 * プロパティー：isTsuushoRiha を返します。
	 *
	 * @return isTsuushoRiha
	 */
	public boolean getIsTsuushoRiha() {
		return isTsuushoRiha;
	}

	/**
	 * プロパティー：isTsuushoRiha を設定します。
	 *
	 * @param isTsuushoRiha isTsuushoRihaを設定。
	 */
	public void setIsTsuushoRiha(boolean isTsuushoRiha) {
		this.isTsuushoRiha = isTsuushoRiha;
	}
}
