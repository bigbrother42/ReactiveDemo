package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;

public class JihiHasuuMWebDto extends CustomerWebDtoBase {

    /** プロパティ startDate */
    private java.sql.Date startDate = null;

    /** プロパティ endDate */
    private java.sql.Date endDate = null;

    /** プロパティ jihiItemHasuuKeisan */
    private int jihiItemHasuuKeisan = 0;

    /** プロパティ jihiHokenKarteHasuuKeisan */
    private int jihiHokenKarteHasuuKeisan = 0;

    /** プロパティ jihiPatientSeikyuuKingakuKeisan */
    private int jihiPatientSeikyuuKingakuKeisan = 0;

    /**
     * デフォルトのコンストラクタ
     */
    public JihiHasuuMWebDto() {
        super();
    }

    /**
     * プロパティー：startDate を返します。
     *
     * @return startDate
     */
    public java.sql.Date getStartDate() {
        return startDate;
    }

    /**
     * プロパティー：startDate を設定します。
     *
     * @param startDate startDateを設定。
     */
    public void setStartDate(java.sql.Date startDate) {
        this.startDate = startDate;
    }

    /**
     * プロパティー：endDate を返します。
     *
     * @return endDate
     */
    public java.sql.Date getEndDate() {
        return endDate;
    }

    /**
     * プロパティー：endDate を設定します。
     *
     * @param endDate endDateを設定。
     */
    public void setEndDate(java.sql.Date endDate) {
        this.endDate = endDate;
    }

    /**
     * プロパティー：jihiItemHasuuKeisan を返します。
     *
     * @return jihiItemHasuuKeisan
     */
    public int getJihiItemHasuuKeisan() {
        return jihiItemHasuuKeisan;
    }

    /**
     * プロパティー：jihiItemHasuuKeisan を設定します。
     *
     * @param jihiItemHasuuKeisan jihiItemHasuuKeisanを設定。
     */
    public void setJihiItemHasuuKeisan(int jihiItemHasuuKeisan) {
        this.jihiItemHasuuKeisan = jihiItemHasuuKeisan;
    }

    /**
     * プロパティー：jihiHokenKarteHasuuKeisan を返します。
     *
     * @return jihiHokenKarteHasuuKeisan
     */
    public int getJihiHokenKarteHasuuKeisan() {
        return jihiHokenKarteHasuuKeisan;
    }

    /**
     * プロパティー：jihiHokenKarteHasuuKeisan を設定します。
     *
     * @param jihiHokenKarteHasuuKeisan jihiHokenKarteHasuuKeisanを設定。
     */
    public void setJihiHokenKarteHasuuKeisan(int jihiHokenKarteHasuuKeisan) {
        this.jihiHokenKarteHasuuKeisan = jihiHokenKarteHasuuKeisan;
    }

    /**
     * プロパティー：jihiPatientSeikyuuKingakuKeisan を返します。
     *
     * @return jihiPatientSeikyuuKingakuKeisan
     */
    public int getJihiPatientSeikyuuKingakuKeisan() {
        return jihiPatientSeikyuuKingakuKeisan;
    }

    /**
     * プロパティー：jihiPatientSeikyuuKingakuKeisan を設定します。
     *
     * @param jihiPatientSeikyuuKingakuKeisan jihiPatientSeikyuuKingakuKeisanを設定。
     */
    public void setJihiPatientSeikyuuKingakuKeisan(int jihiPatientSeikyuuKingakuKeisan) {
        this.jihiPatientSeikyuuKingakuKeisan = jihiPatientSeikyuuKingakuKeisan;
    }
}
