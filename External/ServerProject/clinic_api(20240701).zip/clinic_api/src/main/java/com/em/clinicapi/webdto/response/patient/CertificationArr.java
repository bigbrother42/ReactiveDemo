package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;

import java.util.List;

public class CertificationArr extends ResponseWebDtoBase {

    @JsonProperty("Certification_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<Certification> certification;

    /**
     * Certificationを返事します。
     * @return Certificationの値
     */
    @JsonProperty("Certification_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public List<Certification> getCertification() {
        return certification;
    }

    /**
     * Certificationを設定します。
     * @param certification Certification
     */
    @JsonProperty("Certification_child")
    @JacksonXmlElementWrapper(useWrapping = false)
    @JsonInclude(JsonInclude.Include.NON_NULL)
    public void setCertification(List<Certification> certification) {
        this.certification = certification;
    }
}
