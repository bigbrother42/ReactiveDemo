package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : Insurance クラス <br/>
 * 項目： Insurance <br/>
 * 説明： <br/>
 *       介護保険情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class Insurance extends ResponseWebDtoBase {

	/**
	 * 項目： InsuranceProvider_Number <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String insuranceProviderNumber;
	/**
	 * 項目： HealthInsuredPerson_Number <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String healthInsuredPersonNumber;
	/**
	 * 項目： Certificate_StartDate <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateStartDate;
	/**
	 * 項目： Certificate_ExpiredDate <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String certificateExpiredDate;
	/**
	 * InsuranceProvider_Numberを返事します。
	 * @return InsuranceProvider_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInsuranceProviderNumber() {
		return insuranceProviderNumber;
	}

	/**
	 * InsuranceProvider_Numberを設定します。
	 * @param insuranceProviderNumber InsuranceProvider_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("InsuranceProvider_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInsuranceProviderNumber(String insuranceProviderNumber) {
		this.insuranceProviderNumber = insuranceProviderNumber;
	}

	/**
	 * HealthInsuredPerson_Numberを返事します。
	 * @return HealthInsuredPerson_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getHealthInsuredPersonNumber() {
		return healthInsuredPersonNumber;
	}

	/**
	 * HealthInsuredPerson_Numberを設定します。
	 * @param healthInsuredPersonNumber HealthInsuredPerson_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("HealthInsuredPerson_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setHealthInsuredPersonNumber(String healthInsuredPersonNumber) {
		this.healthInsuredPersonNumber = healthInsuredPersonNumber;
	}

	/**
	 * Certificate_StartDateを返事します。
	 * @return Certificate_StartDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateStartDate() {
		return certificateStartDate;
	}

	/**
	 * Certificate_StartDateを設定します。
	 * @param certificateStartDate Certificate_StartDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_StartDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateStartDate(String certificateStartDate) {
		this.certificateStartDate = certificateStartDate;
	}

	/**
	 * Certificate_ExpiredDateを返事します。
	 * @return Certificate_ExpiredDateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getCertificateExpiredDate() {
		return certificateExpiredDate;
	}

	/**
	 * Certificate_ExpiredDateを設定します。
	 * @param certificateExpiredDate Certificate_ExpiredDate
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Certificate_ExpiredDate")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setCertificateExpiredDate(String certificateExpiredDate) {
		this.certificateExpiredDate = certificateExpiredDate;
	}

}