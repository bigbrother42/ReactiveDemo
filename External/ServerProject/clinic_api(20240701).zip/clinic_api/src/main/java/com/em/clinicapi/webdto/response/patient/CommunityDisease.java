package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : CommunityDisease クラス <br/>
 * 項目： Community_Disease <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class CommunityDisease extends ResponseWebDtoBase {

	/**
	 * 項目： Target_Disease <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Target_Disease")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String targetDisease;
	/**
	 * Target_Diseaseを返事します。
	 * @return Target_Diseaseの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Target_Disease")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getTargetDisease() {
		return targetDisease;
	}

	/**
	 * Target_Diseaseを設定します。
	 * @param targetDisease Target_Disease
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Target_Disease")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setTargetDisease(String targetDisease) {
		this.targetDisease = targetDisease;
	}

}