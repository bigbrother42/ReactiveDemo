package com.em.clinicapi.webdto.response.iryoukikan;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : IryoukikanInfoResponse クラス <br/>
 * 項目： 医療機関情報レスポンス <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class IryoukikanInfoResponse extends ResponseWebDtoBase {

	/**
	 * 項目： Information_Date <br/>
	 * 説明： <br/>
	 *       レスポンスを返す時点の日付 <br/>
	 * 備考： <br/>
	 *       "2024-03-03" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Information_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String informationDate;
	/**
	 * 項目： Information_Time <br/>
	 * 説明： <br/>
	 *       レスポンスを返す時点の時刻 <br/>
	 * 備考： <br/>
	 *       "13:35:52" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Information_Time")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String informationTime;
	/**
	 * 項目： Api_Result <br/>
	 * 説明： <br/>
	 *       成功時は"00"を返す <br/>
	 *       それ以外は要検討 <br/>
	 * 備考： <br/>
	 *       ”00" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Api_Result")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String apiResult;
	/**
	 * 項目： Api_Result_Message <br/>
	 * 備考： <br/>
	 *       "処理終了" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Api_Result_Message")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String apiResultMessage;
	/**
	 * 項目： Reskey <br/>
	 * 備考： <br/>
	 *       ”PatientInfo” <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reskey")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String reskey;
	/**
	 * 項目： Base_Date <br/>
	 * 説明： <br/>
	 *       リクエスト側のBase_Dateを返却 <br/>
	 * 備考： <br/>
	 *       "2023-12-10" <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Base_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String baseDate;
	/**
	 * 項目： Medical_Information <br/>
	 * 説明： <br/>
	 *       医療機関情報 <br/>
	 */
	@Valid
		@JsonProperty("Medical_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private MedicalInformation medicalInformation;
	/**
	 * Information_Dateを返事します。
	 * @return Information_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Information_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInformationDate() {
		return informationDate;
	}

	/**
	 * Information_Dateを設定します。
	 * @param informationDate Information_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Information_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInformationDate(String informationDate) {
		this.informationDate = informationDate;
	}

	/**
	 * Information_Timeを返事します。
	 * @return Information_Timeの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Information_Time")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInformationTime() {
		return informationTime;
	}

	/**
	 * Information_Timeを設定します。
	 * @param informationTime Information_Time
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Information_Time")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInformationTime(String informationTime) {
		this.informationTime = informationTime;
	}

	/**
	 * Api_Resultを返事します。
	 * @return Api_Resultの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Api_Result")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getApiResult() {
		return apiResult;
	}

	/**
	 * Api_Resultを設定します。
	 * @param apiResult Api_Result
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Api_Result")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setApiResult(String apiResult) {
		this.apiResult = apiResult;
	}

	/**
	 * Api_Result_Messageを返事します。
	 * @return Api_Result_Messageの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Api_Result_Message")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getApiResultMessage() {
		return apiResultMessage;
	}

	/**
	 * Api_Result_Messageを設定します。
	 * @param apiResultMessage Api_Result_Message
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Api_Result_Message")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setApiResultMessage(String apiResultMessage) {
		this.apiResultMessage = apiResultMessage;
	}

	/**
	 * Reskeyを返事します。
	 * @return Reskeyの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reskey")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getReskey() {
		return reskey;
	}

	/**
	 * Reskeyを設定します。
	 * @param reskey Reskey
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Reskey")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setReskey(String reskey) {
		this.reskey = reskey;
	}

	/**
	 * Base_Dateを返事します。
	 * @return Base_Dateの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Base_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getBaseDate() {
		return baseDate;
	}

	/**
	 * Base_Dateを設定します。
	 * @param baseDate Base_Date
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("Base_Date")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setBaseDate(String baseDate) {
		this.baseDate = baseDate;
	}

	/**
	 * Medical_Informationを返事します。
	 * @return Medical_Informationの値
	 */
		@JsonProperty("Medical_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public MedicalInformation getMedicalInformation() {
		return medicalInformation;
	}

	/**
	 * Medical_Informationを設定します。
	 * @param medicalInformation Medical_Information
	 */
		@JsonProperty("Medical_Information")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setMedicalInformation(MedicalInformation medicalInformation) {
		this.medicalInformation = medicalInformation;
	}

}