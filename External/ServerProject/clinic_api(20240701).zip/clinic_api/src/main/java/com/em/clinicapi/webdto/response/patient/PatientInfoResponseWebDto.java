package com.em.clinicapi.webdto.response.patient;

import com.em.clinicapi.webdto.response.iryoukikan.IryoukikanInfoResponse;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@JacksonXmlRootElement(localName = "xmlio2")
public class PatientInfoResponseWebDto {

    @JsonProperty("patientinfores")
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private PatientInfoResponse patientInfoResponse;

    @JsonProperty("patientinfores")
    public PatientInfoResponse getPatientInfoResponse() {
        return patientInfoResponse;
    }

    @JsonProperty("patientinfores")
    public void setPatientInfoResponse(PatientInfoResponse patientInfoResponse) {
        this.patientInfoResponse = patientInfoResponse;
    }
}
