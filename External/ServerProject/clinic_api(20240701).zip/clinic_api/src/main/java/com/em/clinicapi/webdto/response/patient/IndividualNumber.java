package com.em.clinicapi.webdto.response.patient;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.em.clinicapi.webdto.response.base.XmlTypeStringAttributeSerialize;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : IndividualNumber クラス <br/>
 * 項目： Individual_Number <br/>
 * 説明： <br/>
 *       個人番号情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class IndividualNumber extends ResponseWebDtoBase {

	/**
	 * 項目： In_Id <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Id")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String inId;
	/**
	 * 項目： In_Number <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String inNumber;
	/**
	 * 項目： In_Description <br/>
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Description")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String inDescription;
	/**
	 * In_Idを返事します。
	 * @return In_Idの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Id")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInId() {
		return inId;
	}

	/**
	 * In_Idを設定します。
	 * @param inId In_Id
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Id")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInId(String inId) {
		this.inId = inId;
	}

	/**
	 * In_Numberを返事します。
	 * @return In_Numberの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInNumber() {
		return inNumber;
	}

	/**
	 * In_Numberを設定します。
	 * @param inNumber In_Number
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Number")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInNumber(String inNumber) {
		this.inNumber = inNumber;
	}

	/**
	 * In_Descriptionを返事します。
	 * @return In_Descriptionの値
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Description")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public String getInDescription() {
		return inDescription;
	}

	/**
	 * In_Descriptionを設定します。
	 * @param inDescription In_Description
	 */
		@JsonSerialize(using = XmlTypeStringAttributeSerialize.class)
		@JsonProperty("In_Description")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setInDescription(String inDescription) {
		this.inDescription = inDescription;
	}

}