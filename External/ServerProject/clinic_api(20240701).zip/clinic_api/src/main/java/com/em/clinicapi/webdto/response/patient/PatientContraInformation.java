package com.em.clinicapi.webdto.response.patient;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.em.clinicapi.webdto.response.base.ResponseWebDtoBase;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : PatientContraInformation クラス <br/>
 * 項目： Patient_Contra_Information <br/>
 * 説明： <br/>
 *       患者禁忌薬剤情報 <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
public class PatientContraInformation extends ResponseWebDtoBase {

	/**
	 * 項目： Patient_Contra_Info <br/>
	 * 説明： <br/>
	 *       患者禁忌薬剤情報 <br/>
	 */
		@JsonProperty("Patient_Contra_Info")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PatientContraInfoArr patientContraInfoArr;
	/**
	 * Patient_Contra_Infoを返事します。
	 * @return Patient_Contra_Infoの値
	 */
	@JsonProperty("Patient_Contra_Info")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public PatientContraInfoArr getPatientContraInfoArr() {
		return patientContraInfoArr;
	}

	/**
	 * Patient_Contra_Infoを設定します。
	 * @param patientContraInfoArr Patient_Contra_Info
	 */
	@JsonProperty("Patient_Contra_Info")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	public void setPatientContraInfoArr(PatientContraInfoArr patientContraInfoArr) {
		this.patientContraInfoArr = patientContraInfoArr;
	}

}