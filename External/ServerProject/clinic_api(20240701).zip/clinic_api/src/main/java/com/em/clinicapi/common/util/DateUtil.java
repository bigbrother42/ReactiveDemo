package com.em.clinicapi.common.util;

import com.em.clinicapi.common.constants.enumerations.DateFormatEnum;
import org.springframework.util.Assert;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.util.Calendar;
import java.util.Objects;

public class DateUtil {

    /**
     * 現在のサーバー日付を取得します。
     *
     * @return SQL日付データ型としてのサーバー日付
     */
    public static Date nowDate() {
        final LocalDate currentDate = LocalDate.now();
        return Date.valueOf(currentDate);
    }

    /**
     * 現在のサーバー日付を取得します。
     *
     * @return Javaローカルデータ型としてのサーバー日付
     */
    public static LocalDate nowLocalDate() {
        return LocalDate.now();
    }

    /**
     * 現在のサーバーの日付と時刻を取得します。
     *
     * @return SQL日時データ型としてのサーバー日付
     */
    public static Timestamp nowTimestamp() {
        final LocalDateTime currentDateTime = LocalDateTime.now();
        return Timestamp.valueOf(currentDateTime);
    }

    /**
     * 現在のサーバー日付を取得します。
     *
     * @return SQL日付データ型としてのサーバー日付
     */
    public static Date currentDate() {
        final LocalDate currentDate = LocalDate.now();
        return Date.valueOf(currentDate);
    }

    /**
     * 現在のサーバー日付を取得します。
     *
     * @return Javaローカルデータ型としてのサーバー日付
     */
    public static LocalDate currentLocalDate() {
        return LocalDate.now();
    }

    /**
     * 現在のサーバーの日付と時刻を取得します。
     *
     * @return SQL日時データ型としてのサーバー日付
     */
    public static Timestamp currentTimestamp() {
        final LocalDateTime currentDateTime = LocalDateTime.now();
        return Timestamp.valueOf(currentDateTime);
    }

    /**
     * MAPsシステム全体的な最大日付の値を取得します。
     *
     * @return SQL日付データ型として、9999年12月31日の値
     */
    public static Date MaxDate() {
        return makeDate(9999, 12, 31);
    }

    /**
     * MAPsシステム全体的な最小日付の値を取得します。
     *
     * @return SQL日付データ型として、1900年1月1日の値
     */
    public static Date MinDate() {
        return makeDate(1900, 1, 1);
    }

    /**
     * MAPsシステム全体的な最大日付の値を取得します。
     *
     * @return Javaローカルデータ型として、9999年12月31日の値
     */
    public static LocalDate MaxLocalDate() {
        return MaxDate().toLocalDate();
    }

    /**
     * MAPsシステム全体的な最小日付の値を取得します。
     *
     * @return Javaローカルデータ型として、1900年1月1日の値
     */
    public static LocalDate MinLocalDate() {
        return MinDate().toLocalDate();
    }

    /**
     * MAPsシステム全体的な最大日時の値を取得します。
     *
     * @return SQL日時データ型として、2099年12月31日23時59分59秒999ミリ秒の値
     */
    public static Timestamp MaxTimestamp() {
        return makeTimestamp(2099, 12, 31, 23, 59, 59, 999);
    }

    /**
     * MAPsシステム全体的な最小日時の値を取得します。
     *
     * @return SQL日時データ型として、1900年1月1日0時0分0秒0ミリ秒の値
     */
    public static Timestamp MinTimestamp() {
        return makeTimestamp(1900, 1, 1, 0, 0, 0, 0);
    }

    /**
     * 指定されていた日付の月初日付を取得します。
     *
     * @param date 値を参照するために使用される日付
     * @return SQL日時データ型として月初日付
     */
    public static Date firstdayOfMonth(Date date) {
        return chgDate(date, true);
    }

    /**
     * 指定されていた日付の月末日付を取得します。
     *
     * @param date 値を参照するために使用される日付
     * @return SQL日時データ型として月末日付
     */
    public static Date lastdayOfMonth(Date date) {
        return chgDate(date, false);
    }

    /**
     * 指定されていた日付に次月日付を取得します。
     *
     * @param date 値を参照するために使用される日付
     * @return SQL日時データ型として次月日付
     */
    public static Date addMonth(Date date) {
        return addMonth(date, 1);
    }

    /**
     * 指定されていた日付に任意月数を算出します。
     *
     * @param date  値を参照するために使用される日付
     * @param month 算出する月数
     * @return 月数を加算または減算した後の日付
     */
    public static Date addMonth(Date date, int month) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.MONTH, month);
        return new Date(cal.getTimeInMillis());
    }

    /**
     * 指定されていた日付に任意日数を算出します。
     *
     * @param date 値を参照するために使用される日付
     * @param days 算出する日数
     * @return 日数を加算または減算した後の日付
     */
    public static Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days);

        return new Date(cal.getTimeInMillis());
    }

    /**
     * 日付から文字列に転換
     *
     * @param date
     * @param pattern
     * @return
     */
    public static String stringFromDate(Date date, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(
                StringUtil.isNullOrEmpty(pattern) ? DateFormatEnum.FormatYYYYMMDD.getValue() : pattern);
        return format.format(date);
    }

    /**
     * 日付から文字列に転換
     *
     * @param localDate
     * @param pattern
     * @return
     */
    public static String stringFromLocalDate(LocalDate localDate, String pattern) {
        SimpleDateFormat format = new SimpleDateFormat(
                StringUtil.isNullOrEmpty(pattern) ? DateFormatEnum.FormatYYYYMMDD.getValue() : pattern);
        return format.format(localDate);
    }

    /**
     * 日付から文字列に転換
     *
     * @param timestamp
     * @param pattern
     * @return
     */
    public static String stringFromTimestamp(Timestamp timestamp, String pattern) {
        try {
            SimpleDateFormat format = new SimpleDateFormat(
                    StringUtil.isNullOrEmpty(pattern) ? DateFormatEnum.FormatYYYYMMDD.getValue()
                            : pattern);
            return format.format(timestamp);
        } catch (Exception ex) {
            LogUtil.getLogger(DateUtil.class).error(ex.getMessage(), ex);
            return timestamp.toString();
        }
    }

    /**
     * 日付から文字列に転換
     *
     * @param timestamp
     * @return
     */
    @Deprecated()
    public static String timestampToString(Timestamp timestamp) {
        DateFormat sdf = new SimpleDateFormat(DateFormatEnum.FormatYYYYMMDDHHmmss.getValue());
        try {
            return sdf.format(timestamp);
        } catch (Exception ex) {
            LogUtil.getLogger(DateUtil.class).error(ex.getMessage(), ex);
        }
        return timestamp.toString();
    }

    /**
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public static boolean isCurrentDateRange(Date startDate, Date endDate) {
        return isDateBetween(nowDate(), startDate, endDate, true, true, true, false);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @return
     */
    public static boolean isDateBetween(Date reference, Date startDate, Date endDate) {
        return isDateBetween(reference, startDate, endDate, true, true, true, false);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @return
     */
    public static boolean isDateBetween(Date reference, Date startDate, Date endDate, boolean isRangeClosed) {
        return isDateBetween(reference, startDate, endDate, isRangeClosed, true, true, true);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @param isCheckValidRange
     * @return
     */
    public static boolean isDateBetween(Date reference, Date startDate, Date endDate, boolean isRangeClosed,
                                        boolean isCheckValidRange) {
        return isDateBetween(reference, startDate, endDate, isRangeClosed, isCheckValidRange, true, true);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @param isCheckValidRange
     * @param isNullEndDateValid
     * @return
     */
    public static boolean isDateBetween(Date reference, Date startDate, Date endDate, boolean isRangeClosed,
                                        boolean isCheckValidRange, boolean isNullEndDateValid) {
        return isDateBetween(reference, startDate, endDate, isRangeClosed, isCheckValidRange, isNullEndDateValid, true);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @param isCheckValidRange
     * @param isNullEndDateValid
     * @return
     */
    public static boolean isDateBetween(Date reference, Date startDate, Date endDate, boolean isRangeClosed,
                                        boolean isCheckValidRange, boolean isNullEndDateValid, boolean isNullStartDateValid) {
        Assert.notNull(reference, "Reference date is not defined.");
        if (!isNullStartDateValid) {
            Assert.notNull(startDate, "Start date is not defined.");
        }
        if (!isNullEndDateValid) {
            Assert.notNull(endDate, "End date is not defined.");
        }

        boolean isStartDateValid = false;
        boolean isEndDateValid = false;
        boolean isValidRange = true;

        if (Objects.isNull(startDate) && isNullStartDateValid) {
            isStartDateValid = true;
            isValidRange = true;
        } else {
            isStartDateValid = (isRangeClosed && reference.equals(startDate)) || reference.after(startDate);
        }

        if (Objects.isNull(endDate) && isNullEndDateValid) {
            isEndDateValid = true;
            isValidRange = true;
        } else {
            isEndDateValid = (isRangeClosed && reference.equals(endDate)) || reference.before(endDate);
        }

        if (isCheckValidRange && Objects.nonNull(startDate) && Objects.nonNull(endDate)) {
            isValidRange = (isRangeClosed && startDate.equals(endDate)) || startDate.before(endDate);
        }

        return isStartDateValid && isEndDateValid && isValidRange;
    }

    public static boolean isCurrentTimestampRange(Timestamp startTimestamp, Timestamp endTimestamp) {
        return isTimestampBetween(currentTimestamp(), startTimestamp, endTimestamp, true, true, true, false);
    }

    public static boolean isTimestampBetween(Timestamp reference, Timestamp startTimestamp, Timestamp endTimestamp) {
        return isTimestampBetween(reference, startTimestamp, endTimestamp, true);
    }

    public static boolean isTimestampBetween(Timestamp reference, Timestamp startTimestamp, Timestamp endTimestamp,
                                             boolean isRangeClosed) {
        return isTimestampBetween(reference, startTimestamp, endTimestamp, isRangeClosed, true);
    }

    public static boolean isTimestampBetween(Timestamp reference, Timestamp startTimestamp, Timestamp endTimestamp,
                                             boolean isRangeClosed, boolean isCheckValidRange) {
        return isTimestampBetween(reference, startTimestamp, endTimestamp, isRangeClosed, isCheckValidRange, true);
    }

    public static boolean isTimestampBetween(Timestamp reference, Timestamp startTimestamp, Timestamp endTimestamp,
                                             boolean isRangeClosed, boolean isCheckValidRange, boolean isNullEndTimestampValid) {
        return isTimestampBetween(reference, startTimestamp, endTimestamp, isRangeClosed, isCheckValidRange,
                isNullEndTimestampValid, true);
    }

    public static boolean isTimestampBetween(Timestamp reference, Timestamp startTimestamp, Timestamp endTimestamp,
                                             boolean isRangeClosed, boolean isCheckValidRange, boolean isNullEndTimestampValid,
                                             boolean isNullStartTimestampValid) {
        Assert.notNull(reference, "Reference date is not defined.");
        if (!isNullStartTimestampValid) {
            Assert.notNull(startTimestamp, "Start timestamp is not defined.");
        }
        if (!isNullEndTimestampValid) {
            Assert.notNull(endTimestamp, "End timestamp is not defined.");
        }

        boolean isStartTimestampValid = false;
        boolean isEndTimestampValid = false;
        boolean isValidRange = true;

        if (Objects.isNull(startTimestamp) && isNullStartTimestampValid) {
            isStartTimestampValid = true;
            isValidRange = true;
        } else {
            isStartTimestampValid = (isRangeClosed && reference.equals(startTimestamp))
                    || reference.after(startTimestamp);
        }

        if (Objects.isNull(endTimestamp) && isNullEndTimestampValid) {
            isEndTimestampValid = true;
            isValidRange = true;
        } else {
            isEndTimestampValid = (isRangeClosed && reference.equals(endTimestamp)) || reference.before(endTimestamp);
        }

        if (isCheckValidRange && Objects.nonNull(startTimestamp) && Objects.nonNull(endTimestamp)) {
            isValidRange = (isRangeClosed && startTimestamp.equals(endTimestamp))
                    || startTimestamp.before(endTimestamp);
        }

        return isStartTimestampValid && isEndTimestampValid && isValidRange;
    }

    /**
     *
     * @param startDate
     * @param endDate
     * @return
     */
    public static boolean isCurrentLocalDateRange(LocalDate startDate, LocalDate endDate) {
        return isLocalDateBetween(LocalDate.now(), startDate, endDate, true, true, true, false);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @return
     */
    public static boolean isLocalDateBetween(LocalDate reference, LocalDate startDate, LocalDate endDate) {
        return isLocalDateBetween(reference, startDate, endDate, true, true, true, false);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @return
     */
    public static boolean isLocalDateBetween(LocalDate reference, LocalDate startDate, LocalDate endDate,
                                             boolean isRangeClosed) {
        return isLocalDateBetween(reference, startDate, endDate, isRangeClosed, true, true, true);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @param isCheckValidRange
     * @return
     */
    public static boolean isLocalDateBetween(LocalDate reference, LocalDate startDate, LocalDate endDate,
                                             boolean isRangeClosed, boolean isCheckValidRange) {
        return isLocalDateBetween(reference, startDate, endDate, isRangeClosed, isCheckValidRange, true, true);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @param isCheckValidRange
     * @param isNullEndDateValid
     * @return
     */
    public static boolean isLocalDateBetween(LocalDate reference, LocalDate startDate, LocalDate endDate,
                                             boolean isRangeClosed, boolean isCheckValidRange, boolean isNullEndDateValid) {
        return isLocalDateBetween(reference, startDate, endDate, isRangeClosed, isCheckValidRange, isNullEndDateValid,
                true);
    }

    /**
     *
     * @param reference
     * @param startDate
     * @param endDate
     * @param isRangeClosed
     * @param isCheckValidRange
     * @param isNullEndDateValid
     * @return
     */
    public static boolean isLocalDateBetween(LocalDate reference, LocalDate startDate, LocalDate endDate,
                                             boolean isRangeClosed, boolean isCheckValidRange, boolean isNullEndDateValid,
                                             boolean isNullStartDateValid) {
        Assert.notNull(reference, "Reference LocalDate is not defined.");
        if (!isNullStartDateValid) {
            Assert.notNull(startDate, "Start LocalDate is not defined.");
        }
        if (!isNullEndDateValid) {
            Assert.notNull(endDate, "End LocalDate is not defined.");
        }

        boolean isStartDateValid = false;
        boolean isEndDateValid = false;
        boolean isValidRange = true;

        if (Objects.isNull(startDate) && isNullStartDateValid) {
            isStartDateValid = true;
            isValidRange = true;
        } else {
            isStartDateValid = (isRangeClosed && reference.equals(startDate)) || reference.isAfter(startDate);
        }

        if (Objects.isNull(endDate) && isNullEndDateValid) {
            isEndDateValid = true;
            isValidRange = true;
        } else {
            isEndDateValid = (isRangeClosed && reference.equals(endDate)) || reference.isBefore(endDate);
        }

        if (isCheckValidRange && Objects.nonNull(startDate) && Objects.nonNull(endDate)) {
            isValidRange = (isRangeClosed && startDate.equals(endDate)) || startDate.isBefore(endDate);
        }

        return isStartDateValid && isEndDateValid && isValidRange;
    }

    public static Date makeDate(int year, int month, int date) {
        final LocalDate maxDate = LocalDate.of(year, month, date);
        return Date.valueOf(maxDate);
    }

    public static Timestamp makeTimestamp(int year, int month, int date, int hour, int minute, int second, int nano) {
        final LocalDateTime maxDateTime = LocalDateTime.of(LocalDate.of(year, month, date),
                LocalTime.of(hour, minute, second, nano));
        return Timestamp.valueOf(maxDateTime);
    }

    // Test if a YYYY-MM date string is valid
    public static boolean isValidYearMonth(String dateString) {
        try {
            YearMonth.parse(dateString);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * 月初/月末日付を取得する
     *
     * @param date
     * @param firstFlg
     * @return cal.getTime()
     */
    private static Date chgDate(Date date, boolean firstFlg) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        int lastDay = cal.getActualMaximum(Calendar.DATE);

        if (!firstFlg) {
            cal.set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), lastDay);
        }
        return new Date(cal.getTimeInMillis());
    }
}
