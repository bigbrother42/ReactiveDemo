package com.em.clinicapi.common.validator;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.FIELD,ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = {EMBigDecimalValidator.class}) //検証類を指定する
public @interface EMBigDecimal {
    String fieldName();
    String message() default "金額が不正";
    Class<?>[] groups() default  {};
    Class<? extends Payload>[] payload() default {};
}
