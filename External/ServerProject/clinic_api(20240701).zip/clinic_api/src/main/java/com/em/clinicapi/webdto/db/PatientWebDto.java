package com.em.clinicapi.webdto.db;

import com.em.clinicapi.webdto.base.CustomerWebDtoBase;
import org.springframework.stereotype.Component;

@Component
public class PatientWebDto extends CustomerWebDtoBase {

    /** プロパティ patientSeq */
    private int patientSeq = 0;

    /** プロパティ patientNo */
    private String patientNo = null;

    /** プロパティ karteNo */
    private String karteNo = null;

    /** プロパティ patientKanjiName */
    private String patientKanjiName = null;

    /** プロパティ patientKanaName */
    private String patientKanaName = null;

    /** プロパティ sexKbn */
    private String sexKbn = null;

    /** プロパティ prescriptionCheckSexKbn */
    private String prescriptionCheckSexKbn = null;

    /** プロパティ innaiSexKbn */
    private String innaiSexKbn = null;

    /** プロパティ birthDate */
    private java.sql.Date birthDate = null;

    /** プロパティ bloodTypeAboKbn */
    private String bloodTypeAboKbn = null;

    /** プロパティ bloodTypeRhKbn */
    private String bloodTypeRhKbn = null;

    /** プロパティ patientGroupSeq */
    private int patientGroupSeq = 0;

    /** プロパティ bunruiMarkNo */
    private String bunruiMarkNo = null;

    /** プロパティ shokugyouCode */
    private String shokugyouCode = null;

    /** プロパティ isTestPatient */
    private boolean isTestPatient;

    /** プロパティ isSearchTaishou */
    private boolean isSearchTaishou;

    /** プロパティ homeNo */
    private String homeNo = null;

    /** プロパティ contactInfoNo */
    private String contactInfoNo = null;

    /** プロパティ seishikiKanjiName */
    private String seishikiKanjiName = null;

    /** プロパティ seishikiKanaName */
    private String seishikiKanaName = null;

    /** プロパティ screenKanjiName */
    private String screenKanjiName = null;

    /** プロパティ screenKanaName */
    private String screenKanaName = null;

    /** プロパティ reportPrintShimeiKbn */
    private String reportPrintShimeiKbn = null;

    /** プロパティ sexBikou */
    private String sexBikou = null;

    /** プロパティ isEmployeeWaribiki */
    private boolean isEmployeeWaribiki;

    /** プロパティ waribikiRate */
    private java.math.BigDecimal waribikiRate = null;

    /** プロパティ wariaiReason */
    private String wariaiReason = null;

    /** プロパティ dataNijiRiyouKbn */
    private String dataNijiRiyouKbn = null;

    /**
     * デフォルトのコンストラクタ
     */
    public PatientWebDto() {
        super();
    }

    /**
     * プロパティー：patientSeq を返します。
     *
     * @return patientSeq
     */
    public int getPatientSeq() {
        return patientSeq;
    }

    /**
     * プロパティー：patientSeq を設定します。
     *
     * @param patientSeq patientSeqを設定。
     */
    public void setPatientSeq(int patientSeq) {
        this.patientSeq = patientSeq;
    }

    /**
     * プロパティー：patientNo を返します。
     *
     * @return patientNo
     */
    public String getPatientNo() {
        return patientNo;
    }

    /**
     * プロパティー：patientNo を設定します。
     *
     * @param patientNo patientNoを設定。
     */
    public void setPatientNo(String patientNo) {
        this.patientNo = patientNo;
    }

    /**
     * プロパティー：karteNo を返します。
     *
     * @return karteNo
     */
    public String getKarteNo() {
        return karteNo;
    }

    /**
     * プロパティー：karteNo を設定します。
     *
     * @param karteNo karteNoを設定。
     */
    public void setKarteNo(String karteNo) {
        this.karteNo = karteNo;
    }

    /**
     * プロパティー：patientKanjiName を返します。
     *
     * @return patientKanjiName
     */
    public String getPatientKanjiName() {
        return patientKanjiName;
    }

    /**
     * プロパティー：patientKanjiName を設定します。
     *
     * @param patientKanjiName patientKanjiNameを設定。
     */
    public void setPatientKanjiName(String patientKanjiName) {
        this.patientKanjiName = patientKanjiName;
    }

    /**
     * プロパティー：patientKanaName を返します。
     *
     * @return patientKanaName
     */
    public String getPatientKanaName() {
        return patientKanaName;
    }

    /**
     * プロパティー：patientKanaName を設定します。
     *
     * @param patientKanaName patientKanaNameを設定。
     */
    public void setPatientKanaName(String patientKanaName) {
        this.patientKanaName = patientKanaName;
    }

    /**
     * プロパティー：sexKbn を返します。
     *
     * @return sexKbn
     */
    public String getSexKbn() {
        return sexKbn;
    }

    /**
     * プロパティー：sexKbn を設定します。
     *
     * @param sexKbn sexKbnを設定。
     */
    public void setSexKbn(String sexKbn) {
        this.sexKbn = sexKbn;
    }

    /**
     * プロパティー：prescriptionCheckSexKbn を返します。
     *
     * @return prescriptionCheckSexKbn
     */
    public String getPrescriptionCheckSexKbn() {
        return prescriptionCheckSexKbn;
    }

    /**
     * プロパティー：prescriptionCheckSexKbn を設定します。
     *
     * @param prescriptionCheckSexKbn prescriptionCheckSexKbnを設定。
     */
    public void setPrescriptionCheckSexKbn(String prescriptionCheckSexKbn) {
        this.prescriptionCheckSexKbn = prescriptionCheckSexKbn;
    }

    /**
     * プロパティー：innaiSexKbn を返します。
     *
     * @return innaiSexKbn
     */
    public String getInnaiSexKbn() {
        return innaiSexKbn;
    }

    /**
     * プロパティー：innaiSexKbn を設定します。
     *
     * @param innaiSexKbn innaiSexKbnを設定。
     */
    public void setInnaiSexKbn(String innaiSexKbn) {
        this.innaiSexKbn = innaiSexKbn;
    }

    /**
     * プロパティー：birthDate を返します。
     *
     * @return birthDate
     */
    public java.sql.Date getBirthDate() {
        return birthDate;
    }

    /**
     * プロパティー：birthDate を設定します。
     *
     * @param birthDate birthDateを設定。
     */
    public void setBirthDate(java.sql.Date birthDate) {
        this.birthDate = birthDate;
    }

    /**
     * プロパティー：bloodTypeAboKbn を返します。
     *
     * @return bloodTypeAboKbn
     */
    public String getBloodTypeAboKbn() {
        return bloodTypeAboKbn;
    }

    /**
     * プロパティー：bloodTypeAboKbn を設定します。
     *
     * @param bloodTypeAboKbn bloodTypeAboKbnを設定。
     */
    public void setBloodTypeAboKbn(String bloodTypeAboKbn) {
        this.bloodTypeAboKbn = bloodTypeAboKbn;
    }

    /**
     * プロパティー：bloodTypeRhKbn を返します。
     *
     * @return bloodTypeRhKbn
     */
    public String getBloodTypeRhKbn() {
        return bloodTypeRhKbn;
    }

    /**
     * プロパティー：bloodTypeRhKbn を設定します。
     *
     * @param bloodTypeRhKbn bloodTypeRhKbnを設定。
     */
    public void setBloodTypeRhKbn(String bloodTypeRhKbn) {
        this.bloodTypeRhKbn = bloodTypeRhKbn;
    }

    /**
     * プロパティー：patientGroupSeq を返します。
     *
     * @return patientGroupSeq
     */
    public int getPatientGroupSeq() {
        return patientGroupSeq;
    }

    /**
     * プロパティー：patientGroupSeq を設定します。
     *
     * @param patientGroupSeq patientGroupSeqを設定。
     */
    public void setPatientGroupSeq(int patientGroupSeq) {
        this.patientGroupSeq = patientGroupSeq;
    }

    /**
     * プロパティー：bunruiMarkNo を返します。
     *
     * @return bunruiMarkNo
     */
    public String getBunruiMarkNo() {
        return bunruiMarkNo;
    }

    /**
     * プロパティー：bunruiMarkNo を設定します。
     *
     * @param bunruiMarkNo bunruiMarkNoを設定。
     */
    public void setBunruiMarkNo(String bunruiMarkNo) {
        this.bunruiMarkNo = bunruiMarkNo;
    }

    /**
     * プロパティー：shokugyouCode を返します。
     *
     * @return shokugyouCode
     */
    public String getShokugyouCode() {
        return shokugyouCode;
    }

    /**
     * プロパティー：shokugyouCode を設定します。
     *
     * @param shokugyouCode shokugyouCodeを設定。
     */
    public void setShokugyouCode(String shokugyouCode) {
        this.shokugyouCode = shokugyouCode;
    }

    /**
     * プロパティー：isTestPatient を返します。
     *
     * @return isTestPatient
     */
    public boolean getIsTestPatient() {
        return isTestPatient;
    }

    /**
     * プロパティー：isTestPatient を設定します。
     *
     * @param isTestPatient isTestPatientを設定。
     */
    public void setIsTestPatient(boolean isTestPatient) {
        this.isTestPatient = isTestPatient;
    }

    /**
     * プロパティー：isSearchTaishou を返します。
     *
     * @return isSearchTaishou
     */
    public boolean getIsSearchTaishou() {
        return isSearchTaishou;
    }

    /**
     * プロパティー：isSearchTaishou を設定します。
     *
     * @param isSearchTaishou isSearchTaishouを設定。
     */
    public void setIsSearchTaishou(boolean isSearchTaishou) {
        this.isSearchTaishou = isSearchTaishou;
    }

    /**
     * プロパティー：homeNo を返します。
     *
     * @return homeNo
     */
    public String getHomeNo() {
        return homeNo;
    }

    /**
     * プロパティー：homeNo を設定します。
     *
     * @param homeNo homeNoを設定。
     */
    public void setHomeNo(String homeNo) {
        this.homeNo = homeNo;
    }

    /**
     * プロパティー：contactInfoNo を返します。
     *
     * @return contactInfoNo
     */
    public String getContactInfoNo() {
        return contactInfoNo;
    }

    /**
     * プロパティー：contactInfoNo を設定します。
     *
     * @param contactInfoNo contactInfoNoを設定。
     */
    public void setContactInfoNo(String contactInfoNo) {
        this.contactInfoNo = contactInfoNo;
    }

    /**
     * プロパティー：seishikiKanjiName を返します。
     *
     * @return seishikiKanjiName
     */
    public String getSeishikiKanjiName() {
        return seishikiKanjiName;
    }

    /**
     * プロパティー：seishikiKanjiName を設定します。
     *
     * @param seishikiKanjiName seishikiKanjiNameを設定。
     */
    public void setSeishikiKanjiName(String seishikiKanjiName) {
        this.seishikiKanjiName = seishikiKanjiName;
    }

    /**
     * プロパティー：seishikiKanaName を返します。
     *
     * @return seishikiKanaName
     */
    public String getSeishikiKanaName() {
        return seishikiKanaName;
    }

    /**
     * プロパティー：seishikiKanaName を設定します。
     *
     * @param seishikiKanaName seishikiKanaNameを設定。
     */
    public void setSeishikiKanaName(String seishikiKanaName) {
        this.seishikiKanaName = seishikiKanaName;
    }

    /**
     * プロパティー：screenKanjiName を返します。
     *
     * @return screenKanjiName
     */
    public String getScreenKanjiName() {
        return screenKanjiName;
    }

    /**
     * プロパティー：screenKanjiName を設定します。
     *
     * @param screenKanjiName screenKanjiNameを設定。
     */
    public void setScreenKanjiName(String screenKanjiName) {
        this.screenKanjiName = screenKanjiName;
    }

    /**
     * プロパティー：screenKanaName を返します。
     *
     * @return screenKanaName
     */
    public String getScreenKanaName() {
        return screenKanaName;
    }

    /**
     * プロパティー：screenKanaName を設定します。
     *
     * @param screenKanaName screenKanaNameを設定。
     */
    public void setScreenKanaName(String screenKanaName) {
        this.screenKanaName = screenKanaName;
    }

    /**
     * プロパティー：reportPrintShimeiKbn を返します。
     *
     * @return reportPrintShimeiKbn
     */
    public String getReportPrintShimeiKbn() {
        return reportPrintShimeiKbn;
    }

    /**
     * プロパティー：reportPrintShimeiKbn を設定します。
     *
     * @param reportPrintShimeiKbn reportPrintShimeiKbnを設定。
     */
    public void setReportPrintShimeiKbn(String reportPrintShimeiKbn) {
        this.reportPrintShimeiKbn = reportPrintShimeiKbn;
    }

    /**
     * プロパティー：sexBikou を返します。
     *
     * @return sexBikou
     */
    public String getSexBikou() {
        return sexBikou;
    }

    /**
     * プロパティー：sexBikou を設定します。
     *
     * @param sexBikou sexBikouを設定。
     */
    public void setSexBikou(String sexBikou) {
        this.sexBikou = sexBikou;
    }

    /**
     * プロパティー：isEmployeeWaribiki を返します。
     *
     * @return isEmployeeWaribiki
     */
    public boolean getIsEmployeeWaribiki() {
        return isEmployeeWaribiki;
    }

    /**
     * プロパティー：isEmployeeWaribiki を設定します。
     *
     * @param isEmployeeWaribiki isEmployeeWaribikiを設定。
     */
    public void setIsEmployeeWaribiki(boolean isEmployeeWaribiki) {
        this.isEmployeeWaribiki = isEmployeeWaribiki;
    }

    /**
     * プロパティー：waribikiRate を返します。
     *
     * @return waribikiRate
     */
    public java.math.BigDecimal getWaribikiRate() {
        return waribikiRate;
    }

    /**
     * プロパティー：waribikiRate を設定します。
     *
     * @param waribikiRate waribikiRateを設定。
     */
    public void setWaribikiRate(java.math.BigDecimal waribikiRate) {
        this.waribikiRate = waribikiRate;
    }

    /**
     * プロパティー：wariaiReason を返します。
     *
     * @return wariaiReason
     */
    public String getWariaiReason() {
        return wariaiReason;
    }

    /**
     * プロパティー：wariaiReason を設定します。
     *
     * @param wariaiReason wariaiReasonを設定。
     */
    public void setWariaiReason(String wariaiReason) {
        this.wariaiReason = wariaiReason;
    }

    /**
     * プロパティー：dataNijiRiyouKbn を返します。
     *
     * @return dataNijiRiyouKbn
     */
    public String getDataNijiRiyouKbn() {
        return dataNijiRiyouKbn;
    }

    /**
     * プロパティー：dataNijiRiyouKbn を設定します。
     *
     * @param dataNijiRiyouKbn dataNijiRiyouKbnを設定。
     */
    public void setDataNijiRiyouKbn(String dataNijiRiyouKbn) {
        this.dataNijiRiyouKbn = dataNijiRiyouKbn;
    }
}
