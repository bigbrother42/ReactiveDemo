package com.em.clinicapi.webdto.response.iryoukikan;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

/****************************************************************************/
/*                      (C) EM Systems Ltd. 2024
/****************************************************************************/
/**
 * WebDto : IryoukikanInfoResponseWebDto クラス <br/>
 * 項目： 医療機関情報レスポンス <br/>
 * <br/>
 * 自動生成クラス <br/>
 *
 * @author WebDtoGenerator4Engine
 */
//***************************************************************************
@JacksonXmlRootElement(localName = "xmlio2")
public class IryoukikanInfoResponseWebDto {

	@Valid
	@JsonProperty("system1001res")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private IryoukikanInfoResponse iryoukikanInfoResponse;

	@JsonProperty("system1001res")
	public IryoukikanInfoResponse getIryoukikanInfoResponse() {
		return iryoukikanInfoResponse;
	}

	@JsonProperty("system1001res")
	public void setIryoukikanInfoResponse(IryoukikanInfoResponse iryoukikanInfoResponse) {
		this.iryoukikanInfoResponse = iryoukikanInfoResponse;
	}
}